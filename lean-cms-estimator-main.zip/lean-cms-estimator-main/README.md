# Lean CMS Estimator

Documents in, a populated estimate workbook out. An agent with file access (Cursor or Claude Code) reads the documents in a project folder, breaks them into requirements, volumes, skills and an AI plan, asks the estimator a few questions in chat, and writes the results and the workbook straight into the folder. No UI, no copy and paste of JSON.

This repository is a fork of `cms-estimator` (the "Blueprint" SharePoint web part, standalone app and skill pack). The files here were copied, not moved, and the original repository is unchanged.

- Source repository: `cms-estimator`
- Source commit: `054a90d` (main, "fix: address review findings on the agent value roadmap")
- Plan: "Lean agent-first estimator (fork)" (stages 1 to 6)

## What is here

| Path | What it is |
| --- | --- |
| `function/` | Document readers (docx, pptx, xlsx, pdf) that turn files into citation-bearing blocks. Compiled to `function/dist` for the tools. |
| `tools/blueprint/` | Parse, assemble, validate, drivers (volumes that must quote the documents), gap sweep, lever advice, question ranking, second opinion. |
| `tools/factors/`, `tools/catalog/`, `tools/*-catalog*` | Estimating factors and the capability catalogs (CMK, toolkit). |
| `tools/workbook/` | `build-template.mjs`, which generates `samples/workbook/Estimate_Template.xlsx`. The workbook itself is built by `tools/blueprint/build-workbook.mjs`. |
| `tools/eval/` | Back-test against the synthetic case. |
| `tools/release/` | Builds and checks the portable skill pack. |
| `.claude/skills/` | The ten skills carried over from `blueprint-*`. |
| `docs/catalogs/` | The estimating, CMK and toolkit catalogs. |
| `samples/` | Factors seed, eval cases, synthetic sources, sample agent run, `workbook/Estimate_Template.xlsx`. |

## Left behind on purpose

The SharePoint web part and standalone app (about 24k lines of UI and session code), Foundry extraction code, phase plan and skill schedule painting, the proposals review state machine, project list, hub folder, Pricer handoff, levers tab. The workbook writer `workbookTemplate.ts` is not copied: stage 5 wrote a new, smaller one (`build-workbook.mjs`) for the trimmed template.

## Set up

Needs Node 22.14 or later.

```
npm install
npm --prefix function install
npm --prefix function run build
npm run test:tools
```

## Status

Stage 1 (repo and carry-over) is done: `npm run test:tools` passes (846 of 847, one skipped), `npm run catalog:check` is ok, and the skill pack builds and checks.

Known carry-over rough edges, left for the later stages:
- The skills, docs and tool names still say "Blueprint", and some docs describe the web part and the standalone app. Stage 2 renames and trims them when the `estimate` skill arrives.
- `driver-quantity.mjs` is now the only copy of the quantity rule. Stage 3 replaces it with workstream volumes.
- Three tests that compared the tools with the web part or with the Foundry parse were rewritten or removed, since those do not exist here.

Stage 2 (contract and orchestrator skill) is done:
- `docs/spfx/plan-contract.md` defines `{Project}_Plan.json`, the one file the agent writes into the project folder.
- `tools/blueprint/plan.mjs` assembles it from the extract (adding only on a re-run), validates it (volumes must quote the parsed blocks), accepts requirements in bulk or by workstream, and prints the first checkpoint's summary.
- `.claude/skills/estimate/SKILL.md` runs the whole flow with four chat checkpoints. It stops after the plan and the client questions: the workbook step arrives in stages 3 to 5.
- The folder's `AGENTS.md` and the starter prompt now point at the `estimate` skill.

Stages 3 to 5 are built (see `docs/PLAN.md` for what is left in each): the workstream estimate (`plan.mjs estimate`), the AI plan (`plan.mjs ai-plan` and its opt-out commands), and the workbook (`tools/blueprint/build-workbook.mjs`, checked in desktop Excel).
