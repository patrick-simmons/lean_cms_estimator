# Human delivery skills

Blueprint’s staffing model uses **human delivery skills** — competencies people bring to a CMS engagement — not CMK capability ids and not Pricer role labels alone.

CMK / toolkit capabilities still drive **requirements coverage** and optional **hours-per-unit** acceleration on the Factors sheet. They do not become rows on the skill demand schedule.

## Why skills instead of role mix

Role-% by work package cannot express calendar reality (four weeks of discovery with a full-time PM, BA, and Architect) or specialty demand on an AEM rebuild with martech (AEM core, React/Next, Analytics, Target). Skills + phase packs can.

## Categories

| Category | Meaning | Examples |
| --- | --- | --- |
| `delivery` | Engagement seats / delivery crafts | `pm`, `ba`, `architect`, `qa`, `delivery-lead` |
| `platform` | CMS / front-end platform craft | `aem-core`, `frontend-react`, `dam`, `devops` |
| `martech` | Experience Cloud / AEP crafts (keep coarse) | `adobe-analytics`, `adobe-target`, `adobe-cja`, `adobe-ajo` |

## Starter catalog (seed)

Defined in `samples/factors/seed/skills.csv` and the workbook **Skills** sheet (SPMVP-018).

| Skill id | Name | Category |
| --- | --- | --- |
| `pm` | Project Manager | delivery |
| `ba` | Business Analyst | delivery |
| `architect` | Solution Architect | delivery |
| `qa` | QA Engineer | delivery |
| `delivery-lead` | Delivery Lead | delivery |
| `aem-core` | AEM (core) — Sites, models, fragments, authoring | platform |
| `frontend-react` | Front end (React / Next) | platform |
| `dam` | DAM / AEM Assets | platform |
| `devops` | Environments / DevOps | platform |
| `adobe-analytics` | Adobe Analytics | martech |
| `adobe-target` | Adobe Target | martech |
| `adobe-cja` | Customer Journey Analytics | martech |
| `adobe-ajo` | Adobe Journey Optimizer | martech |

Keep the catalog coarse: one skill covers several related tools/tasks. Prefer `aem-core` over splitting content modeling or component work into separate skills. Add martech rows only for distinct product crafts estimators staff separately (Analytics, Target, CJA, AJO) — not every AEP surface.

## Project skill set

After the requirements map (SPMVP-030):

1. Infer candidate skills from platform, integrations, and requirement text (using inference hints on the Skills sheet).
2. Estimator confirms, adds, or removes skills.
3. Empty skill set → challenger on schedule build; WP hour rollup may still run.

Example — AEM rebuild integrating martech / AEP:

- `aem-core`, `dam`, `frontend-react`, `adobe-analytics`, `adobe-target`
- add `adobe-cja` / `adobe-ajo` when the map names those products
- plus `pm`, `ba`, `architect`, `qa` as needed for phases

## Project skill set vs phases

- **Project skill set** (SPMVP-030) is the staffing unit for the engagement. Build estimate even-splits sized package hours across that set when present — there is **no** hub Skill mix table (project variance made catalog percents meaningless).
- **Phase packs** assign **FTE × duration** to skills for discovery, build window, hypercare, etc.
- Both feed **hours-by-skill**, transitional Staffing, and the painted **skill demand schedule** on Build (SPMVP-032). Publish rewrites **Phases** and **Skill schedule** alongside Estimate / Staffing.

## Later: Pricer

When SPMVP-013 is un-parked, a hub-owned **skill → Pricer role/level** map converts schedule rows for handoff. Until then, Blueprint stops at skills and hours — seniority lives on that later map, not on the Skills sheet.
