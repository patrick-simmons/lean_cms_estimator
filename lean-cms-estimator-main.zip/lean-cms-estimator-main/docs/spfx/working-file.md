# The working file

Blueprint keeps one JSON file per project in the project folder: `{Project}_Blueprint.json`. **Start** (SPMVP-004) creates it, extraction (SPMVP-008) writes the requirements into it, the review screen (SPMVP-009) saves review decisions, **Build estimate** (SPMVP-012) writes `estimate` and may append to `history`, and **Save handoff** (SPMVP-013) writes `handoff`. This page is the schema both sides follow.

The web part validates the file before it shows anything. A file that fails any rule below is treated as malformed: the project view shows "The working file in the project folder could not be read. It is not in the expected format." and writes nothing.

Pursuit framing and delivery risks/unknowns live in a separate sidecar, `{Project}_Context.json`. See [context-sidecar.md](context-sidecar.md). Blueprint JSON validation does **not** require the sidecar; the web part ignores it until SPMVP-025.

When an agent (the offline skill pack) runs again on a project that already has a Blueprint, it does not touch this file. It writes `{Project}_Proposals.json` beside it and keeps a run record in `.blueprint/run.json`; the Requirements step lists the proposals for accept or reject, and a decision is saved by `proposalSession.ts` (accept writes the rows, questions and any carried `sources[]` here and leaves `revision` alone). Both files are defined in [agent-contract.md](agent-contract.md).

## Root

| Field | Type | Rule |
| --- | --- | --- |
| `projectId` | string | The list item id. Not checked on read. |
| `projectName` | string | The project title at the time of the run. Not checked on read. |
| `revision` | integer | Required. Zero or more. The Requirements step chip reads `Requirements · rev N` when it is above zero. |
| `runId` | string | The run id Start wrote. Not checked on read. |
| `sources` | array | Required. Only its length is used by the review screen, in the step chip `✔ Sources N`. |
| `requirements` | array | Required. Each item follows the requirement table below. Ids must be unique. |
| `questions` | array | Required. Each item follows the question table below. |
| `platform` | object | Optional. See the platform table below. |
| `catalog` | object | Optional. See the catalog table below. Start writes `{}`. |
| `published` | object | Optional. Added only after a workbook upload and conditional JSON save succeed. See below. Legacy files omit it. |
| `notes`, `proposals` | any | Written by Start as empty arrays. Not checked on read, and kept as they are by review and estimate saves. |
| `handoff` | object or `null` | Optional. Start writes `null`. Absent or `null` means no service window yet. When present as an object it must follow the handoff table below, and `estimate` must also be present; handoff without estimate makes the file invalid. |
| `history` | array | Required shape when present: each entry follows the history table below. Start writes `[]`. Malformed entries make the file invalid. |
| `estimate` | object or `null` | Optional. `null` or absent is valid. When present as an object, it must follow the estimate table below; a malformed object makes the file invalid. |
| `skillSet` | array | Optional. Project skill set before/without an estimate (SPMVP-030). Same item shape as `estimate.skills`. Skill ids must be unique. Absent or `[]` is valid; Build estimate treats `[]` as an empty project skill set (not a template fallback). |
| `levers` | object | Optional. The AI levers this project uses (SPMVP-034): `{ "optIn": string[], "methods": string[] }`, ids from the estimating catalog (`optIn` = opt-in capability ids, `methods` = delivery method ids). Both arrays are required when the object is present; a malformed object makes the file invalid, and `null` is read as absent. Absent means the catalog defaults: default-on delivery methods enabled and no opt-in assets. `{ "optIn": [], "methods": [] }` is different: everything is switched off. Save levers on the AI levers tab writes it sorted, de-duplicated and limited to ids the catalog offers (unknown ids refuse the save), and marks an existing estimate `stale` unless it was built with exactly that selection. |
| `phasePlan` | array | Optional. Project phase plan before/without an estimate (SPMVP-031). Same item shape as `estimate.phases` except without `hours` and `taskHours` (Build computes hours into `estimate.phases`). A phase may carry `scope` and `tasks` (SPMVP-042), which are validated, kept on every read, copy and save, and passed to `estimate.phases` by Build. Phase ids must be unique. Hub Phase packs membership is enforced on save (not on parse). Absent or `[]` is valid; Build estimate uses `document.phasePlan` for phases and covers (including empty — no hub Phase packs fallback). Hub packs are templates only; apply via **Use starter templates** or add one phase at a time from the catalog on the Phases tab. |

Any other root field is kept as it is by review and estimate saves. Fields that later tickets add do not need a change here to survive a save.

## Estimate

Built by **Build estimate** (SPMVP-012). Quantities live here, not on requirements. Review saves leave `estimate` untouched.

Hybrid model: **phase pack hours** + **driver × factor** hours for build/migrate packages, attributed to **human delivery skills** (`hoursBySkill` + transitional Staffing + painted `schedule`). Build paints a **skill demand schedule** (week columns × skill FTE) from the ordered phase plan (pre-ramp allocations) plus an even WP-hour overlay on the `build` window (for packages no task binds) and the placed tasks. Empty stub only when no phase or task has weeks, or weekly hours are not positive. Role-mix staffing as the sizing engine is deprecated. See [delivery-skills.md](delivery-skills.md) and [delivery-defaults.md](delivery-defaults.md).

| Field | Type | Rule |
| --- | --- | --- |
| `totalHours` | number | Finite, zero or more. Sum of phase hours (which include `taskHours`) + sized package hours. A package a driver task sizes counts once, in its phase's `taskHours`, not again here. |
| `deliveryMix` | string | Chosen Blended rate mix name. Not empty. |
| `blendedRate` | number | Finite, zero or more. Hourly rate from that mix. |
| `price` | number | Finite, zero or more. Equals `totalHours × blendedRate` when built. |
| `mixCountry` | string | Country from the chosen mix. May be empty. |
| `monthlyHours` | number | Finite and greater than zero when written by Build estimate. Older estimates may omit it; the reader defaults to `0`. |
| `weeklyHours` | number | Finite and greater than zero when written by Build estimate. Derived as `monthlyHours / 4` for phase math. Older estimates may omit it. |
| `deliveryMixes` | string[] | Delivery mix names from the factors workbook at build time, for the Estimate step picker. |
| `skills` | array | Project skill set at build time. See skills table. May be `[]`; empty set should raise a challenger when a schedule is built. |
| `phases` | array | Phase rows used in this build (from `document.phasePlan`, often starter-derived). See phase table. May be `[]`. Built whenever the factors workbook has a skills model, including when no requirement is mapped (SPMVP-043). |
| `packages` | array | One row per work package considered for driver sizing. See package table. |
| `hoursBySkill` | array | Aggregated hours per skill. See hours-by-skill table. Primary skill totals for new builds. |
| `schedule` | object | Skill × time demand. See schedule table. Build paints `W1`…`Wn` to the largest phase or task end week (see **Phase timing** and **Task sizing**) when that span is positive and weekly hours are positive; otherwise `{ "bucket": "week", "columns": [], "rows": [] }`. No cell-level `scheduleOverrides` — edit `phasePlan` / quantities and Rebuild. |
| `staffing` | array | Required by the current schema. On new skill-based builds, transitional rows mirror `hoursBySkill` (skill display name as `role`, `level` `mid`, hours and sources) for the Packages Staffing table, publish Staffing sheet, and Pricer handoff. Older Role-mix estimates may have true role rows; readers may show them read-only. |
| `challengerNotes` | string[] | Challenger questions and notes. May be empty. Notes that start with `AI levers: ` (SPMVP-034, for example an unknown lever id or an unreadable catalog) or `Plan: ` (SPMVP-041, how phases were laid out: a loop in `afterPhaseId`, a link to a phase that is not in the plan, phases that start together, a start moved to week 1, a lag that was ignored or invalid; SPMVP-043, how tasks were sized and placed and how much of the estimate traces to requirements) are shown but do not block: they do not set Waiting to `Challenger` and do not show **Reviewed**. |
| `quantityOverrides` | object | Map of work package id → finite positive quantity the estimator typed. Keys are strings; values are numbers. May be `{}`. |
| `assumedOptIn` | boolean | Boolean. On a lever-aware build (SPMVP-034) `true` when at least one opt-in asset is enabled for the project. On a legacy build (no lever input) always `true`. |
| `assumedMethods` | boolean | Boolean. On a lever-aware build `true` when at least one delivery method is enabled. On a legacy build always `true`. Hours per unit use the **lowest** applicable Factors column (base, opt-in, methods); when neither enabled column is set, base hours. |
| `traditionalHours` | number | Optional. Finite, zero or more. Hours with no levers, `totalHours + savingsHours`. Written on every build since SPMVP-034; absent on older estimates. |
| `savingsHours` | number | Optional. Finite, zero or more. Sum over packages of `max(0, baseHours − hours)`. Written on every build since SPMVP-034; absent on older estimates. |
| `tracedHours` | number | Optional. Finite, zero or more. The sum of `packages[].hours`: the hours that come from mapped requirements, including a package a driver task sized. Written on every build since SPMVP-043; absent on older estimates. |
| `tracedShare` | number | Optional. 0 to 1 at three decimals. `tracedHours / totalHours`, `0` when `totalHours` is `0`. Written on every build since SPMVP-043; absent on older estimates. |
| `levers` | object | Optional. The `{ optIn, methods }` selection the build used (same shape as the root `levers`, with the defaults filled in). Written only when the catalog had lever data; absent otherwise and on older estimates. |
| `stale` | boolean | Set when a lever selection other than the one the estimate was built with is saved (SPMVP-034), and on any lever save for an estimate that has no `levers`. Cleared on a successful rebuild. While set, Publish and Save handoff are refused. |
| `challengerReviewed` | boolean | `true` after **Reviewed** clears Waiting. Notes stay on the file. A successful rebuild sets this back to `false`. |
| `builtAt` | string | ISO 8601 time of the last successful build. |
| `aiAllowance` | object or `null` | Legacy. The `AI allowance` seed sheet it came from was removed in story B-15, so a new estimate has `null`. An older file may still carry `{ label, monthlyAmount }`; nothing reads it. |

Root-level `skillSet` (SPMVP-030) exists outside `estimate` so the estimator can edit it before Build estimate; when present it must follow the estimate skills item shape with unique `skillId`s. Build estimate copies `document.skillSet` into `estimate.skills` (including when empty).

Root-level `phasePlan` (SPMVP-031 / SPMVP-033) is edited on the Estimate **Phases** tab the same way: outside `estimate`, then Build recomputes into `estimate.phases` (pre-ramp `Σ fte × durationWeeks × weeklyHours`; ramps are not applied to hours yet). **Apply-time allowlist (SPMVP-033):** **Use starter templates** and **Add phase from hub catalog** keep only allocations and ramps whose `skillId` is on the project `skillSet` (hub packs stay unfiltered templates). On that same apply path, the hub `build` phase also seats **every** project skill (pack FTEs kept where present; missing skills default to 1.0 FTE). Open/save do not re-expand Build — Remove sticks — but when the skill set later gains skills, those new ids are appended on Build in the draft (Save to persist). Allocation or ramp `skillId`s that are not on `skillSet` (for example hand-edited files) are warned in the UI only — save and Build still accept them. An empty plan yields empty `estimate.phases` and no phase cover union (challenger note when the skill model is active).

### Estimate skills (project skill set snapshot)

| Field | Type | Rule |
| --- | --- | --- |
| `skillId` | string | Id from the Skills sheet, for example `aem-core`. |
| `name` | string | Display name at build time. |
| `category` | string | `delivery`, `platform`, or `martech`. |
| `source` | string | `inferred`, `manual`, or `template`. |

### Estimate phase

| Field | Type | Rule |
| --- | --- | --- |
| `phaseId` | string | Template id, for example `discovery`. |
| `name` | string | Display name. |
| `durationWeeks` | number | Finite, zero or more. |
| `afterPhaseId` | string | Optional. Prior phase id. |
| `lagWeeks` | integer | Optional, absent means `0` (SPMVP-041). Whole weeks after the predecessor ends; negative starts the phase before the predecessor ends (overlap). A fraction, text, `null` or a value beyond 520 weeks either way makes the file invalid. See **Phase timing** below. |
| `scope` | string | Optional (SPMVP-042). Free text label such as `Option 1`; blank means unscoped. Any string is valid, including `""`. |
| `tasks` | array | Optional (SPMVP-042). Tasks and milestones of this phase; see **Phase task**. Absent or `[]` is valid. A bad item makes the file invalid. Build sizes the tasks (SPMVP-043; see **Task sizing** below) and keeps them on `estimate.phases`. |
| `taskHours` | number | Optional, `estimate.phases` only. Finite, zero or more. The hours the phase's tasks contribute, included in `hours` (`hours` = allocation hours + `taskHours`). Build sets it on a phase that has at least one task that is not a milestone (it can be `0`) and leaves it off every other phase. A plan phase that carries it is read and the key is dropped. |
| `coversWorkPackages` | string[] | WP ids that do not also add driver hours while this phase is active. May be `[]`. |
| `allocations` | array | `{ skillId, fte }` rows. `fte` finite and ≥ 0. |
| `ramps` | array | `{ skillId, afterMilestone, fte }` rows. May be `[]`. A ramp's `afterMilestone` is not checked against task ids yet. |
| `hours` | number | Finite, zero or more. At build, the phase's allocation hours `Σ (fte × durationWeeks × weeklyHours)` plus `taskHours` (SPMVP-043). Ramps are stored for display/edit but are not applied to hours yet (milestone-segmented math deferred). |

### Phase task

A task or milestone in `tasks` (SPMVP-042). The schema is checked when the file is read, on `phasePlan` and on `estimate.phases`; errors from the check name the field, for example `phasePlan[1].tasks[0].taskId: duplicate "design-signoff" (first at phasePlan[0].tasks[2])`.

| Field | Type | Rule |
| --- | --- | --- |
| `taskId` | string | Required, non-empty. Unique across the whole plan, tasks and milestones alike. |
| `name` | string | Required, non-empty. |
| `kind` | string | Optional. `task` (default) or `milestone`. |
| `startWeek` | integer | Optional, default `1`. 1 to 520. Week within the phase, where `1` is the phase's first week. |
| `durationWeeks` | number | Optional. Finite, 0 to 520. Not used for a milestone, which occupies only its `startWeek`. The cap keeps a hand-edited file from asking the schedule for billions of week columns. |
| `basis` | string | `driver`, `capacity` or `fixed`. Required for a task. Must be absent on a milestone. |
| `workPackageId` | string | Required, non-empty, when `basis` is `driver`. Two driver tasks may not name the same package. A milestone or another basis may carry one if it is non-empty text. |
| `ownerSkillIds` | string[] | Optional. Non-empty strings. |
| `allocations` | array | `{ skillId, fte }` rows. At least one row is required when `basis` is `capacity`. Optional on `driver` and `fixed`. Not allowed on a milestone. `fte` finite and ≥ 0. |
| `hours` | number | Required when `basis` is `fixed`. Finite, zero or more. Not allowed on a milestone. |
| `deliverable` | string | Optional. For a milestone, the gate label. |
| `scope` | string | Optional. Overrides the phase `scope` for this task. |
| `calendarBound` | boolean | Optional. `true` when the duration does not shrink with more people. |

How Build sizes and paints a task (SPMVP-043) is under **Task sizing** below. The phase plan in [phase-plan-v2.md](phase-plan-v2.md) describes the rest; ramps and the task display arrive in later tickets.

### Estimate package

| Field | Type | Rule |
| --- | --- | --- |
| `workPackageId` | string | Catalog id such as `content-migration`. |
| `name` | string | Display name from factors. |
| `unit` | string | Driver unit from factors. |
| `quantity` | number | Finite, zero or more. Zero when unsized. |
| `hoursPerUnit` | number | Finite, zero or more. The effective hours per unit: the lever-adjusted rate, blended by requirement coverage when the build had lever data (see `coverageShares`). |
| `baseHoursPerUnit` | number | Optional. Finite, zero or more. Factors base hours per unit before levers. Written on every build since SPMVP-034. |
| `baseHours` | number | Optional. Finite, zero or more. `quantity × baseHoursPerUnit` (zero when unsized or phase-covered). |
| `accelerationPct` | number | Optional. From 0 to 100, one decimal. Percent of `baseHours` the levers and requirement coverage remove. `0` when no lever applies, and when the package is unsized or phase-covered. |
| `appliedLevers` | string[] | Optional. Written only when the build had lever data. Ids behind the winning (lowest) hours column, and both columns' ids when they tie. `[]` when no lever lowered the hours, including when no accelerated or partly share is left. |
| `coverageShares` | object | Optional. Written when the build had catalog lever data, including for unsized and phase-covered packages, and absent on legacy builds. `accelerated`, `partly`, `humanLed` and `unresolved`, each from 0 to 1 and rounded to three decimals; they sum to 1 within 0.0025. The share of the package's requirements at each effective coverage: a requirement's coverage raised to the catalog coverage of an enabled lever, never lowered; `question` and `conflict` rows are `unresolved`. Rows are weighted by extracted quantity, or by row count when none carries a quantity; a row with no quantity gets no weight when others have one, and an informational note names it. A quantity override uses the same shares. Accelerated rows use the levered rate, `partly` rows the midpoint of base and levered, the rest base hours. |
| `hours` | number | Finite, zero or more. Zero when unsized or when skipped because a covering phase is active. Kept at the package's figure when a driver task sizes the package (SPMVP-043); those same hours are also in that phase's `taskHours`. So `packages[].hours` plus `phases[].hours` counts such a package twice: a reader that needs a total uses `totalHours`, and `tracedHours` for the hours that trace to requirements. No field on the package says which task bound it. |
| `confidence` | string | Factor confidence, for example `low`. On a build with lever data, lowered to `low` for a sized package when any of its accepted or edited requirements is flagged `question` or `conflict`, even when that row has no quantity and adds no hours. That note needs a reviewer, so it sends the project to Waiting Challenger; the mixed-coverage and other coverage notes carry the `AI levers: ` prefix and do not. |
| `sized` | boolean | `false` when there is no extractable or overridden quantity. |
| `phaseCovered` | boolean | `true` when a active phase lists this WP in `coversWorkPackages` and driver hours were not added. Optional on legacy rows; default `false`. |
| `skillSplit` | array | Optional. `{ skillId, percent, hours }` for sized build packages. Percents should sum to 100 when present. An even split across the project skill set, or across the owner skills of the driver task that sizes the package (SPMVP-043). |

### Estimate hours by skill

| Field | Type | Rule |
| --- | --- | --- |
| `skillId` | string | Skill id. |
| `hours` | number | Finite, zero or more. Phase, task and work package contributions. |
| `peakFte` | number | Finite, zero or more. Max FTE in any schedule bucket for this skill. Optional; default `0` when omitted. Build sets this from the painted schedule row maximum. |
| `sources` | string[] | Labels such as phase names, task names (a driver task shows the package name) and work package names that contributed. May be `[]`. |

### Estimate schedule

| Field | Type | Rule |
| --- | --- | --- |
| `bucket` | string | `week` or `month`. Starter builds use `week`. |
| `columns` | string[] | Bucket labels in order, for example `W1` … `Wn`. Empty when the phase plan has no duration. |
| `rows` | array | One per skill with phase allocations and/or WP skill hours. Each: `skillId` (string), `values` (number[] same length as `columns`, FTE), `unit` (`fte`). |

**Phase timing (SPMVP-041):** Weeks are numbered from 1. A phase occupies weeks `s` to `e`, with `e = s + weeks − 1` and `weeks` the rounded whole weeks below. Painting, the phase legend and per-skill hours all use the same windows.

- A phase with a predecessor in the plan starts at `e(predecessor) + 1 + lagWeeks`. A start below week 1 moves to week 1.
- A phase with no predecessor (none named, or the named id is not in the plan) starts at `1 + lagWeeks`; a negative lag there counts as `0`. Several such phases all start in week 1 (each plus its own lag). Before SPMVP-041 they were placed one after another, so a saved plan with more than one of them changes on its next Build.
- Phases that name the same `afterPhaseId` start together (overlap), each with its own lag. Before SPMVP-041 they were placed one after another, so a saved plan with siblings changes on its next Build.
- Phases in a loop of `afterPhaseId` (including a phase that names itself) have no predecessor. A phase that follows a loop member starts from that member's end.
- A phase with 0 weeks holds its position, so the next phase starts where it does for a linear plan, but it has no window and is never listed as a phase in a note. A note about phases that follow it names the nearest earlier phase that has weeks instead.
- `Plan: ` notes (not blocking) name loops, phases that follow a phase that is not in the plan, two or more phases with no predecessor, parallel phases, a start moved to week 1, a negative lag on a phase with no predecessor, and a lag that is not a whole number within 520 (counted as `0`). A plan that is a single chain with no loop adds none.
- Phase ids on `estimate.phases` must be unique; a file with a repeated id is invalid. Laying out a plan with repeated ids always finishes but promises nothing about where those phases sit.
- Schedule columns run to the largest end week, so a root phase with a positive lag leaves leading weeks empty. The skill schedule view shows its phase header row only when phases run back to back; otherwise the legend shows week ranges such as `Design (W1-W4)`.
- A web part that predates SPMVP-041 drops `lagWeeks` when it round-trips a phase, and it places phases one after another when it builds. Upgrade the web part before using lag, parallel phases or several phases with no predecessor on a project that is open in the pilot.
- In the same way, a web part that predates SPMVP-042 drops phase `scope` and `tasks` when it saves a phase plan. Upgrade it before adding tasks to a project that is open in the pilot.

**Task sizing (SPMVP-043):** A task's window starts at `phaseStart + startWeek − 1` and runs `durationWeeks` rounded to whole weeks (an absent duration is 0 weeks), so it can run past its phase. Hours by basis:

- `capacity`: Σ `fte × weeks × weeklyHours` over the task's `allocations`.
- `fixed`: `hours`, split evenly across `ownerSkillIds`.
- `driver`: the hours of the package in `workPackageId` (quantity × hours per unit, with levers and coverage as for any package), split evenly across `ownerSkillIds`. Applies only when the task binds: the package is mapped, sized, has hours, no phase covers it, no earlier task took it, and the window has weeks. A bound package is no longer split across the project skill set or overlaid on `build`; its hours count in the phase's `taskHours` and not again in `totalHours` (its `packages[].hours` keeps the figure). A package no task binds is sized as before.
- Empty `ownerSkillIds` fall back to the project skill set, spread over the task's own window; this applies to `fixed` and `driver` tasks (a `capacity` task takes its skills from `allocations`). If the project has no skill set either, a `fixed` task's hours are not attributed to skills, and a `driver` task leaves its package to normal sizing. Owner skills that are not on the project skill set are painted too.
- A task the engine cannot use contributes 0 and says so: no or unknown `basis`, a driver task with no `workPackageId`, a `fixed` task with no usable `hours` (an explicit `0` is quiet), a `capacity` task with no allocation row that has a skill and a positive finite `fte`, and a driver task on a package with no hours. A validated plan never has the first four; the notes cover a plan that skipped validation.

The painter spreads each skill's task hours evenly over the task windows and rounds the row cumulatively, so a skill still reconciles within 1 hour however many tasks overlap. Task FTE adds to phase FTE in shared weeks, and the schedule runs to the end of the last task.

`Plan: ` notes (not blocking) cover: a driver task on a package a phase covers (it contributes 0), on a package no requirement maps (0), on a package with no hours (0), or on a package an earlier task already sizes (0); a task with a window of 0 weeks (a capacity or fixed task places nothing; a driver task leaves its package to normal sizing, so no hours are lost); empty owner skills; a task that runs past the end of its phase; a task the engine cannot use (above); and a driver task with `allocations` whose planned capacity differs from the driver hours by more than 20%. That note gives both numbers, the driver hours are used, and nothing is changed; a `calendarBound` task adds that the window is fixed by the calendar. A driver task on a package with no quantity contributes 0 and keeps the package's own "what quantity" question.

Build also produces `phases`, plan hours and the schedule when no requirement is mapped, provided the plan has phases. `Plan: N% of hours trace to mapped requirements.` is added when the phases carry hours, with `N` the rounded `tracedShare`.

**Paint rules (SPMVP-032):** Pre-ramp only — each phase week uses `allocations[].fte` for the full window; stored `ramps` are ignored for cells (milestone-segmented paint deferred). Overlapping phases add their FTE in shared weeks. Schedule columns and phase-hour rollup both use **rounded whole weeks** (`Math.round(durationWeeks)`; values that round to 0 contribute no weeks). WP skill hours of a package no task binds overlay evenly across the positive-duration `build` window only; task hours (SPMVP-043) are painted over the task windows (see **Task sizing**). If skill hours (work package, task, or the plan's own allocation and capacity hours) exist and cannot be placed, Build appends a blocking challenger note (no positive-duration build window for work package hours, no week span, or weekly hours not positive) and does not spread those hours. With a positive-duration `build` window and positive weekly hours, `|hoursBySkill.hours − Σ(schedule FTE × weeklyHours)| ≤ 1` per skill; a large unbound package on a long `build` window can exceed that through the per-cell rounding of the overlay (existing behavior).

Empty stub `{ "bucket": "week", "columns": [], "rows": [] }` remains valid on publish when the ordered span is 0 or weekly hours are not positive.

### Estimate staffing (transitional + legacy)

Required array. **New skill-based builds** write transitional rows from `hoursBySkill` (skill display name as `role`, `level` `mid`) so the Packages Staffing table, publish **Staffing** sheet, and Pricer handoff keep working. Week × skill demand is on the Estimate **Skill schedule** tab and publish **Skill schedule** sheet. **Older Role-mix estimates** may still have true role rows from the deprecated Role mix path.

| Field | Type | Rule |
| --- | --- | --- |
| `role` | string | Skill display name (transitional) or Blueprint role name (legacy Role mix). |
| `level` | string | Seniority (`jr`, `mid`, `sr`, `expert`). Transitional skill builds use `mid`. |
| `hours` | number | Finite, zero or more. |
| `packages` | string[] | Phase / work package labels that contributed (from `hoursBySkill.sources` on transitional rows). May be `[]`. |

## Handoff

Saved on the **Pricer** step (SPMVP-013). `null` or absent means no service window yet. A malformed object makes the working file invalid. Review saves and **Reviewed** preserve `handoff` via the root object. **Build estimate** / **Rebuild** clear `handoff` to `null` so a new staffing mix cannot keep a stale service window.

| Field | Type | Rule |
| --- | --- | --- |
| `serviceStart` | string | Calendar month `YYYY-MM`. |
| `durationMonths` | integer | Whole number greater than zero. |
| `savedAt` | string | ISO 8601 time of the last successful Save handoff. |

## History

Append-only log. A rebuild that replaces an existing estimate pushes one entry with the prior totals before the new estimate is saved.

| Field | Type | Rule |
| --- | --- | --- |
| `at` | string | ISO 8601 time. |
| `kind` | string | The literal `estimate` for a superseded high-level estimate. |
| `totalHours` | number | Prior total hours. |
| `price` | number | Prior price. |
| `deliveryMix` | string | Prior mix name. |

## Published workbook

`published` records the exact SharePoint file version associated with the root `revision`.

| Field | Required | Meaning |
| --- | --- | --- |
| `publishedAt` | Yes | ISO publish time. |
| `publishedBy` | Yes | Publisher email. |
| `publishedByName` | No | Publisher display name. |
| `fileId`, `fileName` | Yes | SharePoint workbook identity and stable output name. |
| `webUrl`, `versionHistoryUrl` | Yes | Open-workbook and SharePoint version-history links. |
| `fileEtag` | Yes | Output ETag used to detect edits before a later publish. |
| `modified` | Yes | SharePoint modified time returned after upload. |
| `modifiedBy`, `versionLabel` | No | SharePoint editor and version label when available. |

The record is validated as one unit. A malformed partial object makes the working file invalid; an absent object remains valid for pre-publish and legacy files.

## Requirement

| Field | Type | Rule |
| --- | --- | --- |
| `id` | string | `R-` followed by at least three digits, for example `R-012`. Unique in the file. |
| `statement` | string | Not empty after trimming. |
| `sources` | array | At least one source. See the source table below. |
| `workPackage` | string | A work package id from the estimating catalog, such as `content-migration`, or `unmapped`. Not empty. The reader does not check it against the catalog; the edit form does. |
| `capabilities` | string[] | Capability ids. May be empty. The review screen shows them as chips and never changes them. |
| `coverage` | string | One of `accelerated`, `partly`, `human-led`, `question`, `conflict`. |
| `questionId` | string | Optional. The id of a linked question. |
| `review` | object | Required. See the review table below. |
| `original` | object | Optional. The extracted values before the first edit. See below. |

### Source

| Field | Type | Rule |
| --- | --- | --- |
| `itemId` | string | The source file's unique id, as in `sources[].itemId`. |
| `fileName` | string | The file name shown in the citation line. |
| `blockId` | string | The parsed block the passage came from. |
| `label` | string | The short citation label shown in the table, for example `RFP p.38 §3.6.1`. A row with several sources shows their labels joined with ` vs `; conflict rows have two. |
| `location` | object | A source location from parsing: `page`, `section`, `slide` or `sheet`, with the same fields as parsed blocks. |
| `passage` | string | The passage text. May be empty. |

The detail panel shows each source as a citation line, `fileName · page N · §x`, `fileName · slide N (notes)` or `fileName · Sheet · rows a–b`, followed by the passage. Page ranges read `pages N–M`, approximate pages carry `~`, and a single sheet row reads `row N`. The block heading, or the slide title, is shown above the passage when present. When the statement appears in the passage, ignoring case and runs of whitespace, that span is marked. A paraphrase shows with no mark.

### Review

| Field | Type | Rule |
| --- | --- | --- |
| `status` | string | One of `pending`, `accepted`, `edited`, `dismissed`. |
| `by` | string | The reviewer's email. Required for every status other than `pending`. |
| `byName` | string | The reviewer's display name. Optional. |
| `at` | string | An ISO 8601 time. Required for every status other than `pending`. |

Extraction writes `{ "status": "pending" }`. The review screen writes the other three with all four fields.

### Original

Written on a row's first edit, and never changed after that. The review screen does not recompute `capabilities` when a row is edited.

| Field | Type | Rule |
| --- | --- | --- |
| `statement` | string | Not empty. |
| `workPackage` | string | Any string. |
| `coverage` | string | A valid coverage. |

## Question

| Field | Type | Rule |
| --- | --- | --- |
| `id` | string | For example `Q6`. |
| `requirementId` | string | The linked requirement. |
| `text` | string | The draft question. |

A question linked to a dismissed row is left out of the Questions count.

## Platform

| Field | Type | Rule |
| --- | --- | --- |
| `id` | string | Required when `platform` is present. |
| `name` | string | Required when `platform` is present. Shown in the summary bar, or "Unknown" when there is no platform. |
| `citation` | string | Optional. |

## Catalog

| Field | Type | Rule |
| --- | --- | --- |
| `cmkCommit` | string | Optional. The CMK commit the run used. |
| `toolkitCommit` | string | Optional. The toolkit commit the run used. |
| `estimatingVersion` | string | Optional. The estimating catalog version the run used. |

Only string values are read. A file written by Start before this schema, with `catalog: { "cmk": null, "estimating": null }`, is valid and reads as an empty catalog. The review screen shows `CMK {short commit} · toolkit {short commit} · catalog v{version}`, taking each part from the file and falling back to the estimating catalog's front matter when the file has none. The label adds the `v` itself, so `estimatingVersion` and the front matter `version` are written without it. The label is hidden when neither source has anything.

## Example row

```json
{
  "id": "R-012",
  "statement": "Migrate 18,240 pages with redirects",
  "sources": [
    {
      "itemId": "src-rfp",
      "fileName": "Northwind_RFP_2026.pdf",
      "blockId": "src-rfp#p38.3-6-1",
      "label": "RFP p.38 §3.6.1",
      "location": { "kind": "page", "page": 38, "section": "3.6.1", "heading": "3.6 Content migration" },
      "passage": "3.6.1 The selected vendor shall migrate all in-scope content, approximately 18,240 pages, and implement 301 redirects so that no organic search ranking is lost."
    }
  ],
  "workPackage": "content-migration",
  "capabilities": ["cmk-migration-assess", "cmk-migration-script", "cmk-seo-architect"],
  "coverage": "accelerated",
  "questionId": "Q6",
  "review": { "status": "pending" }
}
```

After an edit the same row carries `original` and a stamp:

```json
{
  "statement": "Migrate about 18,000 pages with 301 redirects",
  "original": { "statement": "Migrate 18,240 pages with redirects", "workPackage": "content-migration", "coverage": "accelerated" },
  "review": { "status": "edited", "by": "ada@contoso.com", "byName": "Ada Lovelace", "at": "2026-10-19T14:05:00Z" }
}
```

## Finding the file

The reader lists the folder and looks for `{Project}_Blueprint.json`, ignoring case. If the project was renamed and no file has that name, it takes the single file in the folder that ends in `_Blueprint.json`. With none or several, the file is treated as not found, and the project view shows the Extracting or "already started" message.

## Save policy

- **Start overwrites.** Start writes the whole file with `overwrite=true` and no ETag check. That was decided on 2026-10-19 and this page does not change it.
- **Review saves are ETag-checked.** The reader keeps the file's ETag from the folder listing, or reads it from the file when the listing has none; a file whose ETag cannot be read is reported as unreadable. A save re-reads the ETag first and stops without writing if it changed, or if it cannot be read. It then writes the file with `X-HTTP-Method: PUT` and `If-Match: {etag}`, and treats a 412 as a conflict. The ETag is sent back exactly as received. After a successful save the new ETag comes from the PUT response's `ETag` header, or is re-read when the header is missing; if neither is available the file is reloaded, and if that also fails the screen says "The change was saved, but the file could not be reloaded. Go back and open the project again." 
- **A review save replaces only `requirements`.** The reader keeps the parsed root object. A save writes that object back with the `requirements` array swapped, in the same two-space format Start uses. Every other field, including ones this schema does not name, is preserved.
- **An estimate save is ETag-checked the same way as a review save.** It replaces `estimate` and may append to `history`. A rebuild also sets `handoff` to `null`. Quantities are stored on `estimate.quantityOverrides` and `estimate.packages`, never on requirements.
- **A skill-set save is ETag-checked the same way.** It replaces root `skillSet` only. Skill ids must be unique and must exist on the Factors Skills sheet; save fails before write otherwise. Sample projects disable save in the UI.
- **A phase-plan save is ETag-checked the same way.** It replaces root `phasePlan` only. Phase ids must be unique and must exist on the Factors Phase packs sheet; save fails before write otherwise. Phase `scope` and `tasks` are validated as well (SPMVP-042): a plan with a bad task is not saved, and the message starts `The phase plan was not saved because it is not valid:` with the first problem and its field path, then `(and N more)` when there are others. Allocation/ramp skill ids are not checked against `skillSet` on save (UI warning only). Apply-time starters/catalog add already filter to the project skill set and expand `build` to the full skill set (SPMVP-033); that pipeline is not re-applied on save or open. Sample projects disable save in the UI.
- **A handoff save is ETag-checked the same way.** It replaces `handoff` only. Save is refused when there is no estimate, the estimate is stale, or `monthlyHours` is missing/zero.
- **On a review conflict the file is reloaded.** If the acted-on row is unchanged on the server, the action is applied again to the server's rows and saved with the server's ETag. If the row changed or is missing, or the second save also conflicts, the screen shows the reloaded data and the message "Someone else changed this row; reloaded." If the file cannot be reloaded, the action fails with "Someone else saved this file, and it could not be reloaded. Go back and open the project again." If the second save fails for another reason, the screen keeps the reloaded data and shows that failure's message.
- **On an estimate, skill-set, phase-plan, or handoff conflict the file is reloaded once** and the screen shows "Someone else changed the working file; reloaded." There is no automatic re-apply of the build, skill set, phase plan, or handoff.
- **A failed save changes nothing.** The screen rolls back to what it showed before the action, including an edit form's values, and names the cause: "You cannot save changes in this folder. Nothing was changed.", "The working file is no longer in the folder. Nothing was changed.", "The working file is locked or checked out. Nothing was changed." (HTTP 423), "The change could not be saved (HTTP {status}). Nothing was changed.", or "The change could not be saved. Nothing was changed." when there is no status. If the write succeeded but the local state could not be applied, the message is "The change was saved, but the file could not be reloaded. Go back and open the project again."
- **One save at a time.** While a review save is in flight, Accept, Edit, Not a requirement and the `A` key are disabled. While an estimate build, skill-set save, phase-plan save, Reviewed save, or handoff save is in flight, Build estimate, Rebuild, Reviewed, Save handoff, Phases/Skills edits, and step chips are disabled. Arrow navigation still works on the review table.
- **Publish is also ETag-checked.** Publish reloads this file and compares its ETag with the review screen before it downloads or uploads a workbook. After the binary upload, when handoff is present it writes `{Project}_PricerHandoff.csv`, then saves `revision + 1` and `published` with the reloaded ETag. A conflict keeps the new workbook (and CSV if already written), does not update the project index, and requires a reload; it is never retried with `If-Match: *`.
- **Index synchronization is last.** Only after the workbook, optional CSV, and JSON save succeed does Publish MERGE `Status`, `Revision`, and `Waiting` in Blueprint Projects. If that MERGE fails, the new JSON document and workbook remain authoritative and the screen shows a synchronization warning.

### Tenant check

Whether SharePoint honours `If-Match` on a file `$value` PUT is not confirmed by Microsoft's documentation. The save works either way, because the ETag re-read catches a stale save before the write.

Pending: the check on this tenant has not been run yet. To record it, in a test project folder and two browser sessions, note whether a `$value` PUT with a stale `If-Match` returns 412, whether the PUT response and the `$value` GET carry an `ETag` header, and the ETag format in the `Files?$select=ETag` listing. Add the results here.

## Waiting

The index row's **Waiting** value is a short label, or blank. Updates are list MERGEs with `If-Match: *`. If the working file saves but the MERGE fails, the change stands and the screen says "Saved. The project list could not be updated."

| Writer | Waiting |
| --- | --- |
| Extraction / review | `{n} to review`, or blank at zero pending. Review updates Waiting only when an action changes the pending count. |
| Build estimate | `Challenger` when the new estimate has challenger notes; otherwise blank (review still owns `{n} to review` on later review saves). |
| Reviewed (Estimate step) | Cleared to blank. Challenger notes stay on `estimate`. |
| Publish without handoff | `Challenger` when the estimate has notes that are not yet Reviewed; otherwise the pending-review label. |
| Publish with handoff | `Leadership`. Status becomes `In Pricer review`. |

In sample mode (served from localhost with no Blueprint Projects list) the Northwind file is bundled with the web part. Saves and Waiting updates change only the page's own state.

## Estimating catalog

The edit form's work-package choices come from the estimating catalog at the URL in the web part properties. When the URL is blank, the catalog cannot be fetched, or its Activities table does not parse, the choice is disabled with the reason: "No estimating catalog URL is set in the web part properties.", "The estimating catalog could not be read." with the HTTP status when known, or "The estimating catalog is not in the expected format." The statement and coverage can still be edited, and the work package stays as it was.

## Other messages

A project whose status is past Extracting but whose folder has no working file shows "The working file is not in the project folder. Start writes it, and extraction fills it in." A valid file with no requirements shows "The run finished and found no requirements." While the status is Extracting, both cases show the Extracting message instead.

## Test fixtures

`samples/review/` holds ready-to-upload working files for the review screen: the 40-row Northwind file, a 300-row copy, all-pending, zero-pending, Start-only, legacy-catalog and malformed cases. Its README says how to load them. `node tools/samples/review-fixtures.mjs "<project title>" <out dir>` regenerates them with the file name a given project expects.
