# Capability catalogs and estimating catalog

Blueprint maps each requirement to a work package. It also maps the requirement to the capabilities that apply on the detected platform: CMK skills and agents, ai-dev-toolkit skills and agents, and the delivery methods that group them. It reads three Markdown documents as text. There is no SharePoint list of skills, and nothing calls CMK or the toolkit at run time.

| Document | File in this repo | Owner | How it changes |
| --- | --- | --- | --- |
| CMK capability catalog | `docs/catalogs/cmk-capability-catalog.md` | Generated from CMK | Regenerate at a new pinned commit. Never edit by hand. |
| Toolkit capability catalog | `docs/catalogs/toolkit-capability-catalog.md` | Generated from ai-dev-toolkit | Regenerate at a new pinned commit. Never edit by hand. |
| Estimating catalog | `docs/catalogs/estimating-catalog.md` | Catalog owner | Edit by hand, then check it against both generated catalogs. |

**CMK catalog.** It lists:
- CMK's own skills and agents, which apply to every platform;
- the vendor skills each platform adapter offers, with their mode (`default` or `opt_in`) and their status.

Vendor summaries are written by us, in `tools/cmk-vendor-summaries.json`. Upstream skill text is never copied.

**Toolkit catalog.** It lists the skills and agents of the `cdk`, `pdk`, `launch-delivery` and `adr` plugins, under ids such as `cdk:cdk-implement`. Descriptions come from each plugin's own frontmatter. A skill or agent whose description starts with "deprecated", in any case, is listed as `deprecated`, and the checker rejects any reference to it.

**Estimating catalog.** It has three tables and holds no hours, rates or prices; those are in the SPMVP-018 factors workbook.
- **Activities:** the id, name, phase, shape, unit, sizing driver, owner, default coverage and share set of each activity.
- **Capabilities:** one row per activity for `all` platforms, and one per pilot platform (`aem` and `aem-eds`).
  - An activity's capabilities on a platform are its `all` row plus that platform's row.
  - **Opt-in coverage** is set on platform rows. It is the coverage reached when the team enables that platform's opt-in skills.
  - **Method coverage** is set on the `all` row. It is the coverage reached when a delivery method that applies to the activity is assumed.
- **Delivery methods:** the toolkit loops teams run across activities: `cdk-loop`, `pdk-product`, `ld-quality`, `ld-bug` and `adr`. Each lists its capabilities, the activities it applies to, its prerequisites, and whether it is assumed by default.

Each project records which delivery methods and opt-in assets it assumes (SPMVP-034). They are set on the AI levers tab and stored in the working file `levers`.

## Regenerate the CMK catalog

The generator reads CMK only through git, at the commit pinned in `tools/cmk-catalog.pin.json`. It never reads the CMK working tree, so local changes in your CMK checkout don't matter.

1. Have a clone of CMK at `../cmk` (the path in the pin file), or pass `--cmk <path>`.
2. Make sure the pinned commit is in that clone. If it isn't, run `git -C ../cmk fetch origin`.
3. Run `npm run catalog:cmk`.
4. Run `npm run catalog:check`.

Running the generator again at the same commit produces the same file, byte for byte. `npm run test:tools` checks this whenever `../cmk` holds the pinned commit.

## Regenerate the toolkit catalog

The generator reads the ai-dev-toolkit repository only through git, at the commit pinned in `tools/toolkit-catalog.pin.json`. It reads only the plugins listed in the pin, and in each one only `skills/*/SKILL.md`, `agents/*.md` and `plugin.yaml` under `src/plugins/<plugin>/`. It stops and names the problem if a plugin isn't at that commit, has no skills or agents, or has a skill folder without a `SKILL.md`.

1. Have a clone of ai-dev-toolkit at `../ai-dev-toolkit` (the path in the pin file), or pass `--toolkit <path>`.
2. Make sure the pinned commit is in that clone. If it isn't, run `git -C ../ai-dev-toolkit fetch origin`.
3. Run `npm run catalog:toolkit`.
4. Run `npm run catalog:check`.

Running the generator again at the same commit produces the same file, byte for byte. `npm run test:tools` checks this whenever `../ai-dev-toolkit` holds the pinned commit. `npm run catalog:check` also confirms the generated file's tables still agree with its own front matter, so a hand edit is caught even without the checkout.

## Move the pin to a newer CMK commit

1. Change `commit` in `tools/cmk-catalog.pin.json`.
2. Run `npm run catalog:cmk`. If CMK added or removed a vendor asset, the generator stops and names it. Fix `tools/cmk-vendor-summaries.json` and run it again:
   - For a new asset, add a summary in our own words. It must be one line of at most 160 characters, contain no `|`, and end with a full stop.
   - For a removed asset, delete its summary.
3. Update `cmkCommit` in the estimating catalog. If any work package changes, raise the estimating catalog's `version`.
4. Run `npm run catalog:check` and fix anything it reports.
5. Commit the pin, the summaries and the catalogs together.

## Move the pin to a newer toolkit commit

1. Fetch in `../ai-dev-toolkit`, then change `commit` in `tools/toolkit-catalog.pin.json` to the full 40-character SHA.
2. Run `npm run catalog:toolkit`.
3. Update `toolkitCommit` in the estimating catalog. If any work package, capability row or delivery method changes, raise the estimating catalog's `version`.
4. Run `npm run catalog:check`. It reports any delivery-method or `all`-row id that the toolkit renamed, removed or deprecated.
5. Commit the pin and the catalogs together.

## Suggest capabilities

`npm run catalog:suggest` prints, for each work package, up to five candidate ids for the `all` row and for each pilot platform. It scores candidates by how well their ids and descriptions match the package's name, its sizing driver and its keywords in `tools/catalog-suggest-keywords.json`.
- It skips:
  - ids the package already lists;
  - toolkit ids already in a delivery method or in another package's `all` row;
  - deprecated ids;
  - vendor ids that are unavailable;
  - `pdk:pdk-dev-story`, `pdk:pdk-code-review` and `pdk:pdk-quick-dev`, which are alternatives to `cdk-loop`.
- Candidates that match nothing are dropped, so a row can read "no suggestions".
- It refuses to run while `npm run catalog:check` would report problems in the catalogs.
- It never edits a file and calls no model.

The catalog owner decides which suggestions to add, and `npm run catalog:check` remains the gate.

## Upload to the hub

This waits for the Blueprint package to be in the app catalog.

1. Upload `cmk-capability-catalog.md` to the hub library the left navigation calls **CMK capability catalog**.
2. Upload `toolkit-capability-catalog.md` to the library called **Toolkit capability catalog**.
3. Upload `estimating-catalog.md` to the library called **Estimating catalog**.
4. Upload `samples/workbook/Estimate_Template.xlsx` (the old `Blueprint_Template.xlsx` was replaced in stage 5) to a hub library where Blueprint users have read access. Keep the business-owned workbook in SharePoint so template changes do not require a web-part deployment.
5. Copy each file's URL.
6. Edit the Blueprint page, open the web part's property pane, and paste the URLs into the **Catalogs** group: **CMK capability catalog URL**, **Toolkit capability catalog URL**, **Estimating catalog URL** and **Workbook template URL**.

The workbook template URL must be an absolute SharePoint URL on the same origin as the Blueprint page, and the path must end in `.xlsx`. Publish checks the URL and access before it writes the opportunity folder. The workbook must follow the contract in `docs/spfx/workbook-template.md`; missing sheets or defined names stop publication before upload.

There is no factors workbook URL any more. The skills, phase packs, lanes and blended rates it carried are the CSVs under `samples/factors/seed/`, read straight from the repository; story B-15 deleted the generated `.xlsx` because nothing read it back. Contract: `docs/spfx/delivery-defaults.md`. Hours per unit were never in it after story B-12: they come from the case library and the estimating catalog.

## Version label

The review screen (SPMVP-009) shows `CMK {version} · toolkit {version} · catalog {version}`. Until real version labels exist, it shows the short CMK commit, the short toolkit commit and the estimating catalog's `version`: `CMK e81d7ff · toolkit 5d1f76e · catalog v2`. Each part comes from the working file's `catalog` field first; a part the file does not have falls back to the estimating catalog's front matter (`cmkCommit`, `toolkitCommit`, `version`). The label is hidden when neither has anything. See `docs/spfx/working-file.md`.
