# Context sidecar

Blueprint keeps pursuit framing, hard constraints, and the delivery registers (risks, unknowns, assumptions, dependencies) in a second JSON file beside the working file: `{Project}_Context.json`. The Blueprint root schema in [working-file.md](working-file.md) does **not** require this sidecar.

Offline enrich (SPMVP-023) and the Context step in the web part (SPMVP-025, SPMVP-028) read and write this contract. Progressive enrichment is expected: every section may be empty or omitted. An empty or missing sidecar must not block Start, review, publish, or Build estimate.

> **Status.** Both schema versions are implemented by `tools/blueprint/validate-context.mjs` and by `contextFile.ts` in the web part: the validators, the draft and the save path, which keeps every documented field. The contract comes from the 2026-11-04 brainstorming ([session notes](../brainstorming/brainstorming-session--2026-11-04.md)). The review lists for the registers are implemented in the web part (SPMVP-037). The hub libraries ship as seed CSVs and workbook sheets (SPMVP-038), and the offline enrich skill reads the seed CSVs through `tools/blueprint/match-library.mjs` (SPMVP-039); the web part does not read them. Publish writes the Context and the four registers into the workbook (SPMVP-040); see [Published sheets](#published-sheets).

## File name

Same sanitization as the working file: `{Project}_Context.json` next to `{Project}_Blueprint.json` in the opportunity folder.

## Versions

| `meta.schemaVersion` | Adds |
| --- | --- |
| `"1"` | `constraints`, `framing`, `deliveryRisks`, `deliveryUnknowns` (statement, source, review). |
| `"2"` | `assumptions`, `dependencies`; `refs` and `libraryId` on every item; likelihood, severity, impact and mitigation on `deliveryRisks`. All additions are optional. |

A writer sets `meta.schemaVersion` to `"2"` whenever it writes any v2 array or field. A reader that sees `"1"` (or no version) treats every v2 field as absent. A v1 file is a legal v2 file.

The web part writes the version by one rule when it saves: `"2"` when the saved file has any v2 array or field, or when the file was already marked exactly `"2"` (even if no v2 content is left); otherwise `"1"`. A new file with no v2 content is `"1"`. Any other prior value (for example `"3"`) is replaced, so the web part knows only `"1"` and `"2"`. Saving never adds an empty `assumptions` or `dependencies` array to a file that did not have one, and a prior empty array is kept.

A blank optional field means the key is **omitted**. Writers must omit a key rather than write `""`. The web part does this on save: it drops a blank string from any item field (`source`, `libraryId` and the list-specific text and enum fields), as it already drops a blank `constraints` or `framing` value. An empty `refs` array is kept as written. An empty string is not a legal value for an enum field (`likelihood`, `severity`, `confidence`, `priority`, `category`), and `requiredWeek` is a number or absent.

## Root

No root field is required. `{}` is a legal sidecar.

| Field | Type | Rule |
| --- | --- | --- |
| `constraints` | object | Optional. See below. |
| `framing` | object | Optional. See below. |
| `deliveryRisks` | array | Optional. Items follow the risk table. May be `[]`. |
| `deliveryUnknowns` | array | Optional. Items follow the unknown table. May be `[]`. |
| `assumptions` | array | **v2.** Optional. Items follow the assumption table. May be `[]`. |
| `dependencies` | array | **v2.** Optional. Items follow the dependency table. May be `[]`. |
| `meta` | object | Optional. See below. |

Unknown top-level keys that appear on the **out-of-scope** denylist below make the sidecar invalid for offline validate. Other unknown keys are reserved for later tickets and should not be invented by the skill. The web part keeps unknown top-level keys as they are when it saves.

## Constraints

All fields optional. Blank or omitted means unknown — do not invent budget, price-to-win, or dates.

| Field | Type | Rule |
| --- | --- | --- |
| `budgetCap` | string or number | Optional ceiling / cap as stated by the client. |
| `priceToWin` | string or number | Optional. |
| `calendar` | string | Optional dates or windows in free text. |
| `geoResourcing` | string | Optional geo or resourcing limits (e.g. US-only). |

## Framing

All fields optional strings.

| Field | Type | Rule |
| --- | --- | --- |
| `problemStatement` | string | Optional. |
| `desiredOutcome` | string | Optional. |
| `winTheme` | string | Optional. |

## Register items

`deliveryRisks`, `deliveryUnknowns`, `assumptions` and `dependencies` share one base. Each list adds its own fields.

### Common fields (all four lists)

| Field | Type | Rule |
| --- | --- | --- |
| `id` | string | Required when the item is present. Non-empty after trim. Unique across all four lists in the file (**v2**; the prefixes below make that natural). |
| `statement` | string | Required. Non-empty after trim. |
| `source` | string | Optional citation or short source label for the document evidence. Omitted when an item comes only from a hub library. |
| `review` | object | Optional. When present, `status` must be one of `pending`, `accepted`, `edited`, `dismissed`. Nothing else is stored on `review`. |
| `refs` | string[] | **v2.** Optional. Ids this item relates to. Each entry is a non-empty string. See [References](#references). |
| `libraryId` | string | **v2.** Optional. The hub library entry the item was proposed from (see [Hub libraries](#hub-libraries-v2-draft)). Kept as written after the person edits the item, so later tooling can see where it started. |

### Id prefixes

| List | Prefix | Example |
| --- | --- | --- |
| `deliveryRisks` | `DR-` | `DR-001` |
| `deliveryUnknowns` | `DU-` | `DU-003` |
| `assumptions` | `AS-` | `AS-001` |
| `dependencies` | `DP-` | `DP-001` |

The web part numbers new items with three digits. It starts at the list length plus one and skips any id already in use, in that list and, when the caller passes the other lists, in all four. Skills follow the same pattern.

### `deliveryUnknowns`

Common fields only. To record that an unknown was raised as a question, put the question id in `refs` (for example `["Q7"]`).

### `deliveryRisks`

Common fields plus the **v2** fields below. All optional.

| Field | Type | Rule |
| --- | --- | --- |
| `likelihood` | string | `low`, `medium` or `high`. |
| `severity` | string | `low`, `medium` or `high`. |
| `impact` | string | What happens if the risk occurs. |
| `mitigation` | string | What to do about it. |

**Derived, never stored.** The risk level is computed from likelihood × severity (Low = 1, Medium = 2, High = 3): a score of 6–9 is `HIGH`, 3–5 is `MEDIUM`, 1–2 is `LOW`. The level is blank when either value is missing. A stored `level` or `score` key on a risk is invalid.

### `assumptions` (v2)

Common fields plus:

| Field | Type | Rule |
| --- | --- | --- |
| `category` | string | One of `scope`, `architecture`, `dependency`, `resource`, `delivery`, `estimate`. There is deliberately no `commercial` value. Licence and entitlement items are dependencies. |
| `confidence` | string | `low`, `medium` or `high`. |
| `ifFails` | string | What changes if the assumption proves wrong. |
| `appliesTo` | string | Free text phase, week or scope, for example `Wk 2` or `Option 1`. Free text until the plan model gives it a structured home. |

To record that an assumption answers an unknown, put the unknown's id in `refs` (for example `["DU-003"]`).

### `dependencies` (v2)

Common fields plus:

| Field | Type | Rule |
| --- | --- | --- |
| `owner` | string | Team or role that owns the dependency, free text. |
| `needed` | string | What is needed. |
| `impactIfMissing` | string | What happens if it is not available. |
| `priority` | string | `high`, `medium` or `low`. High means it blocks the critical path. |
| `requiredWeek` | integer | Week the dependency is needed, counted from project start. Whole number, 1 or more. |

There is no dependency `status` in v2. At bid time every dependency is not yet started.

### References

`refs` links items to each other and to the Blueprint file. Recognised forms (one or more digits each):

| Form | Points to |
| --- | --- |
| `R-n` | A requirement in `{Project}_Blueprint.json` |
| `Qn` | A question in `{Project}_Blueprint.json` |
| `DR-n`, `DU-n`, `AS-n`, `DP-n` | An item in this sidecar |

A sidecar reference resolves by **exact id**: `DR-1` does not match an item whose id is `DR-001`. A reference that does not resolve is a **warning, not an error**. Requirements and questions live in another file, and a reference may be written before the target exists. Flags, never silent adjustments: nothing is dropped or rewritten because a reference dangles.

## Meta

| Field | Type | Rule |
| --- | --- | --- |
| `schemaVersion` | string | Optional. `"1"` or `"2"`. See [Versions](#versions). |
| `producedBy` | string | Optional. One of `skill`, `ui`, `mixed`. Offline enrich uses `skill`. |
| `updatedAt` | string | Optional ISO 8601 timestamp. |

## Out of scope (do not add)

Do not put these fields on the Context sidecar (or invent them for "later convenience"):

- Account history / new logo
- Commercial risks
- Work-environment / client-difficulty texture
- Difficulty multipliers and staffing profiles
- Cost, price, rate, contingency or margin fields on any item (v2)
- A `commercial` assumption category (v2)

Those stay out of Blueprint for this MVP slice (Scope Cut #2).

## Minimal valid examples

Empty object:

```json
{}
```

Version 1 with empty arrays:

```json
{
  "meta": { "schemaVersion": "1", "producedBy": "skill" },
  "deliveryRisks": [],
  "deliveryUnknowns": []
}
```

Version 2, one item of each kind (illustrative content):

```json
{
  "meta": { "schemaVersion": "2", "producedBy": "skill" },
  "deliveryUnknowns": [
    {
      "id": "DU-001",
      "statement": "Whether the client already has its own platform org is unclear.",
      "source": "RFP p.3 §2.1",
      "refs": ["Q7"],
      "review": { "status": "pending" }
    }
  ],
  "assumptions": [
    {
      "id": "AS-001",
      "statement": "The client runs its own platform org; no shared tenancy.",
      "category": "architecture",
      "confidence": "medium",
      "ifFails": "Legal and licence review, then a re-plan.",
      "appliesTo": "Wk 2",
      "refs": ["DU-001"],
      "review": { "status": "pending" }
    }
  ],
  "dependencies": [
    {
      "id": "DP-001",
      "statement": "Dev sandbox and named-user access",
      "owner": "Client procurement and vendor",
      "needed": "Entitlements and user provisioning",
      "impactIfMissing": "Foundation build blocked",
      "priority": "high",
      "requiredWeek": 3,
      "libraryId": "dep-env-access",
      "review": { "status": "pending" }
    }
  ],
  "deliveryRisks": [
    {
      "id": "DR-001",
      "statement": "Sandbox not available by week 3",
      "likelihood": "medium",
      "severity": "high",
      "impact": "Foundation build and dates slip",
      "mitigation": "Confirm entitlements before kick-off; escalate at the end of week 1.",
      "refs": ["DP-001"],
      "review": { "status": "pending" }
    }
  ]
}
```

Committed samples: `samples/offline/minimal_Context.json`, `samples/offline/Northwind_Context.json` (v1) and `samples/offline/Northwind_v2_Context.json` (v2, one list of each kind with every field used).

## Validation

Offline: `node tools/blueprint/validate-context.mjs <path> [--blueprint <path-to-blueprint.json>]`. Exit `0` when legal; exit `1` with field-path errors, or when the context file or the `--blueprint` file cannot be read, is not JSON, or (Blueprint) is not an object with `requirements` and `questions` arrays; exit `2` for a usage error, including an unknown or single-dash flag and a `--blueprint` with no value.

**v2 rules.** The CLI and the web part validator (`contextFile.ts`) mirror each other. A shared fixture, `tools/blueprint/fixtures/context-validator-cases.json`, holds the expected error text and both test suites run it.

Errors (exit `1`):

- A register list is not an array, or an item is not an object.
- `id` or `statement` missing or blank.
- Duplicate `id` across the four lists.
- `review.status` not one of the four values.
- An enum field (`likelihood`, `severity`, `confidence`, `priority`, `category`) outside its values.
- A text field (`source`, `libraryId`, `impact`, `mitigation`, `ifFails`, `appliesTo`, `owner`, `needed`, `impactIfMissing`) that is not a string.
- `requiredWeek` not a whole number of 1 or more.
- `refs` not an array of non-empty strings.
- A stored `level` or `score` on a risk.
- Any top-level denylist key.

Warnings (printed as `warning: <path>: …`, exit stays `0`; CLI only, the web part shows none):

- A `refs` entry in a recognised sidecar form that matches no item in the file.
- A `refs` entry that matches none of the recognised forms.
- A v2 array or field present while `meta.schemaVersion` is not `"2"`.
- With the optional `--blueprint <path>` argument: an `R-n` or `Qn` reference that is not in that Blueprint file. Without it, `R-n` and `Qn` references are not checked.

Warnings are printed only when there are no errors, so a dangling reference shows up after the errors are fixed.

Unknown item fields are not errors. The web part keeps only the fields documented here on an item when it saves.

## Web part behavior (v2)

The review lists, grouping, bulk accept and challenger note below are implemented (SPMVP-037). Mockups: `docs/mockups/spfx/04-project-context.html` (v2 file) and `04b-project-context-v1.html` (v1-only file).

- **No new step.** The Context step shows four review lists in this order: Unknowns, Assumptions, Dependencies, Risks. Assumptions and Dependencies show only when the file has items for them. A file with only risks and unknowns shows those two lists, Unknowns first, each with its own Add button, and no Assumptions or Dependencies headings. It also gets the Add assumption and Add dependency buttons and a disabled "Accept all pending library items (0)" button. Each row has a status chip, and Id and Source are plain text.
- **Review only.** A person can accept, dismiss, or edit the statement of an item, which sets `review.status` as for v1. Typing in the statement of a dismissed item leaves it dismissed. An item with no `review` shows "Not reviewed" and is not counted as pending. Every other field is written by the skill, copied from a hub library, or edited in the JSON. Id and Source are read-only; each row also shows a read-only line of key fields and its `refs` as plain text.
- **Add.** Adding an item takes a statement only. The id comes from `newDeliveryItemId` and is unique across all four lists, and the item is saved as `pending`.
- **Save keeps what it did not edit.** Saving after a review decision preserves every documented field on every item, including v2 fields. This is implemented; before it, saving rebuilt each item with only `id`, `statement`, `source` and `review`.
- **Bulk accept.** "Accept all pending library items (N)" applies only to pending items with a non-blank `libraryId`, after a confirm dialog that shows the count. It is still a person's decision, each item records `accepted`, and it changes only the draft until Save Context.
- **Grouping.** Assumptions group by `category` in the order scope, architecture, dependency, resource, delivery, estimate; dependencies by `priority`, high first; risks by derived level, high first, with unrated risks last. Items with a missing or unrecognised value go in a final "No category", "No priority" or "Not rated" group. Grouping is display only; saving keeps file order.
- **Derived risk level.** Likelihood times severity (low 1, medium 2, high 3): 6 to 9 HIGH, 3 to 5 MEDIUM, 1 to 2 LOW. Blank when either value is missing or not one of low, medium, high. Shown, never stored.
- **Challenger.** The pending-review note reads "N Context items (risks, unknowns, assumptions, dependencies) still pending review." and counts pending items across all four lists. It still blocks the same way and never changes hours or price.

## Hub libraries (v2 draft)

Hub libraries are the proposal source for `libraryId`. They are CSVs under `samples/factors/seed/`, part of the delivery defaults (see [delivery-defaults.md](delivery-defaults.md)). The catalog owner maintains them. Columns match by position, as on the other seed files. Row 1 is the header.

Library ids are stable kebab-case with a prefix: `asm-`, `dep-`, `risk-`.

**Status.** The seed CSVs and the three workbook sheets ship with SPMVP-038. The web part does not read them. The offline enrich skill reads the seed CSVs through `tools/blueprint/match-library.mjs` (SPMVP-039), not the workbook.

**Platform** is `all` or a platform id. A library may carry platform ids beyond the pilot platforms. The starter libraries use `all`, `aem`, `aem-eds` and `aep`, and a check rejects any other value; adding a platform means adding its id to the check and its entries to the libraries. An entry carries one platform, so a pair of entries covers `aem` and `aem-eds`. **Match hints** are short keywords, separated by semicolons, in the same spirit as Skills inference hints. Blank hints are allowed only on an `all` entry and mean the entry is always listed as a candidate, so the enrich skill judges whether it fits the bid. It sorts after entries that matched hints within the same rank.

### `Assumption library`

| Column | Field |
| --- | --- |
| A | Library id (`asm-…`) |
| B | Platform |
| C | Match hints |
| D | Statement |
| E | Category |
| F | Confidence |
| G | If it fails |

### `Dependency library`

| Column | Field |
| --- | --- |
| A | Library id (`dep-…`) |
| B | Platform |
| C | Match hints |
| D | Statement |
| E | Owner |
| F | Needed |
| G | Impact if missing |
| H | Priority |
| I | Required week, or blank |

### `Risk library`

| Column | Field |
| --- | --- |
| A | Library id (`risk-…`) |
| B | Platform |
| C | Match hints |
| D | Statement |
| E | Impact |
| F | Likelihood |
| G | Severity |
| H | Mitigation |

Libraries hold no cost, rate or contingency, and no `commercial` category.

## Enrich skill rules (v2 draft)

For `blueprint-enrich`, on top of the v1 rules:

- Propose, never decide. Every item the skill writes has `review: { "status": "pending" }`.
- Match library entries to the detected platform and the requirement text through platform and match hints, using `tools/blueprint/match-library.mjs` (the model does not recall library entries). Copy the entry's defaults into the item and set `libraryId`. An item that came only from a library has no `source`.
- The matcher reads requirement statements and question text. It skips dismissed requirements and their questions, and never reads source passages. A platform id that is not a library platform lists only `all` entries.
- Cap library proposals per list (default 8). Order dependencies by priority, risks by derived level, and assumptions by confidence with the least certain first. Candidates the cap cuts, or the skill rejects, are listed again on a re-run.
- On a re-run, add only: skip entries whose `libraryId` is already in the sidecar, and never edit or remove existing items.
- Convert each unknown into a working assumption with an `ifFails`, and link it with `refs`. Do not invent a number: when the document gives none, leave the field blank. When no honest assumption is possible, say so in the run summary; the sidecar has no field for it.
- Link items to requirements and questions with `refs` when the evidence is clear.
- Leave `requiredWeek` as the library entry has it (the tool carries the library's week, or no week when the library has none). Write a week of your own only on a dependency with no `libraryId`, and only when the document states it.
- Set `meta.schemaVersion` to `"2"` and `meta.producedBy` to `"skill"`.

## Published sheets

Publish writes the Context into `{Project}_Blueprint.xlsx`: a `Context` sheet with seven named cells, and `Unknowns`, `Assumptions`, `Dependencies` and `Risks` sheets with one row per item, dismissed items included. The column tables, named cells, summary cells and failure rules are in [workbook-template.md](workbook-template.md#context-and-register-sheets), which is the contract for the template.

How Publish treats the file:

- **Absent or blank.** A missing `{Project}_Context.json`, or one that is zero bytes or only whitespace, is empty. Publish succeeds and leaves the Context sheets as in the template. The Context step opens a blank file as an empty Context, without a warning. The file is the one named after the working `_Blueprint.json` that is in the folder.
- **Present but unusable.** A file that is not valid JSON, fails validation, or cannot be read (no permission, a server error, or the file disappearing mid-read) blocks Publish with a message naming the Context file (and the first problem for an invalid file). Nothing is written.
- **Not an etag check.** Publish reads the file once, early. An edit saved after that read appears in the next publish.
- **Level.** Publish computes the `Risks` Level (`HIGH`, `MEDIUM`, `LOW`) from likelihood and severity with the same rule the Risks list uses. It is not stored in the sidecar.

## Compatibility

- **Older web part, newer file.** The validator ignores unknown keys, so a v2 file opens. A save through a web part that predates this contract rebuilds `deliveryRisks` and `deliveryUnknowns` items with only `id`, `statement`, `source` and `review`, and **drops the v2 fields from them**. The new top-level arrays survive, but that web part also resets `meta.schemaVersion` to `"1"`, so the CLI then warns about the surviving v2 arrays until a v2-aware writer saves the file again. Upgrade the web part before running v2 enrich against a project that is open in the pilot.
- **Older template, newer web part.** Publish fails naming the missing sheet when the sidecar has content for it. The old template and its patch scripts are gone: the estimate workbook of this repository (`samples/workbook/Estimate_Template.xlsx`, see workbook-template.md) has no Context sheets.
- **Unknown fields.** Fields not in this document are not preserved on items by the web part.
