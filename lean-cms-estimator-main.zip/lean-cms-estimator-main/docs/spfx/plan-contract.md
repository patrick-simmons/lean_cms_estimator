# The plan file

`{Project}_Plan.json` is the one file the agent writes into the project folder. It holds what the documents say (requirements, questions, volumes) and what the estimator decided about them. The workstream estimate (stage 3), the AI plan (stage 4) and the workbook (stage 5) are built from it. The tool is `tools/blueprint/plan.mjs`; this page is the schema it checks.

The plan file replaces the Blueprint file for this project. Requirements and questions keep the field names the Blueprint used, so the gap sweep, lever advice, question ranking and `validate-context --blueprint` take a plan file wherever they take a Blueprint.

## Who writes what

| Who | Writes |
| --- | --- |
| The agent | `.blueprint/extract.json` (requirements, platform), optionally `.blueprint/design-sketch.json` (volumes, through `assemble-drivers.mjs`) |
| `plan.mjs assemble` | the plan file from those, checked against the parsed blocks and the estimating catalog |
| `plan.mjs accept` | the review state of requirements and volumes (a person chose it in chat) |
| `plan.mjs rate` | one rate decision, in `rates` (a person chose the figure; the tool never writes one unprompted) |
| `plan.mjs owner` | one ownership decision, in `owners` (a person said the client is doing it, and why) |
| `plan.mjs estimate`, `ai-plan`, `ai-opt-out`, `ai-restore` | the derived sections: `workstreams`, `skills`, `estimateBasis`, `aiPlan` |
| `build-workbook.mjs` | `{Project}_Estimate.xlsx`, read from the plan and nothing else (see [workbook-template.md](workbook-template.md)); it never changes the plan |
| The estimator | decisions, in chat or by asking the agent to run `accept` |

A run **only adds**. A second `assemble` leaves every row in the plan as it is, decisions included, and appends what is new: a requirement whose statement is not there yet, a question for it, a volume for a work package that has none. A figure that differs from a volume already held is reported as a warning and the volume is not changed. A plan file that is not valid is never overwritten (exit 1).

## Root

| Field | Type | Rule |
| --- | --- | --- |
| `schemaVersion` | string | `"1"`. |
| `producedBy` | string | `"skill"`. |
| `projectName` | string | Not empty. The file name is the project name, without characters a file name cannot hold, plus `_Plan.json`. |
| `createdAt`, `updatedAt` | string | ISO times. `updatedAt` changes whenever a run or an accept changes the file. |
| `catalog` | object | `cmkCommit`, `toolkitCommit`, `estimatingVersion` of the catalogs the run used. |
| `platform` | object | Optional. `{ id, name, citation? }`. Only when a document names the platform. |
| `sources` | array | One `{ itemId, name, read?, notRead? }` per document the parse stage saw. |
| `requirements` | array | See below. Ids unique. |
| `questions` | array | See below. |
| `volumes` | array | See below. |
| `rates` | array | Optional. Rate decisions the estimator made, see below. Absent until `plan.mjs rate` runs. |
| `owners` | array | Optional. Ownership decisions the estimator made, see [Owner](#owner). Absent until `plan.mjs owner` runs. |
| `skills` | array | Stage 3, see below. `[]` until `plan.mjs estimate` runs. |
| `workstreams` | array | Stage 3, see below. `[]` until `plan.mjs estimate` runs. |
| `estimateBasis` | object | Written with the workstreams: `{ platform, platformSource, builtAt }`. `platformSource` is `documents` or `estimator` (the platform was chosen with `--platform`). Absent until the estimate runs. |
| `aiPlan` | object or null | Stage 4, see below. `null` until `plan.mjs ai-plan` runs. |

## Requirement

| Field | Type | Rule |
| --- | --- | --- |
| `id` | string | `R-` and at least three digits. Unique. Assigned by the tool, never reused. |
| `statement` | string | Not empty. |
| `sources` | array | At least one `{ itemId, fileName, blockId, label, location, passage }`, from the parsed blocks. |
| `workPackage` | string | A work package id from the estimating catalog, or `unmapped`. |
| `capabilities` | string[] | Derived from the catalog by the tool. The agent never writes them. |
| `coverage` | string | `accelerated`, `partly`, `human-led`, `question` or `conflict`. |
| `questionId` | string | Optional. A question in this file. |
| `review` | object | `{ status }`, plus `via` and `at` once decided. |

`review.status` is `pending`, `accepted`, `edited` or `dismissed`. Every status other than `pending` carries `via` (`bulk` for accept all, `walk` for a choice made one row or one workstream at a time, `edit` for a changed row) and `at` (an ISO time). The `bulk` mark stays in the plan and reaches the workbook, so a reader can tell a reviewed row from a row accepted with the rest.

Nothing is locked. A decision can be changed later by editing the file or asking the agent to; `accept` only moves `pending` rows, so it never undoes a choice.

## Question

`{ id, requirementId, text }`. `id` is `Q` and a number. A question whose requirement is dismissed is not counted.

## Volume

A volume is a design-sketch driver (see `blueprint-design-sketch`): one count for one work package, with the words, names or parts in the documents that back it. `id` is `D-` and three digits, `review` is the same as a requirement's. With `--blocks`, `plan.mjs validate` re-checks every quote and name against the parsed blocks, so a plan cannot carry a number the documents do not support. A volume is never hours; the hours come from the rate ladder in stage 3.

## Rate

A rate decision: `{ activity, hoursPerUnit, note, review }`. `activity` is an activity id of the estimating catalog, once per file. `hoursPerUnit` is above zero, `note` is the typed reason and is required, and `review` is the same shape as a requirement's, with `via: rate`. The first decision for an activity is `accepted`; running `rate` again for it is `edited` and replaces the figure rather than stacking a second one.

A decision is only used when no past project covers the activity. Evidence outranks a decision: if the case library has cases for it, the cases set the rate and the decision sits unused in the file.

## Owner

An ownership decision: `{ activity, owner, note, review }`. `activity` is an activity id of the estimating catalog, once per file. `owner` is `us`, `shared` or `client`, `note` is the typed reason and is required — it is what the exclusion in the estimate is written from — and `review` is the same shape as a requirement's, with `via: owner`. The first decision for an activity is `accepted`; running `owner` again for it is `edited` and replaces it.

Unlike a rate, a decision here always wins: evidence can say how long an activity takes, but only a person can say who is doing it.

## The rate ladder

Every workstream says which rung its hours per unit came from, in `rateBasis`:

| Rung | `rateBasis` | Where the rate came from | Owes a question |
| --- | --- | --- | --- |
| 1 | `cases` | Three or more past projects on this platform cover the activity. The rate is their median. | No — it is evidence |
| 2 | `cases-adjusted` | Past projects cover it, but too few, or only on another platform. | Yes |
| 3 | `derived` | No past project covers it: an estimator's accepted rate, or the catalog's starting figure until somebody accepts one. | Yes |

The field is `rateBasis` rather than `basis` because a workstream already carries `volumeBasis`, and a plan that says `basis` twice about two different things is a plan nobody can read. Rung 1 is the only rung that asks nothing, so `rateQuestion` is present exactly when `rateBasis` is not `cases` — the validator rejects a plan where those two disagree.

Rung 2 adjusts a rate from another platform, and the complexity **deltas** that do the adjusting are not in this contract yet: they arrive with the platform profiles in stage C, as `deltas[]` on a workstream with an accepted multiplier and the finding that triggered it. Until then `cases-adjusted` carries the rate unadjusted and says so in its question, which is honest about the gap rather than hiding it behind a multiplier nobody chose.

## Three-point hours

Every workstream carries `hours`: `{ low, likely, high, spread }`. `likely` is the workstream's `traditionalHours` and the number the summary, the skills roll-up and the workbook lead with; low and high are the range that figure sits in, shown as a range and never as a choice to make.

The range comes from the same place the rate does. `spread` is `quartiles` when three or more cases set it (one unusual project widens the range it belongs in rather than setting it), `observed` when there are fewer and the honest answer is the whole of what was seen, and `none` when no case covers the activity. A `derived` rate has no measured spread, so `low` and `high` equal `likely` and the validator rejects any attempt to widen them: a range invented on top of a figure nobody measured reads as evidence of a width that was never seen. The rung, not the range, is what says how certain the number is.

The range is on the delivered hours, because that is what the cases measured. The AI-assisted figure is a projection off the likely rate and carries no range of its own — a projection of a range is two uncertainties multiplied together and presented as one.

Totals add the lows and add the highs, across the estimate and within each phase. That is the widest the range can be, and it is the arithmetic an estimator can check in a pursuit review; a statistical roll-up would be narrower and more defensible on paper, but a range nobody can explain is a range nobody will stand behind.

## Complexity bands

A `tiered` activity is not sized by a volume: it is sized by how complicated the work is. The band — `small`, `medium` or `large` — is read from the documents by `tools/blueprint/band.mjs` against the signals in `tools/blueprint/data/tier-signals.json`, and recorded with the words that decided it and the block they came from. **A signal never sets an hour figure**; the hours behind a band come from cases, exactly as a per-unit rate does.

Three rules decide the band, in this order:

1. **Quoted beats inferred.** A signal found in a passage the documents actually contain outranks one found only in a requirement statement, which is the model's paraphrase. When any quoted signal matches, the inferred ones are not consulted at all — a summary cannot argue with the passage it was made from.
2. **Among what is left, the higher band wins.** Small under-prices, which is the common failure; large loses deals, which is the visible one.
3. **Signals that disagree raise a challenge, not a question.** Something in the documents says this is bigger than the rest of them suggest, and that is worth arguing about rather than asking the client to settle.

No signal at all means `medium`, low confidence and a client question. A volume signal reads an accepted volume of another activity (`integrations`, `multisite`): a figure nobody has accepted does not set a band, any more than it sizes a workstream.

The signals file is data, not code, so the band boundaries can be tuned against real pursuits without a release. Every activity whose shape is `tiered` in the catalog has an entry, and nothing else does; a test holds the two in step.

## Sized as a share

A `proportional` activity is not a volume times a rate: it is a percentage of a named set of other activities, from the **Share of** column of the catalog. Project management is not an overhead class, it is an activity sized as a share of the work it covers, and the same goes for delivery governance, QA automation and UAT support.

Sizing this way is what makes the phase ratios right by construction. QA lands at a healthy share of build because that is how it is sized, not because an auditor checked afterwards.

Shares of shares would never settle, so resolution runs in passes and the order is fixed:

1. **Per-unit** activities: volume x hours per unit.
2. **Tiered** activities: band to hours.
3. `qa-automation` and `uat-support`, over sets drawn only from passes 1 and 2.
4. `project-management` and `delivery-governance`, over everything from passes 1 to 3.

Which pass an activity falls in is read from its share set, not from a list of ids in the code, so adding a proportional activity is a catalog change. `everything-else` means every activity that does not itself use it, which is what stops the two reporting activities sizing each other.

A share set that leads back to itself is rejected twice. `npm run catalog:check` rejects it where it is written, which is where a maintainer wants to hear about it. `plan.mjs validate` rejects it again on the plan file, because a plan can be edited by hand and the four fixed passes have no way to notice at build time: the message names the activity and says its hours cannot be worked out.

The share comes from cases: per case, the activity's hours over the hours of its reference set, then the median across cases — measured per case rather than total over total, so one large project does not set the percentage for every small one. Until a case covers it, the share is a published ratio from `tools/blueprint/data/proportional-fallbacks.json`, `shareBasis` is `fallback`, and the workstream carries a question saying so. Unlike a per-unit rate these have no cold start to wait out: every signed estimate being reconstructed already carries project-management and QA lines.

The share applies to the traditional hours, and the AI-assisted figure is then built from it the way every other workstream's is. Sizing the AI column off the reference set's AI column instead would make this activity's saving a consequence of everyone else's, which is a different claim from the one the AI plan is making.

## Who does the work

The catalog's **Owner** column says who usually does an activity, `us` or `shared`. An estimate can say otherwise with `plan.mjs owner`, which is the only thing that ever writes `client`: nothing is handed to the client unless a person said so and said why.

Ownership is applied **after** sizing, never before. An activity is sized whole, in `wholeHours`, and then reduced to our portion in `traditionalHours`. That order is what keeps a handover honest: a client-run UAT does not shrink the project management that covers it, because a proportional activity takes its share over `wholeHours`. Work the client runs still has to be managed.

| Owner | Our portion | What the row carries |
| --- | --- | --- |
| `us` | all of it | Nothing extra. |
| `shared` | all of it | `ownerQuestion`: no past project records how a shared activity splits, so it is sized at full and says so. |
| `client` | none of it | Hours at zero, an `exclusion` naming it as out of scope, the `ownerNote` saying why, and an `ownerQuestion` carrying the `wholeHours` it would have been. |

Sizing a shared activity at half would be a number nobody measured, in the direction that loses money. Until a case records a split, the estimate carries the whole thing and asks.

## Scope caps

An assumption used to exist only where evidence was absent: a volume the documents state gets `volumeBasis: document` and produces no assumption row at all. That is the wrong way round commercially. A figure the client gave us is exactly the one worth committing to, because the estimate silently carries whatever it later turns out to have been.

`plan.mjs assume` records a cap on `plan.assumptions`, and nothing else writes that array:

| Field | Rule |
| --- | --- |
| `id` | `AS-###`, the Context sidecar's prefix for an assumption. Kept when a cap is changed. |
| `activity` | An activity of the estimating catalog, once. A `proportional` activity is rejected: it is sized as a share of other activities, so there is no volume to hold down, and capping what it covers is what moves it. |
| `category` | `scope`. The sidecar's categories, which deliberately have no `commercial` value. |
| `cap` | A number above zero. |
| `note` | Why the estimator set it. Required: the cap is what the client is asked to agree to, and the note is what the workbook row is written from. |
| `review` | `{ status, via: 'cap', at }`, as the other decisions carry. |

A cap **is** the volume the estimate is for, whether the figure under it was quoted or assumed, so `volume` becomes the cap and `label` reads `capped at <n> <unit>s`. `volumeBasis` is left alone: where the figure came from before the estimator capped it is still worth knowing, and the label is what says a cap is now in front of it.

A cap no commercial field may accompany: no cost, price, rate, contingency, margin or budget on an assumption, and `validate` rejects one (Scope Cut #2). A cap says how much work, never what it is worth.

Recording a cap does not resize anything, so between `assume` and `estimate` the workstreams legitimately disagree with it. That window is a **stale warning**, never an invalid plan — a plan nobody can validate while a cap is being recorded is a plan nobody can cap.

Caps render on `Assumptions and risks` through the same six columns as the ownership exclusions and the placeholder volumes. There is no second register.

## Workstream

One per activity of the estimating catalog that has Starting figures; an activity with no row there is not sized yet and `estimate` says so as a warning. `kind` is derived from the catalog rather than stored twice: a `proportional` activity in the `run` phase is `overhead`, everything else is `delivery`. Every workstream has hours above zero, unless the client owns it, in which case every hour on it is zero. The three estimate sections are **derived**: `plan.mjs estimate` replaces them every time it runs, and changes nothing else in the file.

| Field | Type | Rule |
| --- | --- | --- |
| `id`, `name`, `unit` | string | An activity id of the estimating catalog. A tiered or proportional activity has no unit of its own and carries `fixed`. |
| `kind` | string | `delivery` or `overhead`, derived from the catalog's shape and phase. |
| `volume` | number | Above zero. An accepted or edited volume of this file; otherwise the assumed volume of the catalog's Starting figures (1 for an activity sized as a share). |
| `volumeBasis` | string | `document` (a volume of this file) or `placeholder`. |
| `volumeIds` | string[] | The volume that sized it (`document`), or empty. |
| `pendingVolumeIds` | string[] | Optional. Quoted volumes nobody accepted yet; they do not size the workstream. |
| `label` | string | Where the volume came from: `quoted in the documents`, `assumed, no requirement`, `assumed, no volume in the documents`, `assumed, quoted volume not accepted yet`, `assumed, overhead default`. A placeholder label starts with `assumed`. |
| `hoursPerUnit` | object | `{ traditional, aiAssisted }`. Traditional is the rate the ladder resolved. AI-assisted is that rate less the activity's `aiSavingPercent`, and needs a tool or delivery method ON for the workstream (any tool ON, for overhead); with none it equals the traditional rate. |
| `rateBasis` | string | `cases`, `cases-adjusted` or `derived`. Which rung of the rate ladder the traditional hours per unit came from. |
| `caseIds` | string[] | The past projects the rate was measured from. Empty on `derived`, at least one otherwise. |
| `caseCount` | number | `caseIds.length`. |
| `rateAccepted` | boolean | `derived` only. Whether an estimator accepted the rate (a `rates` entry), or the plan is still carrying the catalog's starting figure. |
| `rateQuestion` | string | Present exactly when `rateBasis` is not `cases`: what has to be asked before the rate is ours. |
| `aiSavingPercent` | number | 0 to 90, from the catalog's Starting figures (30 as shipped). 0 means the activity claims no saving. When the AI-assisted rate is below the traditional one this is above zero, and the gap between them is exactly this percentage. |
| `traditionalHours`, `aiAssistedHours` | number | Our portion of the activity, to two decimals. `volume` x the hours per unit, unless the activity is sized as a share or owned by the client. AI-assisted never above traditional. |
| `owner` | string | `us`, `shared` or `client`, see [Who does the work](#who-does-the-work). |
| `wholeHours` | number | The activity sized as if we did all of it, above zero whoever owns it. Equal to `traditionalHours` except on a `client` row. |
| `ownerNote` | string | Optional, and required on a `client` row: why the owner is what it is, from the `owners` decision. |
| `exclusion` | string | Present exactly when `owner` is `client`: the activity named as out of scope, for the proposal. |
| `ownerQuestion` | string | Present when `owner` is not `us`: what has to be settled about who does what. |
| `phase` | string | `discover`, `design`, `build`, `assure`, `launch` or `run`, from the catalog. Phase totals roll up over it. |
| `hours` | object | `{ low, likely, high, spread }`, see [Three-point hours](#three-point-hours). `likely` is `traditionalHours`; `low <= likely <= high`. |
| `share` | number | Proportional activities only. Above 0 and below 1, see [Sized as a share](#sized-as-a-share). An activity of any other shape carries none. |
| `shareBasis` | string | `cases`, `cases-adjusted` or `fallback`. A `fallback` share is a published ratio, so `rateBasis` is `derived`; otherwise the two agree. |
| `shareOf` | string[] | The activities the share was actually taken over. An activity the catalog names but this estimate never sized is not in it. |
| `shareHours` | number | Their `wholeHours` added up, not their portions. `wholeHours` is `share` x this. |
| `band` | string | Tiered activities only. `small`, `medium` or `large`, see [Complexity bands](#complexity-bands). An activity of any other shape carries none. |
| `bandConfidence` | string | `high` when a quoted signal decided it, `medium` when an inferred one did, `low` when nothing did. |
| `bandSignals` | array | Every signal that was in the running: `{ band, quoted, reason, matched, blockId?, requirementId?, volumeId? }`. Empty when the documents said nothing. |
| `bandReason` | string | What the band was read from, in words. |
| `bandQuestion` | string | Present exactly when `bandSignals` is empty: the band is an assumption, so the client is asked. |
| `bandChallenge` | string | Optional. Signals disagreed, the higher band was taken, and this says what the other signals read. |
| `confidence` | string | `low`, `medium` or `high`. A placeholder volume is always `low`. |
| `requirementIds` | string[] | The live (not dismissed) requirements mapped to the work package. |
| `skills` | string[] | The activity's default skill list, from the catalog. Hours are split evenly over it. |
| `clientQuestion` | string | A delivery workstream on a placeholder volume carries the question that would replace it. |

A workstream is **out of date** when the plan moved after the estimate: a volume was accepted for a workstream that still uses the placeholder, or the volume it used was changed or dismissed. That is a warning in `validate` and `summary`, never an error. Run `estimate` again.

## Skills

`{ skillId, name, category, traditionalHours, aiAssistedHours, workstreams }`. Hours by skill: each workstream's hours split evenly over its default skill list, added up per skill. Categories are those of `samples/factors/seed/skills.csv`: delivery, platform, martech and business (change management, content strategy, UX and design, SEO, accessibility, legal and compliance, training). `validate` checks that the skills add up to the workstreams.

## AI plan

The estimate assumes **every available tool is used**. `plan.mjs ai-plan` builds the AI plan for the platform of the estimate (it needs `estimate` first), and the only way to turn something off is an opt-out with a reason and a typed note. The tool never writes an hour. The saving is one percentage per activity from the catalog's Starting figures, and the AI plan decides only whether a workstream is allowed to take it: with nothing ON for that workstream, the AI-assisted rate equals the traditional one.

| Field | Type | Rule |
| --- | --- | --- |
| `platform`, `builtAt` | string | The platform of `estimateBasis`, and an ISO time. |
| `catalog` | object | The estimating version and the CMK and toolkit commits it was built from. |
| `inventory` | object | `{ total, used, on, off, unused }`: every tool the catalogs offer for the platform, how many a workstream uses, how many of those are ON or OFF, how many no workstream uses. |
| `methods` | array | Each delivery method of the estimating catalog: `{ id, default, workstreams, tools, status, prerequisites }`. `status` is `on` unless opted out. |
| `tools` | array | Each tool a workstream uses: `{ id, kind, source, plugin?, assetId?, optIn, workstreams, methods, status }`. `source` is `cmk` (all platforms), `vendor` (a CMK vendor capability of the platform) or `toolkit`. A tool is `on` unless it is opted out, or every delivery method that carries it is off. |
| `optOuts` | array | `{ id, kind, reason, note, at }`. `id` is a tool a workstream uses or a delivery method. `reason` is `not-licensed`, `not-installed`, `client-restriction` or `not-suitable`; `note` is the typed reason and is required. |
| `requirements` | array | One per live requirement: `{ requirementId, workstream, tools, methods, reason?, reasonSource? }`. The tools are the ones the catalog lists for the workstream on the platform that are ON, the methods those that apply to it and are ON. **A tool or a method, or a reason, is required**; the validator rejects an entry with none. When the catalog lists nothing (or all of it is opted out) the tool writes that fact as the reason (`reasonSource: catalog`); a reason typed by a person (`reasonSource: estimator`) is kept on a re-run. |
| `unusedTools` | string[] | Tools the catalogs offer on the platform that the estimating catalog maps to no workstream. This is a gap in the catalog's mappings (widening them is the catalog owner's call), not a decision. |
| `readiness` | array | What must be installed or reached to get the AI-assisted number: `{ kind, item, needs, tools, workstreams }` for the CMK plugin, each vendor asset (opt-in ones must be enabled explicitly), each toolkit plugin and the prerequisites of each delivery method that is ON. |

**Hours.** The "with methods" column of the factors needs a delivery method ON that applies to the workstream; the "with opt-in" column needs an opt-in tool ON in the workstream; with neither, the workstream is at the traditional rate. Opting out therefore sends the hours it supported back to traditional, and `validate` rejects a workstream that takes a column no tool or method supports.

A requirement added after the AI plan has no entry yet: that is a warning in `validate` and `summary` (run `ai-plan` again), never an error.

## Placeholders

The **Starting figures** table of the estimating catalog holds the assumed volume, the starting hours per unit, the AI saving percentage and the default skill list of each activity it covers. Every number in it is a placeholder nobody has measured, and the estimate says so: an activity sized from it lands on the `derived` rung and carries a question. An activity with no row there is not sized at all, and `estimate` reports it rather than inventing a figure.

The tool never invents a volume or an hour: every number is a volume of the plan, a past project in the case library, or a starting figure of the catalog.

## Commands

```bash
node tools/blueprint/plan.mjs assemble "<folder>"                      # writes or adds to <Project>_Plan.json
node tools/blueprint/plan.mjs summary "<plan.json>" --markdown         # the counts shown at the first checkpoint
node tools/blueprint/plan.mjs accept "<plan.json>" --all               # accept every pending requirement and volume (via bulk)
node tools/blueprint/plan.mjs accept "<plan.json>" --workstream content-migration  # one workstream (via walk)
node tools/blueprint/plan.mjs accept "<plan.json>" --ids R-001,R-002 --dismiss R-003
node tools/blueprint/plan.mjs validate "<plan.json>" --blocks ".blueprint/parsed/blocks.json"
node tools/blueprint/plan.mjs estimate "<plan.json>" [--platform aem|aem-eds]   # workstreams, skills, estimateBasis
node tools/blueprint/plan.mjs rate "<plan.json>" --activity component-build --hours 7 --note "Matches the last two pursuits."
node tools/blueprint/plan.mjs owner "<plan.json>" --activity uat-support --set client --note "Their own business testers run it."
node tools/blueprint/plan.mjs assume "<plan.json>" --activity content-migration --cap 5000 --note "The 2019 archive is retired first."
```

`owner` and `assume` record a decision; neither resizes anything. Run `estimate` after either.

`estimate` takes the platform from the plan; `--platform` is for when the documents do not name it (the estimator chose). With neither it stops (exit 1, nothing written). A platform the estimator chose is kept when `estimate` runs again.

```bash
node tools/blueprint/plan.mjs ai-plan "<plan.json>"                     # every tool ON; opt-outs already in the file are kept
node tools/blueprint/plan.mjs ai-opt-out "<plan.json>" --id cdk-loop --reason client-restriction --note "No code leaves the client network."
node tools/blueprint/plan.mjs ai-restore "<plan.json>" --id cdk-loop
node tools/blueprint/plan.mjs ai-report "<plan.json>" --markdown        # opt-outs, readiness, requirements with no tool, unused tools
```

`ai-plan`, `ai-opt-out` and `ai-restore` size the estimate again in the same write, so the hours always follow the tools that are ON. A refused command (no reason, no note, an id nothing uses) writes nothing. `estimate` rebuilds an AI plan that is already in the file for the platform, keeping its opt-outs.

Exit codes: 0 done; 1 invalid input or output (nothing written); 2 usage; 4 the extract produced no requirements (nothing written).
