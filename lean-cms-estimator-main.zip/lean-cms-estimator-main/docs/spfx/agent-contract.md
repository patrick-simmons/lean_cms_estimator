# Agent and app file contract

The offline skill pack (the agent) and the Blueprint app meet only through files in the project folder. This page says who owns which file, what a re-run may write, and how the two sides agree on versions. It came out of the standalone track review of 2026-11-09 (SAPP-014); the pack itself is described in [offline-blueprint-skill-pack.md](offline-blueprint-skill-pack.md).

> **Status.** The file contract and the Node tools that write it exist and are tested. The app reads and decides proposals: the Requirements step lists the pending ones and calls `applyProposal` and `rejectProposal` (SAPP-014). The standalone app also reads the run record and shows its status line and version warning (SAPP-014). The rest of the app side is not yet wired in: `buildBootstrapFiles` is written and tested, but nothing in the web part or the standalone app calls it yet. Sentences below that say what "the app" does for the Prepare for the agent action and the Ask Blueprint note path describe the agreed behaviour once that is wired in.

**The agent proposes, the app decides.** On the first run the agent writes the working file and the sidecar. After that it never rewrites a file that holds a person's decisions. It writes proposals, and the estimator accepts or rejects them in the app.

## Files

| File | Owner | Written by |
| --- | --- | --- |
| `{Project}_Blueprint.json` | The estimator, once it has review state | The agent on the first run only; the app on every review, build and publish. Schema: [working-file.md](working-file.md). |
| `{Project}_Context.json` | Shared, add-only for the agent | The agent writes it on the first run and may add items on a re-run; it never edits or removes an item. The app edits items. Schema: [context-sidecar.md](context-sidecar.md). |
| `{Project}_Proposals.json` | The agent appends, the app decides | The agent on every re-run; the app changes only each proposal's `review`. Schema below. |
| `.blueprint/run.json` | The agent's tools | Every tool, one stage at a time. Schema below. |
| `.blueprint/sources.json`, `.blueprint/expect.json`, `AGENTS.md`, `CLAUDE.md` | The app | `tools/blueprint/prepare-folder.mjs` today; the app's Prepare for the agent action when it is wired in (SAPP-016). `prepare-folder` leaves a hand-edited `AGENTS.md` or `CLAUDE.md` alone unless `--force` is given. |
| `.blueprint/parsed/` | The agent's tools | The parse tool. A working folder; the app does not read it. |
| `.blueprint/extract.json` | The agent (the model) | The extract stage: the model writes it, and the assemble tool reads it. A working file; the app does not read it. |
| `.blueprint/design-sketch.json`, `.blueprint/second-opinion-sketch.json` | The agent's tools | `assemble-drivers.mjs`, from drivers the model proposes and the tool checks against the parsed blocks. Every driver is `pending` and has its quote, names or parts. The tool replaces an untouched file and refuses one with review decisions (exit 3). The app does not read them yet (structured sizing drivers are SPMVP-048); the estimator reads them, and the back-test scores them. |
| Team suppression file (any path) | The team | `tools/blueprint/review-stats.mjs --suppress-out`, from review decisions across projects. Keys only, no client text. `match-library`, `gap-sweep` and `lever-advice` read it with `--suppress` and leave out what it lists; nothing in a project folder changes. |

The optional steps (design sketch, gap sweep, lever advice, second opinion) reach the estimator only as **pending items added to the Context sidecar**, through the same add-only rule as the enrich stage. The items carry a machine-readable `source` marker (`Gap sweep checklist WP-nn`, `Lever advice <id>`, `Second opinion WP-nn`, `Second opinion objection R-nnn`), so a re-run does not propose again what is already in the sidecar in any review status; a dismissal stays a dismissal. None of them writes the Blueprint, a lever, hours or a quantity.

`.blueprint/` is a convention, not a hidden folder. SharePoint syncs it like any other folder.

## Review state

A Blueprint has review state when any of these is true: a requirement whose `review.status` is not `pending`, or that carries an `original` (a person edited it); a question the agent did not write (one that no requirement points at, or that no longer matches its requirement's `questionId`); `revision` above zero; an `estimate`, `handoff` or `published` object; a non-empty `history`, `notes`, `proposals`, `skillSet` or `phasePlan`; a `levers` object. `hasReviewState` in `tools/blueprint/assemble-working-file.mjs` is the one definition. The assemble tool refuses a first-run write over such a file (exit 3, nothing written) and tells the agent to run in proposals mode. It refuses just the same when the existing Blueprint cannot be read or parsed: an unreadable file might hold decisions, so the tool never treats it as empty.

**One rule for the agent:** a Blueprint already in the folder means a re-run. The agent writes `{Project}_Proposals.json` and not the Blueprint, whether or not the Blueprint has review state. The only time it assembles a Blueprint is when the folder has none, or, as an escape, when the estimator asks for a repeat first run over a Blueprint nobody has reviewed (the tool allows that and nothing is lost).

## The proposals file

`{Project}_Proposals.json` is one accumulating file per project. The agent appends new proposals with new ids on every re-run and never changes an existing one; the app changes only `review`. Applied and rejected proposals stay in the file so the agent does not propose the same thing again: the assemble tool skips a candidate whose kind, target and normalised statement match an existing proposal, whatever its status.

### Root

| Field | Type | Rule |
| --- | --- | --- |
| `schemaVersion` | string | `"1"`. |
| `projectId`, `projectName` | string | Copied from the Blueprint. |
| `blueprintRevision` | integer | The Blueprint's `revision` when the agent last ran. |
| `sources` | array | Optional. Start-quality `sources[]` entries (same shape as the Blueprint's) for files the Blueprint does not list yet. When a proposal that cites one is applied, the app copies the entry into the Blueprint's `sources[]`. |
| `runs` | array | Optional. One `{ runId, at, packVersion?, added }` per agent run that appended to the file. |
| `proposals` | array | Required. Items follow the table below. Ids are unique. |

### Proposal

| Field | Type | Rule |
| --- | --- | --- |
| `id` | string | `P-` followed by at least three digits. Unique in the file. |
| `kind` | string | `add` (a requirement the Blueprint does not have), `update` (a changed value for an existing row), `conflict` (a new source disagrees with an existing row). |
| `requirementId` | string | The existing row, `R-###`. Required for `update` and `conflict`; absent on `add`. |
| `existing` | object | Required for `update` and `conflict`; absent on `add`. A snapshot of the row when the agent read it: `statement`, `workPackage`, `coverage`, `reviewStatus` (`pending`, `accepted`, `edited` or `dismissed`) and optionally `question`. The app shows it beside the proposal so the estimator sees what would change. |
| `statement` | string | Not empty. For a conflict it names both values and which file said each. |
| `sources` | array | At least one requirement source (`itemId`, `fileName`, `blockId`, `label`, `location`, `passage`): the **new** citation(s). The existing row keeps its own, so a conflict shows both. |
| `workPackage` | string | A catalog WP id or `unmapped`. |
| `capabilities` | string[] | Derived by the tool from the catalog, as on a first run. |
| `coverage` | string | One of the five coverages. A `conflict` proposal has `conflict`. |
| `question` | string or null | The clarifying question, when the extract stage wrote one; `null` or absent means none. **Required (not blank) on a `conflict` proposal**, which goes to the client as a question. |
| `cause` | object | `{ kind: "file", itemId, fileName }` for a document, or `{ kind: "note", at, text }` for a dated note (the Ask Blueprint path, which is not yet implemented, would write this). |
| `review` | object | `{ status: "pending" }` from the agent. The app writes `{ status: "applied" | "rejected", by, at, byName?, requirementId? }`; `requirementId` on an applied `add` is the row it created. |
| `runId`, `proposedAt` | string | Which run wrote it and when. |

Unknown fields are kept. `tools/blueprint/validate-proposals.mjs` and `proposalsFile.ts` in the web part validate the file; `tools/blueprint/fixtures/proposals-validator-cases.json` is the shared set of cases both must agree on.

### What the app does with a proposal

- **Accept an `add`:** a new requirement with the next `R-` id, the proposal's values and `review: accepted` by the person; a new question when the proposal has one; the cited file's `sources[]` entry copied from the proposals file if the Blueprint lacks it.
- **Accept an `update`:** the target row's `statement`, `workPackage` and `coverage` take the proposal's values, `original` is written if the row had none, the new citation is appended to the row's `sources`, and `review` becomes `edited` by the person. The question is added or its text replaced.
- **Accept a `conflict`:** the target row becomes `coverage: conflict` with the proposal's statement, both citations and the question, `original` written, `review: edited`. The app chooses no winner; the question goes to the client.
- **Reject:** the proposal is marked `rejected`. The Blueprint does not change. It stays in the file, so the agent does not propose it again.

Both actions log who and when on the proposal. `applyProposal` and `rejectProposal` in `src/webparts/blueprint/projects/proposalsFile.ts` implement this; they are pure functions over the file contents. The Requirements step lists the pending proposals (no new top-level step, per the 2026-11-04 session) and `proposalSession.ts` runs each decision: Accept saves the working file first and then marks the proposal applied, Reject writes only the proposals file, and both use the same file tokens as any other save, so a change made elsewhere in the meantime is a conflict, not an overwrite. A proposal that targets a dismissed row is not written by the tool. On apply, `applyProposal` refuses (with a message, changing nothing) a target that has been removed, a target that has been dismissed since the proposal was written, a target whose row no longer matches the proposal's `existing` snapshot (statement, work package, coverage, review status or question), and an `add` whose statement is already a row, so an accept never undoes a person's later decision. The list shows the same message on the card and disables Accept; Reject stays available. Because a rejected proposal is never proposed again, the stale message tells the person to edit the requirement by hand if the change still matters. `tools/blueprint/fixtures/proposals-staleness-cases.json` is the shared set of cases the Node warning and `changedFields` must agree on.

## The run record

`.blueprint/run.json` is written by `tools/blueprint/run-record.mjs` and by the tools that call it. One record per folder; each tool merges its patch.

| Field | Type | Rule |
| --- | --- | --- |
| `schemaVersion` | string | `"1"`. |
| `runId` | string | Kept from the first write of a run; `--reset` starts a new one. It is the run record's own id and is not the `runId` the Blueprint and the proposals file carry. |
| `startedAt`, `updatedAt` | string | ISO 8601. |
| `stage` | string | The last stage reached: `prepared`, `parse`, `extract`, `enrich`, `validate`, `done`. |
| `mode` | string | `first-run` or `proposals`. |
| `pack` | object | `name`, `version`, `layout` (`repo` or `pack`), and from a built pack `commit` and `builtAt`. Describes the pack that wrote the record last: each tool replaces it with its own, so after a pack upgrade the next tool run brings it up to date. |
| `schemas` | object | The schema versions the pack that wrote the record last writes: `blueprint`, `context`, `proposals`, `runRecord`. Refreshed with `pack`. |
| `parseTool` | object | Optional. `name` and `version` of the parse tool. |
| `catalog` | object | Optional. `cmkCommit`, `toolkitCommit`, `estimatingVersion` as pinned on the Blueprint. |
| `stages` | object | Stage name to `{ at, note? }`. |
| `files` | object | What was written: `parsed`, `blueprint`, `proposals`, each with a `path` and counts. |
| `notes` | string[] | Dated one-liners from the tools. |

`stage` is the furthest stage the current pass reached and does not move backwards: a tool that reports an earlier stage than the record holds leaves `stage` alone, and that stage's own entry in `stages` is still refreshed. Two exceptions: a record at `done` starts a new pass on any earlier stage, and `--allow-regress` moves `stage` back on purpose. `--reset` starts a new record (and a new `runId`). An unknown flag exits 2. A record that cannot be read as JSON stops the tool (exit 2) with a message that names the file and suggests `--reset`; the tools never replace a damaged record silently.

`parseRunRecord` in `src/webparts/blueprint/projects/runRecord.ts` reads it, and `runRecordGate` there decides what the project screen does with the result. The project screen shows one status line under the folder, for example `Pack 0.1.0 · Run complete · proposals` (pack version, stage label, and the mode when it is a re-run). Only the standalone app reads the file: it opens `.blueprint/` through the optional `openDirectory` of the folder it was given. The SharePoint web part answers `unavailable` (its library reads cannot open a subfolder), so it shows no status line and blocks nothing.

The record is a hint, so only a version problem blocks. The version is read before anything else in the record, so a pack that adds stages or modes the app has never heard of is reported as a newer version, not as a damaged file. A record that is missing, cannot be read, is damaged or leaves a schema out never blocks (a damaged one, or one that leaves a schema out, gets a plain notice). While the record is loading, nothing is blocked.

## Schema handshake

The pack states the schema versions it writes in `run.json` (`schemas`); the app states the ones it understands in `KNOWN_SCHEMAS` in `runRecord.ts`, and `tools/release/pack.config.json` is where the pack's come from. Both are set by hand when a schema changes. The comparison is per schema, numeric on dotted versions:

- Every schema the record names that the app knows must match. A higher version in the record means the files came from a newer pack: the app says so and does not edit. A lower version means an older pack: the app says so and does not edit until the current pack has run on the folder.
- A schema the app does not know is ignored, and so is the pack version itself: the pack and the app agree on files, not on build numbers.

`checkRunRecordSchemas` implements this. When it finds a mismatch, or the record's own `schemaVersion` is not the one the app reads, the project screen shows the warning and refuses every write: Build estimate, Mark reviewed, the review actions, Accept and Reject on a proposal, saving Context, the skill set, the phase plan, the levers or the Pricer handoff, Publish, and Archive. Reading, the status line and Open folder keep working. Current versions: Blueprint `1`, Context `2`, Proposals `1`, run record `1`.

## What a re-run may read

The agent does not need the whole working file in its context. `tools/blueprint/list-requirements.mjs` prints each row's id, status, statement, work package, coverage, cited block ids and question, which is the "Already extracted" list the extract stage needs. The assemble tool reads the full Blueprint itself to build the proposals. The Context sidecar is passed to the library matcher with `--existing` so it skips library entries already present.

## Decisions

- **One accumulating proposals file**, not one per run. The app has one place to read, and rejected proposals persist so they are not re-proposed. Runs are listed in `runs[]`.
- **The tool, not the model, decides what is a proposal.** The model marks `duplicateOf` and `conflict`; the comparison with the Blueprint (changed, unchanged, dismissed target, already proposed) is code, so a re-run is repeatable.
- **A restated requirement with a new citation is not a proposal.** Nothing changed for the estimator to decide. The new file still appears in the proposals file's `sources[]` when another proposal cites it.
- **`.blueprint/` is visible in the library.** Hidden-by-convention only. Whether people mind is recorded in SAPP-009.
