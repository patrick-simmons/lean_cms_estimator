# Delivery defaults

The delivery defaults are the catalog owner's answers to how a project is staffed and scheduled: the human delivery skill catalog, the phase schedule and its lanes, FTE allocations and ramps, named blended rates by delivery mix, and the libraries of reusable assumptions, dependencies and risks (SPMVP-038). The offline enrich skill reads the libraries through `tools/blueprint/match-library.mjs` (SPMVP-039). Build and migrate hours are **not** split by a skill-mix table — attribution uses the project skill set (even split) when present, or the owner skills of the driver task that binds the package (SPMVP-043).

They do **not** hold hours per unit. Rates come from the case library and the Starting figures of the estimating catalog (story B-12); nothing here sets a number of hours.

**The CSVs in `samples/factors/seed/` are the file.** There was once an `.xlsx` built from them, `Blueprint_Factors.xlsx`, but nothing read it back, so it was a second copy of the same data that could only go stale. Story B-15 deleted it along with `npm run factors:build`. `tools/factors/seed.mjs` reads the CSVs directly and is the only loader. Session notes for the starter numbers are in `samples/factors/SESSION-NOTES.md`.

These are not the publish template (`docs/spfx/workbook-template.md`), which is how a per-project estimate workbook is written.

**Deprecated:** Role mix and Role map. New builds must not depend on them. See [delivery-skills.md](delivery-skills.md) for the skill catalog narrative.

## Files

Each is a CSV in `samples/factors/seed/`, named in `SHEETS` in `tools/factors/seed.mjs`. A CSV with no entry there, or an entry with no CSV, fails the seed tests.

| Sheet | Who owns it | What it holds |
| --- | --- | --- |
| `Skills` | Catalog owner | Human delivery skill catalog (ids used by phases and project skill set) |
| `Phase packs` | Catalog owner | One row per phase of the estimating catalog: duration, dependency, optional lag |
| `Phase allocations` | Catalog owner | FTE by skill per phase template |
| `Phase ramps` | Catalog owner | Optional post-milestone FTE changes |
| `Blended rate` | Catalog owner | Named delivery mixes, hourly rate, assumed country, monthly hours; one row may be `default` |
| `Assumption library` | Catalog owner | Not read by the web part. Reusable assumptions the offline enrich skill proposes (SPMVP-039); the seed CSV is its source |
| `Dependency library` | Catalog owner | Not read by the web part. Reusable dependencies the offline enrich skill proposes (SPMVP-039) |
| `Risk library` | Catalog owner | Not read by the web part. Reusable risks the offline enrich skill proposes (SPMVP-039) |
| `Phase tasks` | Catalog owner | Optional. Tasks and milestones inside a phase template; copied onto the starter phase (SPMVP-042) |
| `Phase task allocations` | Catalog owner | Optional. FTE by skill for a `capacity` task, or a planned-capacity cross-check on a `driver` task (SPMVP-042) |
| `Lanes` | Catalog owner | Tracks that run alongside each other inside a phase, and the activities in each |

Sheet names are matched exactly, case included. SPMVP-018 ships the content shape; SPMVP-012 owns parse and arithmetic. The high-level price is **hours × chosen blended rate**. Weekly hours for phase math = **monthly hours ÷ 4**. Country follows the chosen mix. Blueprint does **not** hold a Pricer rate card.

## Columns (position stable)

Row 1 is the header row. Downstream readers should match columns by **position**, not by header text, so the wording can change but the order and count cannot. Columns to the right of the last defined column are free.

### Skills

| Column | Field | Content |
| --- | --- | --- |
| A | Skill id | Stable id, for example `aem-core`, `pm` |
| B | Name | Display name |
| C | Category | `delivery`, `platform`, or `martech` |
| D | Inference hints | Short keywords for map-based suggestion (optional) |

### Phase packs

| Column | Field | Content |
| --- | --- | --- |
One row per phase of the estimating catalog, in the order work happens: `discover`, `design`, `build`, `assure`, `launch`, `run`. The sheet says how long each phase runs and what it follows. It does not say which activities are in a phase: the estimating catalog already does, and holding the mapping twice meant it could disagree with itself.

| Column | Field | Content |
| --- | --- | --- |
| A | Phase id | A phase of the estimating catalog, for example `discover` |
| B | Name | Display name |
| C | Default duration weeks | Number ≥ 0 |
| D | After phase | Phase id this follows, or blank |
| E | Lag weeks | Whole number of weeks after the prior phase ends; negative overlaps it. Optional: blank, or a workbook without this column, means `0`. A fraction or text is rejected when the workbook is read (`The Phase packs sheet has a Lag weeks value that is not a whole number (<phase id>).`), and so is a value beyond 520 weeks either way (`... outside -520 to 520 (<phase id>).`). A non-zero value is copied onto the starter phase as `lagWeeks`. |

### Lanes

Tracks that run alongside each other inside a phase rather than one after another, so the timeline does not read as a waterfall. A phase with a single track needs no row. Build has two: Engineering and Content, with Content offset behind Engineering.

| Column | Field | Content |
| --- | --- | --- |
| A | Lane id | Stable id, for example `build-engineering` |
| B | Phase id | Must exist on Phase packs |
| C | Name | Display name, shown after the phase name |
| D | Offset weeks | Weeks after its phase starts that this lane starts; `0` starts with the phase |
| E | Duration weeks | Number ≥ 0 |
| F | Activities | Activity ids of the estimating catalog, separated by `;`. An activity belongs to at most one lane |

### Phase allocations

| Column | Field | Content |
| --- | --- | --- |
| A | Phase id | Must exist on Phase packs |
| B | Skill id | Must exist on Skills |
| C | FTE | Number ≥ 0 (1.0 = full time for the phase duration) |

### Phase ramps

| Column | Field | Content |
| --- | --- | --- |
| A | Phase id | Phase whose allocation changes |
| B | Skill id | Skill to ramp |
| C | After milestone | Milestone id, for example `design-signoff` |
| D | FTE | FTE after the milestone for the remainder of the phase (or until another ramp) |

### Phase tasks

Optional sheet (SPMVP-042). A workbook without it, or with it empty, has no starter tasks. The seed `phase-tasks.csv` ships with the header row only, so starter hours do not change. Rows are read in sheet order, and a row with every cell blank is skipped. The contract for each field is the task table in [working-file.md](working-file.md#phase-task).

| Column | Field | Content |
| --- | --- | --- |
| A | Phase id | Required. Must exist on Phase packs |
| B | Task id | Required. Unique on the sheet, and unique across the plan once copied (tasks and milestones alike) |
| C | Name | Required |
| D | Kind | `task` or `milestone`; blank means `task` |
| E | Start week | Whole number from 1 to 520, week within the phase; blank means 1 |
| F | Duration weeks | Number from 0 to 520, or blank |
| G | Basis | `driver`, `capacity` or `fixed`; required for a task, blank for a milestone |
| H | Work package id | Required when basis is `driver`. Two driver tasks may not name the same package |
| I | Owner skills | Skill ids from the Skills sheet, separated by `;` |
| J | Hours | Number ≥ 0. Required when basis is `fixed`; blank for a milestone |
| K | Deliverable | Free text, for example a milestone's gate label |
| L | Scope | Free text; overrides the phase scope for this task |
| M | Calendar-bound | `yes` or blank |

The web part rejects a bad row when it reads the workbook, naming the sheet and the row:

- `The Phase tasks sheet row N names phase "x", which is not on the Phase packs sheet.`
- `... repeats task id "x" (first on row M).`
- `... names owner skill "x", which is not on the Skills sheet.`
- `... has a Start week value that is not a number.` (likewise Duration weeks and Hours)
- `... has a Calendar-bound value that is not yes or blank.`
- `... binds work package "component-build" already bound on row M.`
- `... has no Phase id.` (likewise Task id and Name)
- `The Phase tasks sheet row N (<task id>): <field>: <message>.` for the field rules, such as a missing basis, a `driver` task with no work package, a `fixed` task with no hours, a start week below 1, a capacity task with no allocation row, or a milestone with a basis, hours or an allocation row. The messages are the ones `workingFile.ts` gives a plan task.

### Phase task allocations

Optional sheet (SPMVP-042), read with Phase tasks.

| Column | Field | Content |
| --- | --- | --- |
| A | Task id | Must exist on Phase tasks |
| B | Skill id | Must exist on Skills |
| C | FTE | Number ≥ 0 |

A `capacity` task needs at least one row here. A milestone may have none. Errors read `The Phase task allocations sheet row N names task "x", which is not on the Phase tasks sheet.`, `... names skill "x", which is not on the Skills sheet.` and `... has an FTE that is not a number of 0 or more.`

The Phase ramps sheet keeps its columns. Its After milestone values will name milestone task ids from Phase tasks once ramps use them; nothing checks that link yet.

### Blended rate

One row per named delivery mix. No cost-rate column. SPMVP-012 prices with the chosen mix (default row when the estimator has not picked one).

| Column | Field | Content |
| --- | --- | --- |
| A | Delivery mix name | Display name (`Onshore-led`, `Balanced`, `Offshore-led`, …) |
| B | Hourly blended rate | Number; bill-side blended rate only |
| C | Default | `yes` on exactly one row, or blank |
| D | Country | Assumed primary country for this mix |
| E | Monthly hours | Monthly hours for that country |

### Assumption library

| Column | Field | Content |
| --- | --- | --- |
| A | Library id | `asm-` plus lowercase kebab-case, unique on the sheet |
| B | Platform | `all`, `aem`, `aem-eds` or `aep` |
| C | Match hints | Short keywords separated by semicolons, with no empty entry. Blank only when Platform is `all`, meaning always proposed |
| D | Statement | The assumption |
| E | Category | `scope`, `architecture`, `dependency`, `resource`, `delivery` or `estimate` |
| F | Confidence | `low`, `medium` or `high` |
| G | If it fails | What changes if the assumption proves wrong |

### Dependency library

| Column | Field | Content |
| --- | --- | --- |
| A | Library id | `dep-` plus lowercase kebab-case, unique on the sheet |
| B | Platform | As on Assumption library |
| C | Match hints | As on Assumption library |
| D | Statement | The dependency |
| E | Owner | Team or role that owns it |
| F | Needed | What is needed |
| G | Impact if missing | What happens if it is not available |
| H | Priority | `high`, `medium` or `low` |
| I | Required week | Whole number of 1 or more counted from project start, or blank |

### Risk library

| Column | Field | Content |
| --- | --- | --- |
| A | Library id | `risk-` plus lowercase kebab-case, unique on the sheet |
| B | Platform | As on Assumption library |
| C | Match hints | As on Assumption library |
| D | Statement | The risk |
| E | Impact | What happens if it occurs |
| F | Likelihood | `low`, `medium` or `high` |
| G | Severity | `low`, `medium` or `high` |
| H | Mitigation | What to do about it |

The three library sheets match the contract in [context-sidecar.md](context-sidecar.md#hub-libraries-v2-draft). An entry is one platform, so a pair of entries covers `aem` and `aem-eds` where the wording differs. Entries are generalised from delivery experience, with no client text. They hold no cost, rate or contingency, and no `commercial` category (licences are dependencies).

## Values

- Pilot platforms are `aem` and `aem-eds` only (see estimating catalog front matter).
- Library platforms are `all`, `aem`, `aem-eds` and `aep` (`aep` is the first non-pilot platform). The list is `KNOWN_PLATFORMS` in `tools/factors/validate-libraries.mjs`. To add a platform, add its id there and add its library entries.
- `loadSeed` runs the library check and throws when it fails, so no tool sees a bad library. The error names the file and the line of the row for a blank, duplicate, wrong-prefix or non-kebab-case id, an unknown platform, blank hints on a non-`all` entry, an empty hint entry such as `a;;b`, a blank statement or default, an out-of-range value, or a bad Required week. It also fails for a library sheet with no entries, a library sheet that is missing or has no check, and a CSV with a quote inside an unquoted field or text after a closing quote. Zero-width characters count as blank. Seed header text must match the sheet definitions exactly even though readers match by position.
- `loadSeed` also runs the task check (`tools/factors/validate-phase-tasks.mjs`, SPMVP-042) and throws when it fails. The error reads `<file>: row N: ...` and covers a phase id not on `phase-packs.csv`, a skill id not on `skills.csv`, a work package id that is not an activity of the estimating catalog, a task id not on `phase-tasks.csv`, a repeated task id, a bad kind, basis, start week, duration, hours or calendar-bound value, a driver task without a package or two on one package, a capacity task with no allocation row, and a milestone with a basis, hours or allocation row. Keep it in step with the task rules in `workingFile.ts`.
- Starter confidence is `low` so the challenger in SPMVP-012 will surface it.
- Starter blended rates may be derived from a real Pricer Details export (hours-weighted bill averages by mix). Factor hours and phase FTEs remain hypotheses until calibrated.
- Do not put cost rates in these files. The `AI allowance` sheet held a monthly non-labour amount and was removed in story B-15: nothing read it, and a cost figure is the kind of field the commercial scope cut bans.
- CMK capability ids never appear as Skill ids.

## Hybrid sizing reminder

| Effort source | Typical use |
| --- | --- |
| Phase packs | How long each phase runs and what it follows; PM capacity over calendar |
| Activities × drivers | Build, migrate, integrations, components, locales, … |
| Project skill set | Even-split build package hours across confirmed skills (no hub Skill mix) |
| AI levers | Per project (SPMVP-034): one saving percentage per activity comes off the hours per unit, and only while the project has a capability the estimating catalog links to that activity ON; the traditional rate is kept to show traditional vs AI-assisted hours |
| Skill schedule | Unify phase FTE windows (pre-ramp) + spread WP skill hours on the build window; publish Phases + Skill schedule sheets |

## Changing them

Edit the CSV under `samples/factors/seed/` and commit it. There is no build step and nothing to regenerate: `loadSeed` reads the CSVs, and it runs the library and task checks on the way in, so `npm run verify` fails on a bad row rather than a tool failing later.

To add a sheet, add its entry to `SHEETS` in `tools/factors/seed.mjs` and its CSV in the same commit; a test asserts the two sets match exactly.
