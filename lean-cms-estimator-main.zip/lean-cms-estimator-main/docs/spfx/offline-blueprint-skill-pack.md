# Offline Blueprint skill pack

SPMVP-023 ships an in-repo Agent Skills pack that approximates production Parse → Extract+map → Enrich → Validate **without** Azure Functions or Foundry. Use it when Copilot Studio / Foundry extraction is unavailable, and as the extraction path of the standalone app. The same skill bodies are meant to become Studio instructions later.

The standalone track (SAPP-013 to SAPP-017) made the pack deterministic where code can be, safe to re-run, and installable without this repository:

- Parsing is code: `tools/blueprint/parse-local.mjs` reuses the Azure function's document readers (SAPP-013).
- A re-run never rewrites a reviewed Blueprint; it writes `{Project}_Proposals.json`, and every tool records its stage in `.blueprint/run.json` (SAPP-014, [agent-contract.md](agent-contract.md)).
- A release build turns the skills and tools into a portable pack (install guide: `docs/standalone/agent-skill-pack.md` in the repository, `README.md` at the root of a built pack; SAPP-015).
- A folder is prepared for the agent with `AGENTS.md` and a source selection, and the run record is read back. The tools for this exist (`prepare-folder.mjs`, `run-record.mjs`). The standalone app shows the run record (pack version, run state, a version warning that blocks edits); the Prepare for the agent action (SAPP-016) is not yet wired in.
- What code can check is a set of local commands (CI is manual-only, see Checks); the rest is a checklist a person runs (`docs/standalone/agent-run-evaluation.md` in the repository, `docs/agent-run-evaluation.md` in a built pack; SAPP-017).

> **Status.** The skills, Node tools, file contract and pack build described here exist and are tested. The proposals review list is in the Requirements step, and the standalone app shows the run-record status line and version warning. The rest of the app side (the Prepare for the agent action) is not yet wired into the web part or the standalone app. Where this page says the app shows or does something, that is the agreed behaviour once it is.

## Skills

Committed under `.claude/skills/` (discovered by Cursor and Claude Code):

| Skill | Role |
| --- | --- |
| `blueprint-offline` | Orchestrator: bootstrap, mode (first run or re-run), order, catalogs, run record, guardrails |
| `blueprint-parse` | Runs the local parse tool and reads its output; never the raw files |
| `blueprint-extract-map` | Extract JSON from parsed blocks, then `assemble-working-file.mjs` (first run) or `--mode proposals` (re-run) |
| `blueprint-enrich` | v2 `{Project}_Context.json`: unknowns become linked assumptions; assumptions, dependencies and risks are proposed from the hub libraries (SPMVP-039); add-only on a re-run |
| `blueprint-design-sketch` | After extract: proposes one sizing driver per work package (pages, locales, sites, content types, integrations) with its quote, names or parts, checked by `assemble-drivers.mjs`; written to `.blueprint/design-sketch.json` as pending; no driver where sources disagree |
| `blueprint-gap-sweep` | After enrich: work packages with no requirement become pending delivery unknowns with a working assumption, through `gap-sweep.mjs`; never a requirement; add-only on a re-run |
| `blueprint-lever-advice` | After enrich: opt-in assets and delivery methods the documents give a reason to enable (a Figma link, a site to migrate, a stated AEM migration) become pending working assumptions with a quote, through `lever-advice.mjs`; the estimator turns the lever on in the app; add-only on a re-run |
| `blueprint-second-opinion` | Optional: a separate agent re-counts the drivers blind and a challenger argues against accelerated claims; `second-opinion.mjs` turns disagreements and upheld objections into pending unknowns |
| `blueprint-validate` | All validators, then the run record is closed |
| `blueprint-infer-skills` | Propose catalog skill ids for project `skillSet` (SPMVP-030; optional after validate) |

## Catalogs to attach

- `docs/catalogs/estimating-catalog.md`
- `docs/catalogs/cmk-capability-catalog.md`
- `docs/catalogs/toolkit-capability-catalog.md`

Pins land on Blueprint `catalog` as `cmkCommit`, `toolkitCommit`, and `estimatingVersion` (**without** a `v` prefix); the assemble tool takes them from the estimating catalog's front matter unless flags override them. The built pack carries a snapshot and records the pins in `pack.json`; when a hub folder has a newer estimating catalog, the orchestrator prefers it and says so.

## Extraction instructions

The extraction system message and response format live with the extract skill as versioned files: `.claude/skills/blueprint-extract-map/references/system-message.md` and `response-format.md`. They started as the Azure function's drafts under `.cdk/SPMVP-008/` (a working-notes folder that is not in git) and are now written for the offline agent: the work package list comes from the estimating catalog, the platform list from the CMK catalog, and what the assemble tool does with each field is stated. Edit the shipped files in this repository. The pack build does not compare them with the old drafts in `.cdk/`, which are the pre-rewrite originals and always differ; it stops only if a shipped file is missing.

## Private customer pack (manual acceptance)

Per SPMVP-014, **do not commit client text**. Keep the evaluation / customer pack in a private path outside the repo and outside the pack, for example:

```text
../customer-packs/<account>/<opportunity>/
```

Run the pack against that folder; it writes `{Project}_Blueprint.json`, `{Project}_Context.json` and `.blueprint/` beside the sources. Upload the Blueprint into the opportunity folder and open it in the web part, or open the folder in the standalone app, to confirm it is not malformed. The checklist is in `docs/standalone/agent-run-evaluation.md` (`docs/agent-run-evaluation.md` in a built pack).

In the repository, the Northwind fixtures under `samples/review/`, the Blueprint and Context samples under `samples/offline/` (including the synthetic AEM pair), the synthetic source documents under `samples/sources/` and the replayed run under `samples/agent-run/` are smoke tests only.

## Cursor path

1. Open the project folder in Cursor, with the skills installed (this repository as the workspace, or the installed pack: see `docs/standalone/agent-skill-pack.md`).
2. If the app did not prepare the folder, run `node tools/blueprint/prepare-folder.mjs <folder> --project "<Project>" --prompt`.
3. Invoke **blueprint-offline** (or paste the starter prompt).
4. Confirm the validators the agent ran:

```bash
node tools/blueprint/validate-working-file.mjs path/to/{Project}_Blueprint.json
node tools/blueprint/validate-context.mjs path/to/{Project}_Context.json --blueprint path/to/{Project}_Blueprint.json
node tools/blueprint/validate-proposals.mjs path/to/{Project}_Proposals.json --blueprint path/to/{Project}_Blueprint.json --strict
```

Convenience scripts in `package.json`: `npm run blueprint:parse -- <folder>`, `npm run blueprint:prepare -- <folder> --project "<Project>"`, `npm run blueprint:assemble -- …`, `npm run blueprint:match-library -- <path>`, `npm run blueprint:validate-working-file -- <path>`, `npm run blueprint:validate-context -- <path>`, `npm run blueprint:validate-proposals -- <path>`, `npm run blueprint:run-record -- <folder> --show`.

## Claude Code path

1. Open the project folder in Claude Code (project skills load from `.claude/skills/`, user skills from `~/.claude/skills/`, or the pack as a plugin).
2. Prepare the folder if the app has not.
3. `/blueprint-offline`.
4. Run the same validators as above.

## Claude.ai Projects path

1. Create a Project; upload the skill `SKILL.md` bodies (or paste orchestrator + stages), the two extraction reference files and the three catalogs.
2. Upload the parse tool's output (`.blueprint/parsed/`) rather than the raw files, so citations are the tool's.
3. Instruct the model to follow the orchestrator stage order and to call out when a local `node tools/blueprint/…` step is required; run those CLIs on a machine that has the pack or the repo.
4. Validate with the CLIs before treating the run as done.

## Node tools

| Tool | Purpose |
| --- | --- |
| `tools/blueprint/parse-local.mjs` | Parse a folder's sources into blocks with the function's readers (Office) and pdf.js (PDF text layer); writes `.blueprint/parsed/` and a manifest of what was not read or skipped. Exit 3 when nothing is selected, 4 when no block was produced (`--allow-empty` overrides), 2 for an unsafe `--out` or `--select` |
| `tools/blueprint/prepare-folder.mjs` | Write the agent bootstrap (`AGENTS.md`, `CLAUDE.md`, `.blueprint/sources.json`, `.blueprint/expect.json`) and print the starter prompt; leaves a hand-edited `AGENTS.md` or `CLAUDE.md` alone unless `--force` |
| `tools/blueprint/assemble-working-file.mjs` | Capability derivation + assemble; `--mode proposals --existing` on a re-run; refuses (exit 3) to overwrite review state or a Blueprint it cannot read; exit 4 when the extract yields nothing; validates what it writes and writes it in one step |
| `tools/blueprint/write-file-atomic.mjs` | Helper the tools use to replace a file in one step (temporary file, then rename) |
| `tools/blueprint/list-requirements.mjs` | Compact list of a Blueprint's rows for the "Already extracted" message |
| `tools/blueprint/run-record.mjs` | Read or update `.blueprint/run.json` |
| `tools/blueprint/validate-working-file.mjs` | Blueprint field-path validate |
| `tools/blueprint/validate-context.mjs` | Context field-path validate; `--blueprint` also checks `R-n` and `Qn` references |
| `tools/blueprint/validate-proposals.mjs` | Proposals field-path validate; `--blueprint` checks targets and cited files (warnings), and `--strict` makes those mismatches errors |
| `tools/blueprint/match-library.mjs` | Lists hub library entries that fit a Blueprint (enrich) |
| `tools/blueprint/assemble-drivers.mjs` | Checks proposed sizing drivers against the parsed blocks and writes `.blueprint/design-sketch.json`; `--check` re-validates a written file; exit 3 over review decisions, 4 when no driver is valid |
| `tools/blueprint/review-stats.mjs` | Reads the review decisions across project folders and reports kept and rejected rates per library item, per gap and lever advice, and per proposal kind; writes a keys-only suppression file with `--suppress-out`; lists accepted statements worth adding to the libraries |
| `tools/blueprint/suppression.mjs` | The suppression file format, shared by `match-library`, `gap-sweep` and `lever-advice` (`--suppress <file>`) |
| `tools/blueprint/lever-advice.mjs` | Finds evidence in the parsed blocks for opt-in assets and delivery methods the catalog offers on the project's platform, and prints each with its reason, quote and a ready pending assumption (`--markdown` for the report); reads `tools/blueprint/data/lever-evidence.json` |
| `tools/blueprint/second-opinion.mjs` | Compares the design sketch with a blind second sketch, checks the challenger's objections against the blocks, and prints ready pending unknowns (`--markdown` for the report) |
| `tools/blueprint/driver-quantity.mjs` | The rule Build uses to read a quantity from a requirement statement (first number), shared by the tools |
| `tools/blueprint/gap-sweep.mjs` | Lists work packages with no requirement as ready pending unknown and assumption items (gap sweep); reads `tools/blueprint/data/implied-scope.json` |
| `tools/blueprint/rank-questions.mjs` | Orders open questions and unknowns by what the answer would touch and prints the client clarification list (`--markdown`) |
| `tools/blueprint/citation-label.mjs` | Citation labels (same rules as the function) |
| `tools/release/build-skill-pack.mjs` | Build the portable pack; `tools/release/check-skill-pack.mjs` scans it |
| `tools/samples/synthetic-sources.mjs` | Regenerate the synthetic source documents |
| `tools/samples/agent-run-sample.mjs` | Replay the agent run with the tools and refresh `samples/agent-run/` |

The parse tool needs the function's readers built (`npm --prefix function run build`) when run from the repository. The pack bundles them.

Schema docs: [working-file.md](working-file.md), [context-sidecar.md](context-sidecar.md), [agent-contract.md](agent-contract.md).

## Re-runs

The first run on a folder (no Blueprint in it) writes the Blueprint and the sidecar with every row pending. After that, a Blueprint in the folder means a re-run, and the agent never writes the Blueprint again; the assemble tool backs this up by refusing (exit 3, nothing written) a first-run write over a Blueprint that has review state (the estimator reviewed anything, or built, published, or edited the skill set, phases or levers) or that it cannot read. A repeat first run over a Blueprint nobody has reviewed is allowed. A re-run:

1. The extract stage lists what exists with `list-requirements.mjs`, extracts from the new sources, and marks restatements and disagreements with `duplicateOf`.
2. `assemble-working-file.mjs --mode proposals` compares the result with the Blueprint and appends to `{Project}_Proposals.json`: `add`, `update` and `conflict` proposals with the new citation and a snapshot of the existing row. Unchanged rows produce nothing; a row that matches a dismissed requirement is skipped; anything already proposed is not proposed again.
3. The enrich stage adds to the sidecar only (`--existing`).
4. The app shows the proposals inside the Requirements step; accept applies the change and logs who and when, reject marks it rejected so it is not proposed again. A proposal that no longer applies (the row was edited, dismissed or added by hand since the agent read it) is shown with the reason and cannot be accepted, only rejected.

`samples/agent-run/` shows a complete first run, a review and a re-run.

## Enrich v2

`blueprint-enrich` writes a schema version 2 sidecar. The model reads the parsed blocks and judges; the matcher does the library lookup, so proposals do not depend on what the model remembers.

1. **Unknowns first.** Each delivery unknown gets one working assumption with an `ifFails`, linked by `refs`. Numbers the documents do not give stay blank.
2. **Library proposals from code.** `node tools/blueprint/match-library.mjs <Project>_Blueprint.json` reads the assumption, dependency and risk library CSVs from `samples/factors/seed/` and prints candidates as JSON. The seed is validated on load, so a broken library stops the run instead of producing proposals.
   - **What it matches.** Entries whose platform is `all` or the Blueprint's platform, and whose match hints appear in the requirement statements or question text. Matching is case-insensitive, ignores punctuation and is lightly stemmed (plural, `-ing` and `-ed` forms match). The words of a hint must be adjacent and in order within one requirement or one question. Dismissed requirements and their questions are skipped, and source passages are not read. An entry with no match is not listed unless it is always-propose (platform `all`, blank hints).
   - **Platform.** The Blueprint's `platform.id` is used when it is `aem`, `aem-eds` or `aep`. Any other id lists only the `all` entries. `--platform` overrides.
   - **Each candidate** shows the matching hints, the requirement and question ids that matched, and an `item` in sidecar shape with the library defaults, `libraryId`, `review: { "status": "pending" }`, and `requiredWeek` only when the library carries one. The skill adds ids and `refs`.
3. **Cap and order.** At most 8 library proposals per list (`--max`). Dependencies are ordered by priority, risks by derived level, assumptions by confidence with the least certain first; ties go to more matched hints, then the library id. The output reports how many candidates were cut.
4. **Judgement stays with the model and then the estimator.** The skill keeps the candidates the documents support, copies their defaults unchanged, and writes a risk of its own only with document evidence. Nothing is accepted by the skill.
5. **Re-runs add only.** `--existing <Project>_Context.json` skips library entries already in the sidecar. Existing items are never edited or removed.
6. **No assumption possible.** A note in the run summary, not a field in the file, names any unknown the skill could not cover.

The synthetic AEM project under `samples/offline/` (`Synthetic_AEM_Blueprint.json` and `Synthetic_AEM_Context.json`) shows the result and is checked by `tools/blueprint/match-library.test.mjs`.

## Design sketch

Build sizes a package from the first number in a requirement's statement, so "four locales" or a list of integrations gives it nothing. `blueprint-design-sketch` reads the parsed blocks the way the CMK design skills count (pages to migrate, locales, sites, content types) and proposes one driver per work package.

1. The model writes a JSON list of drivers; `node tools/blueprint/assemble-drivers.mjs --input <json> --blocks .blueprint/parsed/blocks.json --out .blueprint/design-sketch.json --blueprint <Project>_Blueprint.json` checks each one.
2. **Every number carries its evidence.** `stated`: a quote of at least two words copied from a cited block that contains the number (digits, or a number word up to twenty); words and figures are matched whole, so "12" is not found in "2012" and a bare "6,400" is not a quote. `counted`: named items, each found in a cited block, as many as the quantity. `summed`: parts, each with its own quote, adding up to the quantity. A driver that fails is rejected with the reason and is not written. The unit comes from the estimating catalog, and a different one is rejected.
3. **No winner.** One driver per package. Where two sources give different figures, the skill writes no driver and names both in the run summary.
4. **Pending proposals.** The file holds `D-nnn` drivers with `review: { "status": "pending" }`. No hours, weeks or dates. The app does not read the file yet (structured sizing drivers are SPMVP-048), so the estimator reads it, and `tools/eval/backtest.mjs --sketch` scores it against a past estimate. The tool's summary lists, per package, the sketch quantity beside the one Build takes from the requirement text.
5. **Re-runs** replace an untouched file and refuse one with review decisions (exit 3). `assemble-drivers.mjs --check` re-validates a written file and also fails when the sources change underneath it.

`samples/eval/synthetic-aem-design-input.json` and `synthetic-aem-design-sketch.json` show the sample (as of the first run, before the addendum). Against the synthetic reference, the sketch lowers the back-test quantity error from 80% to 40% (`samples/eval/suite-sketch.json`).

## Decision feedback

Every review click is a signal about what the agent proposes. `review-stats.mjs` reads them across projects, so the agent learns what the team keeps rejecting and what it keeps accepting.

```bash
node tools/blueprint/review-stats.mjs <folder> [<folder> ...] [--min-decisions 3] [--min-projects 2] [--reject-rate 0.75] [--suppress-out <file>] [--markdown]
```

- **What it reads.** In each project folder: `<Project>_Context.json` (the four lists with `review.status`) and `<Project>_Proposals.json` (`kind` with `review.status`). A folder with no Context file is searched one and two levels down, so you can pass a folder of project folders. An unusable file is skipped with a `warning:` line and counted in `skippedProjects`. Pending is not a decision. Accepted and edited count as kept, dismissed as rejected; for proposals, applied is kept and rejected is rejected.
- **What it reports.** `items` (per library id, and per gap sweep, lever advice and second opinion marker: projects, kept, edited, rejected, pending and the rates), `proposalKinds` (add, update, conflict), `suppress` and `libraryCandidates`.
- **Stop re-proposing.** An item is suppressed when it has at least `--min-decisions` decisions in at least `--min-projects` projects and `--reject-rate` or more of them are rejections. A project is one vote per key, however many of its items carry it (a gap puts its marker on an unknown and an assumption), and one rejected item makes the project's vote a rejection. `--suppress-out` writes the file (keys only: a library id or a `source` marker, never client text); a file already there is extended, never narrowed, and one that cannot be read stops the run, so delete it to start over. Keys are checked on load: a gap sweep key looks like `Gap sweep checklist integrations`, a lever advice key like `Lever advice <lever id>`. Pass it as `--suppress <file>` to `match-library.mjs`, `gap-sweep.mjs` and `lever-advice.mjs`: each leaves out a suppressed item as it does one already in the sidecar but counts it under `suppressed`, not `skipped` or `alreadyProposed`, so the estimator can still add it by hand, and deleting the file brings everything back. Keep the file with the team's shared material, not in a client folder.
- **Items worth adding.** `libraryCandidates` lists agent-written items that did not come from a library, with the same statement accepted unchanged in at least `--min-projects` projects. They hold project text, so they are printed and never written to the suppression file. Whether one becomes a library entry is a person's decision.
- **Second opinion markers are reported, not suppressed**, because that step is optional and its markers name a package or a requirement in one project.

`tools/blueprint/review-stats.test.mjs` covers the rates, the thresholds and the three tools that honour the file.

## Lever advice

The AI levers tab holds the opt-in assets and delivery methods the team assumes for a project (SPMVP-034), and they change how fast a package is sized. The app's **Suggest levers** works from what the requirements map to. `blueprint-lever-advice` works from the documents and runs after enrich.

1. `node tools/blueprint/lever-advice.mjs --blueprint <Project>_Blueprint.json --blocks .blueprint/parsed/blocks.json --existing <Project>_Context.json` reads `tools/blueprint/data/lever-evidence.json` (a lever id, the words that point to it and a reason with no numbers) against the parsed blocks.
2. The evidence is looked at first: a lever with no signal word in a block is `noEvidence` and nothing else. A lever with evidence is advised only when the estimating catalog offers it on the project's platform (an opt-in asset through its Capabilities row, a delivery method that is not already on by default; a lever in both tables counts as a method, or as an asset when the method is on by default). The platform id is compared trimmed and in lower case. The quote is the line of that block. Evidence for a lever the catalog does not offer here is listed as `notOffered`, not advised. A word that is only part of another word does not match.
3. Each advised lever has a ready pending working assumption (`source: "Lever advice <id>"`, `category: "delivery"`, `confidence: "low"`) with the reason, the quote and, for a method, its prerequisites. The skill keeps the real ones and adds the ids.
4. **The estimator confirms twice**: the assumption in review, then the lever itself on the AI levers tab. The tool never writes the working file's `levers`, so no hour moves until the estimator switches the lever on. A lever whose packages have no requirement yet is flagged, because it changes nothing until one exists.
5. An advised lever already in the sidecar, in any review status, is not advised again, so a dismissal stays dismissed.

`tools/blueprint/lever-advice.test.mjs` checks that every lever in the evidence file is in the catalog and that nothing carries a number or a duration. Add a lever by adding an entry to the evidence file.

## Second opinion

`blueprint-second-opinion` follows the ADR pattern (a blind researcher and an adversarial challenger) and is optional, because it costs two more agent runs.

1. **A blind second read.** A separate agent counts the sizing drivers from `.blueprint/parsed/blocks.json`, the catalog table and a short brief printed in the skill (not the design-sketch skill file, which tells its reader to open the Blueprint), and never sees the Blueprint, the first sketch or the Context. `assemble-drivers.mjs` checks its drivers into `.blueprint/second-opinion-sketch.json`. The tools cannot prove the read was blind; the skill requires a fresh subagent or session and says to skip the step, and say so, when none is available.
2. **A challenger.** Another pass argues against each `accelerated` requirement in one of six categories (custom integration, unclear scope, client dependency, legacy source, regulated or security, novel work). An objection is kept only when it names a live accelerated requirement and carries a quote that is in a cited block; it may not state hours, days, weeks or months.
3. **Compare.** `node tools/blueprint/second-opinion.mjs --blueprint <Project>_Blueprint.json --first .blueprint/design-sketch.json --second .blueprint/second-opinion-sketch.json --blocks .blueprint/parsed/blocks.json --objections <file> --existing <Project>_Context.json` prints, per package, agree, disagree (different counts) and one-sided (one read found a count). Both sketches are re-checked against the blocks first. The tool refuses the same file as both reads (exit 1), skips a driver the estimator dismissed in the first sketch, and warns when the two reads are identical, which usually means the second agent was not blind.
4. **Disagreements become pending unknowns, never a changed count.** Each disagreement and each kept objection carries a ready delivery unknown with `source: "Second opinion WP-nn"` or `"Second opinion objection R-nnn"`. The agent adds the id and writes it add-only; an item already in the sidecar, in any review status, is not proposed again. The app computes the challenger notes itself, so this step does not write them: the unknowns are where the estimator sees the disagreement. The question list ranks them with two extra points.
5. **Measure.** `tools/eval/backtest.mjs --second` (or `secondSketch` in a suite case) reports the second read's quantity error and, where the reads differ, which was closer to the reference. How often an objection holds up is the share of its unknowns the estimators accept, which `review-stats.mjs` reports.

`samples/eval/synthetic-aem-second-input.json`, `synthetic-aem-second-sketch.json` and `synthetic-aem-objections.json` show a second read that misses one integration (4 against 3) and two objections that hold up; `samples/eval/suite-second.json` scores them.

## Gap sweep

`blueprint-gap-sweep` runs after enrich and adds to the sidecar. A bid is often short of requirements because the documents never say, not because the scope is small; extraction cannot cite what is not written.

1. `node tools/blueprint/gap-sweep.mjs <Project>_Blueprint.json --existing <Project>_Context.json` checks every package in the estimating catalog against `tools/blueprint/data/implied-scope.json`. A package with a live requirement is covered, and one the estimator dismissed is never a gap.
2. A **usual** package (discovery, content modeling, component build and review, SEO, QA, environments, UAT and training) with no requirement is always a gap. A **signalled** package (integrations, migration, search, localization, multisite, headless) is a gap only when one of its signal words appears in a live requirement or question that belongs to another package. The same stemmed matching as the library matcher applies.
3. Each gap carries a ready pending delivery unknown and a pending scope assumption with `confidence: low`, `ifFails` and no numbers; both carry `source: "Gap sweep checklist WP-nn"`. The skill keeps or rejects each gap against the parsed blocks and adds the ids and `refs`.
4. **Why not a requirement.** A requirement must cite a document and a checklist is not one, so the estimator reads the pair and adds a requirement or asks the client. Nothing is written to the Blueprint.
5. **Re-runs.** A gap whose `source` is already in the sidecar on an unknown or an assumption, in any review status, is not proposed again, so a dismissal is kept.

`tools/blueprint/gap-sweep.test.mjs` checks that the checklist matches the catalog's work packages and names.

## Client clarification list

The orchestrator ends a run with `node tools/blueprint/rank-questions.mjs <Project>_Blueprint.json --context <Project>_Context.json --markdown`. The tool ranks by a fixed score, so the order is the same on every run and the estimator can see why:

| Points | When |
| --- | --- |
| 1 | Every item |
| 3 | The requirement is a conflict between sources |
| 2 | The requirement is flagged as a question |
| 2 | The wording asks for a quantity or a scope (how many, number of, in scope) |
| 2 | The requirement already states a figure, which is what sizes its package today |
| 1 each, up to 3 | Other live requirements in the same package |
| 3 | An unknown from the gap sweep, while no live requirement sits in that package |
| 3, 2 or 1 | Only when the Blueprint holds an estimate: the package carries 25% or more, 10% or more, or some of the hours |

A score of 6 or more is "Ask first", 4 or more "Ask next", otherwise "Ask if there is time". Ties keep the Blueprint order. A question about a dismissed requirement, and an unknown that a question already covers, are left out. The output has two parts. The **client clarification list** holds the question text only, numbered in the order to ask, so it can be sent as it is. **Why this order (team only, do not send)** holds each item's package and reasons, which can mention the estimate's hour shares, and the second opinion's unknowns (two internal reads and their counts), which are not for the client. Neither part carries hours, quantities or dates of its own. The agent may reword a question for the client and must keep the order.

## Checks

The `agent-pack` GitHub Actions workflow is manual-trigger only (hosted runners are disabled for this repository), so no check runs automatically on a pull request. Run them yourself before you open one:

```bash
npm run verify        # Node tool tests, then pack:build, then pack:check
npx heft test         # Jest, including the TypeScript validators that must agree with the Node ones
```

`npm run test:tools` builds `function/dist` first when it is missing or older than `function/src` (the `pretest:tools` hook), then runs `node --test "tools/**/*.test.mjs"`. `npm run build` (the SPFx release build) does not run the Node tool tests.

## Release

`npm run pack:build` (after `npm --prefix function run build`) writes `release/blueprint-skill-pack/` and a zip, stamped with the version in `tools/release/pack.config.json`, the commit, the build time and the catalog pins. The skills and tools in this repository are the source; nobody edits the pack. The build rewrites repo paths in the skills to `$BLUEPRINT_PACK`, bundles `parse-local` and `prepare-folder` with the function readers so the pack needs only Node, copies the catalogs, libraries, contracts and samples, and fails on any remaining reference outside the pack. The pack states which commit it came from in `pack.json`. A build from a working tree with uncommitted changes is stamped `<commit>-dirty`, and one where git could not report the commit is stamped `unknown`; neither is releasable, and the build stops ("the pack is not releasable") unless you pass `--allow-dirty`. Build a release from a clean checkout of a commit. Install and run instructions: `docs/standalone/agent-skill-pack.md` (the `README.md` of a built pack).

## Guardrails

- Do not invent driver quantities or hours
- Do not resolve conflicts
- Do not write Scope Cut #2 commercial fields
- Do not bump `revision` or write `published` / `estimate` / `handoff` in this pack
- Never rewrite a Blueprint that has review state; write proposals
