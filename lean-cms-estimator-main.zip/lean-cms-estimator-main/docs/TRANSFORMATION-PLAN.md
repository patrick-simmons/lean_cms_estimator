# Transformation plan: multi-platform, evidence-based estimating

This is the plan for what comes after stage 5 of [PLAN.md](PLAN.md). It replaces the root `Transformation Plan.md`, which was written without the codebase in front of it: that document's current-state section is stale, about a third of its roadmap is already built under other names, and two of its central proposals reverse decisions this repo made on purpose.

The strategy in that document is right. Multi-platform, citation-backed, non-mechanical sizing, separated acceleration, three-point output. What follows keeps all of it and changes how it is built, so it fits the system we have rather than the one it assumed.

## The decision at the centre: `factors.csv` goes

Everything else in this plan follows from one change, so it comes first.

### Why the factor table fails

`samples/factors/seed/factors.csv` holds hours per unit for each work package on each platform, in three columns (base, with opt-in, with methods). It does not work, for four reasons:

1. **It is a cartesian product of guesses.** Fifteen work packages x every platform x three columns. Adding Sitecore means inventing forty-five numbers before a single estimate can run. The table is the reason multi-platform support feels expensive.
2. **Nobody owns the cells.** Every row is `confidence: low` with a rationale like "conservative template inventory". Every row of `workstream-defaults.csv` is marked `placeholder`. The system is honest about this, which is good, but it means no estimate it produces today is grounded in anything.
3. **Flat rates cannot express complexity.** A component is 24 hours whether it is a hero banner or an authenticated product configurator. This is exactly the "mechanical estimation logic" the root plan complains about, and it is structural: a single number per package per platform has nowhere to put complexity.
4. **It cannot produce a range.** Three-point estimating needs spread. A constant has none, so Low and High would have to be invented on top of an invented Likely.

### What replaces it

Hours come from **past projects we actually delivered**, held in a case library, with the current pursuit's differences expressed as cited multipliers.

The maintenance profile is the thing to notice. A factor table is a grid of guesses that must be kept current forever. A case is an append-only fact about a project that happened: entered once at pursuit close, never edited, and more valuable every year. The library gets better by being used, which the factor table never does.

### The invariant this preserves

The repo's rule is often stated as "hours live in a CSV the catalog owner owns". That is the implementation, not the principle. The principle is:

> Every number traces to a document citation, a recorded past project, or a named assumption a person accepted. The same inputs produce the same outputs.

Case-derived rates with recorded, estimator-accepted multipliers satisfy that. An LLM writing hours per WBS line does not, which is why the root plan's Lean/Conservative debate is reshaped below rather than adopted as written.

## The rate ladder

`plan.mjs estimate` resolves hours per unit for each work package from the highest rung available, and records which rung it used in `basis`.

| Rung | `basis` | Where the number comes from | Confidence | Raises a question |
| --- | --- | --- | --- | --- |
| 1 | `cases` | Three or more comparable cases on the target platform: median hours per unit, with the spread as the range. | medium, high at n >= 5 | no |
| 2 | `cases-adjusted` | Cases from another platform, or fewer than three on this one, plus the platform delta. | low | yes |
| 3 | `derived` | No usable case. The agent decomposes the package into tasks, sizes it against the platform profile and research, and the estimator accepts or edits the figure at a checkpoint. | low | yes, always |

Rung 3 output is promoted into the case library as a `signed-estimate` case when the pursuit closes, so a package only falls to rung 3 once.

There is no silent default anywhere in the ladder. Today a workstream with no evidence quietly takes a placeholder constant; after this change it takes a wide range, a visible label, and a client question.

## The case library

### Shape

One file per case, `cases/<case-id>.json`, appended at pursuit close and never edited afterwards.

```json
{
  "caseId": "C-014",
  "label": "Outdoor retailer replatform",
  "platform": "aem",
  "deliveredIn": "2026-Q1",
  "source": { "kind": "actuals", "confidence": "high", "enteredBy": "...", "enteredAt": "..." },
  "context": {
    "multiSite": true, "locales": 4, "integrationCount": 6,
    "migrationSource": "cms-export", "designSystem": "partial", "wcag": "aa"
  },
  "packages": [
    { "workPackage": "component-build", "unit": "component", "volume": 42, "traditionalHours": 910, "aiToolingUsed": "partial" }
  ],
  "overhead": [{ "id": "project-management", "hours": 320 }],
  "variance": { "estimatedHours": 4100, "actualHours": 4680 }
}
```

`source.kind` is `actuals`, `signed-estimate` or `architect-recall`, each with its own confidence. Recall is allowed. A remembered number from a delivered project beats a constant nobody chose, as long as the record says that is what it is.

**The seed will be signed estimates, not actuals.** That is decided, and it carries a bias worth naming: a library seeded from what we committed to commercially reproduces our historical estimating behaviour, including wherever it was wrong, rather than what delivery actually took. It is still a large improvement on invented constants, because a signed estimate is a number experienced people staked a deal on. But it means the correction loop is not optional. Stage G is what turns estimates into actuals over time, and `variance` on each case is what makes the drift visible. Treat a `signed-estimate` library as calibrated to our pricing, not to our delivery, until variance data says otherwise.

### Deriving a rate

For a work package, take the cases that have it, on the target platform where possible. Per case, hours per unit is `traditionalHours / volume`. Likely is the median; Low and High are the quartiles, or the minimum and maximum when n is small. The tool records n, the contributing case ids and the spread in the audit trail, so a reviewer can open the cases behind any line.

Below three cases this is not statistics and the tool must not pretend otherwise. The label reads "from 1 comparable project, adjusted", confidence is low, and a question is raised. Honest and narrow beats confident and invented.

### Client data

A case holds no client text: a coded label, the platform, volumes, hours and context flags. That makes it practice IP rather than client material, so it lives in this repo under `cases/`, alongside the catalogs and versioned with them. That is decided. `cases.mjs validate` rejects a record carrying free text beyond the fields above, and the redaction rule is enforced by the validator rather than by reviewer discipline.

### The cold start

With an empty library the system is no better than it is today. It is only more honest. This is the hard dependency in the whole plan: **until three to five past projects are back-filled, nothing downstream is real.** Stage A exists for that reason and nothing after it should start first.

## What falls out of the case library for free

Four of the root plan's goals stop being separate work once rates come from cases.

- **Three-point estimates.** Low, Likely and High are the case spread. No invented ranges, and the range narrows on its own as the library grows, which is the behaviour you want.
- **Question ranking by hour variance.** `rank-questions.mjs` currently ranks questions heuristically. The hour swing a question would resolve is now computable: it is the difference the answer makes across the range. Ranking becomes arithmetic.
- **Measured GenAI bands.** Cases record `aiToolingUsed`. Once there are cases with and without tooling on the same package, the acceleration percentage is derived from our own delivery data instead of a published benchmark.
- **Overhead sizing.** Overhead hours become a ratio of delivery hours taken from the same cases, cross-checked against the phase-ratio guardrails. The four `OH-nn` placeholder rows disappear.

## Platform extension without a rate grid

Adding a platform needs three things, none of which is a table of invented hours.

1. **A profile,** `knowledge/platforms/<id>.md`. Prose on architectural strengths, complexity traps and mandatory discovery triggers, plus deltas in the front matter:

   ```yaml
   deltas:
     - workPackage: content-migration
       multiplier: [1.4, 1.8]
       when: source is Sitecore XP with MVC renderings and xDB customisations
       rationale: custom pipelines do not lift and shift; re-architecture to Next.js API routes
   ```

   The agent proposes which deltas apply and cites the documents that trigger them. The estimator accepts them at checkpoint 2. Accepted deltas are recorded in the plan, so a re-run is deterministic. Multipliers are bounded 1.0 to 2.5.

2. **Capability rows** in the estimating catalog, for whichever CMK and toolkit skills genuinely exist for that platform. `catalog:check` already enforces that every id exists, applies to the platform and is marked opt-in correctly. If a platform has few accelerator skills, the AI plan reports less acceleration. That is a correct answer, not a gap to paper over.

3. **Platform-scoped skill lists.** `skills.csv` and the default skill lists are AEM-shaped today (`aem-core` appears in nearly every workstream, and the martech skills are all Adobe). The skill list moves into the estimating catalog per platform, and `skills.csv` gains a platform column.

Cases accrue afterwards. A new platform runs at rung 2 or 3 for its first few pursuits, says so, and climbs.

### The whole of CMK applies to every platform

CMK is platform-agnostic by design, with platform specifics behind an adapter: `cmk-init` detects the platform and writes the project config, and skills like `cmk-scaffold-component` resolve patterns from the shared library, then project overrides, then platform defaults. The catalog says the same thing structurally — the **All platforms** section holds 28 skills and 9 agents that apply everywhere, and the estimating catalog's `all` rows already use them.

So the acceleration baseline for a new platform is not zero and never was. Drupal inherits the full all-platform CMK set the day it has a row: the audit, content modelling and validation, component scaffolding and review, accessibility, the three migration skills, SEO, search, localisation, multisite, performance, QA test generation, governance and editorial QA, headless design, schema deploy and workflow implementation. That is most of the engineering acceleration in the estimate, and it is already pinned and `supported` at the current commit.

### `distributable_excluded` does not mean unusable

The Acquia vendor layer — `acquia` (17 capabilities), `acquia-meo` (8) and the `drupal` vendor asset (2) — reports as unavailable, and the first reading is that it is missing. It is not. The generator tells us exactly why:

```js
if (source.retention === 'local_only') return unavailable('distributable_excluded');
```

Those assets pass the admissibility check immediately above it. `admissible()` has a branch specifically for `usage_scope: internal_use`, which returns true when redistribution is prohibited and retention is local-only. The Acquia skills come from `acquia/acquia-skills` under `LicenseRef-Acquia-Proprietary`, marked `redistribution: prohibited`, `usage_scope: internal_use`, `retention: local_only`, and CMK's own comment reads "internal use only; synchronized locally, never redistributed".

So the status means **we may use these, we may not ship them**. The delivery team already has them installed. Asking the CMK owner to make them distributable would be asking them to breach Acquia's licence, and the answer would rightly be no.

The gap is ours. `catalog:check` rejects anything whose status is not `supported`, which collapses two different questions — *can we redistribute this?* and *can the team use it on an engagement?* — into one. For estimating, only the second matters. A tool the team runs on a Drupal project accelerates that project whether or not it can be bundled into our pack.

**The fix is a third status in our catalog, not a change in CMK.** Distinguish `supported` (usable and redistributable), `local-only` (usable, not redistributable) and `unavailable` (not usable). A `local-only` capability counts toward the estimate and appears in the readiness list — "the team needs `acquia-skills` synced locally" — which is exactly what the readiness list is for. Our skill pack continues to ship only our own skills, so nothing about the licence changes.

That recovers 27 capabilities for Drupal and Acquia, and the environment and DevOps work stops being under-credited. It lands in stage B with the rest of the catalog sweep.

### The all-platform rows are under-mapped, and that costs every estimate

Auditing the estimating catalog against the CMK catalog turns up gaps that hurt AEM estimates as much as Drupal ones. Fixing them is cheap and benefits every platform at once, so it belongs in stage B rather than stage C.

- **Two skills are filed on the `aem` row that belong on `all`.** `cmk-schema-deploy` (content-model) and `cmk-workflow-implement` (uat-support) are both platform-agnostic in CMK — "apply content model schema stubs via platform CLI" and "generate platform-native workflow config". Filing them under AEM silently under-credits every other platform.
- **Six CMK skills map to no work package:** `cmk-dam-design`, `cmk-content-drift`, `cmk-eval-platform`, `cmk-kb-sync`, `cmk-init` and `cmk-help`. Of these, only `cmk-dam-design` gets mapped, onto the new `asset-migration` activity. The other five stay unmapped on purpose: `cmk-init` and `cmk-help` are setup rather than estimable work, and `cmk-content-drift`, `cmk-eval-platform` and `cmk-kb-sync` describe work we are not currently selling as a line item. They stay visible in the `unusedTools` report so the decision is revisited rather than forgotten.
- **There is no DAM work package.** `cmk-dam-design` has nowhere to map, `dam` exists as a skill in `skills.csv`, and asset volumes are a scope driver in every migration pursuit. Stage B adds `asset-migration` (see the work breakdown below).
- **Agents are mostly unmapped.** Most are invoked by a parent skill, so that is usually correct, but `cmk-dxp-architect`, `cmk-platform-analyst` and `cmk-migration-planner` do work that shows up in the estimate.

The principle to encode: **the estimate starts from the full all-platform CMK inventory, and the catalog's job is to map it to activities.** The existing `unusedTools` report already measures the gap. It should be treated as a defect list that is worked down to a small, deliberate remainder, each entry with a recorded reason, rather than a passive observation.

## Rethinking the work breakdown

The fifteen work packages are the other structure worth fixing while the estimate model is open. They are not wrong, but they are hard to read and they conflate things that want to be separate.

### What is wrong with `discovery-audit` to `frontend-delivery`

- **The ids carry no meaning.** `search` means nothing to an estimator, a deal reviewer or a client, and it appears in the plan file, the catalog, the workbook and the conversation. The numbering is also already damaged: `WP-14` was removed and left a hole, which is a sign that the sequence is an accident of history rather than a structure.
- **They mix dimensions.** Some are lifecycle phases (discovery, QA, UAT and training), some are capability areas (search, SEO, localisation, multisite), some are artefact production (content modelling, component build). "Component review and accessibility" is an activity and a quality concern fused together, while QA sits in a different package, so the two halves of quality live apart.
- **"Site" is a fake unit.** SEO, search and multisite are all sized per site, and site count is almost always 1. A driver that is always 1 is not a driver: these are fixed or complexity-banded work wearing a volume costume. The same goes for "templates in the current site" doing duty for discovery, QA and front-end delivery, where three packages key off the same word but mean three different populations.
- **The `OH-nn` namespace duplicates concepts.** `OH-03` test management sits beside `qa-automation` QA and test automation; `OH-04` environment management sits beside `environments-devops` environments and DevOps. Which hours go where is a coin toss.
- **The names do not help the agent.** The extraction step maps each requirement onto a work package. `component-build` tells a model what belongs there; `component-build` does not. Readable targets should measurably improve mapping quality, and `unmapped` should fall.

### The change: name them, and split reporting from sizing

Three moves, which together are more intuitive without being more complicated.

**1. Slugs, not numbers.** `content-migration`, not `content-migration`. Readable in the plan file, the catalog, the workbook and in chat. No renumbering problem, no holes, and ids that survive the list changing shape.

**2. Two levels: phase for reporting, activity for sizing.** A phase is what a client and the workbook lead with — the conventional delivery arc. An activity is what carries a driver, a rate and a set of capabilities. Each activity belongs to one phase. This stops the list having to be legible and fine-grained at the same time, which is what forced the current compromise.

The phases are **Discover, Design, Build, Assure, Launch and Run**. Content work sits inside Build rather than in a phase of its own: migration and authoring run alongside component and front-end work on a real delivery, and splitting them out made the timeline imply a waterfall nobody runs.

**3. Three sizing shapes, stated explicitly**, instead of forcing everything through volume x rate:

| Shape | Sizing | Examples |
| --- | --- | --- |
| `per-unit` | Volume x hours per unit, from cases. | component build, content modelling, migration, locales, integrations, environments |
| `tiered` | A complexity band (small, medium, large) chosen from named signals, with hours per band from cases. | search, SEO, design system, cutover, solution architecture |
| `proportional` | A percentage of a named set of other activities, derived from cases. | project management, delivery governance, QA automation, UAT support |

`proportional` is the move that retires the `OH-nn` namespace: project management is not an overhead class, it is an activity sized as a share of delivery. It also makes the phase-ratio guardrails structural. QA at a healthy share of build hours stops being a thing the auditor checks after the fact and becomes how QA is sized in the first place, with the auditor left to catch the `per-unit` cases that drift.

### Proposed activities

| Phase | Activity | Shape | Driver |
| --- | --- | --- | --- |
| Discover | `discovery-audit` | per-unit | existing templates (brownfield only) |
| Discover | `solution-architecture` | tiered | integration count, platform complexity |
| Design | `content-model` | per-unit | content types |
| Design | `design-system` | tiered | ready, partial or net-new |
| Build | `component-build` | per-unit | components |
| Build | `frontend-delivery` | per-unit | templates |
| Build | `integrations` | per-unit | external systems |
| Build | `search` | tiered | searchable types, facets, relevance tuning |
| Build | `seo` | tiered | structured data, redirects, multi-domain |
| Build | `localization` | per-unit | locales |
| Build | `multisite` | per-unit | additional sites |
| Build | `workflow-governance` | tiered | approval stages, roles |
| Build | `content-migration` | per-unit | pages |
| Build | `asset-migration` | per-unit | assets, or total size (the new DAM activity) |
| Build | `editorial-production` | per-unit | net-new pages authored |
| Assure | `component-review` | per-unit | components |
| Assure | `accessibility-audit` | tiered | WCAG level |
| Assure | `qa-automation` | proportional | build activities |
| Assure | `uat-support` | proportional | build and content activities |
| Launch | `environments-devops` | per-unit | environments |
| Launch | `cutover` | tiered | cutover windows, rollback needs |
| Launch | `training-enablement` | per-unit | authors |
| Run | `hypercare` | tiered | weeks of cover |
| Run | `project-management` | proportional | all delivery activities |
| Run | `delivery-governance` | proportional | all delivery activities |

Twenty-five activities against today's nineteen ids, for considerably more fidelity. **That growth is only affordable because `factors.csv` is gone.** Under a rate grid, twenty-five activities x every platform x three columns would be unmaintainable, and the current fifteen are partly shaped by that cost. Under the case library, finer activities are strictly better: each one gets its own evidence, and nothing has to be pre-populated.

### Tier signals and bands

A tiered activity is sized by choosing a band, and the band is chosen from signals the documents can be quoted for. The hours behind each band come from cases, exactly as a per-unit rate does — **nothing below sets an hour figure.** What it sets is the rule for picking the band, so that two runs over the same documents land on the same tier.

Where the signals are absent the band is `medium`, confidence is low, and a client question is raised. Small under-prices, which is the common failure; large loses deals. Once there are enough cases, the no-signal default becomes the median band observed across them, so it self-corrects.

A signal that is present and quoted wins over one that is inferred. Where two signals disagree, the higher band wins and the disagreement becomes a challenge for checkpoint 3.

| Activity | Small | Medium | Large |
| --- | --- | --- | --- |
| `solution-architecture` | ≤2 integrations, greenfield or same-vendor upgrade, single site, no named compliance regime | 3–6 integrations, or a cross-vendor replatform, or 2–5 sites | 7+ integrations, or cross-vendor replatform carrying legacy custom code, or 6+ sites, or a named regime (HIPAA, PCI, FedRAMP), or federated SSO across multiple identity providers |
| `design-system` | Ready: component library with published tokens | Partial: brand guidelines and some components, no token system | Net-new: no design system exists, we create it |
| `search` | Platform-native, single site, ≤2 facets, no tuning mentioned | External provider, or 3–8 facets, or several content types with differing schemas | Federated across systems, or 9+ facets, or stated relevance tuning, or multilingual, or secured and personalised results |
| `seo` | Single domain, no structured data mentioned, greenfield so no redirects | 1–3 schema types, or under ~500 redirects, or single domain with multiple locales | 4+ schema types, or 500+ redirects or an unquantified legacy URL set, or multi-domain hreflang, or a stated traffic-protection requirement |
| `workflow-governance` | ≤2 stages, ≤3 roles, single site | 3–4 stages, 4–8 roles, or scheduled publishing and embargoes | 5+ stages, or 9+ roles, or legal and regulatory review in the path, or governance that varies per site or brand |
| `accessibility-audit` | WCAG 2.1 A, self-assessed | WCAG 2.1 or 2.2 AA, self-assessed with remediation | AA with third-party audit or VPAT, or AAA, or Section 508 procurement, or a remediation mandate following a complaint |
| `cutover` | Single site, flexible window, rollback is a redeploy | Fixed maintenance window, DNS or CDN cutover, documented rollback, or 2–5 sites or a phased launch | Zero-downtime requirement, or parallel run and dual publishing, or 6+ sites in waves, or regulated change approval, or a business with no freeze window |
| `hypercare` | ≤2 weeks, business hours, no SLA stated | 3–6 weeks, business hours with defined severities | 7+ weeks, or extended and out-of-hours cover, or contractual response SLAs, or transition into a managed service |

Every one of these signals is already something the extract looks for or the design sketch counts. Banding does not need a new kind of evidence, only a rule for reading what is there.

### Proportional reference sets, and the order things resolve in

A proportional activity is a share of other activities' hours. The share comes from cases — and unlike everything else in the ladder, **it has no cold start.** Every signed estimate being reconstructed in stage A already carries project-management and QA lines, so the percentages are computable from the first back-fill rather than waiting for the library to mature.

| Activity | Share of |
| --- | --- |
| `qa-automation` | The Build-phase engineering activities: `component-build`, `frontend-delivery`, `integrations`, `search`, `seo`, `localization`, `multisite`, `workflow-governance` |
| `uat-support` | All Build-phase activities, content included, since the client tests migrated content too |
| `project-management` | Everything else, Discover through Run |
| `delivery-governance` | Everything else, Discover through Run |

Shares referencing shares would be circular, so resolution runs in passes and the order is fixed:

1. **Per-unit** activities: volume x hours per unit.
2. **Tiered** activities: band to hours.
3. **First proportional pass:** `qa-automation` and `uat-support`, over reference sets drawn only from passes 1 and 2.
4. **Second proportional pass:** `project-management` and `delivery-governance`, over everything from passes 1 to 3.

`owner` applies after sizing, not before: a proportional activity is sized whole and then reduced to our portion, so a client running their own UAT does not shrink the project management that covers it.

This is also what makes the phase-ratio guardrails structural rather than advisory. QA lands at a healthy share of build because that is how it is sized, and the auditor is left to catch the per-unit activities that drift out of proportion.

### The timeline gets lanes

Folding content into Build makes Build the phase that carries most of the estimate, and a single bar across twelve weeks says nothing useful about it. The Timeline sheet gains lanes.

A lane is a parallel track inside a phase, covering a named set of activities with its own start offset and duration. Build gets at least two: **Engineering** (`component-build`, `frontend-delivery`, `integrations`, `search`, `seo`, `multisite`, `workflow-governance`) and **Content** (`content-migration`, `asset-migration`, `editorial-production`), with Content starting behind Engineering because migration needs a content model and some components before it can run.

The phase seed has to be reworked for this anyway. `phase-packs.csv` holds four phases today — discovery, build, governance, hypercare — against the six the breakdown now uses, and its `covers work packages` column points at `WP-nn` ids that are going away. Lanes land in the same change, either as a column on that file or as a small `phase-lanes.csv` beside it.

Lane membership is data, not a decision: it derives from activity ids, so the Timeline stays template-owned, the writer is unchanged, and the estimator is asked nothing. Elapsed weeks are still placeholders — though cases could record actual elapsed duration, which would put the timeline on the same evidence footing as the hours. That is a stage G extension, not stage B work.

### Who owns the activity

Not everything in the breakdown is work we do alone, and very little of it is work we do without the client. Each activity carries an `owner`:

| Value | Hours | What it means |
| --- | --- | --- |
| `us` | Full | We deliver it. The client's involvement is incidental. The default for twenty of the twenty-five. |
| `shared` | Our portion | Both contribute materially. We size what we do and state what we assume the client does. |
| `client` | Zero | They deliver it. It appears as an explicit exclusion with the assumed volume attached. |

Most activities default to `us`. Five default to `shared`, because on a real engagement they are genuinely split and assuming otherwise is how estimates end up short:

| Activity | Why it is shared by default |
| --- | --- |
| `editorial-production` | The client usually writes net-new page copy; we may write some of it. |
| `localization` | We build the translation workflow and connectors; linguists are theirs or their vendor's. |
| `uat-support` | They test and sign off, we triage and fix. |
| `environments-devops` | Often their cloud accounts, their network, their change process. |
| `training-enablement` | We deliver the training; they schedule it and cascade it internally. |

Sizing a `shared` activity never invents a split. We size our portion the same way as anything else, and the client's expected contribution is recorded as an assumption with a client question attached. Where cases record the same activity as shared, the portion is observable from them. Where they do not, it sizes at full and says so — identical hours to `us`, but with the split stated and asked about, which is the honest position rather than a percentage nobody chose.

Keeping client-side work visible in the model is the point. "Who writes the copy for 400 new pages?" is among the highest-variance questions in a CMS pursuit, and an activity absent from the breakdown is a question nobody asks.

### Changing the owner on an estimate

The defaults are a starting position, not policy. Every activity's owner is editable per estimate:

- The estimator changes it in conversation at checkpoint 2 or 3. **This does not add a checkpoint** — it rides the ones that already exist.
- The agent runs `plan.mjs owner <activity> --set us|shared|client --note "<what the estimator said>"`. The estimator types nothing, per rule 2 of the friction budget.
- The change is recorded in the plan with its note and timestamp, exactly as review decisions are, and `estimate` re-runs the affected hours in the same write.
- A re-run never resets it. This is a decision a person made, and the existing rule holds: a re-run only adds, and never changes a decision the estimator made.
- The workbook carries the owner on each activity row, and every `client` and `shared` activity appears on `Assumptions and risks` with its assumption and its question.

### Driving `asset-migration`

The driver is raw asset count, with total size as the alternate when that is all the documents give. RFPs quote one or the other — "45,000 assets" or "2 TB of imagery" — and neither is more correct, so the activity accepts both and records which it used.

No conversion between them is assumed. Where a case happens to record both, the ratio is observable, so assets per terabyte becomes something derived from our own delivered projects rather than a constant someone picked. Asset types and rendition rules are deliberately not drivers: they belong in the complexity deltas, where they can be cited, rather than in the unit.

### Migration

About 800 `WP-nn` and `OH-nn` references across 65 files, but the shape is friendlier than the count suggests: most are test fixtures and sample JSON that change mechanically, and a number of them belong to carry-over artefacts from the old web part that are candidates for pruning anyway. The decisions live in four places — the estimating catalog, the plan contract, `tools/blueprint/data/implied-scope.json` and `tools/catalog-suggest-keywords.json` — plus the id-format checks in `estimate-model.mjs` and `check.mjs`.

**The list is settled; implement it in stage B.** What stage A still owes it is the detail — tier signals, proportional reference sets and `owner` defaults — and that has to land before the back-fill, since the people reconstructing past estimates record hours against these activities directly and remapping cases later would waste the workshop. The code migration then rides along with the rate resolver, as both rewrite the same files and the same contract section. Done separately they are two migrations and two rounds of fixture churn.

## Acceleration: two tracks, multiplied

The three rate columns in `factors.csv` collapse into two percentages per workstream, which is also the root plan's dual-track goal.

| Track | Source | Applies when |
| --- | --- | --- |
| `ipSavingPct` | Matched CMK and toolkit capabilities for the workstream, from the generated, commit-pinned catalogs. | The accelerator's prerequisites are verified against the pursuit's scope drivers. Unverified means zero. |
| `genaiSavingPct` | Discipline bands in `knowledge/benchmarks/genai-velocity-bands.md`, about six rows, each with a source and a confidence. | A tool for the workstream is ON in the AI plan. |

Net hours are `raw x (1 - ip) x (1 - genai)`, not `raw - ipSaved - genaiSaved`. Multiplying means the same hour cannot be saved twice and the result cannot fall below zero, which the subtractive formula in the root plan needs a floor to prevent.

The existing opt-out machinery carries over unchanged in behaviour: opting a tool out removes the track it supported and the hours return to the traditional rate.

**Sequencing matters here.** The `with opt-in` and `with methods` rate columns live in `factors.csv`, so deleting that file in stage B also deletes the mechanism that produces AI-assisted hours. Stage B therefore keeps a single saving percentage per activity, still gated on a tool being ON, exactly as the current `ai saving percent` behaves. Stage E splits that one percentage into the two tracks. Stage B must not ship an estimate whose AI-assisted number has quietly become its traditional one.

The hand-written `knowledge/accelerators/*.md` cards in the root plan are **not** adopted. That information already exists in the CMK and toolkit capability catalogs, which are generated from source repositories, pinned to commits, and validated. Hand-authoring a parallel set would fork a maintained source into an unmaintained one, which is the same mistake as `factors.csv`.

## The challenge pass

The adversarial idea is good. Having an LLM author competing hour figures is not, because it makes two runs over the same folder disagree.

So the challenge pass produces **challenges, not hours**. Each one is a cited objection that resolves to a specific, typed adjustment:

> `[Email-04]` specifies legacy SAML with custom AD group-to-role mapping, where the estimate assumes the OIDC starter kit. Proposed: integrations integration count +1, and the `legacy-auth` delta (1.3x) on integrations.

Each challenge names the workstream, the evidence, and the adjustment it proposes: a volume change, a delta, or an accelerator prerequisite that fails. The estimator accepts or rejects each one at checkpoint 3. Accepted challenges are recorded in the plan and applied by the tool. The arithmetic stays deterministic, the reasoning stays adversarial, and the audit trail shows what was challenged and who accepted it.

**The phase-ratio audit** runs as a validator over the computed estimate, not as a prompt. The guardrails themselves are new data: the existing phase seeds hold durations, staffing FTE and task shapes, not hour proportions, so there is no "QA is 18–22% of build" figure in the repo today. Rather than import the root plan's published ratios, derive them from the case library, which already has the hours per work package to compute them, and widen them to a band across cases. Until there are enough cases, fall back to the published ratios marked as such.

`plan.mjs audit` then checks:

- QA and accessibility below its guardrail share of engineering build hours
- Discovery and architecture below its share on migration-heavy or multi-integration work
- Missing allocations for environments, training, runbooks or hypercare
- A delivery workstream still on rung 3

Findings are warnings on the `Assumptions and risks` sheet, never silent corrections.

## Research

`research-stack` is the one genuinely new capability, and it needs rules the root plan does not give it.

- Queries are built from platform, version and vendor terms only. No client-identifying text leaves the machine. The tool constructs the query string; the agent does not free-type it.
- Every finding is recorded in the plan with its URL, the date retrieved and the claim it supports.
- A re-run reuses recorded findings and only re-queries when a finding is older than its staleness window. Two runs a day apart produce the same estimate.
- Findings are evidence for deltas and prerequisites. Research never writes an hour.

What it is for: CMS version lifecycles and deprecations, API and tier ceilings, connector maturity, and known migration bottlenecks for the exact stack in the pursuit. These are the things estimators miss, and they map cleanly onto deltas.

## What does not change

Stated plainly, because the root plan proposes changing all of it:

- **One plan file.** `{Project}_Plan.json` stays the single file the agent writes. The ten-file `.estimator/` layout is rejected: stage 2 consolidated in the opposite direction, and re-fragmenting would rewrite the contract, the validators, the workbook writer and a large share of the test suite for no gain.
- **One orchestrator skill** plus the stage skills. The six-skill roster is rejected for the same reason. New work lands as steps in `estimate` and new commands on `plan.mjs`.
- **`.claude/skills/`** stays. The pack ships as a Claude plugin with a `.claude-plugin/plugin.json` manifest and Cursor loads the directory as it is. Moving to `.agents/skills/` would break `pack-layout.mjs` for a portability benefit that does not currently exist.
- **The generated workbook template.** `build-template.mjs` owns the structure, the writer matches columns by position, and a test compares the two. There is no corporate macro workbook to hydrate.
- **Catalog pinning and `catalog:check`.** Commit-pinned, generated capability catalogs with id validation.
- **Validators as tools, not prompts.** Evidence checks, volume quoting, and the re-run-only-adds rule.
- **The back-test** (`tools/eval`) and the full tool test suite, which the root plan does not mention and which every stage below must keep green.

## Contract changes

| Area | Change |
| --- | --- |
| Plan file, workstreams | `hoursPerUnit` gains `low`, `likely`, `high`; `basis` becomes `cases`, `cases-adjusted` or `derived`; new `caseIds[]`, `caseCount`, `deltas[]`, `ipSavingPct`, `genaiSavingPct`. `aiColumn` is removed. |
| Plan file, root | New `research[]` (recorded findings) and `challenges[]` (proposed, accepted, rejected). |
| Workbook, Workstreams sheet | New columns for Low, Likely, High, Basis, n, IP saving %, GenAI saving %. `AI rate used` is removed. Positional contract means the template is regenerated and its test updated in the same change. |
| Seed files | `factors.csv` deleted. `workstream-defaults.csv` loses default volumes, default hours and `ai saving percent`, keeping only unit and placeholder marks until the skill lists move to the catalog, after which it is deleted too. `skills.csv` gains a platform column. The phase seeds are untouched: they drive the Timeline sheet and hold no rates. |
| Factors workbook | Keep it, and rename it. Only one of its twelve sheets is the Factors sheet; the rest are phases, staffing, blended rates and the assumption, dependency and risk libraries, none of which the case library replaces. Drop the `Factors` sheet, rework `Phase packs` for six phases and lanes, and give the file a name that matches what it is. |
| Code | `loadModelInputs` and `ratesOf`/`fixedRatesOf` in `estimate-model.mjs` are the seam. A new `cases.mjs` resolver replaces them; `buildEstimate` keeps its shape. `workbook-rows.mjs`, `seed.mjs`, `pack-layout.mjs` and the factor tests follow. |

## Ease of use is the constraint, not a goal

Everything above adds capability, and capability is where estimating tools go to die. An estimator reaches for this because it is faster than a spreadsheet and a blank document. The moment it asks more of them than it saves, they stop using it and the case library stops growing, which takes the rest of the plan down with it.

So ease of use is not a quality to aim for at the end. It is a budget that every feature in this plan has to fit inside.

### The friction budget

The skill already states it: *"Keep to the four checkpoints. More questions than that mean the estimator is doing your work."* That line is the budget, and this plan does not get to raise it.

Three rules follow, and they are testable:

1. **Four checkpoints, still.** Nothing here adds a fifth. A feature that needs one has to take over an existing checkpoint or not ship.
2. **The estimator types no commands.** `cases.mjs`, `plan.mjs audit`, `ai-report` and the rest are agent-invoked. The only human surfaces are the conversation and the workbook. Anything an estimator has to remember to run is a feature that will not be used.
3. **Every question carries a recommended answer, pre-selected.** Silence is a valid response and takes the recommendation. A question the agent can answer from the documents is not a question.

### What each proposal costs, and what bounds it

| Proposal | Friction risk | What bounds it |
| --- | --- | --- |
| 25 activities | More mapping decisions | The agent maps, not the estimator. Activity count must never change the number of questions asked. |
| Tiered activities | Eight new band choices | The agent picks the band from cited signals and names it in the summary. It only asks when the signals are missing, and a disagreement becomes a challenge rather than a question. |
| `owner` field | 25 ownership questions | Defaults ship with the activity and are editable in conversation. Client and shared activities appear as lines in the existing assumptions list, not as questions. |
| Three-point ranges | Three numbers to interpret instead of one | Most Likely is the number, everywhere. Low and High sit beside it as a range. The estimator is never asked which to use. |
| Challenge pass | Twenty accept-or-reject decisions | Bulk accept is the default, as at checkpoint 1. Challenges are ranked by hour impact and only the few that move the number are shown; the rest are recorded in the plan. |
| Case entry at close | A form to fill in per pursuit | `cases.mjs promote` generates the case from the plan file. The human corrects actuals where they know them and that is all. |
| Research | A slower run, more to read | Findings are evidence, never a question, and never block the run. They surface only where they changed a delta. |
| Audit findings | A list of warnings to triage | They land on `Assumptions and risks` for the reviewer. They do not interrupt the run. |

### How we would know

Worth measuring on the stage C and stage G runs, because "it feels heavy" arrives too late to act on:

- **Questions asked per run.** Should not rise as stages land. If it does, something broke rule 1.
- **Commands typed by the estimator.** Target zero.
- **Time from "estimate this folder" to a workbook they are willing to send.** This is the number that decides adoption.
- **Re-runs per pursuit.** A high count means the first pass is not trusted, which is a quality problem wearing a usability costume.

If a stage improves the estimate and worsens any of these, it is not done.

## Stages

Sized in engineering days, excluding the owner's time, which is called out separately. These are sequential: each one depends on the one before.

| Stage | What it delivers | Days | Owner time |
| --- | --- | --- | --- |
| **A. Settle the shapes, seed the library** | The twenty-five activities, their bands, reference sets and `owner` defaults are drafted; stage A pressure-tests the band boundaries against real pursuits, then the case schema, `cases.mjs` (validate, list, derive), and three to five past signed estimates back-filled **directly against the activities**. | 4–5 | 1–2 workshops |
| **B. Rate resolver and work breakdown** | The ladder replaces `factors.csv`. `estimate` produces Low/Likely/High with case provenance. Factor seed and its tests removed, back-test re-baselined. In the same change: activities replace `WP-nn`/`OH-nn`, the three sizing shapes land, and the catalog sweep moves `cmk-schema-deploy` and `cmk-workflow-implement` to `all`, maps `cmk-dam-design` to `asset-migration`, and adds the `local-only` capability status. | 12–15 | breakdown and mapping review |
| **C. Drupal** | Profile format with deltas, platform-scoped skill lists, Drupal rows in the estimating catalog, proved end to end on a real pursuit. Inherits the all-platform CMK set on day one; the Acquia vendor layer is a later gain, not a gate. | 5–7 | capability input |
| **D. Challenge and audit** | Challenge pass with typed adjustments, `plan.mjs audit` phase-ratio validator, three-point and challenges in the workbook, question ranking by computed swing. | 5–6 | checkpoint design |
| **E. Acceleration split** | `ipSavingPct` and `genaiSavingPct`, prerequisite verification, benchmark bands, workbook columns, opt-out rewiring. | 4–5 | bands review |
| **F. Research** | `research-stack` step, query construction, recorded findings with staleness, deltas backed by findings. | 3–4 | data-handling sign-off |
| **G. Calibration loop** | Pursuit close promotes the plan into a case; back-test reports estimate-versus-actual variance as the library grows. | 2–3 | process adoption |

**Roughly 33 to 43 engineering days, so eight to twelve weeks at a realistic part-time pace**, not the fifteen days in the root plan. That figure assumed Phase 1 was greenfield when most of it already exists, and did not account for the contract, workbook and test changes that the three-point and acceleration goals require.

### Stop conditions

Worth agreeing before starting, because the honest answer at stage A might be no.

- **After A:** if fewer than three past projects can be reconstructed to work-package level, stop and reconsider. The whole plan rests on that data. Continuing would swap one set of unowned numbers for another.
- **After B:** if case-derived ranges are wider than the estimators find usable, the fix is more cases, not a return to constants.
- **After C:** if the second platform needs code changes rather than a profile plus catalog rows, the extension model is wrong and should be fixed before a third platform.

## Risks

| Risk | Mitigation |
| --- | --- |
| **The library starts empty.** Early estimates sit at rungs 2 and 3 with wide ranges. | Labels and questions say so plainly. This is visible honesty replacing invisible invention, not a regression. |
| **The seed is signed estimates, so it inherits our estimating bias.** The library will reproduce what we priced, not what delivery took. | Stage G is mandatory, not optional: it records `variance` per case and lets the back-test report drift. Until then, say in the workbook that rates derive from signed estimates. |
| **Past data may not map to work packages.** Estimates and timesheets rarely line up with discovery-audit to frontend-delivery. | `source.kind: architect-recall` is a first-class input with lower confidence. Reconstruct in a workshop rather than waiting for perfect data. This is the most likely reason stage A underdelivers. |
| **Conflating redistributable with usable** hides 27 Acquia and Drupal capabilities the team already has installed. | The `local-only` status in stage B. It must stay distinct from `supported`: the pack still ships nothing licensed `redistribution: prohibited`, and `catalog:check` still rejects genuinely unavailable ids. |
| **Catalog mappings are the ceiling on the AI plan.** An unmapped skill is acceleration the estimate cannot see, on every platform. | Stage B's mapping sweep, and treating `unusedTools` as a defect count rather than a report. |
| **Case entry decays.** If nobody records closed pursuits, the library stops improving. | Stage G makes promotion a command run at pursuit close, around thirty minutes. If it is not adopted, the system degrades to stage-B quality rather than breaking. |
| **Small-n statistics mislead.** A median of two is not a median. | Hard rule: below three cases the label says how many, confidence is low, a question is raised, and the range is the full observed span. |
| **Research is not reproducible.** | Findings are recorded with dates and reused until stale. |
| **Scope creep across seven stages.** | Each stage ships a working estimate. B alone is a complete, usable system; everything after it is improvement. |

## Decisions taken

| Decision | Choice | Consequence |
| --- | --- | --- |
| Seed data | Signed estimates, broken down to work-package level. | Library is calibrated to pricing, not delivery. Stage G becomes mandatory. |
| Where cases live | `cases/` in this repo, versioned with the catalogs, redaction enforced by the validator. | No hub folder or SharePoint dependency. Cases are reviewable in pull requests. |
| Stage C platform | Drupal. | Unblocked. Drupal inherits the all-platform CMK set through the adapter; only the Acquia vendor ops layer is unavailable, and it narrows environment work rather than gating the platform. |
| DAM | Added in stage B as the `asset-migration` activity, with `cmk-dam-design` mapped to it. | Asset volumes become a first-class driver instead of being absorbed into content migration. |
| The other unmapped skills | `cmk-content-drift`, `cmk-eval-platform` and `cmk-kb-sync` stay unmapped. | They remain listed in `unusedTools`, so the choice is visible and revisitable rather than lost. |
| Work breakdown | The twenty-five named activities, in two levels with three sizing shapes, replacing `WP-nn` and `OH-nn`. | Confirmed. Implemented in stage B alongside the rate resolver; stage A confirms shapes and tier signals only. |
| `asset-migration` driver | Raw asset count, with total size as the alternate. | Asset types and rendition rules become complexity deltas instead of units. |
| Tiers and shares | Eight tiered activities banded small, medium and large from quoted signals; four proportional activities resolved in two passes after the rest. | No band sets an hour: the hours per band come from cases. The proportional shares are computable from the stage A back-fill, so they have no cold start. |
| Timeline | Lanes inside a phase, starting with Engineering and Content inside Build. | `phase-packs.csv` is reworked for six phases and lanes. Membership derives from activity ids, so the estimator is asked nothing. |
| Factors workbook | Kept and renamed, with the `Factors` sheet dropped. | One of twelve sheets dies. It is the owner's entry point for policy — phases, staffing, rates, libraries — while cases hold evidence. Two surfaces, cleanly split. |
| Activity ownership | Every activity carries an `owner`, editable per estimate. Twenty default to `us`; `editorial-production`, `localization`, `uat-support`, `environments-devops` and `training-enablement` default to `shared`. | `shared` sizes our portion and records the client's as an assumption plus a question. No split is ever invented. Changes ride the existing checkpoints and survive re-runs. |
| Phases | Six: Discover, Design, Build, Assure, Launch, Run. Content folds into Build. | The timeline stops implying a waterfall. Migration and authoring sit beside component work, which is how they run. |
| Ease of use | A budget, not a goal: four checkpoints, zero commands typed, every question pre-answered. | A feature that needs a fifth checkpoint replaces one or does not ship. Measured on the stage C and G runs. |
| Stage A workshop | The estimator who priced it beside someone who delivered it, roughly two hours per project, reading the signed estimate line by line. | Hours land against the activities directly. Selection criteria: recent, volumes recoverable, two platforms if possible, at least one that overran, a mix of greenfield and replatform. |
| Acquia capabilities | Not a CMK change. Add a `local-only` status to our catalog: usable for estimating, never shipped in the pack. | Recovers 27 capabilities. Asking CMK to redistribute them would breach Acquia's licence. |

## Still open

- Which three to five pursuits get reconstructed.
- Whether `qa-automation` belongs in the shared set too, where a client runs their own test function.
- Whether the band boundaries above match how the practice actually reads a pursuit, which is the main thing stage A should pressure-test.
- Whether anyone actually edits the factors workbook in Excel today. If nobody does, the seed CSVs are the real surface and the workbook can go after all.
- What the renamed workbook should be called, and whether the empty `AI allowance` sheet has a purpose.
- Whether Build needs a third lane for localisation, or whether it sits inside Engineering.
