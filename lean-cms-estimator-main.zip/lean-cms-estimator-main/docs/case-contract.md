# The case record

A case is one past project, recorded once. The case library is where the estimate's hours come from: `plan.mjs estimate` derives hours per unit for each activity from the cases that cover it, and the spread across those cases becomes the low and high of the three-point estimate. See [TRANSFORMATION-PLAN.md](TRANSFORMATION-PLAN.md) for why this replaces `factors.csv`.

This page is the schema `cases.mjs validate` checks. It is written before the first reconstruction workshop on purpose: the workshop should capture these fields, not something close to them.

## Where it lives

One file per case, `cases/C-nnn.json`, committed to this repository and reviewed like any other change.

A case is **append-only**. It records what happened on a project that is finished; it is not a working document. The only edit a committed case should ever need is adding `variance` once actuals are known, or correcting a recording error with the correction noted in the commit message.

## What must not be in it

A case holds no client material. That is what makes it practice IP rather than client data, and what lets it live in a repository.

- `label` is a coded description — sector and work type, never the client's name. "Outdoor retailer replatform", not "Fabrikam Inc".
- Every descriptive field is an enum from this page. There is no free-text field except `note`, which is for a sizing caveat ("QA hours include a second accessibility pass"), never for client facts.
- No document quotes, no personal names, no commercial terms, no rates. Hours only.

`cases.mjs validate` enforces the enums. The label is a review question, so it gets looked at in the pull request.

## Root

| Field | Type | Rule |
| --- | --- | --- |
| `caseId` | string | `C-` and three digits. Unique. Matches the file name. |
| `label` | string | Coded description. No client name. |
| `platform` | string | The platform id the project delivered on (`aem`, `aem-eds`, `drupal`, ...). |
| `deliveredIn` | string | `YYYY-Qn`, the quarter the project finished or the estimate was signed. |
| `source` | object | Where the numbers came from. Required, see below. |
| `context` | object | The shape of the project. Required, see below. |
| `activities` | array | One entry per activity, see below. |
| `totalHours` | number | The project total. Must equal the sum of `activities[].hours`, within one hour for rounding. |
| `schedule` | object | Optional, see below. |
| `variance` | object | Optional, see below. |

## `source`

| Field | Type | Rule |
| --- | --- | --- |
| `kind` | string | `actuals`, `signed-estimate` or `architect-recall`. |
| `confidence` | string | `high`, `medium` or `low`. |
| `enteredBy` | string | Who reconstructed it. |
| `enteredAt` | string | ISO date. |

`kind` is the most important field in the record, because it says what the hours actually are:

| `kind` | What it means | Usual confidence |
| --- | --- | --- |
| `actuals` | Hours delivery recorded against the work. What it took. | `high` |
| `signed-estimate` | Hours we committed to commercially. What we said it would take. | `medium` |
| `architect-recall` | Reconstructed from memory by someone who was there. | `low` |

A `signed-estimate` case carries our estimating bias, including wherever it was wrong. That is acceptable and expected — the first library will be mostly signed estimates — but it is the reason `variance` matters, and the reason the rung and confidence reach the workbook rather than being smoothed away.

Mixing kinds within one case is allowed where that is the truth: record the case at its lowest kind and note the mix.

## `context`

The flags that explain why a project sized the way it did. They are what lets the resolver pick comparable cases, and what the tiered bands are read from.

| Field | Type | Values |
| --- | --- | --- |
| `projectType` | string | `greenfield`, `replatform-same-vendor`, `replatform-cross-vendor`, `enhancement` |
| `frontend` | string | `traditional`, `headless`, `hybrid` |
| `siteCount` | number | Sites in the topology, including the first. |
| `locales` | number | Locales launched. `1` for a single-language site. |
| `integrationCount` | number | External systems integrated. |
| `migrationSource` | string | `none`, `api`, `cms-export`, `database`, `scrape`, `manual` |
| `designSystem` | string | `ready`, `partial`, `net-new` |
| `wcag` | string | `none-stated`, `a`, `aa`, `aaa` |
| `compliance` | string[] | Named regimes, e.g. `["hipaa"]`. `[]` when none. |

## `activities`

One entry per activity that had work, plus explicit zeros (below). What each entry needs depends on the activity's shape.

| Field | Type | Rule |
| --- | --- | --- |
| `activity` | string | An activity slug. |
| `hours` | number | Hours for this activity on this project. Required on every entry. |
| `owner` | string | `us`, `shared` or `client` — what actually happened, not what was planned. |
| `volume` | number | **Per-unit activities only.** The count the work was sized against. Omit with `unit` when it cannot be recovered. |
| `unit` | string | **Per-unit activities only.** The unit `volume` is in. Goes with `volume`: both or neither. |
| `altVolume`, `altUnit` | number, string | Optional. A second measure of the same work, where one exists. |
| `band` | string | **Tiered activities only.** `small`, `medium` or `large`. |
| `aiToolingUsed` | string | `none`, `partial`, `full` or `unknown`. See below. |
| `zeroReason` | string | Required when `hours` is `0`. See below. |
| `note` | string | Optional. A sizing caveat. No client facts. |

Three rules that matter more than they look:

**`volume` is what the work was actually sized against, not what the brief said.** If the brief said 60 components and 42 were built, the volume is 42. The resolver is deriving hours per unit, so a volume that does not match the hours produces a rate that is quietly wrong.

**A per-unit activity may carry hours with no volume at all.** Reconstructing an old project sometimes recovers what a piece of work cost and never recovers the count behind it. Leave `volume` and `unit` out and the hours still count towards the case and towards the activity's coverage; the row simply contributes no rate, because there is nothing to divide by. Guessing the count to fill the field is the one thing not to do — the guess would become a rate, and a rate is evidence.

**`band` is required on tiered activities**, because the hours behind each band are exactly what the resolver needs and cannot infer later. Pick the band by reading the band table in the transformation plan against what the project actually was.

**Proportional activities** — `qa-automation`, `uat-support`, `project-management`, `delivery-governance` — carry `hours` and no `volume` or `band`. The resolver computes their share from the hours themselves.

**`altVolume`** exists mainly for `asset-migration`, where a project may be measured in assets or in total size. Record both when both are known: the ratio between them is useful and nobody can recover it afterwards.

### `aiToolingUsed`

This field protects the traditional baseline. Hours from a project that leaned on AI tooling are not a traditional rate, and deriving one from them understates traditional delivery and then double-counts the saving when an AI percentage is applied on top.

It is recorded **per activity**, because tooling helps component build far more than it helps a discovery workshop.

What it records depends on `source.kind`. For a `signed-estimate` it is what the estimate assumed when it was priced; for `actuals` it is what was actually used.

| Value | Meaning |
| --- | --- |
| `none` | No AI tooling assumed or used beyond incidental autocomplete. A clean traditional baseline. |
| `partial` | Ad hoc assistance on part of the work, with no systematic workflow, not relied on when sizing. |
| `full` | The work was planned around AI tooling, and the hours reflect it. |
| `unknown` | Not recallable. |

`unknown` exists so that doubt is recorded rather than resolved as `none`. The resolver may exclude `unknown` activities when deriving a traditional rate; recording a guess would silently bias it instead.

## Zero is not blank

This is the rule most easily lost in a workshop, and the one that cannot be fixed later.

- **An activity absent from `activities`** means *not recorded*. The resolver ignores it. It contributes nothing to the rate and nothing to the count.
- **An activity present with `hours: 0`** means *this project genuinely had none of this work*, and `zeroReason` says why.

| `zeroReason` | When |
| --- | --- |
| `out-of-scope` | Not in the contract. |
| `client-delivered` | The client did it. Set `owner` to `client` as well. |
| `not-needed` | In scope conceptually, but the project did not need it (no localisation on a single-locale site). |
| `absorbed-elsewhere` | Real work that was not separately estimated, and sits inside another activity's hours. Name that activity in `note`. |

`absorbed-elsewhere` is the one to watch when reading an old estimate. Older estimates frequently folded QA into build, or governance into project management. Recording the absorption keeps the other activity's rate honest, because the resolver can see that its hours are carrying passengers.

## `schedule`

Optional, and cheap to capture while the people who remember are in the room. It is not used yet; it is what would eventually put the Timeline on the same evidence footing as the hours.

| Field | Type | Rule |
| --- | --- | --- |
| `totalWeeks` | number | Elapsed weeks from start to go-live. |
| `phaseWeeks` | object | Optional. Elapsed weeks per phase, keyed by phase id. |

## `variance`

Optional, and the field that corrects the library over time. Present when both the estimate and the outcome are known.

| Field | Type | Rule |
| --- | --- | --- |
| `estimatedHours` | number | What was signed. |
| `actualHours` | number | What it took. |
| `note` | string | Optional. The main reason for the gap, in a phrase. |

A `signed-estimate` case that later gains `variance` is the most valuable record in the library: it is the only thing that shows whether we estimate high or low, and by how much.

## A worked example

```json
{
  "caseId": "C-003",
  "label": "Outdoor retailer replatform",
  "platform": "aem",
  "deliveredIn": "2025-Q3",
  "source": {
    "kind": "signed-estimate",
    "confidence": "medium",
    "enteredBy": "workshop-pair",
    "enteredAt": "2026-11-16"
  },
  "context": {
    "projectType": "replatform-cross-vendor",
    "frontend": "hybrid",
    "siteCount": 3,
    "locales": 4,
    "integrationCount": 6,
    "migrationSource": "cms-export",
    "designSystem": "partial",
    "wcag": "aa",
    "compliance": []
  },
  "activities": [
    { "activity": "discovery-audit", "hours": 180, "owner": "shared", "volume": 14, "unit": "template", "aiToolingUsed": "none" },
    { "activity": "solution-architecture", "hours": 240, "owner": "us", "band": "large", "aiToolingUsed": "none" },
    { "activity": "content-model", "hours": 150, "owner": "shared", "volume": 12, "unit": "content-type", "aiToolingUsed": "none" },
    { "activity": "design-system", "hours": 320, "owner": "us", "band": "medium", "aiToolingUsed": "none" },
    { "activity": "component-build", "hours": 980, "owner": "us", "volume": 42, "unit": "component", "aiToolingUsed": "partial" },
    { "activity": "frontend-delivery", "hours": 410, "owner": "us", "volume": 14, "unit": "template", "aiToolingUsed": "partial" },
    { "activity": "integrations", "hours": 260, "owner": "us", "volume": 6, "unit": "integration", "aiToolingUsed": "none" },
    { "activity": "search", "hours": 120, "owner": "us", "band": "medium", "aiToolingUsed": "none" },
    { "activity": "seo", "hours": 90, "owner": "shared", "band": "large", "aiToolingUsed": "none" },
    { "activity": "localization", "hours": 160, "owner": "shared", "volume": 4, "unit": "locale", "aiToolingUsed": "none" },
    { "activity": "multisite", "hours": 110, "owner": "us", "volume": 2, "unit": "site", "aiToolingUsed": "none" },
    { "activity": "workflow-governance", "hours": 70, "owner": "shared", "band": "small", "aiToolingUsed": "none" },
    { "activity": "content-migration", "hours": 520, "owner": "shared", "volume": 1850, "unit": "page", "aiToolingUsed": "partial" },
    { "activity": "asset-migration", "hours": 140, "owner": "us", "volume": 24000, "unit": "asset", "altVolume": 1.8, "altUnit": "terabyte", "aiToolingUsed": "partial" },
    { "activity": "editorial-production", "hours": 0, "owner": "client", "zeroReason": "client-delivered", "aiToolingUsed": "none" },
    { "activity": "component-review", "hours": 280, "owner": "us", "volume": 42, "unit": "component", "aiToolingUsed": "none" },
    { "activity": "accessibility-audit", "hours": 130, "owner": "us", "band": "medium", "aiToolingUsed": "none" },
    { "activity": "qa-automation", "hours": 430, "owner": "us", "aiToolingUsed": "partial" },
    { "activity": "uat-support", "hours": 200, "owner": "shared", "aiToolingUsed": "none" },
    { "activity": "environments-devops", "hours": 190, "owner": "shared", "volume": 4, "unit": "environment", "aiToolingUsed": "none" },
    { "activity": "cutover", "hours": 95, "owner": "us", "band": "medium", "aiToolingUsed": "none" },
    { "activity": "training-enablement", "hours": 85, "owner": "shared", "volume": 22, "unit": "author", "aiToolingUsed": "none" },
    { "activity": "hypercare", "hours": 120, "owner": "us", "band": "medium", "aiToolingUsed": "none" },
    { "activity": "project-management", "hours": 640, "owner": "us", "aiToolingUsed": "none" },
    { "activity": "delivery-governance", "hours": 0, "owner": "us", "zeroReason": "absorbed-elsewhere", "note": "Carried inside project-management on this engagement.", "aiToolingUsed": "none" }
  ],
  "totalHours": 5920,
  "schedule": { "totalWeeks": 26 },
  "variance": { "estimatedHours": 5920, "actualHours": 6890, "note": "SAML integration and content cleanup both ran over." }
}
```

Note what the example does: every one of the 25 activities appears. Two carry zero with a reason rather than being left out, so a reader can tell the difference between "this project had no editorial production" and "nobody asked". That is the habit the workshop needs to build.

This example is not only illustrative: `cases.mjs validate` is tested against it, read from this page. If the contract and the validator ever disagree, the test fails.

## What happens to a case next

Not part of this contract, but worth knowing while recording one:

- `cases.mjs validate` checks this schema (story A-03).
- `cases.mjs list` reports how many cases cover each activity, and which have fewer than three (story A-04).
- `cases.mjs derive` turns the library into hours per unit with a spread (story B-06). It prefers cases on the same platform, falls back to other platforms with the result marked, and returns nothing rather than guessing when no case covers an activity.

The practical consequence: **an activity with no cases produces no rate.** The estimate then falls to a derived figure the estimator has to confirm, and raises a client question. That is the intended behaviour, and it is why recording explicit zeros matters — a zero is evidence, an absence is not.
