# Case capture sheet

One sheet per past project. Fill it in with the signed estimate open, then enter it as `cases/C-nnn.json` per [case-contract.md](../case-contract.md).

Print it, or open [case-capture-sheet.csv](case-capture-sheet.csv) in Excel. It needs no tooling.

## How to run a sheet

Two hours per project, the person who priced it beside someone who delivered it. Read the estimate line by line and ask where each line lands, rather than going down this list asking "how many hours was discovery". Reading the source produces better numbers than interrogating memory.

Five rules, in the order they get broken:

1. **Every activity gets an hours figure, including zero.** Leaving a row blank means "nobody recorded this" and the resolver ignores it. Writing `0` means "this project genuinely had none of this", and needs a reason. These are different facts and the difference cannot be recovered later.
2. **Volume is what the work was actually sized against, not what the brief said.** 42 components built against a brief that said 60 is a volume of 42. Hours are divided by this number to make a rate.
3. **Every tiered row needs a band, and the signal that decided it.** Band goes in its column, the deciding signal goes in the note. The hours are meaningless without knowing which band they bought.
4. **Owner is what actually happened**, not what the contract said. If the client wrote the copy, `editorial-production` is `client`.
5. **No client names anywhere on this sheet**, including the label. Sector and work type only: "Outdoor retailer replatform".

When a line in the old estimate covers work that this breakdown splits apart, put the hours where most of the work was and record the rest as `0` with reason `absorbed-elsewhere`, naming the activity that swallowed it. That is common in older estimates, where QA often sat inside build.

## Project

| | |
| --- | --- |
| Case id | `C-___` |
| Label (no client name) | |
| Platform | |
| Delivered in | `____-Q_` |
| Source kind | `actuals` / `signed-estimate` / `architect-recall` |
| Confidence | `high` / `medium` / `low` |
| Entered by / date | |
| **Total hours** | |

## Context

| Flag | Value |
| --- | --- |
| Project type | `greenfield` / `replatform-same-vendor` / `replatform-cross-vendor` / `enhancement` |
| Frontend | `traditional` / `headless` / `hybrid` |
| Sites in topology | |
| Locales launched | |
| Integrations | |
| Migration source | `none` / `api` / `cms-export` / `database` / `scrape` / `manual` |
| Design system | `ready` / `partial` / `net-new` |
| WCAG | `none-stated` / `a` / `aa` / `aaa` |
| Compliance regimes | |
| Elapsed weeks to go-live | |
| Estimated vs actual hours (if known) | |

## What the shapes mean

A shape says where an activity's hours come from, and therefore which cells on its row you fill in.

| Shape | Hours come from | You fill in |
| --- | --- | --- |
| `per-unit` | volume x hours per unit | Volume. The unit is pre-filled. |
| `tiered` | the hours a complexity band costs | Band, plus the signal that decided it. |
| `proportional` | a share of other activities' hours | Hours only. |

**`per-unit`** — something countable genuinely scales the work: components, pages, content types, locales, environments. Hours divided by that count give a rate. If the hours are recoverable and the count is not, record the hours and leave the volume blank: the row still counts, it just contributes no rate. A guessed count would contribute one, and nobody afterwards could tell it from a measured rate.

**`tiered`** — there is no meaningful count, or the count is always 1, which comes to the same thing. Search was previously sized "per site with search", and nearly every project has one site with search, so the number told us nothing. What actually drives the effort is whether search is platform-native with two facets or federated across systems with relevance tuning. Effort varies by **how hard, not how much**, so you record which band the project was and the hours that band cost.

**`proportional`** — the activity has no driver of its own; its size follows how much other work there was. You cannot count project managements. PM scales with the engagement, QA automation with how much got built. Record the hours and nothing else: the share they represent is computed afterwards, by dividing them by the activities they cover.

## Activities

`—` means the cell does not apply to that row. Owner is `us` / `shared` / `client`.

| Phase | Activity | Shape | Unit | Volume | Hours | Owner | Band | AI | Note / zero reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Discover | `discovery-audit` | per-unit | template | | | | — | | |
| Discover | `solution-architecture` | tiered | — | — | | | | | |
| Design | `content-model` | per-unit | content-type | | | | — | | |
| Design | `design-system` | tiered | — | — | | | | | |
| Build | `component-build` | per-unit | component | | | | — | | |
| Build | `frontend-delivery` | per-unit | template | | | | — | | |
| Build | `integrations` | per-unit | integration | | | | — | | |
| Build | `search` | tiered | — | — | | | | | |
| Build | `seo` | tiered | — | — | | | | | |
| Build | `localization` | per-unit | locale | | | | — | | |
| Build | `multisite` | per-unit | site | | | | — | | |
| Build | `workflow-governance` | tiered | — | — | | | | | |
| Build | `content-migration` | per-unit | page | | | | — | | |
| Build | `asset-migration` | per-unit | asset | | | | — | | |
| Build | `editorial-production` | per-unit | page | | | | — | | |
| Assure | `component-review` | per-unit | component | | | | — | | |
| Assure | `accessibility-audit` | tiered | — | — | | | | | |
| Assure | `qa-automation` | proportional | — | — | | | — | | |
| Assure | `uat-support` | proportional | — | — | | | — | | |
| Launch | `environments-devops` | per-unit | environment | | | | — | | |
| Launch | `cutover` | tiered | — | — | | | | | |
| Launch | `training-enablement` | per-unit | author | | | | — | | |
| Run | `hypercare` | tiered | — | — | | | | | |
| Run | `project-management` | proportional | — | — | | | — | | |
| Run | `delivery-governance` | proportional | — | — | | | — | | |

**`asset-migration`:** record assets if you have a count, total size if that is what was quoted, and both if both are known. Write the second one in the note as `1.8 TB` or `24000 assets`.

**Zero reasons:** `out-of-scope`, `client-delivered`, `not-needed`, `absorbed-elsewhere`.

## The AI column

**What it is for.** It protects the traditional baseline. If a project leaned on AI tooling and we record its hours without saying so, every future "traditional" rate derived from that case is quietly low, and the AI saving we claim on top of it gets counted twice. Later, once there are cases both with and without tooling on the same activity, this column is also what lets the acceleration percentage be measured from our own delivery instead of a published benchmark.

**What to record.** It depends on the kind of case, because the hours mean different things:

- **`signed-estimate`** — what the estimate *assumed* when it was priced. If it was sized as traditional delivery, it is `none`, even if a developer happened to use an assistant.
- **`actuals`** — what was actually *used*, since the hours are what it actually took.

**It is per activity, not per project.** Tooling helps component build far more than it helps a discovery workshop or UAT. Expect the same project to be `partial` on `component-build` and `none` on `uat-support`. Do not fill one value down the column.

| Value | When |
| --- | --- |
| `none` | No AI tooling assumed or used beyond incidental autocomplete. A clean traditional baseline. |
| `partial` | Ad hoc assistance on some of the work — an IDE assistant, an LLM for scaffolding or a transform — but no systematic workflow, and it was not relied on when sizing. |
| `full` | The work was planned around AI tooling: agentic workflows, generated scaffolding, tests or migration scripts as the default path, and the hours reflect that. |
| `unknown` | Genuinely cannot recall. |

**Most of these projects predate systematic AI delivery, so `none` is the right answer for nearly every row.** Do not agonise over it. Use `partial` and `full` only for recent work where it was a deliberate part of how the team delivered, and `unknown` only where the project straddles the change and nobody remembers — guessing `none` there is what contaminates the baseline.

## Band prompts

Pick the band the project *was*, not the band it was sold as. Where two signals disagree, take the higher and say so in the note.

**`solution-architecture`**
- S — ≤2 integrations, greenfield or same-vendor upgrade, one site, no named compliance regime
- M — 3–6 integrations, or a cross-vendor replatform, or 2–5 sites
- L — 7+ integrations, or cross-vendor carrying legacy custom code, or 6+ sites, or a named regime (HIPAA, PCI, FedRAMP), or federated SSO across multiple providers

**`design-system`**
- S — Ready: component library with published tokens
- M — Partial: brand guidelines and some components, no token system
- L — Net-new: no design system existed, we built it

**`search`**
- S — Platform-native, one site, ≤2 facets, no tuning
- M — External provider, or 3–8 facets, or several content types with differing schemas
- L — Federated across systems, or 9+ facets, or relevance tuning, or multilingual, or secured and personalised results

**`seo`**
- S — One domain, no structured data, greenfield so no redirects
- M — 1–3 schema types, or under ~500 redirects, or one domain with several locales
- L — 4+ schema types, or 500+ redirects or an unquantified legacy URL set, or multi-domain hreflang, or a traffic-protection requirement

**`workflow-governance`**
- S — ≤2 stages, ≤3 roles, one site
- M — 3–4 stages, 4–8 roles, or scheduled publishing and embargoes
- L — 5+ stages, or 9+ roles, or legal and regulatory review in the path, or governance varying per site or brand

**`accessibility-audit`**
- S — WCAG 2.1 A, self-assessed
- M — WCAG 2.1 or 2.2 AA, self-assessed with remediation
- L — AA with third-party audit or VPAT, or AAA, or Section 508 procurement, or remediation after a complaint

**`cutover`**
- S — One site, flexible window, rollback is a redeploy
- M — Fixed maintenance window, DNS or CDN cutover, documented rollback, or 2–5 sites or a phased launch
- L — Zero-downtime requirement, or parallel run and dual publishing, or 6+ sites in waves, or regulated change approval, or no freeze window available

**`hypercare`**
- S — ≤2 weeks, business hours, no SLA
- M — 3–6 weeks, business hours with defined severities
- L — 7+ weeks, or out-of-hours cover, or contractual response SLAs, or transition into a managed service

## Before you close the sheet

- Every one of the 25 rows has an hours figure. Count them.
- Every `0` has a reason.
- All eight tiered rows have a band and a deciding signal.
- The AI column is filled on every row, not just the ones that were not `none`.
- The hours add up to the total at the top, within an hour.
- No client name anywhere, including the label.
