---
catalog: estimating-catalog
version: 4
status: draft
owner: Catalog owner
cmkCommit: e81d7ff6cf1f918544dd8b336e0e1e5344eb73dc
toolkitCommit: 5d1f76eeeaa01826f3906f012b21244c1be83584
pilotPlatforms: [aem, aem-eds]
---

# Estimating catalog

**Draft v4 for the catalog owner to review.** This document names the activities Blueprint maps requirements to and sizes. It also records which CMK and ai-dev-toolkit capabilities speed each activity up, on every platform and on each pilot platform, and which ai-dev-toolkit delivery methods apply. It holds no hours, rates or prices. Factors are in the SPMVP-018 workbook.

It has three tables:
- **Activities:** what each activity is, which phase it reports in, and how it is sized.
- **Capabilities:** one row per activity for `all` platforms, plus one row per pilot platform.
- **Delivery methods:** the toolkit loops teams run across activities.

Capability ids come from the CMK capability catalog and the toolkit capability catalog at the commits above. `npm run catalog:check` confirms, for every id:
- that it exists and is available;
- that it applies to its row's platform;
- that it is marked opt-in exactly where CMK lists it as opt-in.

## Coverage

- **accelerated**: the capabilities cover most of the work in this activity on this platform.
- **partly**: the capabilities help with part of the activity. The rest is delivered by people.
- **human-led**: no acceleration. The activity is delivered by people.

**Opt-in coverage** gives the coverage an activity reaches on a platform when the team enables that platform's opt-in skills. The estimate uses it only for projects that record those opt-in assets as enabled (SPMVP-034 records the enabled assets). The coverage applies only when an enabled opt-in asset is listed in that same row.

**Method coverage**, on the `all` row, gives the coverage an activity reaches when at least one delivery method that applies to it is assumed for the project. Each project records which methods it assumes (SPMVP-034). `cdk-loop` and `ld-quality` are assumed unless the project says otherwise. The coverage applies when an assumed method that applies to the activity is enabled.

In both columns, `—` means the coverage level doesn't change. Any speed-up is a factor in SPMVP-018. When both apply to an activity on a platform, the activity takes the higher level.

Sizing (SPMVP-035) raises a requirement's own coverage to the level an activity reaches with the enabled levers and never lowers it: a human-led requirement counts as accelerated when an enabled lever's coverage is accelerated. Case and spacing in a cell are forgiven (`Human led`). A cell that is not `accelerated`, `partly`, `human-led` or `—` is ignored, and the estimate says so in a challenger note. A requirement flagged `question` or `conflict` is never raised.

Treat every method coverage value as an assumption with confidence `low`, as in SPMVP-018. Neither the toolkit nor CMK has measured it yet.

`question` and `conflict` are not catalog values. Extraction sets them on individual requirements (SPMVP-008).

## Units

- **page**: a page or URL in scope.
- **template**: a page template or page type.
- **content-type**: a content type or schema to model.
- **component**: a component or block to build or review.
- **integration**: an external system to connect.
- **site**: a site or site variant in the topology.
- **locale**: a language or locale to launch.
- **environment**: a hosting or delivery environment to set up.
- **author**: a content author or editor to onboard.
- **asset**: an image, document or video to migrate.

## Activities

An activity is what carries a sizing driver, a rate and a set of capabilities. Each belongs to one **phase**, which is what the workbook and the client read: `Discover`, `Design`, `Build`, `Assure`, `Launch`, `Run`. Content work sits inside Build rather than in a phase of its own.

**Shape** says where an activity's hours come from:

- **per-unit**: volume x hours per unit. Needs a unit.
- **tiered**: the hours a complexity band costs. The band is read from the documents.
- **proportional**: a share of other activities' hours, named in **Share of**.

**Owner** is the default for a new estimate, not policy: every activity's owner is editable per estimate. `us` means we deliver it and the client's involvement is incidental. `shared` means both contribute materially, so we size our portion and state what we assume the client does. `client` is never a default — it is a decision made on an estimate.

**Share of** is `—` unless the shape is proportional. `everything-else` means every activity that does not itself use `everything-else`, so the two reporting activities size over delivery without sizing each other.

| Id | Name | Phase | Shape | Unit | Sizing driver | Owner | Default coverage | Share of |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `discovery-audit` | Discovery and audit | Discover | per-unit | template | Templates in the current site | us | accelerated | — |
| `solution-architecture` | Solution architecture | Discover | tiered | — | Integration count and platform complexity | us | human-led | — |
| `content-model` | Content modeling | Design | per-unit | content-type | Content types to model | us | accelerated | — |
| `design-system` | Design system | Design | tiered | — | Whether a design system is ready, partial or net-new | us | human-led | — |
| `component-build` | Component build | Build | per-unit | component | Components to build or extend | us | accelerated | — |
| `frontend-delivery` | Front-end delivery | Build | per-unit | template | Templates delivered through the headless or edge front end | us | partly | — |
| `integrations` | Integrations | Build | per-unit | integration | Systems to integrate | us | human-led | — |
| `search` | Search | Build | tiered | — | Searchable types, facets and relevance tuning | us | partly | — |
| `seo` | SEO and sitemaps | Build | tiered | — | Structured data, redirects and domains | us | accelerated | — |
| `localization` | Localization | Build | per-unit | locale | Locales to launch | shared | partly | — |
| `multisite` | Multisite | Build | per-unit | site | Sites in the topology | us | accelerated | — |
| `workflow-governance` | Workflow and governance | Build | tiered | — | Approval stages and roles | us | partly | — |
| `content-migration` | Content migration | Build | per-unit | page | Pages to migrate | us | accelerated | — |
| `asset-migration` | Asset migration | Build | per-unit | asset | Assets to migrate, or total size | us | human-led | — |
| `editorial-production` | Editorial production | Build | per-unit | page | Net-new pages authored | shared | partly | — |
| `component-review` | Component review | Assure | per-unit | component | Components to review | us | accelerated | — |
| `accessibility-audit` | Accessibility audit | Assure | tiered | — | WCAG level and audit type | us | accelerated | — |
| `qa-automation` | QA and test automation | Assure | proportional | — | Share of the engineering build | us | accelerated | `component-build`, `frontend-delivery`, `integrations`, `search`, `seo`, `localization`, `multisite`, `workflow-governance` |
| `uat-support` | UAT support | Assure | proportional | — | Share of the build, content included | shared | human-led | `component-build`, `frontend-delivery`, `integrations`, `search`, `seo`, `localization`, `multisite`, `workflow-governance`, `content-migration`, `asset-migration`, `editorial-production` |
| `environments-devops` | Environments and DevOps | Launch | per-unit | environment | Environments to set up | shared | partly | — |
| `cutover` | Cutover | Launch | tiered | — | Cutover windows and rollback needs | us | human-led | — |
| `training-enablement` | Training and enablement | Launch | per-unit | author | Authors to onboard | shared | human-led | — |
| `hypercare` | Hypercare | Run | tiered | — | Weeks of cover | us | human-led | — |
| `project-management` | Project management | Run | proportional | — | Share of delivery | us | human-led | `everything-else` |
| `delivery-governance` | Delivery governance | Run | proportional | — | Share of delivery | us | human-led | `everything-else` |

Shares referencing shares would be circular, so resolution runs in fixed passes: per-unit, then tiered, then `qa-automation` and `uat-support` over passes 1 and 2, then `project-management` and `delivery-governance` over everything before them. `npm run catalog:check` fails on a share set that cannot be resolved in that order.

## Starting figures

What an estimate falls back on before it has evidence. **Every number here is a placeholder nobody has measured.** The rate ladder knows that: an activity sized from this table lands on the `derived` rung, says so in the estimate, and carries a question asking somebody to stand behind the figure. A case that covers the activity replaces it, and `plan.mjs rate` overrides it for one estimate.

There is one figure per activity, not one per platform. A grid of guesses across every platform was the thing the case library replaced; a single starting figure costs nothing to carry and makes a new platform free.

- **Starting hours** is per unit of the activity's **Unit**. A tiered activity has no unit, so its figure is whole hours and its assumed volume is 1, until a complexity band sizes it.
- **Assumed volume** is used when the documents quote none. The workstream is labelled as assumed and asks the client what the real figure is.
- **AI saving** is the percentage off the traditional rate, applied only while a capability for the activity is ON in the AI plan. 0 means the activity has no saving to claim.
- **Default skills** split the activity's hours evenly, and every id is on `skills.csv`.

An activity with no row here is **not sized**, and `estimate` says so rather than inventing a figure for it. A proportional activity takes its hours from its share, so it has no starting hours or volume.

| Id | Starting hours | Assumed volume | AI saving | Default skills |
| --- | --- | --- | --- | --- |
| `discovery-audit` | 16 | 5 | 30 | `ba`, `architect`, `aem-core` |
| `content-model` | 12 | 5 | 30 | `architect`, `aem-core`, `content-strategy` |
| `component-build` | 24 | 10 | 30 | `aem-core`, `frontend-react`, `ux-design` |
| `frontend-delivery` | 16 | 5 | 30 | `frontend-react`, `ux-design`, `aem-core` |
| `integrations` | 40 | 2 | 30 | `architect`, `aem-core` |
| `search` | 24 | 1 | 30 | `architect`, `aem-core` |
| `seo` | 12 | 1 | 30 | `seo`, `aem-core` |
| `localization` | 16 | 1 | 30 | `aem-core`, `content-strategy` |
| `multisite` | 20 | 1 | 30 | `architect`, `aem-core` |
| `content-migration` | 2 | 100 | 30 | `aem-core`, `content-strategy`, `seo` |
| `component-review` | 8 | 10 | 30 | `accessibility`, `qa`, `aem-core` |
| `qa-automation` | — | — | 30 | `qa` |
| `uat-support` | — | — | 0 | `ba`, `training`, `change-management` |
| `environments-devops` | 32 | 3 | 30 | `devops` |
| `project-management` | — | — | 30 | `pm`, `delivery-lead` |
| `delivery-governance` | — | — | 30 | `delivery-lead`, `legal-compliance` |

## Capabilities

An activity's capabilities on a platform are its `all` row plus that platform's row. Within an activity, an id is listed once: ids that apply to both pilot platforms go in the `all` row. A toolkit id may be in only one activity's `all` row, and never in both an `all` row and a delivery method.

| Activity | Platform | Capabilities | Opt-in coverage | Method coverage |
| --- | --- | --- | --- | --- |
| `discovery-audit` | all | `cmk-audit`, `pdk:pdk-document-project` | — | — |
| `discovery-audit` | aem | `aem-cloud-code-assessment`, `aem-cloud-ensure-agents-md` | — | — |
| `discovery-audit` | aem-eds | `aem-eds-content-audit`, `aem-eds-block-inventory`, `aem-eds-sitemap-audit` | — | — |
| `solution-architecture` | all | — | — | — |
| `solution-architecture` | aem | — | — | — |
| `solution-architecture` | aem-eds | — | — | — |
| `content-model` | all | `cmk-model-content`, `cmk-validate-model` | — | — |
| `content-model` | aem | `cmk-schema-deploy` | — | — |
| `content-model` | aem-eds | `aem-eds-content-modeling`, `aem-eds-ue-component-model` | — | — |
| `design-system` | all | — | — | — |
| `design-system` | aem | — | — | — |
| `design-system` | aem-eds | — | — | — |
| `component-build` | all | `cmk-scaffold-component`, `cmk-figma` | — | — |
| `component-build` | aem | `aem-cloud-create-component` | — | — |
| `component-build` | aem-eds | `aem-eds-building-blocks`, `aem-eds-content-driven-development`, `aem-eds-block-collection-and-party`, `aem-eds-figma-to-content` (opt-in) | — | — |
| `frontend-delivery` | all | `cmk-headless-design` | — | accelerated |
| `frontend-delivery` | aem | — | — | — |
| `frontend-delivery` | aem-eds | `aem-eds-cwv-optimizer` (opt-in) | accelerated | — |
| `integrations` | all | — | — | accelerated |
| `integrations` | aem | — | — | — |
| `integrations` | aem-eds | — | — | — |
| `search` | all | `cmk-search-design` | — | accelerated |
| `search` | aem | — | — | — |
| `search` | aem-eds | — | — | — |
| `seo` | all | `cmk-seo-architect` | — | — |
| `seo` | aem | — | — | — |
| `seo` | aem-eds | `aem-eds-sitemap-audit`, `aem-eds-structured-data` (opt-in) | — | — |
| `localization` | all | `cmk-localization-design` | — | — |
| `localization` | aem | — | — | — |
| `localization` | aem-eds | — | — | — |
| `multisite` | all | `cmk-multisite-design` | — | — |
| `multisite` | aem | — | — | — |
| `multisite` | aem-eds | `aem-eds-create-site` | — | — |
| `workflow-governance` | all | `cmk-govern-workflow` | — | — |
| `workflow-governance` | aem | `cmk-workflow-implement`, `aem-cloud-workflow` | — | — |
| `workflow-governance` | aem-eds | — | — | — |
| `content-migration` | all | `cmk-migration-assess`, `cmk-migration-plan`, `cmk-migration-script`, `cmk-seo-architect` | — | — |
| `content-migration` | aem | — | — | — |
| `content-migration` | aem-eds | `aem-eds-page-import` (opt-in), `aem-eds-generate-import-html` (opt-in), `aem-eds-preview-import` (opt-in) | — | — |
| `asset-migration` | all | — | — | — |
| `asset-migration` | aem | — | — | — |
| `asset-migration` | aem-eds | — | — | — |
| `editorial-production` | all | `cmk-editorial-qa` | — | — |
| `editorial-production` | aem | — | — | — |
| `editorial-production` | aem-eds | — | — | — |
| `component-review` | all | `cmk-review-component` | — | — |
| `component-review` | aem | — | — | — |
| `component-review` | aem-eds | `aem-eds-code-review` | — | — |
| `accessibility-audit` | all | `cmk-a11y` | — | — |
| `accessibility-audit` | aem | — | — | — |
| `accessibility-audit` | aem-eds | `aem-eds-accessibility-fix` (opt-in) | — | — |
| `qa-automation` | all | `cmk-qa-generate-cms-tests`, `cmk-perf-audit` | — | — |
| `qa-automation` | aem | — | — | — |
| `qa-automation` | aem-eds | `aem-eds-testing-blocks` | — | — |
| `uat-support` | all | — | — | — |
| `uat-support` | aem | — | — | — |
| `uat-support` | aem-eds | — | — | — |
| `environments-devops` | all | — | — | — |
| `environments-devops` | aem | `aem-cloud-dispatcher`, `aem-cloud-rde` (opt-in), `aem-cloud-content-distribution` (opt-in), `aem-cloud-migration` (opt-in) | accelerated | — |
| `environments-devops` | aem-eds | `aem-eds-cli` | — | — |
| `cutover` | all | — | — | — |
| `cutover` | aem | — | — | — |
| `cutover` | aem-eds | — | — | — |
| `training-enablement` | all | — | — | — |
| `training-enablement` | aem | — | — | — |
| `training-enablement` | aem-eds | — | — | — |
| `hypercare` | all | — | — | — |
| `hypercare` | aem | — | — | — |
| `hypercare` | aem-eds | — | — | — |
| `project-management` | all | — | — | — |
| `project-management` | aem | — | — | — |
| `project-management` | aem-eds | — | — | — |
| `delivery-governance` | all | — | — | — |
| `delivery-governance` | aem | — | — | — |
| `delivery-governance` | aem-eds | — | — | — |

## Delivery methods

A delivery method is a toolkit loop a team runs across activities. **Applies to** lists the activities where the method is central to the work. Methods also help elsewhere, and that help belongs in the SPMVP-018 factors.

| Method | Capabilities | Applies to | Prerequisites | Default |
| --- | --- | --- | --- | --- |
| `cdk-loop` | `cdk:cdk-onboard`, `cdk:cdk-start-ticket`, `cdk:cdk-research`, `cdk:cdk-plan`, `cmk-enrich-spec`, `cmk-delivery-analyst`, `cdk:cdk-implement`, `cdk:cdk-review`, `cdk:cdk-fix-review`, `cdk:cdk-commit`, `cdk:cdk-create-pr`, `cdk:cdk-code-explorer`, `cdk:cdk-code-architect`, `cdk:cdk-code-reviewer`, `cdk:cdk-code-simplifier`, `cdk:cdk-comment-analyzer`, `cdk:cdk-silent-failure-hunter`, `cdk:cdk-test-analyzer`, `cdk:cdk-type-design-analyzer` | `component-build`, `component-review`, `accessibility-audit`, `integrations`, `search`, `frontend-delivery` | A Jira or Azure DevOps ticket per unit of work; `cdk-onboard` once per repository; a GitHub repository for pull requests; `cmk-init` in the repository for `cmk-enrich-spec`; a person who approves research, plan and implementation | yes |
| `pdk-product` | `pdk:pdk-init`, `pdk:pdk-product-brief`, `pdk:pdk-domain-research`, `pdk:pdk-market-research`, `pdk:pdk-technical-research`, `pdk:pdk-create-prd`, `pdk:pdk-validate-prd`, `pdk:pdk-create-ux-design`, `pdk:pdk-create-architecture`, `pdk:pdk-create-epics-and-stories`, `pdk:pdk-check-implementation-readiness`, `pdk:pdk-sprint-planning`, `pdk:pdk-sprint-status`, `pdk:pdk-create-story`, `pdk:pdk-correct-course`, `pdk:pdk-retrospective` | `discovery-audit` | The product owner and stakeholders available for facilitated checkpoints; `pdk-init` once per project; a person who copies stories into the tracker before `cdk-loop` | no |
| `ld-quality` | `launch-delivery:setup-project`, `launch-delivery:setup-context`, `launch-delivery:setup-conventions`, `launch-delivery:test-case`, `launch-delivery:automate`, `launch-delivery:fix-it`, `launch-delivery:run-automation`, `launch-delivery:test-it`, `launch-delivery:test-all`, `launch-delivery:e2e`, `launch-delivery:scan` | `qa-automation` | `setup-project` once per project; a test automation repository and runner; a developer-prepared session for `fix-it`; a tracker or store for test cases | yes |
| `ld-bug` | `launch-delivery:onboard`, `launch-delivery:triage`, `launch-delivery:bug-validate`, `launch-delivery:bug-fix`, `launch-delivery:bug-test`, `launch-delivery:bug-rca`, `launch-delivery:bug-metrics` | `qa-automation` | Bugs assigned in the tracker; developer sign-off before `bug-fix`; actual hours recorded for `bug-metrics` | no |
| `adr` | `adr:adr`, `adr:adr-blind-researcher`, `adr:adr-independent-analyst`, `adr:adr-adversarial-challenger` | `discovery-audit`, `frontend-delivery` | The decision maker and stakeholders available for drivers, challenge and acceptance; one run per architecture decision | no |

## Notes

**Opt-in skills**
- **`component-build`** Figma-to-content on Edge Delivery Services is opt-in. Without it, component build is still accelerated by the default block skills.
- **`content-migration`** The Edge Delivery Services import skills are opt-in. Migration is accelerated by the CMK migration skills either way; the import skills make it faster, which belongs in the SPMVP-018 factor.
- **`environments-devops`** `aem-cloud-migration` applies only when an AEM 6.5 codebase moves to AEM as a Cloud Service. With RDE and content distribution enabled, environment work on AEM as a Cloud Service is accelerated.
- **`frontend-delivery`** With the Core Web Vitals optimizer enabled, front-end delivery on Edge Delivery Services is accelerated.

**Method coverage**
- **`integrations`** Integrations have no CMK acceleration on either pilot platform. With `cdk-loop`, each integration runs through research, plan, implementation and review as its own ticket, so the activity is accelerated. Interface agreements, partner access and end-to-end testing with the other system still need people; their effort belongs in the SPMVP-018 factor.
- **`search`** CMK designs the search with `cmk-search-design`. With `cdk-loop`, the indexing, query and results code is built and reviewed through the loop, so the activity is accelerated. Tuning relevance against real content stays with people.
- **`frontend-delivery`** With `cdk-loop` building the front end on top of `cmk-headless-design`, headless delivery is accelerated. `adr` also helps settle rendering and CDN decisions.

**Activities with no acceleration yet**
- `solution-architecture`, `design-system`, `asset-migration`, `cutover`, `hypercare`, `uat-support`, `training-enablement`, `project-management` and `delivery-governance` have no capability rows. Some of these have CMK skills that should map to them; that sweep is a separate change.
- `project-management` and `delivery-governance` are activities now, sized as a share of delivery rather than as standing capacity in phase packs.

**Delivery methods**
- **pdk-product** `pdk:pdk-dev-story`, `pdk:pdk-code-review` and `pdk:pdk-quick-dev` are an alternative to the implement and review steps of `cdk-loop`. A team uses one or the other, so they have no coverage of their own.
- **cdk-loop** `cmk-enrich-spec` writes a CMS spec beside the cdk plan, and the team reads it during implementation. cdk doesn't read it automatically.
