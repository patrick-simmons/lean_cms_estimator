# Backlog

Stories for the transformation in [TRANSFORMATION-PLAN.md](TRANSFORMATION-PLAN.md). Stages A and B are decomposed because they are next and the design is settled. Stages C to G are epics for now: decomposing them before B lands would produce stories written against a contract that is still moving.

Ids are stage-prefixed. Sizes are S (up to a day), M (one to three days), L (three to five days).

## Definition of done

Every story, unless it says otherwise:

- `npm run test:tools` green, with tests for the behaviour the story adds.
- `npm run catalog:check` green where the story touches a catalog.
- `npm run pack:build` and `pack:check` green where the story touches skills, tools or docs that ship.
- No new chat checkpoint. The friction budget is four, and a story that needs a fifth has to take one over.
- The estimator types no command the story introduces: if a person runs it, the skill runs it for them.
- Docs changed in the same commit as the behaviour, not after.

---

## Stage A — settle the shapes, seed the library

### A-01 — Case record format, written down before the workshop
**As** the person running the reconstruction workshop, **I want** the fields of a case agreed and written down, **so that** tomorrow's session captures what the resolver will need instead of what seemed sensible at the time.

- Depends on: nothing. **Do this first; it is the only story that is urgent.**
- Size: S

Acceptance:
- `docs/case-contract.md` lists every field, its type and whether it is required, covering the identity and provenance block, the context flags, per-activity volume and hours, and the optional variance block.
- `source.kind` is one of `actuals`, `signed-estimate`, `architect-recall`, each with its own confidence meaning.
- The redaction rule is stated: coded label, no client name, no free text beyond the named fields.
- A worked example is included, filled in, so the workshop has something to copy.
- An activity with no hours on a project is recorded as an explicit zero with a reason, not left blank. Blank and zero mean different things.

### A-02 — Workshop capture sheet
**As** the workshop pair, **we want** a sheet that maps one-to-one onto the case record, **so that** the session output can be entered later without interpretation.

- Depends on: A-01
- Size: S

Acceptance:
- One row per activity, pre-filled with all 25 in phase order, with columns for volume, unit, hours and a note.
- Header block for the identity, provenance and context flags.
- Prompts beside the tiered activities naming the band signals, so the pair records which band the project was and why.
- Usable on paper or in Excel. No tooling dependency: this has to work tomorrow.

### A-03 — Case schema and `cases.mjs validate`
**As** a maintainer, **I want** a case file validated on the way in, **so that** a malformed or over-sharing record never reaches the library.

- Depends on: A-01
- Size: M

Acceptance:
- JSON schema matching `docs/case-contract.md`.
- `node tools/cases/cases.mjs validate <file|dir>` exits 0 or 1 with a message naming the field and the file.
- Rejects: unknown fields, a missing `source.kind`, an activity id not in the registry, free text in a field that should be an enum, a client name in `label` where a coded label is required.
- Rejects a case whose per-activity hours do not sum to the recorded total, within rounding.
- Fixtures: one valid case, one of each rejection.

### A-04 — `cases.mjs list`
**As** the catalog owner, **I want** to see what the library holds, **so that** I can tell which activities have enough evidence and which do not.

- Depends on: A-03
- Size: S

Acceptance:
- `cases.mjs list --markdown` prints one row per activity: case count, platforms covered, the observed spread of hours per unit, and the resolved confidence rung.
- Activities with fewer than three cases are marked, because that is where rung 2 and 3 behaviour starts.
- Runs against an empty library without failing, and says so.

### A-05 — Back-fill the first cases
**As** the practice, **we want** three to five past pursuits in the library, **so that** the rate resolver has something to resolve from.

- Depends on: A-02, A-03, and the workshop
- Size: M

Acceptance:
- Cases committed under `cases/`, each passing `cases.mjs validate`.
- At least one case that overran, so the spread reflects reality rather than only well-run work.
- A mix of greenfield and replatform, so `discovery-audit` has evidence.
- `cases.mjs list` shows which activities reached three cases and which did not. **This output is the input to the stage B stop condition.**

---

## Stage B — rate resolver and work breakdown

### B-01 — Activity registry
**As** a maintainer, **I want** the 25 activities defined as data, **so that** nothing downstream hard-codes the list.

- Depends on: nothing
- Size: M

Acceptance:
- The registry carries id, name, phase, shape, unit, default owner, and default skill list, and lives in the estimating catalog.
- Shapes are `per-unit`, `tiered` or `proportional`; owner defaults are `us` for twenty and `shared` for the five named in the plan.
- `catalog:check` validates the registry: ids unique and slug-formatted, every phase known, every skill id present in `skills.csv`, every proportional activity's reference set resolvable.
- A proportional activity whose reference set would be circular is a check failure.

### B-02 — Retire `WP-nn` and `OH-nn`
**As** a maintainer, **I want** activity slugs everywhere, **so that** the plan file, catalog and workbook read as English.

- Depends on: B-01
- Size: L

Acceptance:
- Catalog, plan contract, `implied-scope.json`, `catalog-suggest-keywords.json` and the id-format checks in `estimate-model.mjs` and `check.mjs` all use slugs.
- Fixtures and sample plans regenerated. Carry-over fixtures from the old web part that nothing reads are deleted rather than migrated.
- A plan file holding old ids fails validation with a message naming the replacement, rather than being silently migrated.

### B-03 — Requirements map to activities
**As** the estimator, **I want** each requirement mapped to an activity, **so that** mapping targets carry meaning and fewer requirements land `unmapped`.

- Depends on: B-01, B-02
- Size: M

Acceptance:
- Extraction and `derive-capabilities.mjs` map onto activity slugs.
- The back-test records the `unmapped` count before and after. **It should fall; a rise fails the story.**

### B-04 — `local-only` capability status
**As** the estimator, **I want** tools the team has but cannot redistribute to count toward the estimate, **so that** Drupal and Acquia work is not under-credited.

- Depends on: nothing
- Size: M

Acceptance:
- The catalog model distinguishes `supported`, `local-only` and `unavailable`. `local-only` is `retention: local_only` plus an admissible licence policy.
- `catalog:check` accepts `local-only` ids and still rejects `unavailable` ones.
- A `local-only` tool appears in the AI plan and raises a readiness item naming what must be synced locally.
- The skill pack ships nothing `local-only`. A test asserts it.
- Generated catalog counts report the three states separately.

### B-05 — Catalog mapping sweep
**As** the catalog owner, **I want** the all-platform CMK set mapped properly, **so that** every platform gets the acceleration it is entitled to.

- Depends on: B-01, B-04
- Size: S

Acceptance:
- `cmk-schema-deploy` and `cmk-workflow-implement` move from the `aem` row to `all`.
- `cmk-dam-design` maps to `asset-migration`.
- Acquia and Drupal vendor capabilities are mapped now that `local-only` exists.
- `cmk-content-drift`, `cmk-eval-platform`, `cmk-kb-sync`, `cmk-init` and `cmk-help` stay unmapped, each with a recorded reason, and the unused-tool report prints the reason beside the id.

### B-06 — `cases.mjs derive`
**As** the estimate, **I want** hours per unit and a spread per activity derived from comparable cases, **so that** rates come from delivered work.

- Depends on: A-03, B-01
- Size: L

Acceptance:
- Returns likely (median), low and high (quartiles, or the observed span when n is small), with n, the contributing case ids and the platform match quality.
- Prefers same-platform cases; falls back to cross-platform and marks the result accordingly.
- Below three cases, returns the full observed span, low confidence, and a flag that a question is owed.
- Returns nothing rather than guessing when no case covers the activity.
- Deterministic: the same library returns the same numbers.

### B-07 — The rate ladder
**As** the estimator, **I want** every activity to record which rung its hours came from, **so that** I can see what is evidence and what is not.

- Depends on: B-06
- Size: L

Acceptance:
- `basis` is `cases`, `cases-adjusted` or `derived`, recorded per activity with `caseIds[]` and `caseCount`.
- Rungs 2 and 3 always raise a client question; rung 1 never does.
- A `derived` rate requires an estimator decision recorded in the plan. The tool never writes one unprompted.
- `validate` rejects an activity with hours and no basis.

### B-08 — Three-point hours
**As** a pursuit lead, **I want** low, likely and high per activity, **so that** I can see the range the evidence supports.

- Depends on: B-07
- Size: M

Acceptance:
- Each activity carries `low`, `likely`, `high`; `low <= likely <= high` is a validation rule.
- Totals roll up across activities, phases and the estimate.
- Likely is the number the summary and the skill lead with. Low and high are shown as a range, never as a choice to make.

### B-09 — Tiered banding
**As** the estimator, **I want** tiered activities banded from the documents, **so that** complexity is read rather than assumed.

- Depends on: B-01, B-06
- Size: L

Acceptance:
- Each of the eight tiered activities resolves to small, medium or large from the signals in the plan, with the deciding signal and its citation recorded.
- No signals means medium, low confidence, and a client question.
- Conflicting signals take the higher band and emit a challenge, not a question.
- A quoted signal outranks an inferred one.
- Re-running over the same plan produces the same band.

### B-10 — Proportional resolution
**As** the estimate, **I want** QA, UAT, project management and governance sized as shares, **so that** phase ratios are right by construction.

- Depends on: B-07, B-08
- Size: M

Acceptance:
- Four passes in the fixed order: per-unit, tiered, then `qa-automation` and `uat-support`, then `project-management` and `delivery-governance`.
- Shares derive from cases. With no case evidence, the fallback ratio is used and labelled as a fallback.
- The reference set for each is recorded, so a reader can see what the share was taken over.
- A circular reference set is a validation error, not a runtime surprise.

### B-11 — Activity ownership
**As** the estimator, **I want** to change who owns an activity, **so that** the estimate reflects what the client is doing.

- Depends on: B-01, B-07
- Size: M

Acceptance:
- `plan.mjs owner <activity> --set us|shared|client --note "<reason>"`, agent-invoked, note required.
- `client` sizes to zero and writes an exclusion plus a question carrying the assumed volume.
- `shared` sizes our portion; with no case evidence it sizes at full and says so.
- Proportional activities are sized whole and then reduced, so a client-run UAT does not shrink project management.
- The change survives a re-run, like every other estimator decision.

### B-12 — Delete `factors.csv`
**As** a maintainer, **I want** the factor table gone, **so that** there is one way hours are produced.

- Depends on: B-07, B-09, B-10
- Size: M

Acceptance:
- `factors.csv`, the `Factors` sheet in `seed.mjs`, `ratesOf` and `fixedRatesOf` are removed with their tests.
- `workstream-defaults.csv` loses default volumes, default hours and skill lists; whatever remains moves to the registry and the file goes.
- **The AI-assisted rate keeps working.** With the opt-in and methods columns gone, the saving is a single percentage per activity, still gated on a tool being ON. Splitting it into the IP and GenAI tracks is stage E; this story must not regress the number to zero.
- `pack:build` and `pack:check` green with the seed smaller.

### B-13 — Workbook columns
**As** a pursuit lead, **I want** the new fields in the workbook, **so that** the estimate is reviewable without opening JSON.

- Depends on: B-08, B-11
- Size: M

Acceptance:
- Activities sheet carries low, likely, high, basis, case count, owner and band alongside the existing columns; `AI rate used` goes.
- Template regenerated by `build-template.mjs`, and the positional column test updated in the same commit.
- Client and shared activities appear on `Assumptions and risks` with their assumption and question.
- Opens in desktop Excel with every formula calculating and no error cell.

### B-14 — Timeline lanes
**As** a pursuit lead, **I want** Build shown as parallel tracks, **so that** the timeline does not imply a waterfall.

- Depends on: B-01, B-13
- Size: M

Acceptance:
- `phase-packs.csv` reworked for the six phases, with lanes either as a column or a sibling file.
- Build renders Engineering and Content as separate lanes, Content offset behind Engineering.
- Lane membership derives from activity ids. The estimator is asked nothing.
- The Timeline sheet stays template-owned; the writer is unchanged.

### B-15 — Factors workbook trimmed and renamed
**As** the catalog owner, **I want** the workbook to match what it now holds, **so that** its name stops implying it sets rates.

- Depends on: B-12, B-14
- Size: S

Acceptance:
- `Factors` sheet dropped; `Phase packs` reworked for six phases and lanes.
- File and script renamed, with references updated.
- A decision recorded on the empty `AI allowance` sheet: keep with a purpose, or remove.

### B-16 — Validation and contract
**As** a maintainer, **I want** `validate` to enforce the new contract, **so that** an invalid plan cannot reach the workbook.

- Depends on: B-07 to B-11
- Size: M

Acceptance:
- `plan-contract.md` updated for activities, basis, three-point, owner, band and deltas.
- `validate` covers: low ≤ likely ≤ high; basis present wherever there are hours; owner valid; band present on tiered activities; proportional reference sets resolvable and acyclic; skills still summing to activities.
- Each rule has a failing fixture.

### B-17 — Re-baseline the back-test
**As** a maintainer, **I want** the back-test running on the new model, **so that** stage B's effect on accuracy is visible rather than assumed.

- Depends on: B-12, B-16
- Size: M

Acceptance:
- The synthetic case and its expectations are rebuilt against activities.
- The back-test reports estimate against reference, and reports `unmapped` count and the share of activities on each rung.
- A baseline is recorded in the repo so later stages can be compared against it.

### B-18 — Update the skill
**As** the estimator, **I want** the run to explain the new output, **so that** more fidelity does not mean more to work out.

- Depends on: B-08 to B-13
- Size: M

Acceptance:
- Step 8 covers the ladder, bands and three-point; the summary leads with likely and shows the range beside it.
- Bands and their deciding signals appear in the checkpoint 3 summary. They are not a question. (Written as checkpoint 1, moved when it was built: `band.mjs` reads accepted volumes only, and acceptance happens *at* checkpoint 1, so a band shown there would read systematically low and then change. Checkpoint 3 is also where the band's own client question belongs.)
- Ownership changes are offered at checkpoints 2 and 3 only.
- **Still four checkpoints.** A test or a review check asserts the count.
- The guardrails keep saying the agent never invents an hour, a volume or a band.

### B-19 — Scope caps as named assumptions
**As** the estimator, **I want** every figure the estimate assumes to carry a cap I accepted, **so that** a number that is not evidence reads as a commitment rather than as a placeholder waiting to be replaced.

- Depends on: B-11, B-13, B-18
- Size: M

Today an assumption can only exist where evidence is absent: a volume the documents state gets `volumeBasis: document` and produces no assumption row at all. The caps that matter commercially are the ones on volumes the client gave us.

Acceptance:
- `plan.mjs assume <activity> --cap <n> --note "<reason>"` is agent-invoked, requires the note, and records `via` and `at` as the other review decisions do. A re-run never resets it.
- A capped activity's `Source of the volume` reads `capped at <n> <unit>s`, whether its basis is `document` or `placeholder`.
- Each cap produces one `Assumptions and risks` row naming the cap, the activity, the basis and what a breach costs, in the existing six columns with none added.
- Caps, the ownership exclusions from B-11 and the gap sweep's scope assumptions render through one code path and one vocabulary. No second assumption record is introduced.
- The assumptions reuse the Context sidecar's field names rather than inventing a third vocabulary, but live on the plan file, because the workbook reads only the plan.
- No commercial field, category, rate or contingency is written anywhere. A test asserts it, as the scope cut checks already do.
- **Still four checkpoints.** The caps are offered at checkpoint 3 as one accept-all question, and a test asserts the count.

---

## Later stages, as epics

To decompose when B lands, not before.

| Epic | What it covers |
| --- | --- |
| **C. Drupal** | Platform profile format with deltas, platform-scoped skill lists, Drupal catalog rows, proved end to end on a real pursuit. |
| **D. Challenge and audit** | Challenge pass producing typed adjustments, `plan.mjs audit` for phase ratios, challenges in the workbook, question ranking by computed hour swing. |
| **E. Acceleration split** | The single saving percentage from B-12 splits into `ipSavingPct` and `genaiSavingPct`, multiplied not subtracted, with prerequisite verification and benchmark bands. |
| **F. Research** | Query construction that carries no client text, recorded findings with staleness, deltas backed by findings. |
| **G. Calibration** | `cases.mjs promote` turning a closed pursuit into a case, variance tracking, and the ease-of-use measures taken on a real run. |
