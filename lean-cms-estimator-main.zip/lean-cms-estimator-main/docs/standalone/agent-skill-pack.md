# Blueprint skill pack: install and run

The Blueprint skill pack lets an estimator run the offline Blueprint pipeline in Cursor or Claude Code against a project folder, without this repository, without Azure and without Foundry. It holds ten skills, the Node tools they call, a snapshot of the catalogs and hub libraries, the file contracts, and sample projects to try it on. This page is the install guide; it is also the `README.md` at the root of a built pack.

## What you need

- Node 22.14 or later on the 22 line, 24, or 26 (`node --version`). Nothing else: the tools have no dependencies to install.
- Cursor, or Claude Code (CLI, desktop or IDE extension).
- The pack: a zip named `blueprint-skill-pack-<version>.zip`, or the `blueprint-skill-pack/` folder it unpacks to. In the repository, `npm run pack:build` writes both to `release/`.
- A project folder with the opportunity's source files. When the standalone Blueprint app prepared it, it already holds `AGENTS.md` and `.blueprint/sources.json`.

## Install

1. Unzip the pack somewhere permanent, for example `C:\Tools\blueprint-skill-pack` or `~/tools/blueprint-skill-pack`. That folder is the **pack root**: it holds `pack.json`, `skills/`, `tools/`, `docs/` and `samples/`.
2. Set the environment variable `BLUEPRINT_PACK` to the pack root. The skills refer to the tools and catalogs through it.
   - Windows (PowerShell, once): `[Environment]::SetEnvironmentVariable('BLUEPRINT_PACK', 'C:\Tools\blueprint-skill-pack', 'User')`, then restart the editor.
   - macOS or Linux: add `export BLUEPRINT_PACK="$HOME/tools/blueprint-skill-pack"` to your shell profile.
   - If you cannot set it, the skills tell the agent to use the pack root path directly. Have it to hand.
3. Install the skills where your tool looks for them:
   - **Claude Code, every project:** copy the folders under `skills/` into `~/.claude/skills/`. Or load the pack as a plugin for one session: start Claude Code with `claude --plugin-dir <pack root>` (the pack carries `.claude-plugin/plugin.json`).
   - **Claude Code, one project:** copy `skills/*` into the project folder's `.claude/skills/`.
   - **Cursor, every project:** copy `skills/*` into `~/.cursor/skills/`.
   - **Cursor, one project:** copy `skills/*` into the project folder's `.cursor/skills/`.
   Keep the folder names (`blueprint-offline`, `blueprint-parse`, ...). The `references/` folder inside `blueprint-extract-map` travels with it.
4. Check that it works (the commands in this guide use bash syntax; in PowerShell write `$env:BLUEPRINT_PACK` where they say `$BLUEPRINT_PACK`):

   ```bash
   node "$BLUEPRINT_PACK/tools/blueprint/validate-working-file.mjs" "$BLUEPRINT_PACK/samples/offline/Synthetic_AEM_Blueprint.json"
   ```

   ```powershell
   node "$env:BLUEPRINT_PACK/tools/blueprint/validate-working-file.mjs" "$env:BLUEPRINT_PACK/samples/offline/Synthetic_AEM_Blueprint.json"
   ```

   Either prints `OK`.

To upgrade, unzip the new version over the old pack root and copy the skills again. `pack.json` says which version is installed; every tool records the version it ran in `.blueprint/run.json`, which is where you can see which version produced a project's files. The standalone app shows it too: the project screen has a line such as `Pack 0.1.0 · Run complete`.

## Run it on a project folder

1. Open the project folder in Cursor or Claude Code. If the app prepared the folder, `AGENTS.md` is there and tells the agent what to read and write. Otherwise prepare it yourself: `node "$BLUEPRINT_PACK/tools/blueprint/prepare-folder.mjs" "<folder>" --project "<Project name>" --prompt`.
2. Ask for the orchestrator skill: in Claude Code, `/blueprint-offline`; in Cursor, invoke the `blueprint-offline` skill, or paste the starter prompt the prepare step printed ("Open this folder ... and run the blueprint-offline skill on it ...").
3. The agent runs parse, extract and map, enrich and validate, and ends with a summary: mode (first run or re-run), pack and catalog versions, files written, sources not read.
4. Back in the app, reload the project. A first run shows the requirements. A re-run writes `{Project}_Proposals.json` for the estimator to accept or reject: the Requirements step lists the pending proposals, and Accept or Reject saves the decision. The project screen also shows the pack version and the run's stage. If the files were written by a newer or older schema than the app knows, it says so and turns editing off until the app or the pack is updated; to see the record yourself run `node "$BLUEPRINT_PACK/tools/blueprint/run-record.mjs" "<folder>" --show`.

What a run writes into the folder, and what it never touches, is in `docs/agent-contract.md` in the pack.

When a tool stops, its exit code says why. `parse-local.mjs`: 2 bad usage or an unsafe `--out` or `--select`, 3 no source was selected (a prepared folder whose selection is empty), 4 no source produced any block (pass `--allow-empty` only when you expect that). `assemble-working-file.mjs`: 3 the Blueprint has review state or cannot be read, so it will not be overwritten (run the re-run path instead), 4 the extract JSON yielded no requirement. `prepare-folder.mjs` and `run-record.mjs`: 2 bad usage; a damaged `.blueprint/run.json` stops the tools with a message that names the file (`run-record.mjs --reset` starts a new record).

## Try it on the sample

The pack carries a synthetic project. Copy `samples/sources/synthetic-aem/` to a scratch folder, run the two commands below, then ask the agent to run `blueprint-offline` on that folder:

```bash
node "$BLUEPRINT_PACK/tools/blueprint/prepare-folder.mjs" "<scratch>" --project "Fabrikam Outdoor"
node "$BLUEPRINT_PACK/tools/blueprint/parse-local.mjs" "<scratch>"
```

`samples/agent-run/` holds what a complete run produced (first run, review, re-run with `samples/sources/synthetic-aem-addendum/`), so you can compare. The checklist for judging a run is `docs/agent-run-evaluation.md`.

## Catalog freshness

`pack.json` names the estimating catalog version and the CMK and toolkit commits the pack carries. When your hub folder (the synced catalog library the app reads) has a newer estimating catalog, tell the agent its path; the orchestrator prefers it and names both versions in the run summary.

## Data handling

The pack runs on your machine and the tools make no network call. What the agent itself sends to its model is governed by your Cursor or Claude account and your organization's rules. The data-handling note for the standalone app (SAPP-011) says where this step sits; it does not assess it. Client files stay in the project folder; never copy them into the pack or into this repository.

## Building the pack (repository only)

```bash
npm --prefix function run build
npm run pack:build
```

This writes `release/blueprint-skill-pack/` and `release/blueprint-skill-pack-<version>.zip`, stamped with the version from `tools/release/pack.config.json`, the git commit, the build time and the catalog pins. The skills in `.claude/skills/` and the tools in `tools/` are the source; the build rewrites repo paths to `$BLUEPRINT_PACK`, bundles the parse and prepare tools with the function's document readers, and fails if a skill still names a path outside the pack (`npm run pack:check`). A build from a working tree with uncommitted changes is stamped `<commit>-dirty`, and one where git could not give the commit is stamped `unknown`; neither is releasable, so the build stops ("the pack is not releasable") unless you pass `--allow-dirty`. Build a release from a clean checkout. The extraction instructions in `blueprint-extract-map/references/` are the source and are edited in this repository; the build stops only if one of them is missing. To release a new version, bump `version` in `pack.config.json`, build, and attach the zip to the release.

### Running the checks locally

The `agent-pack` GitHub Actions workflow is manual-trigger only (hosted runners are disabled for this repository), so nothing runs automatically on a pull request. Before you open one:

```bash
npm run verify    # tool tests (builds function/dist first when needed), then pack:build, then pack:check
npx heft test     # Jest, including the TypeScript validators that must agree with the Node ones
```

`npm run build` (the SPFx release build) does not run the Node tool tests.

## Install notes from people who tried it

Record here who followed this guide, in which tool, and what tripped them up (SAPP-015 acceptance).

| Date | Who | Tool | Notes |
| --- | --- | --- | --- |
| | | | not yet done |
