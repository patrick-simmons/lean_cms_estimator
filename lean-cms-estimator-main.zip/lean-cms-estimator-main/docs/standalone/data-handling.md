# Data handling in the standalone app

Where client data goes when the Blueprint standalone app is used, and where it does not (SAPP-011). The readers are the security reviewer and the pilot users. No client text belongs here. "The project folder" is the folder a person picks for one opportunity; it may be a OneDrive-synced library folder, but the app does not check.

> **Status.** This describes what the code does and what has been checked. It is input to the security review, not an approval to handle client documents. Not yet run: the browser checks in [Hosting and launch](hosting-and-launch.md#manual-checks), the [OneDrive checks](onedrive-round-trip.md) and the [agent runs](agent-run-evaluation.md). The AI step is a separate review (section 4).

## 1. What the app's page can send

| Claim | Evidence |
| --- | --- |
| The app reads and writes in the project folder, and reads an optional hub folder (catalogs, factors workbook, template) without write access, through the browser's folder access. The launcher never sees those files. | `app/fsa.ts`; `app/HubBar.tsx`; [SAPP-004](../../backlog/standalone/SAPP-004-folder-handle-file-storage.md); `tools/app/serve.mjs` reads only the site folder |
| Served by the launcher, the page is stopped from requesting another origin: `default-src 'none'`, `connect-src 'self'`. The header is sent and tested; a browser obeying it is manual check 1, not yet run. A static host has this only if it sends the same header. | `CSP_DIRECTIVES` in `tools/app/serve.mjs`; `tools/app/serve.test.mjs`; [Hosting and launch](hosting-and-launch.md#the-content-security-policy) |
| The build fails if an SPFx or MSAL package reaches the bundle. | `FORBIDDEN_PREFIXES` and `findForbidden` in `tools/app/forbidden.mjs`, used by `tools/app/build.mjs`; test "keeps SharePoint and MSAL packages out of the bundle" in `tools/app/build.test.mjs`; `src/webparts/blueprint/uiImportBoundary.test.ts` |
| That check names packages, not Graph or Azure. The web part's extraction code is still in the repo and nothing enforces that the app leaves it out. The app's extraction callbacks are stubs, and the UI hides their buttons. | `extractionStubs` in `app/host.ts`; `extractionAvailable={false}` in `app/FolderGate.tsx` |
| A one-off search of a built bundle on 2026-11-10 found no `fetch(`, `XMLHttpRequest`, `sendBeacon`, `WebSocket`, `EventSource`, `importScripts` or service worker. Image and script-tag requests were not searched; only the policy would stop those. Not a test. | Repeat it as in section 6 |
| Link clicks and `window.open` are outside the policy. In folder mode `folderUrl`, `webUrl`, `versionHistoryUrl` and the publish link are empty; a link appears only if a working file saved elsewhere carries one, and opens only on a click. | [Hosting and launch](hosting-and-launch.md#what-the-policy-does-not-cover); `folderStorage.ts` |

## 2. What is stored on the machine

| Where | What | Evidence |
| --- | --- | --- |
| Browser IndexedDB `blueprint-app` (one origin, `http://localhost:<port>`) | Folder handles and folder names for up to 25 recent project folders, plus the hub folder's handle (`hub-folder`). No file content. A folder name can name a client. A kept handle can reopen a folder without the picker while the browser allows. Entries can be removed. | `app/fsa.ts`; `app/README.md` (Folder access) |
| Browser `localStorage` `blueprint.identity.v1` | The name and email typed at the start, unverified. They are also written into the folder: as owner in the project file, and as reviewer and `publishedBy` in working files. | `IDENTITY_KEY` in `app/identity.ts`; [SAPP-005](../../backlog/standalone/SAPP-005-local-project-index-and-status.md) |
| The project folder | The working file (`{Project}_Blueprint.json`, holding extracted passages from client documents), the published workbook, `{Project}_PricerHandoff.csv` (hours and FTE figures), `.blueprint-project.json`, and the browser's `.crswap` file during a save. | `app/README.md` (Publishing, The project file) |
| Clipboard | A starter prompt, only on Copy prompt. It may contain the project name. | `src/webparts/blueprint/components/OfflineSourcesPanel.tsx` |
| Browser console | Error messages, which can include file names. No file content was found being logged. | The app's `console.error` calls |

## 3. What the app does not do

- **No sign-in.**
- **No Graph, SharePoint or Foundry call was found** in the app or bundle (section 1). That is a search result and a package check, not a test of those services.
- **No telemetry through `fetch`, XHR, WebSocket or `sendBeacon` was found.**
- **Nothing else is stored** by the app beyond section 2. The agent's files (section 4) are written by its tools.

## 4. Where AI sees client data

Extraction is not in the app. A person runs Cursor or Claude Code against the project folder, using the skill pack ([SAPP-015](../../backlog/standalone/SAPP-015-portable-skill-pack.md)), the local parse tool ([SAPP-013](../../backlog/standalone/SAPP-013-local-parse-tool-for-the-skill-pack.md)) and the file contract ([SAPP-014](../../backlog/standalone/SAPP-014-agent-and-app-file-contract.md)). The app shows a starter prompt and reads the result on reload. Preparing the folder from the app (SAPP-016) is not wired in: `npm run blueprint:prepare` (`tools/blueprint/prepare-folder.mjs`) writes `AGENTS.md`, `CLAUDE.md`, `.blueprint/sources.json` and `.blueprint/expect.json`, which hold the project and file names.

- **Written by the tools into the project folder:** `.blueprint/parsed/` (extracted passages), `.blueprint/run.json`, `.blueprint/extract.json` and `{Project}_Proposals.json`. They sync with the folder. The parse tool can send its output elsewhere with `--out`.
- **Parse tool and the network:** none in the tested run, with `fetch`, `http`, `https` and sockets blocked, on the synthetic sample (`tools/blueprint/parse-local.test.mjs`).
- **Cursor or Claude's handling** of the source files is under their own data terms and the organization's AI rules. **This note does not assess it.** The concern behind leaving Foundry (SAPP-011 decisions) may apply to this route too.
- **Status: built, not yet evaluated.** SAPP-013 to 017 have open acceptance boxes. The only recorded run is the author's replay in a repository checkout, not the installed pack ([evaluation](agent-run-evaluation.md), [pack guide](agent-skill-pack.md)).
- The earlier review of the function and Foundry path (SPMVP-015) covers a different route and is not reused.

## 5. Sync, limits and what is not assessed

| Item | Wording | Evidence |
| --- | --- | --- |
| Sync and permissions | If the project folder is in a synced SharePoint library, SharePoint controls who can reach the library; the app adds no permission check. Anyone using the machine account can read the local copy. Labels and retention on it are not checked. | [OneDrive round trip](onedrive-round-trip.md) |
| Known limits | Identity is self-declared. The app keeps no audit trail; if the folder syncs, SharePoint version history records the OneDrive user, not the typed name (a prediction). One editor per project is a proposed rule, not enforced, and the conflict check is best effort. | [SAPP-005](../../backlog/standalone/SAPP-005-local-project-index-and-status.md); [SAPP-009](../../backlog/standalone/SAPP-009-onedrive-round-trip-and-conflict-test.md); `app/README.md` (Saving) |
| The browser | Edge or Chrome's own data handling is outside this note and not assessed. | None |
| Fluent UI | Its font fallback to a Microsoft CDN would be blocked by `font-src 'self'`, with no client data in it. Its bundle holds `localStorage` and `sessionStorage` helpers; no call from the app's code was found. Neither was run. | [Hosting and launch](hosting-and-launch.md#the-fluent-font-request) |

## 6. Check it yourself

`npm run app:build`, then search `dist-app/` for `fetch(`, `XMLHttpRequest`, `sendBeacon`, `WebSocket`, `EventSource`, `localStorage`, `sessionStorage` and `https://`. An `https://` hit should be an XML namespace, a documentation link, a sample-project label or Fluent's CDN font address. `node --test tools/app/*.test.mjs` runs the policy, bundle and note checks.
