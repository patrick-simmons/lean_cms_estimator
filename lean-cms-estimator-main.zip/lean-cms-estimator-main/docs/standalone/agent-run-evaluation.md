# Agent run evaluation and guardrail checks

How we know whether the installed skill pack, run by a real agent in Cursor and in Claude Code, produces files the app accepts, follows its guardrails and protects review decisions (SAPP-017). Code decides what code can decide and local commands check it; the model's part is judged by a person with the checklist below, on every pack release and whenever the model changes. No client text belongs in this file.

> **Status.** The tools, the file contract and the automated checks below exist. The proposals review list is in the Requirements step. The standalone app also shows the run-record status line and the version warning. The Prepare for the agent action is not yet wired in, so item 1 can only be met through the validators and the folder files until it is.

## Automated checks (no model)

Run by `npm run verify` (which runs `npm run test:tools`, `pack:build` and `pack:check`) and `npx heft test` locally. The `agent-pack` GitHub Actions workflow runs the same checks, but GitHub-hosted runners are disabled for this repository (2026-11-09), so it is manual-trigger only until a self-hosted runner is registered (set the repository variable `AGENT_PACK_RUNNER` to its label) or hosted runners are enabled. **Nothing gates a pull request automatically:** run the checks on the developer's machine before a PR.

| Check | Where |
| --- | --- |
| Every shipped Blueprint and Context sample validates with the Node validators; the deliberately malformed review fixture is rejected | `tools/blueprint/samples.test.mjs` |
| The TypeScript validators the app uses agree with the Node validators on the shared fixtures (Context and Proposals), and read the shipped samples | `src/webparts/blueprint/projects/contextFile.test.ts`, `proposalsFile.test.ts` (Jest, `npx heft test`) |
| **No-overwrite contract:** a full replay of the agent run (prepare, parse, first run, review, addendum, proposals) changes no requirement, question or source of the reviewed Blueprint, and a first-run write over it is refused | `tools/samples/agent-run-sample.test.mjs`, `tools/blueprint/assemble-proposals.test.mjs` |
| Citations in the Blueprint and the proposals are block ids the parse tool produced, with the tool's labels and passages | `tools/samples/agent-run-sample.test.mjs` |
| The Office readers used locally produce exactly the function's blocks; a PDF without a text layer is `not read`; no network call is made | `tools/blueprint/parse-local.test.mjs` |
| No commercial or work-environment field, driver quantity or hours in any file of the replayed run, and the tools do not carry such fields through from model output | `tools/samples/agent-run-sample.test.mjs` |
| No committed sample file and no file in a built pack names an absolute local path (a user folder or a temp folder) | `tools/samples/agent-run-sample.test.mjs` |
| The built pack refers only to itself and the project folder, and works from a folder outside the repository | `tools/release/build-skill-pack.test.mjs` |

The replayed run uses the committed extract JSON and Context sidecar under `tools/samples/agent-run/` as the model's part. That checks the tools and the contract, not the model.

## Manual agent runs

Do these with the **installed pack** (not the repository checkout), in Cursor and in Claude Code, on each of:

1. `samples/sources/synthetic-aem/` with the project name `Fabrikam Outdoor`, then the re-run with `samples/sources/synthetic-aem-addendum/Fabrikam_Addendum.docx` added after reviewing (accept a few rows, edit one, dismiss one).
2. The Northwind evaluation pack when its source documents are available (the repository has only the extracted sample, `samples/review/`, which a built pack does not carry).
3. The private customer pack (SPMVP-014), outside git.

### Checklist

For each run, record pass or fail and a note. Compare with `samples/agent-run/` for the synthetic project.

| # | Check | How to tell |
| --- | --- | --- |
| 1 | The app opens the result with no "malformed" message | Reload the project in the web part or the standalone app; `validate-working-file` and `validate-context --blueprint` exit 0 with no warnings (the validators are the check until the standalone app's agent hand-off is wired in) |
| 2 | Citations match the parse tool's output | Every `sources[].blockId` is in `.blueprint/parsed/blocks.json` with the same label and passage (the replay test does this by code; by hand, spot-check five rows) |
| 3 | The planted contradiction is one `conflict` row with two citations from two files, a question, and no winner | Synthetic project: two locales (deck) against four (RFP) |
| 4 | No driver quantity or hours are invented | No `estimate`; no number in a statement, assumption or risk that the documents do not state; numbers the documents give are kept as given |
| 5 | A second run after review changes none of the reviewed rows | Diff the Blueprint before and after; only `{Project}_Proposals.json` and `.blueprint/` changed |
| 6 | No commercial or work-environment field (Scope Cut #2) | Search the three files for `accountHistory`, `newLogo`, `commercialRisks`, `workEnvironment`, `clientDifficulty`, `difficultyMultipliers`, `staffingProfiles`, rates, prices, contingency |
| 7 | The run summary names mode, pack version, catalog versions, files written and sources not read | Read the agent's final message |
| 8 | Files the tool could not read are reported, not transcribed | The scan and the legacy `.doc` appear as `not read` in the manifest and in the summary; nothing cites them |
| 9 | Every register item and every requirement the agent wrote is `pending` | `list-requirements.mjs`; the sidecar's `review.status` fields |
| 10 | The run record ends at `done` and names the pack version | `.blueprint/run.json` (`run-record.mjs <folder> --show`); the standalone app's project status line shows it (`Pack 0.1.0 · Run complete`) |

### Scoring

When the known past opportunity and the SPMVP-014 scoring harness exist, score recall and precision of the requirements against its reference list. Until then record a hand score: of the requirements a person lists from the documents, how many the run found (recall) and how many of the run's rows a person agrees are requirements (precision). The harness itself is SPMVP-014's deliverable, not this ticket's.

### Model and tool variance

Note differences between Cursor and Claude Code and between model versions: statements phrased differently, a conflict missed or invented, rows merged or split, a work package chosen differently. Record what to pin (model version, pack version) when a difference matters.

## Results

Keep one block per run. No client text; for the private pack record counts and judgements only.

### 2026-11-09, Claude Code (the implementing agent, repository checkout, not the installed pack), synthetic AEM

- Run: `tools/samples/agent-run-sample.mjs` replays it. The model's extract and sidecar were written by the implementing agent from the parsed blocks, then the tools did the rest. Result committed as `samples/agent-run/`.
- Checks 1, 2, 3, 4, 5, 6, 8, 9, 10: pass (by code, in the replay test). Check 7: the replay has no agent summary; not applicable.
- Hand score on the synthetic documents: 16 requirements listed by hand, 16 found (recall 16 of 16); 15 of the 16 rows kept as requirements (precision 15 of 16): R-016, the statement that the content inventory lists 6,400 pages, was dismissed as a duplicate of the migration row during review. This is the author scoring their own run and counts for little.
- Not done: a run through the installed pack in Cursor; a run through the installed pack in Claude Code by someone other than the author; the Northwind pack (no source documents in the repository); the private pack. These are open items for the product owner and a pilot estimator.

### Open: Cursor, installed pack, synthetic AEM

Not yet run.

### Open: Claude Code, installed pack, synthetic AEM

Not yet run.

### Open: private customer pack, both tools

Not yet run. Record counts only.

## Known limitations

- **PDF headings are a heuristic.** The local tool detects headings by section numbering and font size, not by layout analysis. Page numbers are exact; a heading may be missed or a numbered paragraph taken for one. Office formats use the function's own readers and are exact.
- **Scans and images are not read.** The local tool does no OCR. Such files are reported `not read` and the estimator supplies text another way. A PDF whose pages carry only a stamp, footer or watermark counts as having no usable text on those pages: the file is `partial` or `not read` and the manifest lists the page ranges, so a scan with a Bates stamp is not mistaken for a readable file.
- **Multi-column PDF pages can interleave.** The heuristic sorts a page's text by position, so two columns on one page may be merged line by line. Page numbers stay right; check the statements drawn from such pages.
- **The model's part is not deterministic.** Two runs can phrase statements differently, so a repeat first run on an unreviewed folder can produce a different file. Once the Blueprint has review state, a repeat first run is refused (and so is a Blueprint the tool cannot read), and differences arrive as proposals.
- **A restated requirement with a new citation is not proposed.** Only changed values, conflicts and new requirements are. The new source file still appears on the proposals file when another proposal cites it.
