# Back-testing the agent against past estimates

Before changing a skill to make the estimate more accurate, measure what it does today. The back-test
compares a project's Blueprint with a reference taken from a past estimate and prints a few numbers. Run it
before and after a change: if a number gets worse, the change is not an improvement.

It does not call a model and it does not judge wording. It needs no actuals, only the past estimate.

## What it measures

| Metric | Meaning | Better is |
| --- | --- | --- |
| `requirementRecall` | Share of the reference's requirements that a live row in the Blueprint covers | higher |
| `workPackageAgreement` | Of those found, the share the run put in the same work package as the reference | higher |
| `unmappedShare` | Share of the run's live rows that found no activity to belong to. Measured against the run's own rows, not the reference, so it reports whether the catalog and the extraction prompt between them gave every requirement a home | lower |
| `rowPrecisionProxy` | Share of the run's live rows that match a reference item. A floor only, because a reference is never complete | higher |
| `quantityError` | Mean distance of the run's quantity per work package from the reference, one package capped at 100% | lower |
| `secondQuantityError` | `quantityError` for the blind second read (`--second`, or `secondSketch` in a suite case). The report also lists each package where the two reads differ and which was closer to the reference | lower |
| `hoursError` | The same for hours per work package (needs an estimate in the Blueprint) | lower |
| `totalHoursError` | Signed distance of total hours from the reference total (needs an estimate) | closer to 0 |
| `casesShare` | Share of the plan's workstreams whose rate came from past projects (rung 1 of the rate ladder) | higher |
| `derivedShare` | Share whose rate is nobody's evidence: an accepted figure, or the catalog's starting figure (rung 3) | lower |

A metric the reference cannot answer shows `n/a`. It is never counted as zero.

The rung metrics answer a different question from the rest. Every other metric asks how close this run came
to a past estimate; these ask what the numbers in it are standing on. The report prints all three rungs,
but only two are metrics: `cases-adjusted` has no better direction, because a rate that moves up to it from
`derived` improved and one that falls to it from `cases` did not. The three shares add to 1, so the two
that are tracked pin the third. A workstream whose `rateBasis` names no rung is counted as unrated and
reported separately, rather than quietly scoring as evidence.

Quantities come from the first source that exists: a design sketch given with `--sketch`, the estimate the
app saved in the Blueprint, the `workstreams` of a plan file (stage 3), or else the number the app would
extract from each requirement statement. The last is how the old Build sized a package, so a file with no
digits in its statements scores a high `quantityError`. That is the gap the design sketch step is meant to
close.

For a plan file the quantity is the volume the estimate used, placeholder or not, and the report marks the
packages that rest on a placeholder. Hours are the traditional hours; the total includes the overhead
workstreams. The synthetic plan is built by `node tools/eval/synthetic-plan.mjs`; run it with
`--suite samples/eval/suite-plan.json`, baseline `samples/eval/synthetic-plan-baseline.json`.

## The reference file

One file per past estimate. Every field except `schemaVersion` and `name` is optional, but give at least
one of `workPackages`, `requirements`, `totalHours`.

```json
{
  "schemaVersion": "1",
  "name": "Past estimate, short label",
  "totalHours": 5200,
  "workPackages": {
    "content-migration": { "quantity": 6400, "hours": 1900 }
  },
  "requirements": [
    {
      "id": "REF-01",
      "text": "What the past estimate covered, in your words",
      "workPackage": "content-migration",
      "match": ["migrate", "pages"]
    }
  ]
}
```

`match` is a list of terms, all of which must appear (any case) in a live requirement's statement for the
reference item to count as found. Pick terms from the RFP, not from the agent's output. `workPackage` is
optional; leave it out for work the catalog does not size (the domain, a legal clause).

## The suite file

```json
{
  "cases": [
    { "blueprint": "acme/Acme_Blueprint.json", "reference": "acme/reference.json" },
    { "blueprint": "beta/Beta_Blueprint.json", "reference": "beta/reference.json", "sketch": "beta/.blueprint/design-sketch.json" }
  ]
}
```

Paths are relative to the suite file.

## Run it

```
npm run eval:backtest -- --suite eval-private/suite.json
npm run eval:backtest -- --suite eval-private/suite.json --record eval-private/baseline.json
npm run eval:backtest -- --suite eval-private/suite.json --baseline eval-private/baseline.json --fail-on-regress
npm run eval:backtest -- "Acme_Blueprint.json" --reference reference.json --json
```

`--record` writes only the numbers (no statements, no names), so a baseline can be kept in a shared place.
With `--baseline`, each metric reads better, same or worse. A change of two points either way counts as the
same. `--fail-on-regress` exits 1 when any metric is worse, and needs `--baseline` (without one there is
nothing to compare with, so it is a usage error, not a pass).

- **A baseline is never overwritten by a bad run.** `--record` is not written when `--fail-on-regress` fails,
  the file is written whole or not at all, and `--record` may not name the `--baseline` file.
- **A figure that disappears is a regression.** If the baseline had a metric and this run cannot answer it
  (for example a reference that no longer gives that figure), the metric reads worse rather than `n/a`.
- **Quantities are only comparable from the same source.** A baseline records which source sized the
  quantities (`extracted`, `estimate` or `sketch`). When this run used a different one, the two quantity
  metrics are left out of the comparison instead of being counted as better or worse.
- **Reference figures must be above zero**, and a number that is not a number is an error naming the field.

## Keep real data out of git

Real RFPs, Blueprints and references hold client facts. Keep them under `eval-private/`, which `.gitignore`
excludes, or anywhere outside the repository. The repository carries one synthetic case only:

- `samples/eval/suite.json` and `samples/eval/synthetic-aem-reference.json` score the Fabrikam sample run.
  The reference is a made-up fixture with two gaps on purpose (a performance budget and author single
  sign-on that the documents never state), so recall is not a perfect score.
- `samples/eval/suite-sketch.json` scores the same run with the design sketch's drivers
  (`synthetic-aem-design-sketch.json`). Its quantity error is 40% against 80% without the sketch, which is
  how a stage earns its place: it has to move a number.
- `samples/eval/synthetic-baseline.json` is the committed baseline. A test runs the back-test against it, so
  a change that makes a synthetic number worse fails `npm run test:tools`. If a change should move the
  baseline, record a new one in the same commit and say why.
- `samples/eval/suite-plan.json` scores the plan file the estimator produces, with
  `samples/eval/synthetic-plan-baseline.json` as its baseline. This is the one stage B moved.

The synthetic baseline shows the tool works. It is not evidence about real accuracy.

**The committed reference has quantities but no hours, and that is deliberate.** Its quantities come from
the Fabrikam sample documents — 6,400 pages, four locales, three sites — so they are facts something can be
measured against. There is no past project behind an hours figure, and writing the model's own output into
the reference would score `hoursError` at zero forever while looking like accuracy. The hours and total
comparison is exercised by a test in `tools/eval/synthetic-plan.test.mjs` instead, and the figures it needs
arrive with the real references in `eval-private/`. Drift in the model's own hours is what the baseline
already records.

The plan baseline opens stage B at `casesShare` 0 and `derivedShare` 1: the repository ships no case
library, so every rate in the synthetic plan is a starting figure from the catalog. That is the number a
case library has to move, and it is recorded so the move is visible rather than claimed.

## Recording the real baseline

This is a step for a person with the real files.

1. Pick three to five past RFPs that span your usual platforms and sizes.
2. For each, run the skill pack with the current skills and keep the Blueprint (build the estimate in the
   app if you want the hours metrics).
3. Write a reference from the past estimate: its total, the quantity and hours per work package, and the
   requirements it covered, each with `match` terms.
4. Put the files in `eval-private/`, run with `--record eval-private/baseline.json`.
5. After each skill change, re-run the pack on the same RFPs and run with `--baseline`.

Re-running on the same RFPs gives different rows each time, so judge a change by the direction over several
cases, not by one case's number.
