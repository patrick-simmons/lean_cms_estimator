---
status: in-review
slug: b-04-local-only-status
baseline_commit: 8785b87ddda0c9503510ecb8d8721d4393c49ab7
---

<frozen-after-approval reason="human-owned intent — do not modify unless human renegotiates">

## Intent

**Problem:** CMK assets that pass the existing licence/admissibility checks but have `retention: local_only` are flattened into `unavailable`, so their capabilities cannot contribute to estimates even though the delivery team may use locally synchronized copies.

**Approach:** Introduce `local-only` as a third catalog status, propagate it through validation, generated counts, AI inventory and readiness, and prove that the portable pack retains only metadata—not the local-only implementations.

## Boundaries & Constraints

**Always:** Preserve the existing licence and admissibility logic; retain `reasonCode: distributable_excluded`; keep local-only tools ON by default when mapped; require readiness wording that names the asset and says it must be synced locally; report supported, local-only and unavailable counts separately; keep the unavailable validation message exactly `is unavailable at this commit`.

**Ask First:** Any change that would require local-only assets to be locked, redistribute or copy their implementation, alter catalog schema/generator versions, or modify mappings outside B-04.

**Never:** Add Drupal/Acquia estimating rows, change `derive-capabilities.mjs`, fix `environments-devops`, add new licence rules, default local-only tools OFF, or weaken rejection of genuinely unavailable capabilities.

## I/O & Edge-Case Matrix

| Scenario | Input / State | Expected Output / Behavior | Error Handling |
|----------|--------------|---------------------------|----------------|
| Admissible local asset | Admissible policy plus `retention: local_only` | Status `local-only`, reason code `distributable_excluded`; no lock entry required | N/A |
| Genuinely unavailable asset | Failed activation/admissibility | Status remains `unavailable` | `catalog:check` retains the exact unavailable message |
| Mapped local-only tool | Default or opt-in capability is mapped | Tool is ON and carries `localOnly: true`; readiness requires local sync and preserves opt-in obligation | Opt-out behavior remains unchanged |
| Portable pack | Generated catalog contains local-only metadata | Catalog ships; no local-only capability implementation path ships | Build test fails on any matching skill path |

</frozen-after-approval>

## Code Map

- `tools/catalog/cmk-model.mjs` -- authoritative asset status, lock gate and global/per-platform counts.
- `tools/catalog/cmk-render.mjs` -- generated frontmatter counts and status explanation.
- `tools/catalog/check.mjs` -- estimating-catalog capability gate.
- `tools/blueprint/ai-plan.mjs` -- platform inventory, ON tools and readiness obligations.
- `docs/catalogs/cmk-capability-catalog.md` -- regenerated published catalog.
- `tools/release/build-skill-pack.test.mjs` -- built-pack guard for metadata-only local capabilities.

## Tasks & Acceptance

**Execution:**
- [x] `tools/catalog/cmk-model.mjs`, `tools/catalog/cmk-model.test.mjs`, `tools/catalog/pin.test.mjs` -- add/export the three statuses, classify admissible retained-local assets, keep the supported-only lock gate, and report all three count states.
- [x] `tools/catalog/check.mjs`, `tools/catalog/check.test.mjs` -- accept local-only capability ids while rejecting unavailable ids with the existing message.
- [x] `tools/blueprint/ai-plan.mjs`, `tools/blueprint/ai-plan.test.mjs` -- admit local-only inventory entries, carry `localOnly: true`, keep them ON, and add local-sync readiness for default and opt-in assets.
- [x] `tools/catalog/cmk-render.mjs`, `docs/catalogs/cmk-capability-catalog.md` -- render three-state counts, clarify status semantics and regenerate from the pinned CMK commit.
- [x] `tools/release/build-skill-pack.test.mjs` -- assert the built catalog retains six local-only assets/27 platform placements while required and built skill paths contain no local-only capability implementation.

**Acceptance Criteria:**
- Given the pinned CMK data, when the catalog is generated, then six assets and 25 unique capabilities are local-only, their Acquia/Acquia MEO/Drupal placements total 27, and unavailable counts exclude them.
- Given a local-only capability in an estimating row, when catalogs are checked and an AI plan is built, then validation passes, the tool is ON, and readiness names the local sync obligation.
- Given a genuinely unavailable capability in an estimating row, when catalogs are checked, then validation fails with the unchanged unavailable message.
- Given a skill-pack build, when its catalog and file manifest are inspected, then local-only metadata is present and no matching capability implementation ships.

## Spec Change Log

## Design Notes

Global capability counts follow existing unique-asset semantics: the six assets expose 25 unique capabilities. Per-platform placement counts are Acquia 17, Acquia MEO 8 and Drupal 2, totaling 27 because Drupal repeats two maintenance capabilities. Local-only readiness takes precedence over default/opt-in installation wording; an opt-in local-only asset must state both local sync and explicit enablement. The `localOnly` field is additive metadata and is not made mandatory in saved-plan validation.

## Verification

**Commands:**
- `node --test tools/catalog/cmk-model.test.mjs tools/catalog/check.test.mjs tools/catalog/pin.test.mjs tools/blueprint/ai-plan.test.mjs tools/release/build-skill-pack.test.mjs` -- expected: all targeted behavior and pack guards pass.
- `npm run catalog:cmk` -- expected: deterministic catalog regeneration with six local-only assets and three-state counts.
- `npm run catalog:check` -- expected: catalog consistency check passes without loosening unavailable failures.
- `npm run test:tools` -- expected: complete tool suite passes.
