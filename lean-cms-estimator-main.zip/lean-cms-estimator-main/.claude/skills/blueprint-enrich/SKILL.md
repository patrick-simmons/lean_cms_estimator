---
name: blueprint-enrich
description: Write a v2 {Project}_Context.json sidecar for the offline Blueprint pack. Turns delivery unknowns into working assumptions and proposes assumptions, dependencies and risks from the hub libraries through tools/blueprint/match-library.mjs. Everything is written as pending.
---

# Blueprint enrich (Context sidecar v2)

Write `{Project}_Context.json` beside `{Project}_Blueprint.json`. Schema: [docs/spfx/context-sidecar.md](../../../docs/spfx/context-sidecar.md). The skill proposes and the estimator decides: every item you write is `review: { "status": "pending" }`.

## Inputs

- `{Project}_Blueprint.json` (requirements, questions, platform), already valid. On a re-run that wrote `{Project}_Proposals.json`, the Blueprint is still the file to read; proposals are not requirements until the estimator accepts them.
- The parsed blocks in `.blueprint/parsed/` (the parse stage), for document evidence. Cite them by label in `source`.
- The library matcher: it reads `samples/factors/seed/` (nothing to attach)

## Steps

1. **Framing and constraints.** Prefer client-stated constraints only (`budgetCap`, `calendar`, `geoResourcing`, `priceToWin`) and the framing fields. Omit anything the documents do not state.
2. **Unknowns.** Write each delivery unknown as a `deliveryUnknowns` item (`DU-`) with a `source`. Skip dismissed requirements and questions linked to them, as the matcher does. Put the Blueprint question id (`Q7`) and requirement id (`R-012`) in `refs` when the evidence is clear.
3. **One working assumption per unknown.** (Exempt: an unknown whose `source` is a tool marker, `Gap sweep checklist …` or `Second opinion …`. Those come from later steps and are not yours to convert; the gap sweep brings its own assumption, the second opinion none.) For each other unknown, write an `assumptions` item (`AS-`) with `category`, `confidence`, `ifFails` and `refs` containing the unknown's id (`["DU-003"]`), or reuse a matching library item in step 4 by adding the unknown's id to its `refs`. Do not invent a number: when the document gives none, leave the field blank or say so in words. If no honest assumption is possible, write none and list the unknown in the run summary with the reason. These assumptions do not count toward the library cap.
4. **Library proposals.** Run the matcher, then judge its output:

   ```bash
   node tools/blueprint/match-library.mjs "<Project>_Blueprint.json" [--platform all|aem|aem-eds|aep] [--max <n>] [--existing "<Project>_Context.json"] [--suppress "<team-suppress.json>"]
   ```

   - **If it exits non-zero, stop and report its message.** Do not propose library items from memory. (`--seed-dir` points the tool at another library folder; it is for tests, not for runs.)
   - It prints JSON: `platform` (the id used, how it was chosen, what the Blueprint asked for), `max`, `input` (counts of requirements and questions read and skipped: dismissed, unusable text, unlinked, no id), `existingUnmatched` (ids in `--existing` that no library entry has), then `assumptions`, `dependencies` and `deliveryRisks`. Each list has `candidates` (matches kept after platform and `--existing`), `dropped` (cut by the cap), `skipped` (already in `--existing`), `suppressed` (listed in `--suppress`: the team keeps dismissing it), `excludedByPlatform` and `entries`. Each entry has `libraryId`, `alwaysPropose`, `matchedHints`, `requirementIds`, `questionIds` and an `item`.
   - Anything odd is also printed on stderr as `warning:` lines (a platform that fell back to `all`, unusable or id-less requirements and questions, unlinked questions, unknown ids in `--existing`). Put them in the run summary.
   - The tool matches hints against requirement statements and question text. It skips dismissed requirements and their questions, and never reads source passages.
   - **Keep an entry only when the evidence supports it.** `matchedHints` shows why it was listed; `alwaysPropose` entries have no hint and need your judgement on whether they fit this bid. Drop the rest, and record each rejected entry (`libraryId` and the reason) for the run summary. When a list has no candidates, or you reject all of them, write none for that list and say so.
   - **Copy the `item` as it is.** Do not change a library default, including `requiredWeek`. The week is present only when the library carries one, and stays absent otherwise. Write a week of your own only on a dependency that has no `libraryId`, and only when the document states it. Do not add a `source` to an item that came only from a library.
   - Add the `id` and `refs`. Use the entry's `requirementIds` and `questionIds` for `refs`, plus any unknown it answers (an assumption or dependency that covers an unknown lists the `DU-` id).
5. **Document-evidenced risks.** Write a risk the libraries do not cover only when a source document states the evidence, with a `source`, `likelihood`, `severity`, `impact` and `mitigation`. **No library match and no document evidence means no risk.** Never invent one to fill a list.
6. **Ids.** `DR-`, `DU-`, `AS-` and `DP-` followed by three digits (`DR-001`), unique across all four lists. Number in the order written. On a re-run, continue after the highest existing suffix across all four lists.
7. **Meta.** Set `meta.schemaVersion` to `"2"` and `meta.producedBy` to `"skill"`.

## Limits and order

- The matcher caps **library proposals** per list at `--max`, default **8** per list. Unknown-derived assumptions and document-evidenced risks are not library proposals and are not capped by it.
- Each list is ordered for you: dependencies by priority (high first), risks by derived level (HIGH first, from likelihood times severity), assumptions by confidence (low first). Ties go to the entry with more matched hints, then to the library id. The cap cuts from the end of that order.
- `dropped` counts candidates the cap cut. Say so in the run summary so the estimator can ask for more with a higher `--max`.
- The cap applies to each run. On a re-run, `--existing` skips entries whose `libraryId` is already in the sidecar, so a re-run can add up to `--max` more.
- The tool does not know which candidates you rejected, so they come back on every re-run. Judge them again and keep rejecting.

## Platform

The tool uses the Blueprint's `platform.id` when it is a library platform (`aem`, `aem-eds`, `aep`), after trimming and lowercasing. Any other platform id, or none, lists only the platform-independent (`all`) entries. Pass `--platform all|aem|aem-eds|aep` to override; any other value exits 2. Report which platform was used and why.

## Re-runs

If a sidecar already exists, **add only**: pass it to the matcher with `--existing`, add new items with new ids, and never edit, reorder or remove an existing item. The estimator's review decisions stay as they are. Do not add a second unknown, or a second assumption, for a question that already has a `DU-` item. An unknown whose `source` starts with `Gap sweep checklist` comes from `blueprint-gap-sweep` and already has its assumption: leave it alone.

## Run summary

End the run with a short summary for the operator:

- Platform used and its source (`flag`, `blueprint` or `default`)
- Counts written per list, `dropped` and `skipped` per list, and the number of document-evidenced risks written
- Library entries you rejected, each with its `libraryId` and the reason
- The matcher's `input` counts (requirements and questions read and skipped) and any `warning:` lines it printed
- Every unknown that has no linked assumption, with the reason
- Anything left blank because the documents did not state it

## Guardrails

- Propose, never decide: no item is `accepted`, `edited` or `dismissed`
- No invented quantities, hours, dates or weeks; leave numbers blank when the documents give none
- Do not resolve conflicts (no winner)
- No cost, rate or contingency, and no `commercial` category (licence and entitlement items are dependencies)
- Never write the out-of-scope fields below
- A gap-sweep unknown is not yours to convert: step 3 applies to unknowns you wrote, and `blueprint-gap-sweep` runs after this skill

## Out of scope (never write)

- Account history / new logo
- Commercial risks
- Work-environment / client-difficulty texture
- Difficulty multipliers or staffing profiles

## Validate

```bash
node tools/blueprint/validate-context.mjs "<Project>_Context.json" --blueprint "<Project>_Blueprint.json"
node tools/blueprint/run-record.mjs "<project-folder>" --stage enrich --note "context sidecar written"
```

Exit 0 is required. A `warning:` line on stderr means the file and the Blueprint disagree: a reference points at nothing (a mistyped `R-` or `Q` id, or a sidecar id that is not in the file), or v2 content sits under another `schemaVersion`. Fix it and run again.
