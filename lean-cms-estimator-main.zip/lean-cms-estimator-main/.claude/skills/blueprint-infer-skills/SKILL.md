---
name: blueprint-infer-skills
description: Propose human delivery skill ids from a Blueprint requirements map against the Factors Skills catalog (offline; no Azure or Foundry).
---

# Blueprint infer skills

Propose the **project skill set** after extract+map. Output catalog **skill ids only**. The web part (or estimator) confirms, merges add-only, and saves root `skillSet` on `{Project}_Blueprint.json`.

## Inputs

Attach or `@`-reference:

- The project `{Project}_Blueprint.json` (at least `platform`, `requirements[]`)
- Skills catalog — Prefer Factors Skills sheet / `samples/factors/seed/skills.csv`, or list ids from `docs/spfx/delivery-skills.md`
- Optional: Skills **inference hints** as few-shot (semicolon keywords per skill)

## Output shape

Emit JSON only:

```json
{
  "skillIds": ["aem-core", "adobe-analytics"],
  "notes": ["optional short why per id or overall"]
}
```

Rules:

- Every `skillIds` entry **must** exist on the Skills catalog — never invent ids or Pricer role names
- Prefer platform craft (`aem-core`, `frontend-react`, …) and martech when the map implies them
- Include delivery seats (`pm`, `ba`, `architect`, `qa`, …) only when the map or engagement framing clearly needs them; do not dump the whole catalog
- If platform id is `aem` or `aem-eds`, **always** include `aem-core`
- Do **not** write the Blueprint file unless the operator asks; proposal only by default
- Do **not** change WP hours, phases, or estimate

## Guardrails

- No Azure Functions / Foundry calls (offline skill)
- No CMK capability ids as skill ids
- No silent wipe of an existing estimator-edited `skillSet` — if merging into a file, **add missing ids only**

## Related

- Domain: [docs/spfx/delivery-skills.md](../../../docs/spfx/delivery-skills.md)
- UI ticket: SPMVP-030 (`skillSet` on working file)
- Orchestrator: run after **blueprint-extract-map** / validate; before Build estimate
