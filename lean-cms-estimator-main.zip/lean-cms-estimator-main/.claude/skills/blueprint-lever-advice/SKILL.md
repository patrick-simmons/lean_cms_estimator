---
name: blueprint-lever-advice
description: Recommend which opt-in assets and delivery methods of the estimating catalog to enable for this project, from evidence in the source documents (a Figma link, an existing site to migrate, an accessibility standard, a stated move from an older AEM installation), through tools/blueprint/lever-advice.mjs. Runs after blueprint-enrich and adds pending working assumptions to the Context sidecar only. The estimator confirms.
---

# Blueprint lever advice

The estimating catalog lists opt-in assets (skills the team has to turn on) and delivery methods. Whether the project really uses them changes how fast a package is sized, so the choice is made per project, by the estimator, on the AI levers tab. The app's own "Suggest levers" works from what the requirements map to. This step works from the **documents**: it finds the words that give a reason, quotes them, and recommends the lever with that reason.

It proposes and the estimator decides. It writes pending assumptions into `{Project}_Context.json` beside the Blueprint (schema: [docs/spfx/context-sidecar.md](../../../docs/spfx/context-sidecar.md)). It never switches a lever on: the working file's `levers` and every hour stay as they are.

## Inputs

- `{Project}_Blueprint.json`, already valid. The platform id decides which levers the catalog offers.
- `{Project}_Context.json`, already written by `blueprint-enrich`. This step adds to it and never edits or removes an item.
- `.blueprint/parsed/blocks.json`.

## Steps

1. **Run the tool.**

   ```bash
   node tools/blueprint/lever-advice.mjs --blueprint "<Project>_Blueprint.json" --blocks ".blueprint/parsed/blocks.json" --existing "<Project>_Context.json" [--suppress "<team-suppress.json>"]
   ```

   **If it exits non-zero, stop and report its message.** Do not recommend levers from memory. It prints JSON: `advised` (a lever, the activities it speeds up, the reason, the signal words, the block ids and a quote, and a ready `assumption`), `selection` (the advised ids split into `optIn` and `methods`), `alreadyProposed` (the sidecar already holds the lever, in any review status), `suppressed` (listed in the `--suppress` file: the team keeps dismissing it), `alreadyOnByDefault`, `notOffered` (evidence found, but the catalog does not offer that lever on this platform) and `noEvidence`. Add `--markdown` for the part of the run summary the estimator reads.

2. **Judge each advised lever.** Read the quote in its block. Keep the lever when the words really bear on the reason (a Figma link that is the design for this site, not a mention of a competitor's). Reject it when they do not, or when another block says the opposite (for example the client says the content is being rebuilt from scratch, so there is nothing to import), and say which block in the run summary.
3. **Write what you keep.** For each kept lever add one `assumptions` item.
   - Copy the `assumption` as it is, including `source`. Do not reword it and do not add numbers, hours, weeks or a quantity.
   - Give it the next `AS-` id after the highest across all four lists.
   - `refs` is the lever's `requirementIds` (it may be empty when `hasLiveRequirement` is false).
4. **Never touch the Blueprint, and never write `levers`.** The estimator turns the lever on in the app after reading the assumption.

## Re-runs

Pass the existing sidecar every time. A lever whose `source` is already in the sidecar is listed under `alreadyProposed` and is not advised again, even when the estimator dismissed it. That is the point: a dismissal is a decision. Do not edit, reorder or remove an existing item.

## Run summary

Paste the tool's `--markdown` output for the kept levers, then:

- Levers rejected, each with the reason and the block you read
- `notOffered` levers: the document points to something the catalog does not offer on this platform. The estimator may want to know
- A lever with no requirement in its packages yet: it changes nothing until a requirement exists, so say what is missing

## Guardrails

- Propose, never decide: no item is `accepted`, `edited` or `dismissed`, and no lever is switched on
- No invented quantities, hours, dates, weeks, rates or difficulty multipliers
- Only levers the estimating catalog offers on the project's platform, and only with a quote from a block
- No requirement is written, and no existing item is changed

## Validate

```bash
node tools/blueprint/validate-context.mjs "<Project>_Context.json" --blueprint "<Project>_Blueprint.json"
```

Exit 0 is required. Fix a `warning:` line (a reference that points at nothing) and run it again.
