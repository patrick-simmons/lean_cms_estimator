---
name: blueprint-second-opinion
description: Optional. A second agent that has not seen the first read re-counts the sizing drivers from the parsed blocks, and a challenger argues against each accelerated claim. tools/blueprint/second-opinion.mjs compares the reads and turns the disagreements and the objections that hold up into pending delivery unknowns. Never changes a count, a requirement or hours.
---

# Blueprint second opinion

One agent reading a bid has one set of blind spots. This step reads it twice and compares:

1. **A blind second read.** Another agent counts the sizing drivers from the parsed blocks alone. It never sees the Blueprint, the design sketch or the Context, so it cannot be anchored by them.
2. **A challenger.** A third pass argues against every requirement the Blueprint claims as `accelerated`, and must quote the documents to do it.

Where the reads differ, or a challenge holds up, the result is a **pending delivery unknown**. A silent change to a count, to coverage or to hours is never an outcome: the estimator reads the unknown and decides.

This step is **optional and costs two more agent runs**. Run it when the bid is large, or the estimator asks. It needs `.blueprint/design-sketch.json` (from `blueprint-design-sketch`) and the Context sidecar (from `blueprint-enrich`).

## The two agents must be separate

Run each as a **fresh subagent or a new session**, with only the inputs named below. If you cannot start a separate agent (for example in a single chat with no subagents), **skip this step and say so in the run summary**. Do not do the second read yourself in the same context: you have seen the first read, so it would not be blind, and a result that looks independent but is not is worse than none.

## Step 1: the blind second read

Give the second agent only:

- `.blueprint/parsed/blocks.json`
- the activity table in `docs/catalogs/estimating-catalog.md` (names, units)
- the brief below, pasted as its task. Do **not** hand it the `blueprint-design-sketch` skill file: that file tells its reader to open `{Project}_Blueprint.json`, which is exactly what this agent must not see.

Do not give it `{Project}_Blueprint.json`, `.blueprint/design-sketch.json` or `{Project}_Context.json`, and do not tell it what the first read found.

**Brief for the second agent** (paste it as it is):

> Count the sizing drivers in the parsed blocks of a bid. Read only `blocks.json` and the activity table. Cite blocks by id. One driver per activity, and only when the documents give the number.
>
> | Count | Activity (unit) | Where it shows up |
> | --- | --- | --- |
> | Pages or URLs to move | content-migration (page) | content inventories, a stated page count |
> | Locales to launch | localization (locale) | a list of languages or regions |
> | Sites in the topology | multisite (site) | corporate site, brand sites, microsites |
> | Sites that have search | search (site) | a search requirement, by site |
> | Content types to model | content-model (content-type) | a content model, a list of page or content types |
> | Templates delivered the headless way | frontend-delivery (template) | a stated headless front end and its page types |
> | Systems to integrate | integrations (integration) | named systems, feeds, connectors |
> | Templates in the current site | discovery-audit, qa-automation (template) | an audit or inventory of templates |
> | Components | component-build, component-review (component) | a component list |
> | Environments | environments-devops (environment) | named environments |
> | Authors to onboard | uat-support (author) | a stated number of editors |
>
> Write `{ "drivers": [ ... ] }`. Each driver has `workPackageId`, `quantity`, `basis`, `blockIds`, `confidence` (`high` stated outright, `medium` counted or summed, `low` vague) and an optional `note`. Back the number one of three ways: `stated` (add `quote`, at least two words copied from a cited block, holding the number as digits or a number word up to twenty), `counted` (add `items`, the names, each found in a cited block; `quantity` is how many), or `summed` (add `parts`, each `{ label, quantity, quote }`; `quantity` is their sum).
>
> Never: a figure the documents give two ways (write no driver, name both figures and blocks in your answer); a number you cannot point to in the words or names; hours, weeks, dates, rates, risk or complexity ratings.

It writes its drivers as an input file and you run the same tool:

```bash
node tools/blueprint/assemble-drivers.mjs --input "<second-input.json>" --blocks ".blueprint/parsed/blocks.json" --out ".blueprint/second-opinion-sketch.json"
```

Do not pass `--blueprint`: the comparison with the requirement text is the first read's.

## Step 2: the challenger

Give the challenger the `accelerated` rows of the Blueprint (`node tools/blueprint/list-requirements.mjs "<Project>_Blueprint.json" --json`), the blocks they cite, and this brief: argue against each `accelerated` claim where the documents give a reason, in one of these categories, and say nothing where they do not.

| Category | The objection |
| --- | --- |
| `custom-integration` | a custom integration is not the kind of work that AI assistance speeds up |
| `unclear-scope` | the scope is unclear, so there is little to accelerate yet |
| `client-dependency` | the work waits on the client or a third party |
| `legacy-source` | the source content or system is old or irregular, which resists automation |
| `regulated-or-security` | compliance or security review limits how much can be automated |
| `novel-work` | the work is new for the team and has no pattern to reuse |

Each objection is `{ "requirementId", "category", "reason", "blockIds", "quote" }`, in a file `{ "objections": [ ... ] }`. The `quote` is words copied from a cited block. The `reason` is one or two sentences, with no hours, days, weeks or months. One objection per requirement. An empty list is a good answer.

## Step 3: compare

```bash
node tools/blueprint/second-opinion.mjs --blueprint "<Project>_Blueprint.json" --first ".blueprint/design-sketch.json" --second ".blueprint/second-opinion-sketch.json" --blocks ".blueprint/parsed/blocks.json" --objections "<objections.json>" --existing "<Project>_Context.json" --markdown
```

Drop `--markdown` for JSON. **If it exits non-zero, stop and report its message**: a sketch that no longer matches the blocks must be fixed first. It prints, per package, `agree`, `disagree` (both counted, different numbers) and `oneSided` (only one read found a count), and the objections it `kept` or `rejected` with the reason. Anything already in the sidecar, in any review status, is in `alreadyProposed` and is not proposed again, so a dismissal stays dismissed.

## Step 4: write what holds up

Each `disagree`, `oneSided` and kept objection has an `unknown` in sidecar shape. Judge them:

- **Disagreements and one-sided counts:** keep them all. Whoever is wrong, a count the two reads cannot agree on is something the estimator should look at. Do not say which read is right.
- **Objections:** keep an objection only if its quote really bears on the claim. Drop one that quotes the documents but does not support the reason, and say why in the run summary.

Add each kept `unknown` to `{Project}_Context.json` as a `deliveryUnknowns` item with the next `DU-` id after the highest across all four lists, copying `statement`, `source`, `refs` and `review` as they are. Then run `validate-context.mjs --blueprint`. Add only: never edit, reorder or remove an existing item.

Do not write an assumption for these unknowns. The estimator's decision is the answer.

## Never

- No change to a requirement, a coverage, an activity, a count or the estimate. The Blueprint is not written.
- No hours, weeks, dates, rates or difficulty multipliers.
- No winner between the two reads, and no averaging of two counts.
- No second read made in the same context as the first.

## Run summary

- Whether the step ran, and if not, why (no separate agent)
- Packages the two reads agree on, differ on and found one-sided
- Objections kept and the ones you dropped, each with the reason
- Anything rejected by the tool, with its message
