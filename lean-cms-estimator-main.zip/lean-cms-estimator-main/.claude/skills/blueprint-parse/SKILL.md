---
name: blueprint-parse
description: Parse the selected opportunity files into citation-bearing blocks and Start-quality Blueprint sources[] with the deterministic local parse tool; the model reads the tool's output, never the raw files.
---

# Blueprint parse

Turn each selected source file into blocks with stable ids and locations the extract stage can cite. Code does the parsing. The model reads what the code produced.

## Run the tool

```bash
node tools/blueprint/parse-local.mjs "<project-folder>"
```

- It reads `.blueprint/sources.json` when the folder was prepared for the agent, and otherwise every supported file at the top level of the folder. To parse a chosen list instead: `--select <file> <file> ...` (paths relative to the folder; a path outside the folder is refused).
- **Read only the files the selection lists.** A `.blueprint/sources.json` that lists no sources means the estimator has chosen nothing: the tool parses nothing and exits 3. Stop and ask the estimator to choose sources; do not pass the whole folder yourself.
- `--out <dir>` changes where the parsed files go. The tool refuses (exit 2) an output folder that is the project folder, contains it or contains a selected source, and only replaces a folder it wrote itself.
- It writes `.blueprint/parsed/`:
  - `manifest.json`: every file, its format, whether it was `read`, `partial` or `not read`, and why; `skipped` lists files in the folder it did not parse, each with the reason (an unsupported type, or a subfolder). It holds no absolute path.
  - `sources.json`: Start-quality `sources[]` for the assemble step (`--sources`)
  - `blocks.json`: every block, for the assemble step (`--blocks`)
  - `<itemId>.json`: one file per source with its blocks, for reading one source at a time
- It records the `parse` stage in `.blueprint/run.json` and makes no network call.
- Exit codes: 0 parsed; 2 bad usage or an unsafe `--out` or `--select`; 3 nothing selected; 4 no block was produced from any source (every file unreadable, or nothing supported), unless you pass `--allow-empty`. Exit 4 means the later stages would run on nothing: report the `not read` reasons to the estimator instead of continuing.
- It needs the function readers to be built when run from the repository (`npm --prefix function run build`); the portable pack carries them bundled.

## What the tool reads

| Format | How | Citation |
| --- | --- | --- |
| `.docx` | The function's Word reader (headings, numbering, tables) | `kind: section` with heading and section number |
| `.pptx` | The function's PowerPoint reader (slides, titles, notes) | `kind: slide`, `notes: true` for speaker notes |
| `.xlsx` | The function's Excel reader (rows in groups) | `kind: sheet` with row range |
| `.pdf` with a text layer | pdf.js text extraction, headings by numbering and font size | `kind: page` with exact page, section and heading when detected |
| `.pdf` where some pages have no usable text (a scan with a stamp or footer, a mixed file) | The pages with text are read; the file is `partial` and the manifest lists the pages with no usable text, as page ranges | pages with text only |
| `.pdf` with no text layer (a scan), images, `.doc`/`.ppt`/`.xls`, `.xlsb`, anything else | Not read; the manifest says why | none |

The Office readers are the Azure function's own code, so blocks and labels are the same ones the function would produce. PDF text comes from the file's text layer instead of Document Intelligence; page numbers are exact, headings are a heuristic.

## Read the output

Read `.blueprint/parsed/manifest.json` first, then one `<itemId>.json` at a time. Blocks look like:

```json
{
  "id": "src-fabrikam-rfp-2027#p2.1",
  "itemId": "src-fabrikam-rfp-2027",
  "fileName": "Fabrikam_RFP_2027.pdf",
  "label": "Fabrikam_RFP_2027 p.2 §2",
  "location": { "kind": "page", "page": 2, "section": "2", "heading": "Content migration" },
  "text": "…passage…"
}
```

Cite blocks by `id`. Never rewrite an id, a label or a location.

## Files the tool did not read

For each `not read` entry in the manifest, and each `partial` file's pages with no usable text, tell the estimator the file name, the pages and the reason. Also name the files under `skipped`. Do not transcribe any of it yourself. If the estimator supplies the text (for example a scan they had OCR'd elsewhere, saved as `.docx`), add the file to the selection and run the tool again. Human-assisted parsing is only for that case, and the blocks still come from the tool.

## Labels

The tool writes labels. When you need one for a location you did not get from the tool (you should not), the same rules are in:

```bash
node --input-type=module -e "import { citationLabel } from './tools/blueprint/citation-label.mjs'; console.log(citationLabel('RFP.pdf', { kind: 'page', page: 38, section: '3.6.1' }));"
```

## Guardrails

- Do not invent passage text, block ids, pages or slides that the tool did not produce
- Do not read a file the selection does not list
- Do not skip files silently: every `not read` file, every page range with no usable text and every `skipped` file is named in the run summary with its reason
