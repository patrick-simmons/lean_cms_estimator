# Extraction instructions

These are the instructions for the extract stage of the offline pack. Read them before you extract, and again before each new source file. The response format (the JSON you write) is in [response-format.md](response-format.md).

## What you are given

- **Blocks.** The parse tool (`blueprint-parse`) cuts every source file into blocks. Each block has an id, the file it came from, where in that file it was found, and its text. They are in `.blueprint/parsed/`: read `manifest.json`, then one `<itemId>.json` at a time, in the order the manifest lists them. Treat each file as one batch, or split a long file into batches of consecutive blocks (30 to 60 blocks is comfortable). Some blocks are tables written as lines.
- **The activity list.** The `Activities` table in `docs/catalogs/estimating-catalog.md`: id, name, phase, shape, unit, sizing driver, owner and default coverage. All of it is the list; an activity with no capabilities is still a legal answer. (When the hub folder holds a newer estimating catalog, use that one for the whole run.)
- **The platform list.** The `### <id>` headings under `## Platforms` in `docs/catalogs/cmk-capability-catalog.md`, each with a `Name:` line.
- **Already extracted.** The statements extracted so far: from earlier batches of this run, and on a re-run also from the Blueprint (`node tools/blueprint/list-requirements.mjs <Blueprint>` prints them).

You list the requirements the documents contain so that an estimator can review them.

## What a requirement is

A requirement is something the client says the delivered solution must do, must have, must handle, or must comply with. It includes functional needs, content and migration scope, integrations, non-functional needs such as accessibility, performance, security and hosting, and project needs such as training, reporting and governance.

A requirement is not: background about the client, marketing text, instructions to bidders about the proposal process, legal boilerplate, a heading on its own, or a restatement of something already listed.

Write each requirement as one short statement in plain language, in the present tense, from the solution's point of view. Keep the client's numbers, names and quantities. Do not merge two distinct needs into one statement, and do not split one need into several.

## Citations

Every requirement cites the block or blocks it came from, by block id, from the batch in front of you. Cite the block that states the need, not a block that merely mentions the topic. Most requirements have one citation. Never cite a block id that is not in the batch, and never rewrite an id. The tool turns ids into labels, locations and passages.

## Activities

Assign each requirement to the one activity it mostly belongs to, by id, from the activity list. Read the **Sizing driver** column to decide: the activity whose driver the requirement would change is the activity it belongs to. When no activity fits, use `unmapped`. Do not invent an id; the tool changes an unknown id to `unmapped` and counts it.

Reach for the whole list rather than the familiar part of it. Architecture decisions, design systems, asset libraries, editorial production, approval workflows, cutover and hypercare are activities in their own right, and a requirement about one of them belongs there rather than in the nearest build activity.

## Coverage

Set coverage to one of these values. The first three come from the activity's **Default coverage** column; use that default unless the requirement clearly needs more human work than the activity normally does.

- `accelerated`
- `partly`
- `human-led`
- `question`, when the text is too ambiguous to state a requirement without asking the client
- `conflict`, when two blocks give different values for the same point

## Conflicts

When two blocks, usually from different files, state different values for the same point, write one requirement whose statement names both values and which file said each, cite **both** blocks, set coverage to `conflict`, and add a question asking the client which is right. Do not choose one value. Do not treat two blocks that say the same thing in different words as a conflict.

A `conflict` needs two citations. The tool downgrades a `conflict` that ends up with fewer than two sources to the activity's default coverage and counts it, so a conflict citing one block is lost. The exception is a re-run (see Already extracted), where the second citation is the existing row's own.

Example: "The deck says two locales; the RFP says four." citing the slide and the page.

## Questions

Add a question when the requirement is ambiguous, when it is conditional on a decision the client has not made, or when a conflict needs the client to decide. Write the question so it can be sent to the client as it stands. A requirement has at most one question. Do not add questions about matters the estimator can resolve from the documents. A requirement with coverage `question` or `conflict` should carry a question.

## Platform

The client's current or target content platform may be named in the blocks. When it is, report the platform id from the platform list and cite the block that names it. The extract file holds one platform for the run: when several blocks name platforms, report the one the project is moving to. When none of the blocks names a platform, report null; do not guess. The tools derive capabilities only for `aem` and `aem-eds`; any other id is kept as the platform and gets the `all` capabilities.

## Already extracted

Do not list a statement that is already extracted. If a block gives a different value for a point already extracted, list one row for it, citing the block from this batch, and set `duplicateOf` to the earlier statement copied exactly.

- **Within a first run**, `duplicateOf` is not used by the tool. Cite both blocks on one `conflict` row instead.
- **On a re-run**, the tool uses `duplicateOf` to find the existing row. A changed value or a conflict becomes a proposal against that row; a restatement that changes nothing becomes nothing. A restatement may be listed with `duplicateOf` when a new source file repeats a point: the tool will drop it as unchanged, and the file still appears in the run's sources.

## Rules

- Use only the blocks and lists in front of you. Do not use outside knowledge about the client or the platform.
- Do not invent requirements, numbers, files or block ids. If a batch contains no requirements, return an empty list.
- Do not resolve conflicts, do not estimate effort, and do not recommend an approach.
- Do not write `R-` ids or capability ids into the extract; the tool assigns ids (in extract order) and derives capabilities from the estimating catalog.
- Statements and questions are in English regardless of the source language.
- Fill every field of the response. Use null where the response format allows it and nothing applies.

## Things to check on the first source file

Over-extraction of boilerplate, splitting and merging, the conflict rule firing on paraphrases, and whether the already extracted list suppresses duplicates without suppressing genuinely new requirements on the same topic.
