# Extraction response format

The JSON you write to `.blueprint/extract.json`, and what the assemble tool (`tools/blueprint/assemble-working-file.mjs`) does with each field. Companion to [system-message.md](system-message.md), which says what the fields mean. Combine all batches of a run into one file: one `requirements` array in reading order, one `platform`, one `notes`.

## The shape

```json
{
  "requirements": [
    {
      "statement": "string",
      "blockIds": ["string"],
      "workPackage": "string",
      "coverage": "accelerated | partly | human-led | question | conflict",
      "question": "string or null",
      "duplicateOf": "string or null"
    }
  ],
  "platform": { "id": "string or null", "blockId": "string or null" },
  "notes": "string or null"
}
```

Every property is present on every object; use `null` where nothing applies.

| Field | Meaning |
| --- | --- |
| `requirements` | Every requirement found, in the order the first cited block appears. Empty when there are none. |
| `statement` | One short sentence in the present tense, from the solution's point of view, keeping the client's numbers and names. For a conflict, name both values and which file said each. |
| `blockIds` | Ids of the blocks that state the requirement. Usually one. Exactly the blocks a conflict disagrees across. |
| `workPackage` | The id of the one activity from the estimating catalog that the requirement mostly belongs to, or the word `unmapped`. |
| `coverage` | The package's default unless the requirement clearly needs more human work; `question` when the text is too ambiguous to state; `conflict` when two blocks disagree. |
| `question` | A question that can be sent to the client as it stands, when the requirement is ambiguous, conditional on an open decision, or a conflict. `null` otherwise. |
| `duplicateOf` | When this requirement restates or conflicts with a statement listed under Already extracted, that statement copied exactly. `null` otherwise. |
| `platform.id` | The platform id (from the CMK catalog's platform headings) that the project is moving to, when a block names it. `null` when no block does. |
| `platform.blockId` | The id of the block that names the platform. `null` when `id` is `null`. |
| `notes` | Anything the estimator should know that the fields do not cover, in one or two sentences. `null` when there is nothing. The tool ignores it, so say it in the run summary as well. |

## Example

For a batch holding the Northwind RFP page 38 blocks (`src-rfp#p38.3-6-1`, `src-rfp#p38.3-6-2`) and the deck's launch-scope slide (`src-deck#s9`), with the RFP's locale sentence already extracted in an earlier batch:

```json
{
  "requirements": [
    {
      "statement": "Migrate approximately 18,240 pages of in-scope content with 301 redirects so that no organic search ranking is lost.",
      "blockIds": ["src-rfp#p38.3-6-1"],
      "workPackage": "content-migration",
      "coverage": "accelerated",
      "question": "Northwind plans to remove redundant content first. How many pages remain in scope after that?",
      "duplicateOf": null
    },
    {
      "statement": "Preserve inbound links with a redirect map approved by Northwind marketing.",
      "blockIds": ["src-rfp#p38.3-6-2"],
      "workPackage": "content-migration",
      "coverage": "accelerated",
      "question": null,
      "duplicateOf": null
    },
    {
      "statement": "The deck says the site launches with two locales; the RFP says four.",
      "blockIds": ["src-deck#s9", "src-rfp#p38.3-6-3"],
      "workPackage": "localization",
      "coverage": "conflict",
      "question": "The kickoff deck lists two launch locales and the RFP lists four. Which is the launch scope?",
      "duplicateOf": "The platform launches in four locales: English, Spanish, Vietnamese and Chinese."
    }
  ],
  "platform": { "id": null, "blockId": null },
  "notes": null
}
```

The third row cites both disagreeing blocks. `duplicateOf` names the earlier statement; on a first run the tool ignores it, on a re-run it finds the existing row with it.

## What the assemble tool does with it

| Response | Working file | Done by |
| --- | --- | --- |
| `statement` | `requirements[].statement` | copied after trimming; a requirement with an empty statement is skipped |
| `blockIds` | `requirements[].sources[]` with `itemId`, `fileName`, `blockId`, `label`, `location`, `passage` | block lookup in `.blueprint/parsed/blocks.json`; passage is the block text; ids not in the blocks file are dropped, and a row left with no source is dropped; both are counted |
| `workPackage` | `requirements[].workPackage` | checked against the estimating catalog; anything else becomes `unmapped` and is counted |
| `coverage` | `requirements[].coverage` | copied; a `conflict` with fewer than two surviving sources is downgraded to the package default and counted |
| `question` | `questions[]` with `Q` ids and `requirements[].questionId` | ids assigned in extract order |
| `duplicateOf` | first run: nothing; re-run: selects the existing row the proposal targets | `--mode proposals` only |
| `platform` | root `platform` with `id`, `name`, `citation` | `name` is "Adobe Experience Manager" for `aem`, "AEM Edge Delivery Services" for `aem-eds`, otherwise the id itself; the citation text is built from the cited block |
| `notes` | nothing stored | ignored |
| (derived) | `requirements[].capabilities` | the activity's `all` row plus the `aem` or `aem-eds` row from the estimating catalog |
| (derived) | `requirements[].id`, `review: { status: "pending" }`, root `catalog` | the tool |

The tool prints counts for dropped block ids, rows dropped for lack of a source, unknown activities and downgraded conflicts. It exits 4 and writes nothing when no requirement survives, so a wrong block-id convention or an empty extract fails the run instead of producing an empty Blueprint. Check the counts before you move on.

## Why these choices

- **`duplicateOf` carries the statement text, not an id.** You write statements, not `R-` ids, and the already-extracted list shows statements. Matching on exact text is reliable because you copy it.
- **One platform per run.** The file holds one `platform`; when several batches name platforms, keep the one the project is moving to.
- **`notes` is a release valve.** Without it the model tends to force observations into statements or questions. The tool ignores it, so nothing in it reaches the Blueprint.
- **No `confidence` field.** It invites noise and the estimator reviews every row anyway; `question` and `coverage` already carry the uncertainty the screen can show.

## Checks you make yourself

The tool does not check these. Run through them before assembling:

- `blockIds` has at least one entry and every entry is a block id from `.blueprint/parsed/blocks.json`.
- `coverage: "conflict"` cites two blocks, and `coverage: "question"` or `"conflict"` has a non-null `question`.
- `platform.blockId` is null exactly when `platform.id` is null.
- `duplicateOf`, when set, is a statement copied exactly from the already-extracted list.
