---
name: blueprint-extract-map
description: Extract requirements from parsed blocks and map them to activities and coverage; assemble a web-part-valid Blueprint JSON on a first run, or a proposals file on a re-run, via Node post-process.
---

# Blueprint extract and map

## Instructions

Read these before extracting. They are the extraction system message and response format, shipped with this skill:

- [references/system-message.md](references/system-message.md): what a requirement is, citations, activities, coverage, conflicts, questions, platform, "already extracted"
- [references/response-format.md](references/response-format.md): the JSON you emit, field by field

Short durable rules:

- One short present-tense statement per requirement; keep client numbers and names
- Cite real block ids from `.blueprint/parsed/` only, and only from the blocks in front of you
- `workPackage` is a catalog WP id from `docs/catalogs/estimating-catalog.md` or `unmapped`
- `coverage` is one of `accelerated`, `partly`, `human-led`, `question`, `conflict`
- Conflicts: name both values and which file said each; cite **both** disagreeing blocks; include a clarifying `question`; **do not pick a winner**
- **Do not invent capability ids**: leave them out of the model JSON; Node derives them

## Input

Work from `.blueprint/parsed/` (the parse stage). Read `manifest.json`, then one `<itemId>.json` at a time in the order the manifest lists them. Treat each file as one batch, or split a long file into batches of consecutive blocks. Carry the statements you have already written into the next batch's "Already extracted" list.

## Model output shape

Emit extract JSON matching the response format: `requirements[]` with `statement`, `blockIds`, `workPackage`, `coverage`, `question`, `duplicateOf`; plus `platform` and `notes`. Write it to `.blueprint/extract.json` in the project folder.

## First run or re-run

One rule decides which section to follow: **a Blueprint already in the folder means a re-run**, so propose and never write the Blueprint. Only a folder with no `{Project}_Blueprint.json` gets a first-run assemble. The tool backs this up: a first-run write exits 3 and writes nothing when the existing Blueprint has review state (any decision, edit, note, added question, estimate, proposal, or edit to the skill set, phases or levers a person made) or cannot be read. Do not delete, rename or repair the Blueprint to get past that; stop and tell the estimator.

## First run (no Blueprint in the folder)

```bash
node tools/blueprint/assemble-working-file.mjs \
  --extract "<folder>/.blueprint/extract.json" \
  --blocks "<folder>/.blueprint/parsed/blocks.json" \
  --sources "<folder>/.blueprint/parsed/sources.json" \
  --estimating docs/catalogs/estimating-catalog.md \
  --project-id <id> \
  --project-name "<Project>" \
  --out "<folder>/<Project>_Blueprint.json"
```

Optional pins: `--cmk-commit`, `--toolkit-commit`, `--estimating-version` (version **without** a `v` prefix); without them the catalog's front matter is used. `--run-id` names the run; without it the tool makes one.

Post-process will:

- Assign `R-###` ids and `review: { status: "pending" }`
- Map blocks to requirement `sources` with citation labels
- Derive capabilities = estimating catalog WP `all` ∪ platform row (`aem` / `aem-eds` only; else `all`)
- Coerce unknown WPs to `unmapped`
- Downgrade a `conflict` with fewer than two surviving sources to the package default and count it
- Leave `revision: 0`, `estimate`/`handoff` null, no `published`
- Validate the Blueprint it is about to write, and write it in one step (a temporary file, then a rename)
- Record the `extract` stage in `.blueprint/run.json`

Exit codes: 3 when `--out` names a Blueprint that already has review state or one the tool cannot read (nothing is written; this is a re-run, follow the next section); 4 when no requirement survives (check the extract JSON and the block ids); 2 for bad usage; 1 when the input or the file it would write is invalid (the field-path errors are printed and nothing is written). A repeat first run over a Blueprint nobody has reviewed is allowed and rewrites it.

## Re-run (a Blueprint is already in the folder)

The Blueprint belongs to the estimator now. You propose; the app decides.

1. **See what exists** without loading the whole file into context:

   ```bash
   node tools/blueprint/list-requirements.mjs "<folder>/<Project>_Blueprint.json"
   ```

   It prints each row's id, review status, activity, coverage, statement, cited block ids and question. Put the statements in the "Already extracted" list of every batch.

2. **Extract from the new or changed sources only** (the ones the parse manifest lists that the Blueprint's `sources[]` does not, or that changed). Follow the system message: a statement already extracted is normally not listed again; a block that gives a different value for a point already extracted becomes a `conflict` row citing the new block, with `duplicateOf` set to the earlier statement copied exactly (on a re-run the second citation is the existing row's own, so one new block is enough); a changed value with no disagreement (for example a corrected count in an addendum) is a row with the new statement and `duplicateOf` naming the earlier one. A restatement that changes nothing may be listed with `duplicateOf`; the tool drops it as unchanged.

3. **Assemble proposals.** The Blueprint is read and never written:

   ```bash
   node tools/blueprint/assemble-working-file.mjs --mode proposals \
     --existing "<folder>/<Project>_Blueprint.json" \
     --extract "<folder>/.blueprint/extract.json" \
     --blocks "<folder>/.blueprint/parsed/blocks.json" \
     --sources "<folder>/.blueprint/parsed/sources.json" \
     --estimating docs/catalogs/estimating-catalog.md \
     --out "<folder>/<Project>_Proposals.json"
   ```

   The tool compares each row with the Blueprint: a row whose `duplicateOf` (or whose statement) matches an existing row becomes an `update` when a value changed, a `conflict` when you marked it so, and nothing when nothing changed; a row that matches no existing statement becomes an `add`; a row that matches a dismissed requirement is skipped; a `duplicateOf` that names no existing row is treated as a new row, and a `conflict` among those is downgraded because it has only one citation. Each proposal carries the new citation, the cause (the file it came from), and a snapshot of the existing row. A `conflict` proposal without a question fails validation (exit 1, nothing written), so give every conflict row one. When `<Project>_Proposals.json` already exists the tool appends with new `P-` ids and skips anything already proposed, whatever its status; it refuses (exit 1, the file left as it is) a previous proposals file that belongs to another project. Every parsed source file the Blueprint and the proposals file do not list yet is carried on the proposals file.

   The tool refuses to run when `--out` is the Blueprint itself (exit 2, nothing is written), exits 4 when the extract holds no requirement the tool can use (check the extract JSON and its block ids), and exits 3 if the proposals file changed while it ran (run it again). It validates the proposals file before writing and writes it in one step.

4. **Validate** with `node tools/blueprint/validate-proposals.mjs "<folder>/<Project>_Proposals.json" --blueprint "<folder>/<Project>_Blueprint.json" --strict`.

The contract for the proposals file is [docs/spfx/agent-contract.md](../../../docs/spfx/agent-contract.md).

## Guardrails

- No invented drivers, hours, or capability ids
- No conflict winners
- No Scope Cut #2 commercial fields on the Blueprint root
- Never rewrite a Blueprint that has review state; propose instead
