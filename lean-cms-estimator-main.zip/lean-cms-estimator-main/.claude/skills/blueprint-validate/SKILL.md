---
name: blueprint-validate
description: Validate offline Blueprint, Context and Proposals JSON with field-path errors before handing files to the web part, and close the run record.
---

# Blueprint validate

Run every validator that applies. All must exit 0.

```bash
node tools/blueprint/validate-working-file.mjs "<Project>_Blueprint.json"
node tools/blueprint/validate-context.mjs "<Project>_Context.json" --blueprint "<Project>_Blueprint.json"
node tools/blueprint/validate-proposals.mjs "<Project>_Proposals.json" --blueprint "<Project>_Blueprint.json" --strict
node tools/blueprint/assemble-drivers.mjs --check ".blueprint/design-sketch.json" --blocks ".blueprint/parsed/blocks.json"
```

The third runs only on a re-run that wrote proposals. The fourth runs only when the design sketch step wrote `.blueprint/design-sketch.json`; it re-checks every driver's quote, names and sum against the parsed blocks. Run it again with `.blueprint/second-opinion-sketch.json` when the second opinion step wrote one. With `--blueprint`, a reference that matches nothing in the Blueprint (an `R-n` or `Qn` in the Context, a `requirementId` or a cited `itemId` in the proposals) prints a `warning:` line on stderr, and without `--strict` the warnings do not change the exit code. `--strict` (it needs `--blueprint`; use it on proposals) turns the proposals' cross-file mismatches into errors (exit 1): a `requirementId` or cited `itemId` that is not in the Blueprint, a different `projectId` or `blueprintRevision`, and a pending proposal whose `existing` snapshot no longer matches the live row. Clear every warning before handing the files over.

Then close the run:

```bash
node tools/blueprint/run-record.mjs "<project-folder>" --stage validate
node tools/blueprint/run-record.mjs "<project-folder>" --stage done
```

## What success means

- Blueprint mirrors `parseWorkingFileContent` / [working-file.md](../../../docs/spfx/working-file.md): the web part opens it without "malformed"
- Context matches [context-sidecar.md](../../../docs/spfx/context-sidecar.md); an empty `{}` is fine
- Proposals match [agent-contract.md](../../../docs/spfx/agent-contract.md); the app lists them for review
- `.blueprint/run.json` ends at stage `done` and names the files written

## Failure

Field-path errors on stderr; fix the JSON and re-run. Do not hand a failing file to the estimator, and do not mark the run `done`.

## CI note

Committed fixtures under `samples/offline/` and `samples/agent-run/` (and, in the repository only, the Northwind review fixtures) cover automated checks, with the same fixtures run through the TypeScript validators the app uses. Full customer-pack acceptance remains a documented manual gate (private pack path; not in git): see [docs/standalone/agent-run-evaluation.md](../../../docs/standalone/agent-run-evaluation.md).
