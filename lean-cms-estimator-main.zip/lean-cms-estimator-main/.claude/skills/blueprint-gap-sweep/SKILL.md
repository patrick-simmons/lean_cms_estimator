---
name: blueprint-gap-sweep
description: Check every estimating-catalog activity that has no requirement, and propose a delivery unknown plus a working assumption for each real gap through tools/blueprint/gap-sweep.mjs. Runs after blueprint-enrich and adds to the Context sidecar only. Everything is written as pending.
---

# Blueprint gap sweep

A bid is often short of requirements, not because the scope is small but because the documents never say. Content modeling, QA and environments are in nearly every build, and an RFP seldom lists them. Extraction cannot cite what is not written, so a package with no requirement stays out of the estimate without anyone deciding that.

This step finds those packages and asks. It writes into `{Project}_Context.json` beside the Blueprint. Schema: [docs/spfx/context-sidecar.md](../../../docs/spfx/context-sidecar.md). The skill proposes and the estimator decides: every item is `review: { "status": "pending" }`.

## Why an unknown and an assumption, not a requirement

A requirement must cite a document, and a checklist is not one. So a gap is a delivery unknown ("the documents do not say") with a working assumption ("we assume this is in scope, and this is what breaks if it is not"). The estimator accepts the pair, which tells them to add a requirement by hand or ask the client, or dismisses it.

## Inputs

- `{Project}_Blueprint.json`, already valid.
- `{Project}_Context.json`, already written by `blueprint-enrich`. This step adds to it and never edits or removes an item.
- The parsed blocks in `.blueprint/parsed/`, for checking whether a document rules a package out.

## Steps

1. **Run the tool.**

   ```bash
   node tools/blueprint/gap-sweep.mjs "<Project>_Blueprint.json" --existing "<Project>_Context.json" [--suppress "<team-suppress.json>"]
   ```

   **If it exits non-zero, stop and report its message.** Do not write gaps from memory. It prints JSON: `input` (counts read), `covered` (packages with a live requirement), `dismissedOnly` (the estimator dismissed every row: never a gap), `alreadyProposed` (the sidecar already holds the gap as an unknown or an assumption, in any review status), `suppressed` (listed in the `--suppress` file: the team keeps dismissing it), `notSignalled` (a package that is only asked about when the documents hint at it, and they did not), `unknownPackageIds` and `gaps`. Anything odd is also on stderr as `warning:` lines; put them in the run summary.

2. **Judge each gap.** Each entry has `basis`, `evidence`, an `unknown` and an `assumption`.
   - `usual`: the package is part of nearly every build. Keep the gap unless a parsed block says the work is out of scope, done by the client, or already covered (for example "the client supplies the content models"). When you reject a gap for that reason, say which block in the run summary.
   - `signalled`: `evidence` names the requirement and question ids and the words that matched. Read those rows. Keep the gap when they really point to the package's work; reject it when the word is used in another sense.
3. **Write what you keep.** For each kept gap add one `deliveryUnknowns` item and one `assumptions` item.
   - Copy `unknown` and `assumption` as they are, including `source`. Do not reword them and do not add numbers, hours, weeks or a quantity.
   - Give them the next `DU-` and `AS-` ids after the highest across all four lists.
   - The unknown's `refs` are the evidence `requirementIds` and `questionIds` (none for a `usual` gap). The assumption's `refs` is `["DU-nnn"]`, the unknown you just wrote.
4. **Never touch the Blueprint.** Do not add a requirement, a question or an activity. The estimator does that in the app after reading the unknown.

## Re-runs

Pass the existing sidecar every time. A gap whose `source` is already in the sidecar is listed under `alreadyProposed` and is not proposed again, even when the estimator dismissed it. That is the point: a dismissal is a decision. Do not edit, reorder or remove an existing item.

## Run summary

- Gaps kept, each with its package and basis
- Gaps rejected, each with the reason and the block you read
- The tool's `covered`, `dismissedOnly`, `alreadyProposed`, `suppressed` and `notSignalled` lists, and any `warning:` lines
## Guardrails

- Propose, never decide: no item is `accepted`, `edited` or `dismissed`
- No invented quantities, hours, dates or weeks
- No requirement is written, and no existing item is changed
- Do not write the commercial or difficulty fields the other stages are barred from writing

## Validate

```bash
node tools/blueprint/validate-context.mjs "<Project>_Context.json" --blueprint "<Project>_Blueprint.json"
```

Exit 0 is required. Fix a `warning:` line (a reference that points at nothing) and run it again.
