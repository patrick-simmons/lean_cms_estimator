---
name: estimate
description: Run the whole estimate on a project folder, from the documents to the plan file, talking to the estimator at four checkpoints (accept all or walk through, only the questions that matter, the client questions, the result). Writes {Project}_Plan.json and {Project}_Estimate.xlsx into the folder; nothing is pasted anywhere. Use when the estimator says "estimate this folder".
---

# Estimate

One skill for the whole run. It uses the stage skills for the heavy parts (parse, extract, design sketch, enrich) and the plan tool for the file that holds the result. Do **not** call Azure functions or Foundry. A person starts every run; nothing here runs on its own.

You write into the project folder yourself. The estimator never copies JSON between windows: the files appear in the folder, and you tell them what is in them.

## Before you start

1. **Read the folder's `AGENTS.md`** when it has one. It names the project and the source files the estimator chose, and the pack version expected. Read only the sources it lists. If the list is empty, stop and ask the estimator to choose sources. Without `AGENTS.md`, the sources are the supported files at the top level of the folder and the project name is the folder name.
2. **Is there a plan file already?** `{Project}_Plan.json` in the folder means this is a **re-run**. A re-run only adds: the tool leaves every existing row alone, decisions included. Ask nothing about rows that are already decided.
3. Client text stays in the project folder. Never copy client files or text into the pack or into a repository.

## Steps

### 1. Parse

Follow `blueprint-parse`: `node tools/blueprint/parse-local.mjs <folder>` writes `.blueprint/parsed/`. Read the parsed blocks, never the raw files. Note what the tool could not read (scanned PDFs, legacy `.doc`): you will say so at the end.

### 2. Extract

Follow `blueprint-extract-map` for what a requirement is and how to cite, and write `.blueprint/extract.json`. Skip that skill's assemble step: the plan tool does the assembling. Be thorough rather than short: every requirement the documents give, each mapped to the activity it mostly belongs to, with a client-ready question wherever the text is ambiguous, conditional or in conflict. Two sources that disagree become one requirement with coverage `conflict`, both citations and a question. No winner.

### 3. Assemble the plan

```bash
node tools/blueprint/plan.mjs assemble "<folder>"
```

It writes `{Project}_Plan.json`, or adds to the one there. Exit 4 means no requirement survived: check the block ids in the extract. Exit 1 means the plan it would write is not valid, or the one in the folder is not: say which, and stop; never delete or repair a plan file to get past it.

### 4. Volumes

Follow `blueprint-design-sketch` to count what the documents let you count (pages, locales, sites, systems, content types, components, environments, authors). Pass the plan file as `--blueprint`. Every volume carries the words, names or parts that back it; a number the documents do not support gets no volume. Then run step 3 again: the tool adds the volumes to the plan.

### 5. Checkpoint 1: accept all or walk through

```bash
node tools/blueprint/plan.mjs summary "<folder>/<Project>_Plan.json" --markdown
```

Say what you found in two or three sentences: requirements and workstreams, volumes found, questions and conflicts, platform, and the workstreams with no requirement. Then ask **one question** with these choices, the first marked as recommended:

- **Accept all** (recommended): `node tools/blueprint/plan.mjs accept "<plan>" --all`. Every pending requirement and volume is marked `accepted (bulk)`.
- **Walk through by workstream**: for each workstream, list its requirements in one message and ask to accept it as it is, or name the rows to change or drop. Accept a workstream with `--workstream <activity>`, rows with `--ids`, drop rows with `--dismiss`. To change a statement or its activity, edit that row in the plan file, set its `review` to `{ "status": "edited", "via": "edit", "at": "<ISO time>" }`, and run `plan.mjs validate`.
- **Decide later**: leave everything pending.

Nothing is locked. Say so: the estimator can add, change or drop rows at any time, and a re-run only adds.

### 6. Enrich

Follow `blueprint-enrich`, `blueprint-gap-sweep` and `blueprint-lever-advice`, writing `{Project}_Context.json`. Wherever those skills say "Blueprint", use the plan file: the tools read `requirements` and `questions` from it. Run `blueprint-second-opinion` only for a large bid or when the estimator asks.

### 7. Checkpoint 2: only when needed

Stop to ask **only** when one of these is true, and give a recommended answer with each question:

- The documents do not name the platform, or name two.
- Two documents disagree on something that sizes a workstream (locales, pages, sites). Both figures and their sources, and ask which to use.
- A large workstream has requirements but no volume the documents support.
- The documents say the client is doing an activity themselves, or sharing it. Offer to record it; do not record it on your own reading.

Anything else: do not ask. Write the assumption into the Context sidecar and go on.

Ownership is recorded with one command, and only when the estimator says so:

```bash
node tools/blueprint/plan.mjs owner "<plan>" --activity <id> --set us|shared|client --note "<why they said it>"
```

The note is the estimator's own words: it becomes the exclusion the client reads. This is one of only two places ownership is offered; the other is checkpoint 3.

### 8. Estimate

```bash
node tools/blueprint/plan.mjs estimate "<plan>"
```

Add `--platform aem` or `--platform aem-eds` only when the estimator chose the platform at checkpoint 2. It writes `workstreams`, `skills` and `estimateBasis` into the plan; a re-run replaces those three and nothing else.

Four things decide a workstream's hours, and the tool decides all four. You read them out; you never choose one.

**The volume.** An accepted volume from the documents, or a **placeholder** default labelled `assumed`, with low confidence and a client question. The placeholder is a real number doing real work, and it is called a placeholder every time it is shown.

**The rate ladder.** Hours per unit come from one of three rungs, and the workstream says which in `rateBasis`:

| Rung | Where the rate came from | Owes a question |
| --- | --- | --- |
| `cases` | Three or more past projects on this platform cover the activity. The rate is their median. | No — it is evidence |
| `cases-adjusted` | Past projects cover it, but too few, or only on another platform. | Yes |
| `derived` | No past project covers it: an estimator's accepted rate, or the catalog's starting figure until somebody accepts one. | Yes |

An estimator who wants to set a rate does it with a command, not by typing a number into the plan:

```bash
node tools/blueprint/plan.mjs rate "<plan>" --activity <id> --hours <n> --note "<why>"
```

**The band.** The eight tiered activities resolve to small, medium or large from signals in the documents, with the deciding signal and its citation recorded. No signal means medium at low confidence and a client question. Conflicting signals take the higher band and record a **challenge**, which is a statement for the estimator to overturn, not a question to ask. You never pick a band, and you never ask the estimator to pick one. Bands are shown at checkpoint 3.

**Who does the work.** `us`, `shared` or `client`, applied after the sizing. A client-owned activity leaves the estimate; a shared one is carried whole until somebody records the split. Ownership is only ever changed by the estimator, at checkpoints 2 and 3 (step 7 and step 10).

Four activities are not sized from a volume at all. QA automation, UAT support, project management and delivery governance are **shares** of the activities they cover, so a bigger build moves them without anyone editing them. They are not placeholders.

Every workstream carries **low, likely and high**. Likely is the number: it is the hours the estimate quotes, and the one to lead with. The range is the spread the past projects showed. A rate nobody has measured has no range at all, so low and high equal likely — that is the absence of evidence, not confidence, and it is worth saying so out loud when it happens.

The AI-assisted rate is the activity's saving percentage from the catalog, applied only while a tool for the workstream is ON. Never type a volume or hours yourself; to change one, accept or edit the volume in the plan, or record a rate with `plan.mjs rate`, then run `estimate` again.

Run `plan.mjs summary --markdown` and read its **Estimate** section. Lead with likely and give the range beside it in the same breath. Warnings about out-of-date workstreams mean a volume changed after the last estimate: run `estimate` again.

### 9. AI plan

```bash
node tools/blueprint/plan.mjs ai-plan "<plan>"
node tools/blueprint/plan.mjs ai-report "<plan>" --markdown
```

The estimate assumes **every available tool is used**: the tool inventory is generated from the catalogs for the platform, every tool and delivery method is ON (opt-in ones included), and each requirement gets a tool or a catalog reason. You do not choose levers and you do not decide that a tool is "not needed". Nothing is opted out unless the estimator says so, and then only with a reason from the list (`not-licensed`, `not-installed`, `client-restriction`, `not-suitable`) and a typed note in their own words:

```bash
node tools/blueprint/plan.mjs ai-opt-out "<plan>" --id <tool-or-method> --reason <reason> --note "<what the estimator said>"
node tools/blueprint/plan.mjs ai-restore "<plan>" --id <tool-or-method>
```

The hours follow: what the tool supported goes back to the traditional rate. Lever advice (step 6) is evidence for the estimator; it no longer switches anything on.

### 10. Checkpoint 3: the client questions

```bash
node tools/blueprint/rank-questions.mjs "<plan>" --context "<Project>_Context.json" --markdown
```

Show the **Client clarification list** (question text only, in the order to ask). Then show the questions for the assumed volumes (the summary's "Assumed volumes" list), and say that each figure is a placeholder until the client answers. Keep **Why this order** to yourself unless the estimator asks; it is internal.

Then show the summary's **Complexity bands** section as it stands: each tiered activity, its band, and the signal that decided it. Every band rests on accepted volumes by now, so this is where it is settled rather than provisional. Two of its lines are not client questions and are read differently:

- An **Ask** line is a band with no signal behind it. It goes on the client list with the rest.
- A **Challenge** line is a band the signals disagreed about, where the higher one was taken. It is for the estimator, not the client. Show it and move on; if they want the lower band, they say so and you record it.

The band itself is never a question to the estimator. Do not offer a list of bands to choose from.

Show the summary's **Who does the work** section, and offer to change any of it with `plan.mjs owner` (step 7). This is the last of the two places ownership is offered.

Then offer the **scope caps**, as one question and not one per activity. A volume the documents state produces no assumption of its own today, so the estimate quietly carries whatever the figure turns out to be. A cap turns that into something the client agreed to: the estimate is for this many, and more than this many is a change. Propose a cap for each workstream sized on a volume, at the figure the estimate already uses, and ask one question: accept them all, name the ones to change, or none. For each cap the estimator takes:

```bash
node tools/blueprint/plan.mjs assume "<plan>" --activity <id> --cap <n> --note "<why they set it>"
```

The note is theirs, not yours, and the command refuses without one. A cap changes the volume, so run `estimate`, `ai-plan` and the workbook again afterwards; the summary says so until you do. Do not cap an activity on your own judgement, and do not propose a cap below the figure the documents give: lowering what the estimate covers is the estimator's decision to make and to explain.

Show the AI plan in a few lines: the platform, that every tool is assumed on, any opt-outs, and the **readiness list** (what must be installed or reached for the AI-assisted number to hold). Then the levers the documents give a reason for (from `lever-advice`), as evidence only. Ask whether to go on or change anything, including opting out of anything the client or the team cannot use.

### 11. Checkpoint 4: the result

```bash
node tools/blueprint/plan.mjs validate "<plan>"
node tools/blueprint/build-workbook.mjs "<plan>"
```

It writes `{Project}_Estimate.xlsx` next to the plan file, built from the template `samples/workbook/Estimate_Template.xlsx` ([workbook-template.md](../../../docs/spfx/workbook-template.md)). Every cell is a field of the plan: you never type into the workbook, and a change goes into the plan (or the opt-outs) followed by `estimate`, `ai-plan` and `build-workbook` again. The workbook is rebuilt from the plan each time, so anything typed into it is replaced.

If the tool stops (the plan is not valid, has no estimate, or has no AI plan), say which and run the missing step; do not work around it. A warning that the estimate is out of date means a volume changed since the last `estimate`: run `estimate` and `ai-plan` again and build once more.

Then tell the estimator where the file is and what is in it: the totals on **Coverage**, the **Questions** to send first, **Assumptions and risks**, and the **AI plan** sheet with its readiness items and any opt-outs. Say that formulas calculate when the file is opened in Excel, so a preview may show blanks.

## End the run with a summary

- The mode (first run or re-run) and the pack version.
- What was written (file names, counts): the plan file, the Context sidecar, the design sketch, the workbook.
- What was accepted, and how (`bulk`, `walk`), and what is still pending.
- Sources not read, and why.
- The totals, likely first and the range beside it: "4,200 h likely, 3,800 to 4,900 on the evidence behind it", traditional and AI-assisted. Never offer low or high as a number to pick instead.
- How many workstreams were sized from the documents, how many rest on a placeholder volume, and how many rates are on each rung of the ladder. A total built mostly on `derived` rates is a different thing from one built on past projects, and the estimator is the one who has to stand behind it.
- The bands that no signal decided, which are the parts of the estimate most likely to move.
- The AI plan: opt-outs with their reasons, requirements with no tool, the readiness list, and the count of tools the catalogs offer that no workstream uses.
- What is assumed rather than found, and the first questions to ask the client.

## Guardrails

- Do not invent a volume, an hour, a band, a rate, a date or a week. A volume needs its quote, names or parts. A figure you did not find is a placeholder, and is called one. A band comes from the signals in the documents; where there is no signal the answer is medium at low confidence and a question, not your reading of how hard the work looks.
- Do not present a rate as evidence when its rung says it is not. `derived` means nobody measured it.
- Do not resolve a conflict. Do not write a capability id yourself: the tool derives them.
- Do not change who does the work on your own reading, and never outside checkpoints 2 and 3.
- Do not set a scope cap on your own judgement, and never write the reason for one. A cap is what the estimate commits to.
- Do not opt a tool out on your own judgement, and never write an opt-out reason for the estimator. Do not make up a tool: the inventory comes from the catalogs.
- Never overwrite a plan file that is not valid, and never change a decision the estimator made.
- Keep to the four checkpoints. More questions than that mean the estimator is doing your work.
