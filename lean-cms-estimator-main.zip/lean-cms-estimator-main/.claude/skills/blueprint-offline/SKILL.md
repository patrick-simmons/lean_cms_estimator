---
name: blueprint-offline
description: Orchestrate the offline Blueprint pipeline (Parse → Extract+map → Enrich → Validate) on a project folder to write web-part-valid {Project}_Blueprint.json and a v2 {Project}_Context.json on a first run, or {Project}_Proposals.json on a re-run, without Azure or Foundry.
---

# Offline Blueprint orchestrator

Run the stage skills in order on one project folder. Do **not** call Azure functions or Foundry. Do **not** bump `revision` or write `published`, `estimate`, or `handoff`. A person starts every run; nothing here runs on its own.

## Before the first stage

1. **Read the folder's bootstrap when it has one.** `AGENTS.md` and `.blueprint/sources.json` are written by the app (or by `node tools/blueprint/prepare-folder.mjs`). They name the project, the source files the estimator chose, and the pack version the app expects. Read only the sources they list. If the list is empty, stop and ask the estimator to choose sources; the parse tool exits 3 on an empty selection and does not fall back to the whole folder. Without a bootstrap, the sources are the supported files at the top level of the folder, and the project name is the folder name unless the operator says otherwise.
2. **Check the pack version.** `.blueprint/expect.json` (when present) names the pack version and schema versions the app expects; this pack's own version and schemas are in `tools/release/pack.config.json`. When this pack is older, say so before running. When the app expects a schema this pack does not write, stop.
3. **Decide the mode.** If `{Project}_Blueprint.json` is not in the folder, this is a **first run**. If it is, this is a **re-run**: you do not write the Blueprint, and the extract stage writes `{Project}_Proposals.json` instead. That is the one rule; the assemble tool backs it up (a first-run write exits 3 and writes nothing when the existing Blueprint has any review state or cannot be read), so never delete, rename or repair an existing Blueprint to get around it.

## Catalogs

- `docs/catalogs/estimating-catalog.md` (activities, capabilities, delivery methods; pins in its front matter)
- `docs/catalogs/cmk-capability-catalog.md`
- `docs/catalogs/toolkit-capability-catalog.md`

The pack carries a snapshot of these. **Catalog freshness:** when the estimator's hub folder (the synced catalog library the app also reads) holds an estimating catalog with a higher `version` in its front matter, prefer it: pass its path to `--estimating` and name both versions in the run summary. Never mix catalogs within one run.

## Private customer pack

Client source text stays **out of git** (SPMVP-014). The project folder is the operator's, outside this repository and this pack. Never copy client files into either. The Northwind fixtures and the synthetic AEM sources under `samples/` are smoke tests only.

## Stage order

1. **blueprint-parse**: `node tools/blueprint/parse-local.mjs <folder>` writes `.blueprint/parsed/` (blocks, sources, manifest). The model reads the parsed blocks, never the raw files.
2. **blueprint-extract-map**: the model extracts from the blocks; `node tools/blueprint/assemble-working-file.mjs` writes `{Project}_Blueprint.json` (first run) or, with `--mode proposals --existing`, `{Project}_Proposals.json` (re-run).
   **blueprint-design-sketch** (part of this stage, once the Blueprint exists): `node tools/blueprint/assemble-drivers.mjs` checks the model's proposed sizing drivers against the parsed blocks and writes `.blueprint/design-sketch.json`. Each driver quotes or names its evidence; a figure the sources give two ways gets no driver.
3. **blueprint-enrich**: v2 `{Project}_Context.json` (`meta.schemaVersion: "2"`, `meta.producedBy: "skill"`). On a re-run, add only: pass the existing sidecar to the matcher with `--existing` and never edit or remove an item.
   **blueprint-gap-sweep** (part of this stage, after the sidecar is written): `node tools/blueprint/gap-sweep.mjs` lists activities with no requirement; the model keeps the real gaps and adds each as a pending delivery unknown with a working assumption. It never adds a requirement.
   **blueprint-lever-advice** (part of this stage, after the gap sweep): `node tools/blueprint/lever-advice.mjs` finds words in the documents (a Figma link, an existing site to migrate, an accessibility standard, a stated AEM migration) that give a reason to enable an opt-in asset or delivery method the catalog offers on this platform; the model keeps the real ones as pending working assumptions with the quote. It never switches a lever on: the estimator does that on the AI levers tab.
   **blueprint-second-opinion** (optional, part of this stage, after the gap sweep; for large bids or when the estimator asks): a separate agent that has not seen the first read re-counts the drivers from the blocks, a challenger argues against each accelerated claim, and `second-opinion.mjs` turns the disagreements and the objections that hold up into pending unknowns. Skip it, and say so, when no separate agent can be started.
4. **blueprint-validate**: every validator exits 0 (`validate-working-file`, `validate-context --blueprint`, `validate-proposals --blueprint --strict` on a re-run, and `assemble-drivers --check` for each sketch file that exists), then `node tools/blueprint/run-record.mjs <folder> --stage done`.
5. **blueprint-infer-skills** (optional, SPMVP-030): propose catalog `skillIds` for root `skillSet`; the estimator confirms in the app.

## Run record

Every tool records its stage in `.blueprint/run.json`. The app reads it to show which pack produced the files and how far the run got. When a stage fails, leave the record as the tools left it and say which stage stopped; do not edit the record by hand.

## Extract rules

The extraction system message and response format are shipped with the extract skill: `.claude/skills/blueprint-extract-map/references/system-message.md` and `response-format.md`. They are the source of truth for what a requirement is, how to cite, and how to report a conflict. They are written for this pack: the activity list comes from the estimating catalog and the platform list from the CMK catalog, both in `docs/catalogs/`.

## Operator docs

- Run paths and tools: [docs/spfx/offline-blueprint-skill-pack.md](../../../docs/spfx/offline-blueprint-skill-pack.md)
- File contract between the agent and the app: [docs/spfx/agent-contract.md](../../../docs/spfx/agent-contract.md)

## Run summary

End every run with: the mode (first run or re-run), the pack version used, the catalog versions used, what was written (file names and counts), which sources were not read and why, and anything left open for the estimator.

Add a **client clarification list** after validate, so the estimator can send the questions in the order that matters most:

```bash
node tools/blueprint/rank-questions.mjs "<Project>_Blueprint.json" --context "<Project>_Context.json" --markdown
```

Paste its output into the summary. It orders the Blueprint's open questions, and the Context unknowns no question covers (the gap sweep's too), by what the answer would touch: conflicts between sources, a quantity or scope that sizes a package, the figure already sizing it, the other requirements riding on it, and, when the Blueprint holds an estimate, the package's share of the hours. The output has two parts. **Client clarification list** holds the question text only, in the order to ask, and is the part the estimator can send. **Why this order (team only, do not send)** holds the reasons, which can mention the estimate and the second opinion's findings; label it as internal when you paste it, and never copy it into a message for the client. You may reword a question for the client. Keep the order and the tiers, and add no hours, quantities or dates of your own. If the tool exits non-zero, say so and give the open questions unranked.

When lever advice ran, also paste `node tools/blueprint/lever-advice.mjs --blueprint "<Project>_Blueprint.json" --blocks ".blueprint/parsed/blocks.json" --existing "<Project>_Context.json" --markdown`, cut to the levers you kept, so the estimator knows what to confirm on the AI levers tab.

## What the team keeps rejecting

If the team keeps a suppression file (written by `node tools/blueprint/review-stats.mjs <project folders> --suppress-out <file>` from the review decisions across projects), pass it as `--suppress <file>` to `match-library.mjs`, `gap-sweep.mjs` and `lever-advice.mjs`. Each leaves out what the team keeps dismissing, the same way it leaves out an item already in the sidecar, and counts it under `suppressed` (apart from `skipped` or `alreadyProposed`). A suppression file that cannot be used stops the tool with exit 1 and the reason: say so, do not run without it. Say in the run summary that a suppression file was used and how many items it left out. The file holds keys only; never copy client text into it. `review-stats` extends a file that is already there and never narrows it. Without a file nothing changes.

## Guardrails

- Do not invent driver quantities or hours
- Do not resolve conflicts (no winner)
- Do not write Scope Cut #2 commercial fields onto Blueprint or Context (`accountHistory`, commercial risks, difficulty multipliers, staffing profiles)
- Capability ids come from Node post-process only; the model must not invent them
- A gap becomes a pending unknown and assumption, never a requirement: a requirement must cite a document
- Never rewrite a Blueprint that has review state; propose instead
