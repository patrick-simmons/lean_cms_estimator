---
name: blueprint-design-sketch
description: Propose sizing drivers (pages to migrate, locales, sites, content types, integrations) from the parsed sources, each with its evidence, through tools/blueprint/assemble-drivers.mjs. A light pass of the CMK design skills' counting. Writes .blueprint/design-sketch.json as pending proposals; never hours.
---

# Blueprint design sketch

Today a package is sized from the first number in a requirement's statement. A requirement that says "four locales" in words, or lists the integrations by name, gives Build nothing to multiply. The real driver is usually in the documents: an inventory with page counts, a list of languages, the systems named in a kickoff deck.

This step reads the parsed blocks the way the CMK design skills would, **only to count**, and proposes one driver per activity. Each driver carries the words or names it comes from, so the tool can check them and the estimator can see them. The output is `.blueprint/design-sketch.json`, beside the parse output. The app does not read it yet (structured sizing drivers are SPMVP-048). The estimator reads it, and the maintainers' back-test scores it against a past estimate.

The skill proposes and the estimator decides: every driver is `review: { "status": "pending" }`.

## Inputs

- `.blueprint/parsed/blocks.json` (the parse stage). Cite blocks by id. Read nothing else for counts.
- `{Project}_Blueprint.json`, already valid, for the platform and for what the requirements already say.
- The CMK design skills, when installed (`cmk-model-content`, `cmk-multisite-design`, `cmk-localization-design`, `cmk-migration-assess`, `cmk-search-design`, `cmk-headless-design`), for how each one counts. Do not run them in full and do not use their output other than the count: their complexity ratings, risk registers and level-of-effort figures are not sizing drivers here.

## What to count

| Count | Activity (unit) | Design skill | Where it shows up |
| --- | --- | --- | --- |
| Pages or URLs to move | content-migration (page) | `cmk-migration-assess` | Content inventories, a stated page count, a scope clause |
| Locales to launch | localization (locale) | `cmk-localization-design` | A list of languages or regions |
| Sites in the topology | multisite (site) | `cmk-multisite-design` | Corporate site, brand sites, microsites, a locator |
| Sites that have search | search (site) | `cmk-search-design` | A search requirement, by site |
| Content types to model | content-model (content-type) | `cmk-model-content` | A content model, a list of page or content types |
| Templates in the front end the headless way | frontend-delivery (template) | `cmk-headless-design` | A stated headless front end and its page types |
| Systems to integrate | integrations (integration) | none | Named systems, feeds and connectors |
| Templates in the current site | discovery-audit, qa-automation (template) | none | An audit or an inventory of templates |
| Components | component-build, component-review (component) | none | A component list or design inventory |
| Environments | environments-devops (environment) | none | Named environments |
| Authors to onboard | uat-support (author) | none | A stated number of editors |

The unit is fixed by the estimating catalog; the tool fills it in and rejects a different one.

## Steps

1. **Find the figures.** For each row above, look in the blocks for a stated number, a list of names, or a table you can add up.
2. **Write one driver per activity** into a JSON file (anywhere outside the repository, for example `.blueprint/design-sketch-input.json`):

   ```json
   { "drivers": [ { "workPackageId": "localization", "quantity": 4, "basis": "counted",
       "items": ["English", "German", "French", "Dutch"],
       "blockIds": ["src-rfp#p3.1"], "confidence": "medium",
       "designSkill": "cmk-localization-design", "note": "Optional, 400 characters." } ] }
   ```

   Choose how the number is backed:
   - `stated`: add `quote`, at least two words copied from a cited block (not the bare number) that contain the number (digits, or a number word up to twenty). The tool matches whole words, so "12" does not match "2012".
   - `counted`: add `items`, the names of the things, each found in a cited block. `quantity` is how many.
   - `summed`: add `parts`, each `{ label, quantity, quote }` with its own quote. `quantity` is their sum. Use it for a table you add up.

   `confidence` is `high` when a document states the number outright, `medium` when you counted or summed it, `low` when the document is vague (a plural with no number).
3. **Run the tool.**

   ```bash
   node tools/blueprint/assemble-drivers.mjs --input "<input.json>" --blocks ".blueprint/parsed/blocks.json" --out ".blueprint/design-sketch.json" --blueprint "<Project>_Blueprint.json"
   ```

   It prints the drivers written, each driver it **rejected with the reason**, and, per package, the quantity Build would take from the requirement text next to yours. Fix a rejected driver from the blocks, or leave it out. Never loosen a quote or an item list to get past a check. If the tool exits 4, nothing was valid: say so in the run summary.
4. **Exit 3** means the file already holds review decisions: stop and say so. Do not delete or rename it.

## What never gets a driver

- **A figure the sources give two ways.** The sketch does not resolve conflicts. Where two blocks give different numbers for the same package (a kickoff deck and an RFP, an RFP and its addendum), write no driver and put both figures and their blocks in the run summary. The Blueprint already carries the conflict, or the re-run proposes it.
- **A number the documents do not support.** No estimate from experience, no average, no rounding, no "typical". If you cannot point to the words or the names, there is no driver. The package is left to the estimator, and the run summary says what the documents did not give.
- **Anything that is not a count.** No hours, weeks, dates, rates, risk or complexity ratings.

## Re-runs

The tool replaces an untouched `design-sketch.json` and refuses one with review decisions. On a re-run, read the new blocks, redo the counts and write the file again. A package that now has conflicting figures loses its driver, and the run summary says why.

## Run summary

- Drivers written, each with its package, quantity, basis and confidence
- Drivers rejected, each with the tool's reason
- Packages with no driver, and why (no figure in the documents, or the sources disagree with both figures named)
- Where the sketch differs from the requirement-text quantity (the tool's `comparison`)

## Guardrails

- Propose, never decide: no driver is `accepted`, `edited` or `dismissed`
- No invented quantities; every number carries its quote, names or parts
- Do not resolve conflicts (no winner)
- No hours, dates, weeks, rates or difficulty multipliers

## Validate

```bash
node tools/blueprint/assemble-drivers.mjs --check ".blueprint/design-sketch.json" --blocks ".blueprint/parsed/blocks.json"
```

Exit 0 is required. It re-checks every driver against the blocks, so it also fails after the sources change underneath a sketch.
