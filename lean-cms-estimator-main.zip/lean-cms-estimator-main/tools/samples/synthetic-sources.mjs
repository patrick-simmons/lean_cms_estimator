#!/usr/bin/env node
/**
 * Writes the synthetic AEM source documents under samples/sources/synthetic-aem/ (SAPP-013, SAPP-017).
 *
 * They are the inputs the local parse tool and the agent run are checked against: an RFP as a text PDF,
 * a kickoff deck, a workshop notes document, a content inventory workbook, a scanned-looking PDF with no
 * text layer and a legacy .doc. Every word is invented; the client, the numbers and the planted
 * contradiction (two locales in the deck, four in the RFP) are there to be found by the checks in
 * docs/standalone/agent-run-evaluation.md. There is no client text here.
 *
 * Usage: node tools/samples/synthetic-sources.mjs [out-dir]
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { docxFixture, HEADING_STYLES, pptxFixture, shape, sheetRow, wPara, xlsxFixture } from '../blueprint/fixtures/ooxml-fixture.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '../..');
export const SOURCES_DIR = join(root, 'samples/sources/synthetic-aem');
/** The document that arrives after the first review, for the re-run (SAPP-014, SAPP-017). */
export const ADDENDUM_DIR = join(root, 'samples/sources/synthetic-aem-addendum');
/** The file name inside ADDENDUM_DIR; the agent run sample selects it by this name. */
export const ADDENDUM_FILE = 'Fabrikam_Addendum.docx';

// pdf-lib is a dependency of the extraction function, not of the web part.
const requireFromFunction = createRequire(join(root, 'function/package.json'));
const { PDFDocument, StandardFonts } = requireFromFunction('pdf-lib');

const RFP_PAGES = [
  {
    heading: '1 Overview',
    body: [
      '1.1 Fabrikam Outdoor will replatform its public website to Adobe Experience Manager as a Cloud Service during 2027, keeping the fabrikam-outdoor.example domain.',
      '1.2 The programme covers the corporate site, the dealer locator and the seasonal campaign microsites.'
    ]
  },
  {
    heading: '2 Content migration',
    body: [
      '2.1 The selected vendor shall migrate all in-scope content, approximately 6,400 pages, and implement 301 redirects so that no organic search ranking is lost.',
      '2.2 Inbound links are preserved with a redirect map approved by Fabrikam marketing before launch.',
      '2.3 Fabrikam will remove redundant content before migration starts; the final page count is confirmed at the end of discovery.'
    ]
  },
  {
    heading: '3 Languages and regions',
    body: [
      '3.1 The platform launches in four locales: English, German, French and Dutch.',
      '3.2 Translation is handled by the incumbent agency through a connector to the CMS.'
    ]
  },
  {
    heading: '4 Non-functional requirements',
    body: [
      '4.1 All public pages meet WCAG 2.2 AA.',
      '4.2 The platform runs in a public cloud region in the European Union and holds no payment data.',
      '4.3 Editors receive two days of role-based training before go-live.'
    ]
  }
];

async function rfpPdf() {
  const doc = await PDFDocument.create();
  doc.setTitle('Fabrikam Outdoor RFP 2027');
  doc.setCreationDate(new Date('2026-01-01T00:00:00Z'));
  doc.setModificationDate(new Date('2026-01-01T00:00:00Z'));
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  for (const section of RFP_PAGES) {
    const page = doc.addPage([612, 792]);
    let y = 740;
    page.drawText(section.heading, { x: 54, y, size: 16, font: bold });
    y -= 36;
    for (const paragraph of section.body) {
      for (const line of wrap(paragraph, 88)) {
        page.drawText(line, { x: 54, y, size: 11, font });
        y -= 15;
      }
      y -= 10;
    }
  }
  return doc.save({ useObjectStreams: false });
}

function wrap(text, width) {
  const words = text.split(' ');
  const lines = [];
  let line = '';
  for (const word of words) {
    if (line.length + word.length + 1 > width && line.length > 0) {
      lines.push(line);
      line = word;
    } else {
      line = line.length ? `${line} ${word}` : word;
    }
  }
  if (line.length) {
    lines.push(line);
  }
  return lines;
}

async function scannedPdf() {
  const doc = await PDFDocument.create();
  doc.setCreationDate(new Date('2026-01-01T00:00:00Z'));
  doc.setModificationDate(new Date('2026-01-01T00:00:00Z'));
  // Two pages with a drawn rectangle and no text: what a scanner produces without OCR.
  for (let index = 0; index < 2; index += 1) {
    const page = doc.addPage([612, 792]);
    page.drawRectangle({ x: 40, y: 40, width: 532, height: 712, borderWidth: 1 });
  }
  return doc.save({ useObjectStreams: false });
}

function kickoffDeck() {
  return pptxFixture({
    order: [1, 2, 3],
    slides: [
      { file: 1, shapes: shape('Fabrikam Outdoor replatform kickoff', 'ctrTitle') + shape('Programme summary, March 2027', 'subTitle') },
      {
        file: 2,
        shapes: shape('Launch scope', 'title') + shape('Two locales at launch: English and German\nFrench and Dutch follow in a second release\nDealer locator moves with the first release'),
        notes: 'Marketing asked to confirm the locale list with procurement.'
      },
      {
        file: 3,
        shapes: shape('Integrations', 'title') + shape('Product data from the PIM through a nightly feed\nDealer records from Salesforce\nAnalytics with Adobe Analytics')
      }
    ]
  });
}

function workshopNotes() {
  return docxFixture({
    styles: HEADING_STYLES,
    body: [
      wPara('Workshop notes, discovery day 2', 'Heading1'),
      wPara('Search', 'Heading2'),
      wPara('Site search must return products and articles together, with filters by activity and season.'),
      wPara('Forms', 'Heading2'),
      wPara('Dealer enquiry and newsletter forms post to the marketing automation platform; no form data is stored in the CMS.'),
      wPara('Open points', 'Heading2'),
      wPara('The team could not say how many templates the current site has. An audit is needed before design.')
    ].join('')
  });
}

function contentInventory() {
  return xlsxFixture({
    sheets: [{
      name: 'Inventory',
      rows: [
        sheetRow(1, ['Section', 'Pages', 'Owner']),
        sheetRow(2, ['Products', 2100, 'Catalogue team']),
        sheetRow(3, ['Stories', 3400, 'Content team']),
        sheetRow(4, ['Dealers', 600, 'Sales operations']),
        sheetRow(5, ['Campaigns', 300, 'Marketing'])
      ].join('')
    }]
  });
}

function addendum() {
  return docxFixture({
    styles: HEADING_STYLES,
    body: [
      wPara('Addendum 1 to the RFP, following the clarification call', 'Heading1'),
      wPara('Migration scope', 'Heading2'),
      wPara('After the content clean-up, approximately 5,900 pages remain in scope. The 301 redirect requirement stands so that no organic search ranking is lost.'),
      wPara('Training', 'Heading2'),
      wPara('Editors receive four days of role-based training before go-live, split across two sessions.'),
      wPara('Hosting', 'Heading2'),
      wPara('The production environment is hosted in the Frankfurt region.'),
      wPara('Accessibility', 'Heading2'),
      wPara('All public pages meet WCAG 2.2 AA.')
    ].join('')
  });
}

export function writeAddendum(outDir = ADDENDUM_DIR) {
  mkdirSync(outDir, { recursive: true });
  writeFileSync(join(outDir, ADDENDUM_FILE), addendum());
  return [ADDENDUM_FILE];
}

export async function writeSyntheticSources(outDir = SOURCES_DIR) {
  mkdirSync(outDir, { recursive: true });
  const files = {
    'Fabrikam_RFP_2027.pdf': await rfpPdf(),
    'Fabrikam_Kickoff_Deck.pptx': kickoffDeck(),
    'Workshop_Notes.docx': workshopNotes(),
    'Content_Inventory.xlsx': contentInventory(),
    'Signed_NDA_scan.pdf': await scannedPdf(),
    'Legacy_Brief.doc': new Uint8Array([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0, 0, 0, 0, 0, 0, 0, 0])
  };
  for (const [name, bytes] of Object.entries(files)) {
    writeFileSync(join(outDir, name), bytes);
  }
  return Object.keys(files);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const out = process.argv[2] ? resolve(process.argv[2]) : SOURCES_DIR;
  writeSyntheticSources(out)
    .then((names) => {
      console.log(`wrote ${names.length} files to ${out}`);
      if (!process.argv[2]) {
        const added = writeAddendum();
        console.log(`wrote ${added.length} files to ${ADDENDUM_DIR}`);
      }
    })
    .catch((error) => {
      console.error(error instanceof Error ? error.stack || error.message : String(error));
      process.exit(1);
    });
}
