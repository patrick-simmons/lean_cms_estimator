#!/usr/bin/env node
/**
 * Replays a full agent run on the synthetic AEM sources with the real tools and writes the result to
 * samples/agent-run/ (SAPP-014, SAPP-017). The model's part of the run (the extract JSON and the
 * Context sidecar) is the committed text under tools/samples/agent-run/, written by hand against the
 * parsed blocks; everything else is the tools:
 *
 *   1. prepare-folder          AGENTS.md, CLAUDE.md, .blueprint/sources.json, .blueprint/expect.json
 *   2. parse-local             .blueprint/parsed/
 *   3. assemble (first run)    Fabrikam Outdoor_Blueprint.json
 *   4. enrich                  Fabrikam Outdoor_Context.json (committed), validated against the Blueprint
 *   5. review                  the estimator's decisions from review.json are stamped on the Blueprint
 *   6. the addendum arrives    prepare-folder with the new file, parse-local again
 *   7. assemble (proposals)    Fabrikam Outdoor_Proposals.json; the Blueprint is not touched
 *   8. validate                both validators and the proposals validator exit 0
 *
 * Usage: node tools/samples/agent-run-sample.mjs [out-dir]   (default samples/agent-run)
 */
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ADDENDUM_FILE } from './synthetic-sources.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '../..');
const inputs = join(here, 'agent-run');
export const SAMPLE_DIR = join(root, 'samples/agent-run');
export const PROJECT_NAME = 'Fabrikam Outdoor';
const BLUEPRINT = `${PROJECT_NAME}_Blueprint.json`;
const CONTEXT = `${PROJECT_NAME}_Context.json`;
const PROPOSALS = `${PROJECT_NAME}_Proposals.json`;
export const FIRST_SOURCES = ['Content_Inventory.xlsx', 'Fabrikam_Kickoff_Deck.pptx', 'Fabrikam_RFP_2027.pdf', 'Legacy_Brief.doc', 'Signed_NDA_scan.pdf', 'Workshop_Notes.docx'];
const ADDENDUM = ADDENDUM_FILE;
const README_MARKER = '# Agent run sample';
/** What a published sample shows in place of the temporary folder the run happened in. */
const PROJECT_FOLDER_PLACEHOLDER = '<project-folder>';

function tool(name, args, options = {}) {
  const result = spawnSync(process.execPath, [join(root, 'tools', 'blueprint', `${name}.mjs`), ...args], { cwd: root, encoding: 'utf8' });
  if (result.status !== (options.expectStatus ?? 0)) {
    throw new Error(`${name} ${args.join(' ')}\nexit ${result.status}\n${result.stdout}\n${result.stderr}`);
  }
  return result;
}

function readJson(file) {
  return JSON.parse(readFileSync(file, 'utf8'));
}

function writeJson(file, value) {
  writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);
}

/** The review screen's saves, as the estimator made them between the runs. */
function applyReview(blueprintPath) {
  const review = readJson(join(inputs, 'review.json'));
  const working = readJson(blueprintPath);
  const stamp = (status) => ({ status, by: review.reviewer.email, byName: review.reviewer.displayName, at: review.at });
  for (const decision of review.decisions) {
    const row = working.requirements.find((r) => r.id === decision.id);
    if (!row) {
      throw new Error(`review.json names ${decision.id}, which the first run did not produce`);
    }
    if (decision.status === 'edited') {
      row.original = row.original || { statement: row.statement, workPackage: row.workPackage, coverage: row.coverage };
      row.statement = decision.statement;
      row.workPackage = decision.workPackage;
      row.coverage = decision.coverage;
    }
    row.review = stamp(decision.status);
  }
  writeJson(blueprintPath, working);
  return working;
}

/**
 * @param {string} work a folder to run in (it is filled with the sources)
 * @returns {{ work: string, firstRun: object, reviewed: object, afterRerun: object, proposals: object, record: object }}
 */
export function replayAgentRun(work) {
  mkdirSync(work, { recursive: true });
  cpSync(join(root, 'samples/sources/synthetic-aem'), work, { recursive: true });
  rmSync(join(work, '.blueprint'), { recursive: true, force: true });
  const blueprintPath = join(work, BLUEPRINT);
  const contextPath = join(work, CONTEXT);
  const proposalsPath = join(work, PROPOSALS);
  const estimating = join(root, 'docs/catalogs/estimating-catalog.md');

  // 1 and 2: prepare and parse.
  tool('prepare-folder', [work, '--project', PROJECT_NAME, '--select', ...FIRST_SOURCES]);
  tool('parse-local', [work, '--quiet']);

  // 3: first run.
  tool('assemble-working-file', [
    '--extract', join(inputs, 'extract-first.json'),
    '--blocks', join(work, '.blueprint/parsed/blocks.json'),
    '--sources', join(work, '.blueprint/parsed/sources.json'),
    '--estimating', estimating,
    '--project-id', 'sample-fabrikam-outdoor',
    '--project-name', PROJECT_NAME,
    '--out', blueprintPath,
    '--run-id', 'run-first'
  ]);
  const firstRun = readJson(blueprintPath);

  // 4: enrich. The sidecar is the committed text; the matcher must still agree with the Blueprint.
  tool('match-library', [blueprintPath]);
  cpSync(join(inputs, 'context-first.json'), contextPath);
  tool('run-record', [work, '--stage', 'enrich', '--note', 'context sidecar written']);
  tool('validate-context', [contextPath, '--blueprint', blueprintPath]);
  tool('validate-working-file', [blueprintPath]);
  tool('run-record', [work, '--stage', 'done']);

  // 5: the estimator reviews in the app.
  const reviewed = applyReview(blueprintPath);
  const reviewedText = readFileSync(blueprintPath, 'utf8');

  // 6: the addendum arrives and the folder is prepared again with it selected.
  cpSync(join(root, 'samples/sources/synthetic-aem-addendum', ADDENDUM), join(work, ADDENDUM));
  tool('prepare-folder', [work, '--project', PROJECT_NAME, '--select', ...FIRST_SOURCES, ADDENDUM]);
  tool('parse-local', [work, '--quiet']);

  // A first-run assemble must now refuse.
  tool('assemble-working-file', [
    '--extract', join(inputs, 'extract-rerun.json'),
    '--blocks', join(work, '.blueprint/parsed/blocks.json'),
    '--estimating', estimating,
    '--project-id', 'sample-fabrikam-outdoor',
    '--project-name', PROJECT_NAME,
    '--out', blueprintPath
  ], { expectStatus: 3 });

  // 7: proposals.
  tool('assemble-working-file', [
    '--mode', 'proposals',
    '--existing', blueprintPath,
    '--extract', join(inputs, 'extract-rerun.json'),
    '--blocks', join(work, '.blueprint/parsed/blocks.json'),
    '--sources', join(work, '.blueprint/parsed/sources.json'),
    '--estimating', estimating,
    '--out', proposalsPath,
    '--run-id', 'run-second'
  ]);
  if (readFileSync(blueprintPath, 'utf8') !== reviewedText) {
    throw new Error('the proposals run changed the Blueprint');
  }

  // 8: validate everything.
  tool('validate-working-file', [blueprintPath]);
  tool('validate-context', [contextPath, '--blueprint', blueprintPath]);
  tool('validate-proposals', [proposalsPath, '--blueprint', blueprintPath, '--strict']);
  tool('run-record', [work, '--stage', 'validate']);
  tool('run-record', [work, '--stage', 'done']);

  return {
    work,
    firstRun,
    reviewed,
    afterRerun: readJson(blueprintPath),
    proposals: readJson(proposalsPath),
    record: readJson(join(work, '.blueprint/run.json'))
  };
}

function plural(count, noun, many = `${noun}s`) {
  return `${count} ${count === 1 ? noun : many}`;
}

/** The README text, with every count taken from the run so it cannot go stale when the inputs change. */
function describeSample(result) {
  const rows = result.afterRerun.requirements;
  const byStatus = (status) => rows.filter((row) => row.review.status === status).length;
  const conflicts = rows.filter((row) => row.coverage === 'conflict').map((row) => row.id);
  const proposals = result.proposals.proposals;
  const kinds = ['update', 'conflict', 'add']
    .map((kind) => ({ kind, list: proposals.filter((p) => p.kind === kind) }))
    .filter((entry) => entry.list.length > 0)
    .map((entry) => `${plural(entry.list.length, entry.kind)}${entry.kind === 'add' ? '' : ` (${entry.list.map((p) => p.requirementId).join(', ')})`}`);
  const context = readJson(join(inputs, 'context-first.json'));
  const list = (value) => (Array.isArray(value) ? value.length : 0);
  return [
    README_MARKER,
    '',
    'This folder is generated. Edit the inputs under `tools/samples/agent-run/` and run `node tools/samples/agent-run-sample.mjs`.',
    '',
    `A full run of the skill pack tools on \`samples/sources/synthetic-aem/\` for the project **${PROJECT_NAME}**, then a review, then a`,
    `re-run after \`samples/sources/synthetic-aem-addendum/${ADDENDUM}\` arrived. The extract JSON and the Context sidecar are`,
    'the model\'s part, written by hand against the parsed blocks (`tools/samples/agent-run/`); the tools did the rest.',
    '',
    '| File | What it shows |',
    '| --- | --- |',
    `| \`${BLUEPRINT}\` | The first run after review: ${plural(rows.length, 'requirement')}, of which ${byStatus('accepted')} accepted, ${byStatus('edited')} edited, ${byStatus('dismissed')} dismissed; ${conflicts.length === 1 ? `one planted conflict (${conflicts[0]})` : `${plural(conflicts.length, 'conflict')} (${conflicts.join(', ')})`} with two citations and no winner. Untouched by the re-run. |`,
    `| \`${CONTEXT}\` | The v2 sidecar the enrich stage wrote: ${plural(list(context.deliveryUnknowns), 'delivery unknown')}, ${plural(list(context.assumptions), 'assumption')}, ${plural(list(context.dependencies), 'dependency', 'dependencies')}, ${plural(list(context.deliveryRisks), 'delivery risk')}. |`,
    `| \`${PROPOSALS}\` | What the re-run proposed instead of rewriting the Blueprint: ${plural(proposals.length, 'proposal')} (${kinds.join(', ')}). A restated requirement that changed nothing produced nothing. |`,
    '| `AGENTS.md`, `CLAUDE.md` | The bootstrap `prepare-folder` wrote (SAPP-016). |',
    '| `.blueprint/run.json` | The run record (SAPP-014). |',
    '| `.blueprint/sources.json`, `.blueprint/expect.json` | The selection and the versions the app expects. |',
    '| `.blueprint/parsed/` | The parse tool\'s manifest, blocks and sources for the second parse (with the addendum). |',
    '',
    'The source documents themselves stay under `samples/sources/`; copy them beside these files to reproduce the folder the agent saw.',
    ''
  ].join('\n');
}

/** Every file under a folder, as paths relative to it. */
function listFiles(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const file = join(dir, entry);
    if (statSync(file).isDirectory()) {
      out.push(...listFiles(file));
    } else {
      out.push(file);
    }
  }
  return out;
}

/** The folder text with the temporary run folder replaced by a placeholder, in every spelling JSON can hold. */
export function scrubFolderPaths(text, work) {
  const spellings = [work, work.replace(/\\/g, '/'), work.replace(/\\/g, '\\\\')];
  let out = text;
  for (const spelling of new Set(spellings)) {
    out = out.split(spelling).join(PROJECT_FOLDER_PLACEHOLDER);
  }
  return out;
}

const LOCAL_PATH = /(^|[^A-Za-z0-9])[A-Za-z]:(\\\\|\\|\/)|\/(Users|home)\/[^/\s"']+\//;

/** The first absolute local path found in a text, or undefined. */
export function findLocalPath(text) {
  const hits = [LOCAL_PATH.exec(text)];
  for (const dir of new Set([tmpdir(), homedir()])) {
    hits.push(text.includes(dir) ? [dir] : null);
  }
  const hit = hits.find(Boolean);
  return hit ? hit[0].trim() : undefined;
}

/**
 * Refuses a target that is not a place this script owns: the repository or one of its parents, a
 * filesystem root, the home folder, or a non-empty folder that did not come from a previous publish.
 */
export function assertSafeTarget(outDir) {
  const target = resolve(outDir);
  if (dirname(target) === target) {
    throw new Error(`refusing to publish into a filesystem root: ${target}`);
  }
  for (const guarded of [root, homedir()]) {
    const inside = relative(target, guarded);
    if (inside === '' || (!inside.startsWith('..') && !isAbsolute(inside))) {
      throw new Error(`refusing to publish into ${target}, which is or contains ${guarded}`);
    }
  }
  if (existsSync(target)) {
    if (!statSync(target).isDirectory()) {
      throw new Error(`${target} exists and is not a folder`);
    }
    const marker = join(target, 'README.md');
    const generated = existsSync(marker) && readFileSync(marker, 'utf8').startsWith(README_MARKER);
    if (readdirSync(target).length > 0 && !generated) {
      throw new Error(`refusing to replace ${target}: it is not empty and was not written by this script`);
    }
  }
  return target;
}

/**
 * Copies the run's outputs (not the source documents) into the sample folder. The files are staged next to
 * the target and swapped in at the end, so a failed copy leaves the committed sample as it was. Any path
 * of the temporary run folder is replaced with a placeholder, and the publish fails if any absolute local
 * path is left.
 * @param {string} work the folder the run happened in
 * @param {string} outDir where the sample goes
 * @param {{ afterRerun: object, proposals: object }} result what replayAgentRun returned (for the README counts)
 */
export function publishSample(work, outDir, result) {
  const target = assertSafeTarget(outDir);
  mkdirSync(dirname(target), { recursive: true });
  const staging = mkdtempSync(join(dirname(target), '.agent-run-publish-'));
  try {
    mkdirSync(join(staging, '.blueprint', 'parsed'), { recursive: true });
    for (const name of [BLUEPRINT, CONTEXT, PROPOSALS, 'AGENTS.md', 'CLAUDE.md']) {
      cpSync(join(work, name), join(staging, name));
    }
    for (const name of ['run.json', 'sources.json', 'expect.json']) {
      cpSync(join(work, '.blueprint', name), join(staging, '.blueprint', name));
    }
    for (const name of ['manifest.json', 'blocks.json', 'sources.json']) {
      cpSync(join(work, '.blueprint', 'parsed', name), join(staging, '.blueprint', 'parsed', name));
    }
    writeFileSync(join(staging, 'README.md'), describeSample(result));

    for (const file of listFiles(staging)) {
      const original = readFileSync(file, 'utf8');
      const scrubbed = scrubFolderPaths(original, work);
      if (scrubbed !== original) {
        writeFileSync(file, scrubbed);
      }
      const leftover = findLocalPath(scrubbed);
      if (leftover) {
        throw new Error(`${relative(staging, file)} still names a local path (${leftover}); a sample must not carry one`);
      }
    }

    const backup = `${staging}.old`;
    if (existsSync(target)) {
      renameSync(target, backup);
    }
    try {
      renameSync(staging, target);
    } catch (error) {
      if (existsSync(backup)) {
        renameSync(backup, target);
      }
      throw error;
    }
    rmSync(backup, { recursive: true, force: true });
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const work = mkdtempSync(join(tmpdir(), 'agent-run-'));
  try {
    const outDir = assertSafeTarget(process.argv[2] ? resolve(process.argv[2]) : SAMPLE_DIR);
    const result = replayAgentRun(work);
    publishSample(work, outDir, result);
    console.log(`wrote ${outDir}`);
    console.log(`first run: ${result.firstRun.requirements.length} requirements; proposals: ${result.proposals.proposals.length}; stage ${result.record.stage}`);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  } finally {
    rmSync(work, { recursive: true, force: true });
  }
}
