/**
 * The no-overwrite contract check (SAPP-017): a full replay of the agent run with the real tools, a
 * review in between, and the assertion that the re-run changed no reviewed row and wrote proposals.
 * Also what keeps the committed sample honest: no local path in it, and the tools (not the fixtures)
 * refuse commercial fields and a first-run overwrite.
 */
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { after, before, describe, it } from 'node:test';
import { fileURLToPath } from 'node:url';
import { assembleWorkingFile } from '../blueprint/assemble-working-file.mjs';
import { validateContextValue } from '../blueprint/validate-context.mjs';
import { validateWorkingFileValue } from '../blueprint/validate-working-file.mjs';
import { buildSkillPack } from '../release/build-skill-pack.mjs';
import { assertSafeTarget, FIRST_SOURCES, findLocalPath, publishSample, replayAgentRun, SAMPLE_DIR, scrubFolderPaths } from './agent-run-sample.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '../..');
const inputs = join(here, 'agent-run');
const work = mkdtempSync(join(tmpdir(), 'agent-run-test-'));
const scratch = mkdtempSync(join(tmpdir(), 'agent-run-scratch-'));
let run;

function readJson(...parts) {
  return JSON.parse(readFileSync(join(...parts), 'utf8'));
}

const TEXT_FILE = /\.(json|md|txt|csv|mjs|yml|yaml)$/i;

function textFiles(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const file = join(dir, entry);
    if (statSync(file).isDirectory()) {
      out.push(...textFiles(file));
    } else if (TEXT_FILE.test(entry)) {
      out.push(file);
    }
  }
  return out;
}

before(() => {
  run = replayAgentRun(work);
});

after(() => {
  rmSync(work, { recursive: true, force: true });
  rmSync(scratch, { recursive: true, force: true });
});

describe('agent run contract', () => {
  it('the first run writes every requirement pending with sources and a planted conflict', () => {
    const extract = readJson(inputs, 'extract-first.json');
    assert.equal(run.firstRun.requirements.length, extract.requirements.length, 'every extracted requirement survived assembly');
    assert.ok(run.firstRun.requirements.every((r) => r.review.status === 'pending'));
    assert.equal(run.firstRun.revision, 0);
    assert.equal(run.firstRun.sources.length, FIRST_SOURCES.length, 'one source per selected file, including the two that cannot be read');
    assert.equal(run.firstRun.platform.id, extract.platform.id);
    const conflict = run.firstRun.requirements.find((r) => r.coverage === 'conflict');
    assert.equal(conflict.sources.length, 2);
  });

  it('the re-run changes no requirement the estimator decided on, nor any other', () => {
    assert.deepEqual(run.afterRerun.requirements, run.reviewed.requirements);
    assert.deepEqual(run.afterRerun.questions, run.reviewed.questions);
    assert.deepEqual(run.afterRerun.sources, run.reviewed.sources);
    assert.equal(run.afterRerun.revision, run.reviewed.revision);
    const review = readJson(inputs, 'review.json');
    const decided = run.afterRerun.requirements.filter((r) => r.review.status !== 'pending');
    assert.equal(decided.length, review.decisions.length);
    assert.deepEqual(decided.map((r) => r.id).sort(), review.decisions.map((d) => d.id).sort());
  });

  it('a first-run assemble over the reviewed Blueprint is refused and leaves it byte for byte', () => {
    const blueprint = join(work, 'Fabrikam Outdoor_Blueprint.json');
    const before = readFileSync(blueprint);
    const result = assemble(blueprint);
    assert.equal(result.status, 3, result.stderr);
    assert.ok(readFileSync(blueprint).equals(before));
  });

  it('a first-run assemble over a Blueprint it cannot read is refused too, not treated as empty', () => {
    const damaged = join(scratch, 'Damaged_Blueprint.json');
    const text = readFileSync(join(work, 'Fabrikam Outdoor_Blueprint.json'), 'utf8');
    writeFileSync(damaged, text.slice(0, Math.floor(text.length / 2)));
    const before = readFileSync(damaged);
    const result = assemble(damaged);
    assert.equal(result.status, 3, result.stderr);
    assert.ok(readFileSync(damaged).equals(before));
  });

  it('the re-run writes proposals for what changed and nothing for what did not', () => {
    const kinds = run.proposals.proposals.map((p) => [p.kind, p.requirementId]);
    assert.deepEqual(kinds, [
      ['update', 'R-003'],
      ['conflict', 'R-009'],
      ['add', undefined]
    ]);
    const update = run.proposals.proposals[0];
    assert.equal(update.existing.reviewStatus, 'accepted');
    assert.match(update.statement, /5,900 pages/);
    const conflict = run.proposals.proposals[1];
    assert.equal(conflict.coverage, 'conflict');
    assert.match(conflict.question, /two days.*four/);
    assert.equal(conflict.existing.statement, 'Editors receive two days of role-based training before go-live.');
    assert.ok(run.proposals.proposals.every((p) => p.review.status === 'pending'));
    assert.ok(run.proposals.proposals.every((p) => p.sources.every((s) => s.itemId === 'src-fabrikam-addendum')));
    assert.deepEqual(run.proposals.sources.map((s) => s.itemId), ['src-fabrikam-addendum']);
    assert.equal(run.proposals.blueprintRevision, run.reviewed.revision);
  });

  it('every citation in the proposals is a block the parse tool produced', () => {
    const blocks = readJson(work, '.blueprint/parsed/blocks.json');
    const ids = new Set(blocks.map((b) => b.id));
    for (const proposal of run.proposals.proposals) {
      for (const source of proposal.sources) {
        assert.ok(ids.has(source.blockId), `${proposal.id} cites ${source.blockId}`);
        const block = blocks.find((b) => b.id === source.blockId);
        assert.equal(source.label, block.label);
        assert.equal(source.passage, block.text);
      }
    }
    for (const row of run.afterRerun.requirements) {
      for (const source of row.sources) {
        assert.ok(ids.has(source.blockId), `${row.id} cites ${source.blockId}`);
      }
    }
  });

  it('the run record ends at done in proposals mode and names what was written', () => {
    assert.equal(run.record.stage, 'done');
    assert.equal(run.record.mode, 'proposals');
    assert.equal(run.record.files.blueprint.requirements, run.afterRerun.requirements.length);
    assert.equal(run.record.files.proposals.proposals, run.proposals.proposals.length);
    assert.equal(run.record.parseTool.name, 'parse-local');
    assert.ok(run.record.stages.prepared && run.record.stages.parse && run.record.stages.extract && run.record.stages.enrich && run.record.stages.validate);
    assert.equal(run.record.pack.version, readJson(root, 'tools', 'release', 'pack.config.json').version);
  });
});

/** A first-run assemble with the re-run's extract: what an agent that ignored the mode would try. */
function assemble(out) {
  return spawnSync(process.execPath, [
    join(root, 'tools', 'blueprint', 'assemble-working-file.mjs'),
    '--extract', join(inputs, 'extract-rerun.json'),
    '--blocks', join(work, '.blueprint/parsed/blocks.json'),
    '--estimating', join(root, 'docs/catalogs/estimating-catalog.md'),
    '--project-id', 'sample-fabrikam-outdoor',
    '--project-name', 'Fabrikam Outdoor',
    '--out', out
  ], { cwd: root, encoding: 'utf8' });
}

describe('guardrails are enforced by the tools, not only present in the fixtures', () => {
  const banned = ['accountHistory', 'newLogo', 'commercialRisks', 'workEnvironment', 'clientDifficulty', 'difficultyMultipliers', 'staffingProfiles'];

  it('the assembler carries nothing but the fields it knows from model output', () => {
    const extract = readJson(inputs, 'extract-first.json');
    const polluted = {
      ...extract,
      accountHistory: { wins: 3 },
      requirements: extract.requirements.map((r) => ({ ...r, hours: 400, quantity: 12, rate: 150, price: 9000, commercialRisks: ['x'] }))
    };
    const blocks = readJson(work, '.blueprint/parsed/blocks.json');
    const { working } = assembleWorkingFile({
      extract: polluted,
      blocks,
      catalogMd: readFileSync(join(root, 'docs/catalogs/estimating-catalog.md'), 'utf8'),
      meta: { projectId: 'p', projectName: 'Fabrikam Outdoor', runId: 'r', sources: readJson(work, '.blueprint/parsed/sources.json') }
    });
    const text = JSON.stringify(working);
    for (const key of [...banned, 'hours', 'quantity', 'rate', 'price']) {
      assert.ok(!text.includes(`"${key}"`), `${key} reached the Blueprint`);
    }
    assert.equal(working.estimate ?? null, null);
    assert.deepEqual(validateWorkingFileValue(working), []);
  });

  it('the Context validator rejects every commercial field', () => {
    const context = readJson(inputs, 'context-first.json');
    assert.deepEqual(validateContextValue(context), []);
    for (const key of banned) {
      const errors = validateContextValue({ ...context, [key]: {} });
      assert.ok(errors.some((e) => e.includes(key)), `${key} should be rejected, got ${JSON.stringify(errors)}`);
    }
  });

  it('the run wrote no estimate and no driver quantity', () => {
    assert.equal(run.afterRerun.estimate ?? null, null);
    const sidecar = JSON.stringify(readJson(work, 'Fabrikam Outdoor_Context.json'));
    assert.ok(!sidecar.includes('"hours"') && !sidecar.includes('"quantity"'));
  });
});

describe('the committed sample', () => {
  it('matches a fresh replay apart from timestamps', () => {
    const strip = (value) => JSON.parse(JSON.stringify(value).replace(/\d{4}-\d\d-\d\dT[\d:.]+Z/g, 'T'));
    const committed = readJson(SAMPLE_DIR, 'Fabrikam Outdoor_Proposals.json');
    assert.deepEqual(strip(run.proposals), strip(committed), 'regenerate with node tools/samples/agent-run-sample.mjs');
    const committedBlueprint = readJson(SAMPLE_DIR, 'Fabrikam Outdoor_Blueprint.json');
    assert.deepEqual(strip(run.afterRerun), strip(committedBlueprint));
  });

  it('names no absolute local path in any file', () => {
    for (const file of textFiles(SAMPLE_DIR)) {
      const found = findLocalPath(readFileSync(file, 'utf8'));
      assert.equal(found, undefined, `${file.slice(root.length + 1)} names ${found}; regenerate with node tools/samples/agent-run-sample.mjs`);
    }
  });

  it('is not carried into a built pack with a local path either', () => {
    const built = buildSkillPack({ out: join(scratch, 'pack'), zip: false, allowDirty: true, allowDrift: true });
    // Only the samples: the install guide and docs name example locations such as C:/Tools on purpose.
    const files = textFiles(join(built.dir, 'samples'));
    assert.ok(files.length > 20, `scanned ${files.length} files`);
    for (const file of files) {
      const found = findLocalPath(readFileSync(file, 'utf8'));
      assert.equal(found, undefined, `${file.slice(built.dir.length + 1)} in the built pack names ${found}`);
    }
  });
});

describe('publishing the sample', () => {
  it('replaces the temporary run folder with a placeholder in every spelling', () => {
    const folder = 'C:\\Users\\someone\\AppData\\Local\\Temp\\agent-run-abc';
    const text = JSON.stringify({ a: folder, b: folder.replace(/\\/g, '/'), c: `${folder}\\x.docx` });
    const scrubbed = scrubFolderPaths(text, folder);
    assert.ok(!scrubbed.includes('someone'), scrubbed);
    assert.equal(findLocalPath(scrubbed), undefined);
    assert.equal(findLocalPath('see C:\\Users\\someone\\x'), 'C:\\');
    assert.equal(findLocalPath('see https://example.com/page'), undefined);
  });

  it('refuses a target that is not the script\'s to replace', () => {
    assert.throws(() => assertSafeTarget(root), /is or contains/);
    assert.throws(() => assertSafeTarget(dirname(root)), /is or contains/);
    assert.throws(() => assertSafeTarget(resolve('/')), /filesystem root/);
    const stranger = join(scratch, 'stranger');
    rmSync(stranger, { recursive: true, force: true });
    publishInto(stranger, 'keep.txt');
    assert.throws(() => assertSafeTarget(stranger), /not empty and was not written by this script/);
  });

  it('leaves the previous sample alone when the copy fails', () => {
    const target = join(scratch, 'published');
    publishSample(work, target, run);
    const before = readFileSync(join(target, 'Fabrikam Outdoor_Proposals.json'), 'utf8');
    assert.throws(() => publishSample(join(scratch, 'no-such-run'), target, run));
    assert.equal(readFileSync(join(target, 'Fabrikam Outdoor_Proposals.json'), 'utf8'), before);
    assert.deepEqual(readdirSync(scratch).filter((name) => name.startsWith('.agent-run-publish-')), []);
  });

  it('writes a README whose counts come from the run, and replays to the same files twice', () => {
    const target = join(scratch, 'published-twice');
    publishSample(work, target, run);
    publishSample(work, target, run);
    const readme = readFileSync(join(target, 'README.md'), 'utf8');
    assert.match(readme, new RegExp(`${run.afterRerun.requirements.length} requirements`));
    assert.match(readme, new RegExp(`${run.proposals.proposals.length} proposals`));
    assert.ok(existsSync(join(target, '.blueprint', 'parsed', 'manifest.json')));
  });
});

function publishInto(dir, name) {
  rmSync(dir, { recursive: true, force: true });
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, name), 'x');
}
