import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { readCatalogDocs, runCli } from './catalog/cli.mjs';
import { readJsonFile } from './catalog/generate.mjs';
import { suggest } from './catalog/suggest.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));

runCli(() => {
  parseArgs({ options: {}, strict: true, allowPositionals: false });
  const { text } = suggest({
    ...readCatalogDocs(root),
    keywords: readJsonFile(join(root, 'tools', 'catalog-suggest-keywords.json'))
  });
  process.stdout.write(text);
});
