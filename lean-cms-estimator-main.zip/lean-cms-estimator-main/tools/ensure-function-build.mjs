// Make sure function/dist is built and not older than function/src, because the Node tool tests and the
// skill pack build import the function's readers from there. Run as the `pretest:tools` npm hook.
// Installs the function's dependencies first when they are missing. No network call when both exist.
import { execSync } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const functionDir = join(root, 'function');
const marker = join(functionDir, 'dist', 'src', 'localParse.js');

function newestSource(dir) {
  let newest = 0;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    newest = Math.max(newest, entry.isDirectory() ? newestSource(path) : statSync(path).mtimeMs);
  }
  return newest;
}

function run(command) {
  console.log(`> ${command}`);
  execSync(command, { cwd: root, stdio: 'inherit' });
}

const stale = !existsSync(marker) || newestSource(join(functionDir, 'src')) > statSync(marker).mtimeMs;
if (stale) {
  if (!existsSync(join(functionDir, 'node_modules'))) {
    run('npm --prefix function ci');
  }
  run('npm --prefix function run build');
}
