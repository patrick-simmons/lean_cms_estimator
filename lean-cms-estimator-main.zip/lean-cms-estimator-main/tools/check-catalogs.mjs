import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { checkCatalogs, countReferences } from './catalog/check.mjs';
import { readCatalogDocs, runCli } from './catalog/cli.mjs';
import { loadToolkitPin, readJsonFile } from './catalog/generate.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));

runCli(() => {
  parseArgs({ options: {}, strict: true, allowPositionals: false });
  const cmkPin = readJsonFile(join(root, 'tools', 'cmk-catalog.pin.json'));
  const toolkitPin = loadToolkitPin(root);
  const { cmk, toolkit, estimating } = readCatalogDocs(root);
  const errors = checkCatalogs({ cmk, toolkit, estimating, cmkPin, toolkitPin });
  if (errors.length > 0) {
    errors.forEach((error) => console.error(error));
    process.exitCode = 1;
    return;
  }
  console.log(`ok: ${estimating.activities.length} activities, ${countReferences(estimating)} capability references checked against CMK ${cmk.frontMatter.cmkCommitShort} · toolkit ${toolkit.frontMatter.toolkitCommitShort} · catalog v${estimating.frontMatter.version}`);
});
