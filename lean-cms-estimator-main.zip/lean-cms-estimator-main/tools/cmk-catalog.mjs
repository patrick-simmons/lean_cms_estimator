import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { runCli, writeCatalog } from './catalog/cli.mjs';
import { generateCmkCatalog, loadInputs } from './catalog/generate.mjs';
import { CMK_TREE_OPTIONS, openPinnedTree } from './catalog/git-tree.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));

runCli(() => {
  const { values } = parseArgs({
    options: { cmk: { type: 'string' }, out: { type: 'string' } },
    strict: true,
    allowPositionals: false
  });
  const { pin, summaries } = loadInputs(root);
  const cmkPath = values.cmk ? resolve(values.cmk) : resolve(root, pin.localPath);
  const output = values.out ? resolve(values.out) : join(root, 'docs', 'catalogs', 'cmk-capability-catalog.md');
  const { text } = generateCmkCatalog(openPinnedTree(cmkPath, pin.commit, undefined, CMK_TREE_OPTIONS), pin, summaries);
  writeCatalog(output, text);
});
