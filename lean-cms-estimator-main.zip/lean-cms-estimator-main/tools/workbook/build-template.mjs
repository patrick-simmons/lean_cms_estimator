// Builds samples/workbook/Estimate_Template.xlsx, the template build-workbook.mjs fills (stage 5).
//
// The template owns everything that is not a data row: the header text, the formulas, the formats, the
// timeline's phase shape and the named cells on Coverage. The tool owns the rows from row 2 down on the data
// sheets and the named cells. Edit this file (or the .xlsx in Excel, then keep the rules in
// docs/spfx/workbook-template.md) and run: node tools/workbook/build-template.mjs
import ExcelJS from 'exceljs';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadSeed } from '../factors/seed.mjs';
import { DEFAULT_CATALOG, parseActivities } from '../blueprint/rank-questions.mjs';
import { lanesOf, NAMED_CELLS, OVERHEAD_PHASE, phasesOf, SHEET_COLUMNS } from '../blueprint/workbook-rows.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '../..');
export const TEMPLATE_PATH = join(root, 'samples/workbook/Estimate_Template.xlsx');

/** Sheet order in the workbook; Coverage and Notes are the template's own sheets. */
export const SHEET_ORDER = ['Coverage', 'Workstreams', 'Skills', 'AI plan', 'Assumptions and risks', 'Timeline', 'Requirements', 'Questions', 'Sources', 'Notes'];

/** Widths taken from a workbook sized by hand, so a column fits what the tool actually writes. */
const WIDTHS = {
  Sources: [35.22, 38.89, 15.78, 70.33],
  Requirements: [12, 72.22, 40.78, 27.78, 47.22, 19.44, 18.55, 18.55, 34.22, 15.78, 47.22, 35.22, 57.44],
  Questions: [10.22, 32.44, 15.78, 16.66, 74.11, 17.55, 42.55, 81.44],
  Workstreams: [32.44, 37, 16.66, 17.55, 28.66, 14.78, 18.55, 15.78, 16.66, 21.33, 49.11, 18.55, 21.33, 22.22, 18.55, 18.55, 21.33, 23.11, 21.33, 24.11, 21.33, 16.66, 18.55, 55.55, 18.55, 68.55],
  'AI plan': [18.55, 61.11, 23.11, 27.78, 16.66, 63, 33.33, 46.33, 90.78],
  Skills: [27.78, 40.78, 18.55, 25, 25, 23.11, 77.78],
  'Assumptions and risks': [14.78, 18.55, 75.89, 35.22, 52.78, 85.22],
  Timeline: [17.55, 28.66, 57.44, 12, 18.55, 16.66, 16.66, 64.78, 25, 25]
};
const WRAP = { Requirements: [2, 3, 13], Questions: [5, 8], Workstreams: [11, 24, 26], 'AI plan': [9], 'Assumptions and risks': [3, 5, 6], Sources: [4] };
const HOURS = { Workstreams: [17, 18, 19, 20, 21], Skills: [4, 5, 6], Timeline: [9, 10] };
const COUNTS = { Workstreams: [9], Questions: [1], Timeline: [4, 6, 7] };
const PERCENTS = { Workstreams: [22] };

const FONT = 'Aptos';
const INK = 'FF243746';
/** The id column and the row labels: present, but not what the reader is here for. */
const MUTED = 'FF516879';
const PAPER = 'FFFFFFFF';
const NAVY = 'FF17324D';
/** The volume group on Workstreams: where the figure came from, which is read as a block. */
const NAVY_MID = 'FF355A74';
/** The AI and saving totals, the one group a reader looks for on three different sheets. */
const TEAL = 'FF007F82';
const TEAL_INK = 'FF00696D';
const BAND = 'FFF3F6F9';
const WASH = { teal: 'FFEAF4F4', grey: 'FFE8EDF2', amber: 'FFFFF3D6' };
const NAME_FILL = 'FFFFF2B3';
const NAME_INK = 'FF674C00';

/**
 * Zero reads as an em dash rather than as 0.00. An activity at zero hours is work that left the
 * estimate, and a column of 0.00s hides the few rows that carry the number.
 */
const HOURS_FMT = '#,##0.00;[Red](#,##0.00);"—"';
const COUNT_FMT = '#,##0';
const WHOLE_FMT = '0';

/** The header fills that are not the default navy, by column number. */
const ACCENTS = {
  Workstreams: { 9: NAVY_MID, 10: NAVY_MID, 11: NAVY_MID, 12: NAVY_MID, 20: TEAL, 21: TEAL, 22: TEAL },
  Skills: { 5: TEAL, 6: TEAL },
  Timeline: { 10: TEAL }
};

/**
 * Cells that colour themselves from their own value. These carry the reading of the estimate a
 * reader would otherwise have to do by eye: which volumes are assumed, which tools are off, which
 * rows are risks. They are conditional formats rather than fills the tool writes, so they keep
 * working on a workbook somebody has sorted, filtered or pasted rows into.
 */
const TONES = {
  good: { bg: 'FFE5F3ED', ink: 'FF21634B' },
  warn: { bg: 'FFFFF3D6', ink: 'FF805B12' },
  bad: { bg: 'FFFCE9E7', ink: 'FF9D342B' },
  ai: { bg: 'FFE0F2EF', ink: TEAL_INK },
  idle: { bg: 'FFE8EDF2', ink: MUTED }
};

const STATUS_RULES = {
  Sources: [['C', 'read', 'good'], ['C', 'not read', 'bad']],
  Requirements: [
    ['F', 'accelerated', 'ai'], ['F', 'conflict', 'bad'], ['F', 'partly', 'warn'], ['F', 'question', 'warn'],
    ['G', 'accepted', 'good']
  ],
  Questions: [['C', 'high', 'bad'], ['C', 'medium', 'warn']],
  Workstreams: [['J', 'placeholder', 'warn'], ['J', 'document', 'good'], ['L', 'low', 'warn']],
  'AI plan': [['E', 'on', 'good'], ['E', 'off', 'bad'], ['E', 'needed', 'warn'], ['E', 'unused', 'idle']],
  'Assumptions and risks': [['B', 'Risk', 'bad'], ['B', 'Assumption', 'warn']]
};

const solid = (argb) => ({ type: 'pattern', pattern: 'solid', fgColor: { argb } });
/** A conditional-format fill, which Excel stores on `bgColor` rather than `fgColor`. */
const dxfFill = (argb) => ({ type: 'pattern', pattern: 'solid', bgColor: { argb } });

/**
 * The column letter a Workstreams header sits in. The formulas below read columns of that sheet, and
 * writing the letters by hand means every new column silently points the formulas at the wrong data.
 */
function ws(header) {
  const index = SHEET_COLUMNS.Workstreams.indexOf(header);
  if (index === -1) {
    throw new Error(`Workstreams has no "${header}" column; the formula below reads it`);
  }
  let letters = '';
  for (let n = index; n >= 0; n = Math.floor(n / 26) - 1) {
    letters = String.fromCharCode(65 + (n % 26)) + letters;
  }
  return letters;
}

/** A Workstreams column as a formula range over the data rows, header row excluded. */
const wsRange = (header) => `Workstreams!${ws(header)}$2:${ws(header)}$1048576`;
/** The hrs/unit pair. Columns 10 and 11 carried this format before, which was the volume's basis
 * and source: text, and two columns to the left of the rates they were named for. */
const RATES = { Workstreams: [13, 14] };

/** The last column letter of a sheet, for a conditional format that covers the whole row. */
function lastColumn(count) {
  let letters = '';
  for (let n = count - 1; n >= 0; n = Math.floor(n / 26) - 1) {
    letters = String.fromCharCode(65 + (n % 26)) + letters;
  }
  return letters;
}

function dataSheet(wb, name, headers) {
  const ws = wb.addWorksheet(name, { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.addRow(headers);

  // Column styles first: ExcelJS applies them to the cells that exist as well as the ones the
  // estimate tool adds later, so the header row is styled after this or it would be overwritten.
  (WIDTHS[name] || []).forEach((width, index) => { ws.getColumn(index + 1).width = width; });
  for (let index = 1; index <= headers.length; index += 1) {
    const column = ws.getColumn(index);
    column.font = { name: FONT, size: 11, color: { argb: INK } };
    column.alignment = { wrapText: true };
  }
  for (const index of WRAP[name] || []) {
    ws.getColumn(index).alignment = { vertical: 'top', wrapText: true };
  }
  for (const index of [...(HOURS[name] || []), ...(RATES[name] || [])]) {
    ws.getColumn(index).numFmt = HOURS_FMT;
  }
  for (const index of COUNTS[name] || []) {
    ws.getColumn(index).numFmt = index === 9 ? COUNT_FMT : WHOLE_FMT;
  }
  for (const index of PERCENTS[name] || []) {
    // A share the tool writes as 28.2 rather than 0.282, so the suffix is text, not a percent format.
    ws.getColumn(index).numFmt = '0.0"%"';
  }
  // The id is how a reader finds the row again after sorting; everything else is the content.
  ws.getColumn(1).font = { name: FONT, size: 11, bold: true, color: { argb: MUTED } };

  const header = ws.getRow(1);
  header.height = 43.95;
  header.eachCell({ includeEmpty: true }, (cell, index) => {
    cell.font = { name: FONT, size: 11, bold: true, color: { argb: PAPER } };
    cell.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
    cell.fill = solid((ACCENTS[name] || {})[index] || NAVY);
  });

  // Banding is written as a rule rather than as fills on the rows, because the tool rewrites every
  // data row on each build and a fill it wrote would have to be rewritten with them.
  const to = lastColumn(headers.length);
  const rules = [{
    type: 'expression',
    priority: 1,
    formulae: [`AND($A2<>"",MOD(ROW(),2)=0)`],
    style: { fill: dxfFill(BAND) }
  }];
  ws.addConditionalFormatting({ ref: `A2:${to}1048576`, rules });
  (STATUS_RULES[name] || []).forEach(([column, value, tone], index) => {
    ws.addConditionalFormatting({
      ref: `${column}2:${column}1048576`,
      rules: [{
        type: 'expression',
        priority: index + 2,
        formulae: [`$${column}2="${value}"`],
        style: { fill: dxfFill(TONES[tone].bg), font: { bold: true, italic: true, color: { argb: TONES[tone].ink } } }
      }]
    });
  });
  return ws;
}

function timelineSheet(wb, phases, lanes) {
  const ws = dataSheet(wb, 'Timeline', ['Phase', 'Lane', 'Name', 'Weeks', 'After phase', 'Start week', 'End week', 'Covers', 'Traditional hours', 'AI-assisted hours']);
  const first = 2;
  const last = first + phases.length - 1;
  phases.forEach((phase, index) => {
    const row = first + index;
    const inPhase = lanes.filter((lane) => lane.phase === phase.id);
    ws.addRow([
      phase.id,
      '',
      phase.name,
      phase.weeks,
      phase.after,
      { formula: `IF(E${row}="",1,INDEX(G$${first}:G$${last},MATCH(E${row},A$${first}:A$${last},0))+1)` },
      { formula: `F${row}+D${row}-1` },
      inPhase.length ? `${inPhase.length} lanes, below` : 'every activity the catalog puts in this phase',
      { formula: `SUMIFS(${wsRange('Traditional hours')},${wsRange('Phase')},A${row})` },
      { formula: `SUMIFS(${wsRange('AI-assisted hours')},${wsRange('Phase')},A${row})` }
    ]);
  });
  // Lanes run alongside each other inside their phase, not after it, so their start is the phase's
  // start plus an offset. They sit below the phase rows so the sequential formulas above, which
  // index the phase rows by position, keep reading only phase rows.
  lanes.forEach((lane) => {
    const row = ws.rowCount + 1;
    const phaseRow = first + phases.findIndex((phase) => phase.id === lane.phase);
    const added = ws.addRow([
      lane.phase,
      lane.id,
      `${phases.find((phase) => phase.id === lane.phase).name}: ${lane.name}`,
      lane.weeks,
      '',
      { formula: `F${phaseRow}+${lane.offset}` },
      { formula: `F${row}+D${row}-1` },
      lane.activities.join(', '),
      { formula: `SUMIFS(${wsRange('Traditional hours')},${wsRange('Phase')},A${row},${wsRange('Lane')},B${row})` },
      { formula: `SUMIFS(${wsRange('AI-assisted hours')},${wsRange('Phase')},A${row},${wsRange('Lane')},B${row})` }
    ]);
    // A lane is a breakdown of the phase above it, not another phase. Summing this column down the
    // sheet double counts, and the tint is what tells a reader that before they try.
    added.eachCell({ includeEmpty: true }, (cell) => { cell.fill = solid(WASH.teal); });
  });
  const overhead = ws.rowCount + 1;
  const overheadRow = ws.addRow([
    OVERHEAD_PHASE,
    '',
    'Overhead (project management and delivery governance), spread over the whole project',
    null,
    '',
    null,
    null,
    'OH-nn workstreams',
    { formula: `SUMIFS(${wsRange('Traditional hours')},${wsRange('Phase')},A${overhead})` },
    { formula: `SUMIFS(${wsRange('AI-assisted hours')},${wsRange('Phase')},A${overhead})` }
  ]);
  // Overhead belongs to no phase and has no weeks, so it sits apart from the sequence above it.
  overheadRow.eachCell({ includeEmpty: true }, (cell) => {
    cell.fill = solid(WASH.grey);
    cell.font = { name: FONT, size: 11, bold: true, color: { argb: INK } };
  });
  ws.getColumn(3).alignment = { vertical: 'top', wrapText: true };
  return ws;
}

function coverageSheet(wb, workPackages) {
  const ws = wb.addWorksheet('Coverage');
  ws.getColumn(1).width = 61;
  ws.getColumn(2).width = 50;
  for (let column = 1; column <= 10; column += 1) {
    ws.getColumn(column).font = { name: FONT, size: 11, color: { argb: INK } };
    if (column >= 3) {
      ws.getColumn(column).width = 16.67;
    }
  }
  const names = {};
  const bothCells = (at, apply) => ['A', 'B'].forEach((column) => apply(ws.getCell(`${column}${at}`)));

  /** A section heading, and the first one doubles as the sheet's title. */
  const section = (title, size = 12) => {
    const row = ws.addRow([title]);
    row.height = size > 12 ? 42 : undefined;
    bothCells(row.number, (cell) => {
      cell.fill = solid(NAVY);
      cell.font = { name: FONT, size, bold: true, color: { argb: PAPER } };
      cell.alignment = { horizontal: 'left', vertical: size > 12 ? 'top' : 'middle', wrapText: true };
    });
    return row.number;
  };
  const line = (label, value, fmt) => {
    const row = ws.addRow([label, value]);
    if (fmt) {
      row.getCell(2).numFmt = fmt;
    }
    return row.number;
  };
  /** The headline figures: bigger, and tinted so the eye lands on them before the detail. */
  const lead = (at, wash) => bothCells(at, (cell) => {
    cell.fill = solid(wash);
    cell.font = { name: FONT, size: cell.col === 2 ? 16 : 11, bold: true, color: { argb: cell.col === 2 ? TEAL_INK : INK } };
  });
  /** A figure that is not wrong, but is worth a second look before the estimate goes out. */
  const watch = (at) => { ws.getCell(`B${at}`).fill = solid(WASH.amber); };
  const named = (label, name, placeholder, size = 11) => {
    const at = line(label, placeholder);
    names[name] = at;
    const cell = ws.getCell(`B${at}`);
    cell.fill = solid(NAME_FILL);
    cell.font = { name: FONT, size, bold: size > 11, color: { argb: NAME_INK } };
    cell.alignment = { wrapText: true, vertical: 'top' };
  };

  section('About this estimate', 18);
  named('Project', 'ProjectName', '(project)', 14);
  named('Platform', 'Platform', '(platform)');
  named('Platform source', 'PlatformSource', '(source)');
  named('CMK commit', 'CmkCommit', '(commit)');
  named('Toolkit commit', 'ToolkitCommit', '(commit)');
  named('Estimating catalog', 'EstimatingVersion', '(version)');
  named('Estimated at', 'EstimatedAt', '(time)');
  named('Workbook built at', 'BuiltAt', '(time)');
  ws.addRow([]);
  ws.addRow(['Yellow cells are written by the estimate tool. Everything else on this sheet is formulas.'])
    .getCell(1).font = { name: FONT, size: 11, italic: true, color: { argb: 'FF697C8A' } };
  ws.addRow([]);

  section('Hours');
  line('Low hours', { formula: `SUM(${wsRange('Low hours')})` }, '#,##0.00');
  const traditional = line('Traditional hours', { formula: `SUM(${wsRange('Traditional hours')})` }, '#,##0.00');
  line('High hours', { formula: `SUM(${wsRange('High hours')})` }, '#,##0.00');
  const ai = line('AI-assisted hours', { formula: `SUM(${wsRange('AI-assisted hours')})` }, '#,##0.00');
  const saved = line('Saved hours', { formula: `B${traditional}-B${ai}` }, '#,##0.00');
  const savedShare = line('Saved share of traditional hours', { formula: `IF(B${traditional}=0,0,B${saved}/B${traditional})` }, '0.0%');
  const placeholder = line('Traditional hours on placeholder volumes', { formula: `SUMIFS(${wsRange('Traditional hours')},${wsRange('Volume basis')},"placeholder")` }, '#,##0.00');
  const placeholderShare = line('Share of hours on placeholder volumes', { formula: `IF(B${traditional}=0,0,B${placeholder}/B${traditional})` }, '0.0%');
  line('Timeline (weeks)', { formula: 'MAX(Timeline!G$2:G$1048576)' }, WHOLE_FMT);
  // The traditional total is the number the estimate is; the AI block is the number it could be.
  lead(traditional, WASH.grey);
  [ai, saved, savedShare].forEach((at) => lead(at, WASH.teal));
  [placeholder, placeholderShare].forEach(watch);
  ws.addRow([]);

  section('AI plan');
  line('Tools on', { formula: 'COUNTIFS(\'AI plan\'!A$2:A$1048576,"Tool",\'AI plan\'!E$2:E$1048576,"on")' }, COUNT_FMT);
  line('Tools off (opted out, or every method that carries them is)', { formula: 'COUNTIFS(\'AI plan\'!A$2:A$1048576,"Tool",\'AI plan\'!E$2:E$1048576,"off")' }, COUNT_FMT);
  line('Delivery methods off', { formula: 'COUNTIFS(\'AI plan\'!A$2:A$1048576,"Method",\'AI plan\'!E$2:E$1048576,"off")' }, COUNT_FMT);
  watch(line('Tools no workstream uses (a gap in the catalog)', { formula: 'COUNTIF(\'AI plan\'!A$2:A$1048576,"Unused")' }, COUNT_FMT));
  watch(line('Things to have ready (see the AI plan sheet)', { formula: 'COUNTIF(\'AI plan\'!A$2:A$1048576,"Readiness")' }, COUNT_FMT));
  ws.addRow([]);

  section('Review');
  line('Requirements (not dismissed)', { formula: 'COUNTA(Requirements!A$2:A$1048576)-COUNTIF(Requirements!G$2:G$1048576,"dismissed")' }, COUNT_FMT);
  line('Need review', { formula: 'COUNTIF(Requirements!G$2:G$1048576,"pending")' }, COUNT_FMT);
  line('Accepted', { formula: 'COUNTIF(Requirements!G$2:G$1048576,"accepted")' }, COUNT_FMT);
  line('Edited', { formula: 'COUNTIF(Requirements!G$2:G$1048576,"edited")' }, COUNT_FMT);
  line('Dismissed', { formula: 'COUNTIF(Requirements!G$2:G$1048576,"dismissed")' }, COUNT_FMT);
  watch(line('Client questions to ask', { formula: 'COUNTIF(Questions!D$2:D$1048576,"client")' }, COUNT_FMT));
  line('Sources read', { formula: 'COUNTIF(Sources!C$2:C$1048576,"read")+COUNTIF(Sources!C$2:C$1048576,"partial")' }, COUNT_FMT);
  watch(line('Sources not read in full', { formula: 'COUNTIF(Sources!C$2:C$1048576,"partial")+COUNTIF(Sources!C$2:C$1048576,"not read")' }, COUNT_FMT));
  ws.addRow([]);

  section('By work package');
  const header = ws.addRow(['Work package', 'Name', 'Requirements', 'Pending', 'Accepted', 'Edited', 'Dismissed', 'Accelerated', 'Partly', 'Human-led']);
  header.eachCell({ includeEmpty: true }, (cell) => {
    cell.fill = solid(NAVY_MID);
    cell.font = { name: FONT, size: 11, bold: true, color: { argb: PAPER } };
  });
  const firstPackage = header.number + 1;
  for (const [id, pack] of workPackages) {
    const r = ws.rowCount + 1;
    const live = (extra) => `COUNTIFS(Requirements!D$2:D$1048576,A${r}${extra})`;
    ws.addRow([
      id,
      pack.name,
      { formula: `COUNTIF(Requirements!D$2:D$1048576,A${r})-${live(',Requirements!G$2:G$1048576,"dismissed"')}` },
      { formula: live(',Requirements!G$2:G$1048576,"pending"') },
      { formula: live(',Requirements!G$2:G$1048576,"accepted"') },
      { formula: live(',Requirements!G$2:G$1048576,"edited"') },
      { formula: live(',Requirements!G$2:G$1048576,"dismissed"') },
      { formula: live(',Requirements!F$2:F$1048576,"accelerated",Requirements!G$2:G$1048576,"<>dismissed"') },
      { formula: live(',Requirements!F$2:F$1048576,"partly",Requirements!G$2:G$1048576,"<>dismissed"') },
      { formula: live(',Requirements!F$2:F$1048576,"human-led",Requirements!G$2:G$1048576,"<>dismissed"') }
    ]);
  }
  // The only block on Coverage with a row per record, so the only one that needs banding. Its
  // length is the catalog's, which the template knows, so the range is fixed rather than open.
  ws.addConditionalFormatting({
    ref: `A${firstPackage}:J${ws.rowCount}`,
    rules: [{ type: 'expression', priority: 1, formulae: ['MOD(ROW(),2)=1'], style: { fill: dxfFill(BAND) } }]
  });
  return { ws, names };
}

const NOTES = [
  ['Estimate workbook template'],
  ['The estimate tool (tools/blueprint/build-workbook.mjs) fills a copy of this workbook from {Project}_Plan.json and saves it as {Project}_Estimate.xlsx in the project folder.'],
  [''],
  ['What the tool writes'],
  ['Sources, Requirements, Questions, Workstreams, AI plan, Skills, and Assumptions and risks: the tool removes every row from row 2 down and writes one row per record, in the column order of row 1. Row 1 is yours: you may change the header text, not the order or count of the columns. Extra columns to the right are free.'],
  ['Coverage: the tool writes the yellow cells, which are the defined names ProjectName, Platform, PlatformSource, CmkCommit, ToolkitCommit, EstimatingVersion, EstimatedAt and BuiltAt. Every other cell on Coverage is a formula.'],
  ['Timeline: the phase shape comes from the factors seed (samples/factors/seed/phase-packs.csv) and belongs to this template. The tool writes only the Phase column of Workstreams, which the Timeline formulas add up.'],
  [''],
  ['Rules that keep the formulas right'],
  ['Refer to data rows from row 2 to the bottom of the sheet, for example Workstreams!Q$2:Q$1048576. Do not include row 1: a header such as "read" would be counted as a value.'],
  ['No Excel table and no AutoFilter over a data range: the range cannot follow the row count. A frozen header row is fine.'],
  ['The tool does not copy a per-row formula down. Put row-dependent calculations on another sheet.'],
  ['Text is written as text, never as a formula, and dates and times as ISO 8601 text.'],
  [''],
  ['This workbook is an output. Run the estimate again and build it again, and anything typed into the data sheets is replaced. Keep your own analysis in another workbook.'],
  ['Hours are the catalog owner\'s factors times the volumes of the plan. A volume marked "placeholder" is an assumption until the client answers the question next to it.']
];

/**
 * @returns {Promise<Buffer>} the template as .xlsx bytes
 */
export async function buildTemplate() {
  const workPackages = parseActivities(readFileSync(DEFAULT_CATALOG, 'utf8'));
  const seed = loadSeed();
  const phases = phasesOf(seed.find((sheet) => sheet.name === 'Phase packs'));
  const lanes = lanesOf(seed.find((sheet) => sheet.name === 'Lanes'));

  const wb = new ExcelJS.Workbook();
  wb.creator = 'Lean CMS Estimator';
  wb.created = new Date(0);
  wb.modified = new Date(0);
  wb.calcProperties.fullCalcOnLoad = true;

  const sheets = {};
  const coverage = coverageSheet(wb, workPackages);
  sheets.Coverage = coverage.ws;
  for (const name of ['Workstreams', 'Skills', 'AI plan', 'Assumptions and risks']) {
    sheets[name] = dataSheet(wb, name, SHEET_COLUMNS[name]);
  }
  sheets.Timeline = timelineSheet(wb, phases, lanes);
  for (const name of ['Requirements', 'Questions', 'Sources']) {
    sheets[name] = dataSheet(wb, name, SHEET_COLUMNS[name]);
  }
  const notes = wb.addWorksheet('Notes');
  notes.getColumn(1).width = 140.78;
  notes.getColumn(1).font = { name: FONT, size: 11, color: { argb: INK } };
  const headings = new Set(['What the tool writes', 'Rules that keep the formulas right']);
  // The last two lines are the ones people ignore and then lose work to.
  const warnings = new Set(NOTES.slice(-2).map((row) => row[0]));
  for (const row of NOTES) {
    const added = notes.addRow(row);
    added.alignment = { wrapText: true, vertical: 'top' };
    const cell = added.getCell(1);
    if (added.number === 1) {
      added.height = 48;
      cell.fill = solid(NAVY);
      cell.font = { name: FONT, size: 20, bold: true, color: { argb: PAPER } };
    } else if (headings.has(row[0])) {
      added.height = 31.95;
      cell.fill = solid(WASH.teal);
      cell.font = { name: FONT, size: 13, bold: true, color: { argb: TEAL_INK } };
    } else if (warnings.has(row[0])) {
      cell.fill = solid(WASH.amber);
    }
  }

  for (const name of NAMED_CELLS) {
    wb.definedNames.add(`Coverage!$B$${coverage.names[name]}`, name);
  }
  const order = wb.worksheets.map((sheet) => sheet.name);
  if (order.join('|') !== SHEET_ORDER.join('|')) {
    throw new Error(`sheet order is ${order.join(', ')}, expected ${SHEET_ORDER.join(', ')}`);
  }
  return wb.xlsx.writeBuffer();
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const { writeFileSync } = await import('node:fs');
  writeFileSync(TEMPLATE_PATH, Buffer.from(await buildTemplate()));
  console.log(`wrote ${TEMPLATE_PATH}`);
}
