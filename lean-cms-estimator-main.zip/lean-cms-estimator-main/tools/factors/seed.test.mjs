import assert from 'node:assert/strict';
import { mkdtempSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import { SEED_DIR, SHEETS, cellValue, loadSeed, parseCsv } from './seed.mjs';
import { PHASES } from '../blueprint/estimate-model.mjs';

const PILOTS = ['aem', 'aem-eds'];
/** The activities the seed has rates for. The catalog names more; those are not sized yet. */
const WP_IDS = [
  'discovery-audit', 'content-model', 'component-build', 'component-review', 'integrations', 'content-migration',
  'seo', 'search', 'localization', 'multisite', 'qa-automation', 'environments-devops', 'uat-support', 'frontend-delivery'
];
const CATEGORIES = new Set(['delivery', 'platform', 'martech', 'business']);
const LIBRARY_SHEETS = ['Assumption library', 'Dependency library', 'Risk library'];

const SEEDED = Object.fromEntries(loadSeed().map((s) => [s.name, s]));

/**
 * Temp seed dir holding every seed file. `rewrites` maps a seed file name to a function that
 * takes the file text and returns the text to write instead.
 */
function seedDirWith(rewrites) {
  const dir = mkdtempSync(join(tmpdir(), 'factors-seed-'));
  for (const sheet of SHEETS) {
    const source = readFileSync(join(SEED_DIR, sheet.file), 'utf8');
    const rewrite = rewrites[sheet.file];
    writeFileSync(join(dir, sheet.file), rewrite ? rewrite(source) : source);
  }
  return dir;
}

/** CSV text with one data cell changed. `rowNumber` 2 is the first data row; the cell is found by header. */
function csvWithCell(text, rowNumber, header, value) {
  const rows = parseCsv(text);
  rows[rowNumber - 1][rows[0].indexOf(header)] = value;
  return rows.map((row) => row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(',')).join('\n') + '\n';
}

describe('the delivery defaults the seed CSVs hold', () => {
  const sheets = Object.fromEntries(loadSeed().map((s) => [s.name, s]));

  it('holds no rates: hours come from the case library and the estimating catalog, not the seed', () => {
    assert.equal(sheets.Factors, undefined);
    const headers = loadSeed().flatMap((sheet) => sheet.headers);
    assert.deepEqual(headers.filter((header) => /hours\/unit|saving/.test(header)), []);
  });

  it('defines Skills with category', () => {
    assert.ok(sheets.Skills.rows.length >= 8);
    for (const row of sheets.Skills.rows) {
      assert.ok(row[0].trim().length > 0, 'skill id');
      assert.ok(row[1].trim().length > 0, 'name');
      assert.ok(CATEGORIES.has(row[2].trim()), `category ${row[2]}`);
    }
  });

  it('does not ship a Skill mix sheet', () => {
    assert.equal(sheets['Skill mix'], undefined);
    assert.ok(!SHEETS.some((s) => s.name === 'Skill mix'));
  });

  it('covers every phase skill id on Skills', () => {
    const skillIds = new Set(sheets.Skills.rows.map((r) => r[0]));
    for (const row of sheets['Phase allocations'].rows) {
      assert.ok(skillIds.has(row[1]), `allocation skill ${row[1]}`);
    }
    for (const row of sheets['Phase ramps'].rows) {
      assert.ok(skillIds.has(row[1]), `ramp skill ${row[1]}`);
    }
  });

  it('has phase packs with allocations and at least one ramp', () => {
    const phaseIds = new Set(sheets['Phase packs'].rows.map((r) => r[0]));
    assert.deepEqual([...phaseIds], PHASES, 'the seed schedules the phases of the estimating catalog, in order');
    for (const row of sheets['Phase allocations'].rows) {
      assert.ok(phaseIds.has(row[0]), `unknown phase ${row[0]}`);
      assert.ok(Number(row[2]) >= 0, 'fte');
    }
    assert.ok(sheets['Phase ramps'].rows.length >= 1);
    const architectRamp = sheets['Phase ramps'].rows.find(
      (r) => r[0] === 'build' && r[1] === 'architect' && r[2] === 'design-signoff'
    );
    assert.ok(architectRamp, 'architect ramp after design-signoff');
    assert.equal(Number(architectRamp[3]), 0.25);
  });

  it('has Onshore-led, Balanced, and Offshore-led with one default', () => {
    const names = sheets['Blended rate'].rows.map((r) => r[0]);
    assert.deepEqual(names.sort(), ['Balanced', 'Offshore-led', 'Onshore-led'].sort());
    assert.ok(!sheets['Blended rate'].headers.some((h) => /cost/i.test(h)));
    const defaults = sheets['Blended rate'].rows.filter((r) => r[2].trim().toLowerCase() === 'yes');
    assert.equal(defaults.length, 1);
    for (const row of sheets['Blended rate'].rows) {
      assert.ok(Number(row[1]) > 0, 'hourly rate');
      assert.ok(row[3].trim().length > 0, 'country');
      assert.ok(Number(row[4]) > 0, 'monthly hours');
    }
  });

  it('does not ship Role mix or Role map sheets', () => {
    assert.equal(sheets['Role mix'], undefined);
    assert.equal(sheets['Role map'], undefined);
    assert.ok(!SHEETS.some((s) => s.name === 'Role mix' || s.name === 'Role map'));
  });

  it('holds the delivery shape first, then the libraries, then the optional sheets', () => {
    assert.deepEqual(
      SHEETS.map((s) => s.name).slice(0, 5),
      ['Skills', 'Phase packs', 'Phase allocations', 'Phase ramps', 'Blended rate']
    );
    assert.deepEqual(SHEETS.slice(5, 8).map((s) => s.name), LIBRARY_SHEETS);
    assert.deepEqual(SHEETS.slice(8).map((s) => s.name), ['Phase tasks', 'Phase task allocations', 'Lanes']);
  });

  it('gives each library entries for all, aem, aem-eds and aep', () => {
    LIBRARY_SHEETS.forEach((name) => {
      const platforms = new Set(sheets[name].rows.map((r) => r[1].trim()));
      ['all', 'aem', 'aem-eds', 'aep'].forEach((platform) => {
        assert.ok(platforms.has(platform), `${name} has ${platform}`);
      });
    });
  });

  it('keeps entries without hints to platform all, with at least one always-proposed entry', () => {
    LIBRARY_SHEETS.forEach((name) => {
      const blank = sheets[name].rows.filter((r) => r[2].trim() === '');
      assert.ok(blank.length >= 1, `${name} has an always-proposed entry`);
      blank.forEach((r) => assert.equal(r[1].trim(), 'all'));
    });
  });

  it('puts the sample library ids in the matching library', () => {
    const ids = (name) => new Set(sheets[name].rows.map((r) => r[0].trim()));
    assert.ok(ids('Assumption library').has('asm-idp-stays'));
    assert.ok(ids('Dependency library').has('dep-env-access'));
    assert.ok(ids('Dependency library').has('dep-test-tenant'));
    assert.ok(ids('Risk library').has('risk-content-owners'));
  });

  it('resolves every libraryId in the Northwind v2 Context sample', () => {
    const context = JSON.parse(
      readFileSync(join(SEED_DIR, '../../offline/Northwind_v2_Context.json'), 'utf8')
    );
    const lists = {
      assumptions: 'Assumption library',
      dependencies: 'Dependency library',
      deliveryRisks: 'Risk library'
    };
    let checked = 0;
    Object.keys(lists).forEach((key) => {
      const ids = new Set(sheets[lists[key]].rows.map((r) => r[0].trim()));
      (context[key] ?? []).forEach((item) => {
        if (item.libraryId) {
          checked++;
          assert.ok(ids.has(item.libraryId), `${item.id} libraryId ${item.libraryId}`);
        }
      });
    });
    assert.ok(checked >= 3);
  });

  it('keeps cost, rate and contingency columns and a commercial category out of the libraries', () => {
    LIBRARY_SHEETS.forEach((name) => {
      sheets[name].headers.forEach((h) => assert.ok(!/cost|rate|contingency/i.test(h), `${name}: ${h}`));
    });
    sheets['Assumption library'].rows.forEach((r) => assert.notEqual(r[4].trim(), 'commercial'));
  });

  it('carries no client text', () => {
    LIBRARY_SHEETS.forEach((name) => {
      sheets[name].rows.forEach((r) => {
        assert.ok(!/northwind/i.test(r.join(' ')), `${name}: ${r[0]}`);
      });
    });
  });
});

describe('the sheets the seed defines', () => {
  it('names its sheets and no longer carries the ones that were dropped', () => {
    const names = SHEETS.map((sheet) => sheet.name);
    assert.deepEqual(loadSeed().map((sheet) => sheet.name), names);
    for (const gone of ['Factors', 'Skill mix', 'Role mix', 'Role map', 'AI allowance']) {
      assert.equal(names.indexOf(gone), -1, `${gone} was dropped`);
    }
  });

  it('turns a numeric column into a number and a blank optional one into null', () => {
    const packs = loadSeed().find((sheet) => sheet.name === 'Phase packs');
    assert.equal(typeof cellValue(packs.rows[0][2], 'default duration weeks', packs.numeric ?? new Set(['default duration weeks']), 'test'), 'number');
    assert.equal(cellValue('', 'lag weeks', new Set(['lag weeks']), 'test'), null);
  });

  it('checks required week before it is turned into a number', () => {
    // cellValue would accept all of these as numbers, so only the library check rejects them.
    for (const week of ['0', '2.5', '1e1']) {
      const dir = seedDirWith({
        'dependency-library.csv': (text) => csvWithCell(text, 2, 'required week', week)
      });
      assert.throws(
        () => loadSeed(dir),
        new RegExp(`dependency-library\\.csv: row 2: "required week" value "${week}" must be a whole number`),
        week
      );
    }
  });

  it('rejects a duplicate library id', () => {
    const first = SEEDED['Assumption library'].rows[0][0];
    const dir = seedDirWith({
      'assumption-library.csv': (text) => csvWithCell(text, 3, 'library id', first)
    });
    assert.throws(() => loadSeed(dir), /assumption-library\.csv: row 3: duplicate library id/);
  });

  it('ships Phase packs with a blank Lag weeks column E, the last of the five', () => {
    const packs = SHEETS.find((s) => s.name === 'Phase packs');
    assert.equal(packs.headers.length, 5);
    assert.equal(packs.headers[4], 'lag weeks');
    assert.ok(packs.numeric.has('lag weeks'));
    assert.ok(SEEDED['Phase packs'].rows.every((row) => row[4] === ''));
  });

  it('ships Lanes, which say which activities run alongside each other inside a phase', () => {
    const lanes = SHEETS.find((s) => s.name === 'Lanes');
    assert.deepEqual(lanes.headers, ['lane id', 'phase id', 'name', 'offset weeks', 'duration weeks', 'activities']);
    const phaseIds = new Set(SEEDED['Phase packs'].rows.map((row) => row[0]));
    const rows = SEEDED.Lanes.rows;
    assert.ok(rows.length >= 2, 'a phase with one lane needs no row; Build has two');
    for (const row of rows) {
      assert.ok(phaseIds.has(row[1]), `unknown phase ${row[1]}`);
      assert.ok(row[5].split(';').every((id) => id.trim() !== ''), 'a lane lists the activities in it');
    }
  });

  it('reads a whole-number lag, positive or negative', () => {
    const dir = seedDirWith({
      'phase-packs.csv': (text) => csvWithCell(text, 3, 'lag weeks', '-2')
    });
    const packs = loadSeed(dir).find((sheet) => sheet.name === 'Phase packs');
    assert.equal(packs.rows[1][4], '-2');
    assert.equal(packs.rows[0][4], '');
  });

  it('rejects a lag that is not a whole number', () => {
    for (const lag of ['1.5', 'abc', '1e1']) {
      const dir = seedDirWith({
        'phase-packs.csv': (text) => csvWithCell(text, 3, 'lag weeks', lag)
      });
      assert.throws(
        () => loadSeed(dir),
        new RegExp(`phase-packs\\.csv: row 3: "lag weeks" value "${lag}" must be a whole number, or blank`),
        lag
      );
    }
  });

  it('rejects a lag beyond 520 weeks either way', () => {
    for (const lag of ['521', '-521', '99999999']) {
      const dir = seedDirWith({
        'phase-packs.csv': (text) => csvWithCell(text, 3, 'lag weeks', lag)
      });
      assert.throws(
        () => loadSeed(dir),
        new RegExp(`phase-packs\\.csv: row 3: "lag weeks" value "${lag}" must be from -520 to 520`),
        lag
      );
    }
  });

  it('accepts a lag of 520 weeks either way', () => {
    for (const lag of ['520', '-520']) {
      const dir = seedDirWith({
        'phase-packs.csv': (text) => csvWithCell(text, 3, 'lag weeks', lag)
      });
      assert.doesNotThrow(() => loadSeed(dir), lag);
    }
  });

  it('defines the Phase tasks and Phase task allocations sheets with their numeric columns', () => {
    const tasks = SHEETS.find((s) => s.name === 'Phase tasks');
    assert.deepEqual(tasks.headers, [
      'phase id', 'task id', 'name', 'kind', 'start week', 'duration weeks', 'basis',
      'work package id', 'owner skills', 'hours', 'deliverable', 'scope', 'calendar-bound'
    ]);
    assert.deepEqual([...tasks.numeric].sort(), ['duration weeks', 'hours', 'start week']);
    const allocations = SHEETS.find((s) => s.name === 'Phase task allocations');
    assert.deepEqual(allocations.headers, ['task id', 'skill id', 'fte']);
    assert.deepEqual([...allocations.numeric], ['fte']);
  });

  it('ships both task sheets with a header and no rows', () => {
    assert.deepEqual(SEEDED['Phase tasks'].rows, []);
    assert.deepEqual(SEEDED['Phase task allocations'].rows, []);
  });

  it('ships a CSV for every sheet it defines, and no CSV it does not', () => {
    const defined = SHEETS.map((sheet) => sheet.file).sort();
    const onDisk = readdirSync(SEED_DIR).filter((name) => name.endsWith('.csv')).sort();
    assert.deepEqual(onDisk, defined, 'a CSV nobody defines is dead data, and a sheet with no CSV fails to load');
  });
});

describe('Phase tasks seed check', () => {
  const TASK_HEAD = SHEETS.find((s) => s.name === 'Phase tasks').headers.join(',') + '\n';
  const ALLOCATION_HEAD = SHEETS.find((s) => s.name === 'Phase task allocations').headers.join(',') + '\n';
  // phase id, task id, name, kind, start week, duration weeks, basis, work package id, owner skills,
  // hours, deliverable, scope, calendar-bound
  const FIXED = 'build,t1,Task one,,2,4,fixed,,pm,40,,,';
  const MILESTONE = 'discover,m1,Sign-off,milestone,4,,,,,,Gate 1,,';
  const driver = (id, wp = 'component-build') => `build,${id},Driver ${id},,1,6,driver,${wp},pm;architect,,,,yes`;
  const CAPACITY = 'build,c1,Capacity,,1,12,capacity,,,,,,';

  /** A seed dir with the given task and allocation rows. */
  function seedWith(taskRows, allocationRows = []) {
    return seedDirWith({
      'phase-tasks.csv': () => TASK_HEAD + taskRows.map((row) => `${row}\n`).join(''),
      'phase-task-allocations.csv': () => ALLOCATION_HEAD + allocationRows.map((row) => `${row}\n`).join('')
    });
  }

  it('accepts a valid mix of tasks, a milestone, a driver task and capacity rows', () => {
    const dir = seedWith(
      [FIXED, MILESTONE, driver('d1'), CAPACITY],
      ['c1,pm,0.5', 'c1,ba,1', 'd1,architect,0.25']
    );
    const sheets = Object.fromEntries(loadSeed(dir).map((s) => [s.name, s]));
    assert.equal(sheets['Phase tasks'].rows.length, 4);
    assert.equal(sheets['Phase task allocations'].rows.length, 3);
  });

  it('reads the task row back with its start week, duration and hours', () => {
    const dir = seedWith([FIXED]);
    const sheet = loadSeed(dir).find((entry) => entry.name === 'Phase tasks');
    const at = (header) => sheet.rows[0][sheet.headers.indexOf(header)];
    assert.equal(at('task id'), 't1');
    assert.equal(at('start week'), '2');
    assert.equal(at('duration weeks'), '4');
    assert.equal(at('hours'), '40');
    assert.equal(at('kind'), '');
  });

  const BAD_TASKS = [
    ['a blank phase id', [FIXED.replace('build', '')], /phase-tasks\.csv: row 2: "phase id" is blank/],
    ['a phase that is not on phase-packs.csv', [FIXED.replace('build', 'nope')], /phase-tasks\.csv: row 2: phase id "nope" is not on phase-packs\.csv/],
    ['a repeated task id', [FIXED, FIXED], /phase-tasks\.csv: row 3: task id "t1" repeats the one on row 2/],
    ['a bad kind', [FIXED.replace(',,2,', ',phase,2,')], /phase-tasks\.csv: row 2: "kind" value "phase" must be task or milestone/],
    ['a start week of 0', [FIXED.replace(',2,4,', ',0,4,')], /phase-tasks\.csv: row 2: "start week" value "0" must be a whole number of 1 or more/],
    ['a fractional start week', [FIXED.replace(',2,4,', ',1.5,4,')], /"start week" value "1\.5" must be a whole number/],
    ['a negative duration', [FIXED.replace(',2,4,', ',2,-1,')], /"duration weeks" value "-1" must be a number of 0 or more/],
    ['a start week above the cap', [FIXED.replace(',2,4,', ',521,4,')], /"start week" value "521" must be at most 520/],
    ['a duration above the cap', [FIXED.replace(',2,4,', ',2,1000000,')], /"duration weeks" value "1000000" must be at most 520/],
    ['a bad basis', [FIXED.replace('fixed', 'guess')], /phase-tasks\.csv: row 2: "basis" value "guess" must be driver, capacity or fixed/],
    ['a task without a basis', [FIXED.replace('fixed', '')], /phase-tasks\.csv: row 2: "basis" value "" must be driver, capacity or fixed/],
    ['a fixed task without hours', [FIXED.replace(',40,', ',,')], /phase-tasks\.csv: row 2: "hours" is required when basis is fixed/],
    ['a driver task without a package', [driver('d1', '')], /phase-tasks\.csv: row 2: "work package id" is required when basis is driver/],
    ['a package that is not an activity', [driver('d1', 'WP-99')], /phase-tasks\.csv: row 2: work package id "WP-99" is not an activity in the estimating catalog/],
    ['two driver tasks on one package', [driver('d1'), driver('d2')], /phase-tasks\.csv: row 3: work package "component-build" is already bound by the driver task on row 2/],
    ['an owner skill that is not on skills.csv', [FIXED.replace(',pm,', ',pm;zzz,')], /phase-tasks\.csv: row 2: owner skill "zzz" is not on skills\.csv/],
    ['a milestone with a basis', [MILESTONE.replace('milestone,4,,,', 'milestone,4,,fixed,')], /phase-tasks\.csv: row 2: "basis" must be blank on a milestone/],
    ['a milestone with hours', [MILESTONE.replace(',,,,,,Gate 1', ',,,,,5,Gate 1')], /phase-tasks\.csv: row 2: "hours" must be blank on a milestone/],
    ['a calendar-bound value other than yes', [FIXED.replace(/,$/, ',maybe')], /"calendar-bound" value "maybe" must be yes, or blank/],
    ['a capacity task with no allocation row', [CAPACITY], /phase-tasks\.csv: row 2: capacity task "c1" needs at least one row on phase-task-allocations\.csv/]
  ];

  for (const [label, rows, expected] of BAD_TASKS) {
    it(`rejects ${label}`, () => {
      assert.throws(() => loadSeed(seedWith(rows)), expected);
    });
  }

  const BAD_ALLOCATIONS = [
    ['a task that is not on phase-tasks.csv', [FIXED], ['ghost,pm,1'], /phase-task-allocations\.csv: row 2: task id "ghost" is not on phase-tasks\.csv/],
    ['a skill that is not on skills.csv', [FIXED], ['t1,zzz,1'], /phase-task-allocations\.csv: row 2: skill id "zzz" is not on skills\.csv/],
    ['a negative fte', [FIXED], ['t1,pm,-1'], /phase-task-allocations\.csv: row 2: "fte" value "-1" must be a number of 0 or more/],
    ['a blank fte', [FIXED], ['t1,pm,'], /phase-task-allocations\.csv: row 2: "fte" value "" must be a number of 0 or more/],
    ['a text fte', [FIXED], ['t1,pm,lots'], /phase-task-allocations\.csv: row 2: "fte" value "lots" must be a number of 0 or more/],
    ['a blank task id', [FIXED], [',pm,1'], /phase-task-allocations\.csv: row 2: "task id" is blank/],
    ['a milestone with a row', [MILESTONE], ['m1,pm,1'], /phase-tasks\.csv: row 2: milestone "m1" must have no rows on phase-task-allocations\.csv/]
  ];

  for (const [label, taskRows, allocationRows, expected] of BAD_ALLOCATIONS) {
    it(`rejects an allocation with ${label}`, () => {
      assert.throws(() => loadSeed(seedWith(taskRows, allocationRows)), expected);
    });
  }

  it('reports a structural error in an earlier file before a task row error', () => {
    const dir = seedDirWith({
      'phase-tasks.csv': () => TASK_HEAD + FIXED.replace('build', 'nope') + '\n',
      'skills.csv': (text) => text.replace('skill id', 'renamed')
    });
    assert.throws(() => loadSeed(dir), /skills\.csv: column 1 is "renamed"/);
  });
});

describe('parseCsv', () => {
  it('keeps commas inside quoted fields', () => {
    const rows = parseCsv('a,b\n"UAT, training",x\n');
    assert.deepEqual(rows[1], ['UAT, training', 'x']);
  });

  it('keeps an escaped quote inside a quoted field', () => {
    assert.deepEqual(parseCsv('"say ""hi""",x\n')[0], ['say "hi"', 'x']);
  });

  it('rejects an unclosed quote', () => {
    assert.throws(() => parseCsv('a,b\n"open,x\n'), /unclosed quote/);
  });

  it('rejects a quote inside an unquoted field', () => {
    assert.throws(() => parseCsv('a,b\nab"cd"ef,x\n'), /CSV line 2 has a quote inside an unquoted field/);
  });

  it('rejects text after a closing quote', () => {
    assert.throws(() => parseCsv('a\n"abc"def\n'), /CSV line 2 has text after a closing quote/);
  });

  it('records the file line each kept row starts on, skipping blank lines and multi-line fields', () => {
    const rows = parseCsv('a,b\n\n1,2\n"x\ny",z\n3,4\n');
    assert.equal(rows.length, 4);
    assert.deepEqual(rows.lineNumbers, [1, 3, 4, 6]);
  });
});
describe('cellValue', () => {
  const numeric = new Set(['hourly blended rate', 'percent']);

  it('returns null for blanks and numbers for numeric headers', () => {
    assert.equal(cellValue('', 'percent', numeric, 't'), null);
    assert.equal(cellValue('40', 'percent', numeric, 't'), 40);
  });

  it('throws when a numeric cell is not a finite number', () => {
    assert.throws(
      () => cellValue('16h', 'hourly blended rate', numeric, 'blended-rate.csv: row 2'),
      /not a number/
    );
  });
});

describe('loadSeed', () => {
  const SKILLS_HEAD = 'skill id,name,category,inference hints\n';
  const shortRow = (text) => {
    const lines = text.split(/\r?\n/);
    lines[1] = 'only-one-cell';
    return lines.join('\n');
  };

  it('rejects a renamed header', () => {
    const dir = seedDirWith({
      'skills.csv': () => 'skill id,name,category,grade\npm,Project Manager,delivery,x\n'
    });
    assert.throws(() => loadSeed(dir), /expected "inference hints"/);
  });

  it('rejects a short data row', () => {
    const dir = seedDirWith({ 'skills.csv': () => SKILLS_HEAD + 'pm,Project Manager\n' });
    assert.throws(() => loadSeed(dir), /skills\.csv: row 2 has 2 columns/);
  });

  it('names the file line of a bad row, even after blank lines', () => {
    const dir = seedDirWith({ 'skills.csv': () => SKILLS_HEAD + '\n\npm,Project Manager\n' });
    assert.throws(() => loadSeed(dir), /skills\.csv: row 4 has 2 columns/);
  });

  it('names the file when a CSV has a quoting mistake', () => {
    const dir = seedDirWith({ 'skills.csv': () => SKILLS_HEAD + 'pm,"Project"Manager,delivery,x\n' });
    assert.throws(() => loadSeed(dir), /skills\.csv: CSV line 2 has text after a closing quote/);
  });

  it('rejects a renamed header and a short row in every library file', () => {
    LIBRARY_SHEETS.forEach((name) => {
      const sheet = SHEETS.find((s) => s.name === name);
      const firstHeader = sheet.headers[0];
      const renamed = seedDirWith({ [sheet.file]: (text) => text.replace(firstHeader, 'renamed') });
      assert.throws(() => loadSeed(renamed), (error) => error.message === `${sheet.file}: column 1 is "renamed", expected "${firstHeader}"`, name);
      const short = seedDirWith({ [sheet.file]: shortRow });
      assert.throws(
        () => loadSeed(short),
        (error) => error.message === `${sheet.file}: row 2 has 1 columns, expected ${sheet.headers.length}`,
        name
      );
    });
  });

  it('rejects a bad library value with the file and row', () => {
    const dir = seedDirWith({
      'risk-library.csv': (text) => csvWithCell(text, 2, 'severity', 'sky-high')
    });
    assert.throws(() => loadSeed(dir), /risk-library\.csv: row 2: "severity" value "sky-high"/);
  });

  it('reports a structural error in a later file before a library error in an earlier one', () => {
    // assumption-library.csv loads before risk-library.csv, so a check run per file would report
    // its category first. The structural error must win.
    const dir = seedDirWith({
      'assumption-library.csv': (text) => csvWithCell(text, 2, 'category', 'bogus'),
      'risk-library.csv': shortRow
    });
    assert.throws(
      () => loadSeed(dir),
      (error) => {
        assert.match(error.message, /^risk-library\.csv: row 2 has 1 columns/);
        assert.doesNotMatch(error.message, /category/);
        return true;
      }
    );
  });

  it('lists library errors from several files in one error', () => {
    const dir = seedDirWith({
      'assumption-library.csv': (text) => csvWithCell(text, 2, 'category', 'bogus'),
      'risk-library.csv': (text) => csvWithCell(text, 2, 'severity', 'sky-high')
    });
    assert.throws(
      () => loadSeed(dir),
      (error) => {
        assert.equal(error.message.split('\n').length, 2);
        assert.match(error.message, /assumption-library\.csv: row 2: "category" value "bogus"/);
        assert.match(error.message, /risk-library\.csv: row 2: "severity" value "sky-high"/);
        return true;
      }
    );
  });
});
