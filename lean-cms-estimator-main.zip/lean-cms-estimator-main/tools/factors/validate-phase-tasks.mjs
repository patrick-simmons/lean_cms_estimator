/**
 * Check for the hub Phase tasks and Phase task allocations sheets in the factors workbook.
 *
 * It works on loadSeed-shaped sheets: { name, file, headers, rows, lines? } where rows hold raw CSV
 * text and lines holds the file line of each row (row numbers fall back to index + 2).
 * It imports nothing from seed.mjs because loadSeed imports this module.
 *
 * Keep the rules in step with validatePhaseTask in
 * src/webparts/blueprint/projects/workingFile.ts and the Phase tasks reader in factorsWorkbook.ts;
 * the web part rejects the same rows when it loads the workbook.
 * Contract: docs/spfx/phase-plan-v2.md and docs/spfx/delivery-defaults.md.
 */

import { readFileSync } from 'node:fs';
import { DEFAULT_CATALOG, parseActivities } from '../blueprint/rank-questions.mjs';

const TASK_KINDS = ['task', 'milestone'];
const TASK_BASES = ['driver', 'capacity', 'fixed'];
// Keep in step with MAX_TASK_WEEKS in src/webparts/blueprint/projects/workingFile.ts.
const MAX_TASK_WEEKS = 520;
const ZERO_WIDTH = /[\u200B-\u200D\u2060\uFEFF]/g;

function clean(value) {
  return String(value ?? '').replace(ZERO_WIDTH, '').trim();
}

function sheetNamed(sheets, name) {
  return sheets.find((sheet) => sheet.name === name);
}

function columnOf(sheet, header) {
  return sheet.headers.indexOf(header);
}

function rowsOf(sheet) {
  return sheet.rows.map((row, index) => ({
    row,
    line: sheet.lines ? sheet.lines[index] : index + 2
  }));
}

function isBlank(row) {
  return row.every((cell) => clean(cell) === '');
}

function asNumber(text) {
  return text === '' ? undefined : Number(text);
}

/** Ids of a catalog sheet column, for reference checks. A missing sheet has no ids. */
function idsOf(sheets, sheetName, header) {
  const sheet = sheetNamed(sheets, sheetName);
  if (!sheet) {
    return new Set();
  }
  const index = columnOf(sheet, header);
  return new Set(
    rowsOf(sheet)
      .map(({ row }) => clean(row[index]))
      .filter((id) => id !== '')
  );
}

/** Throws on the first bad row of the two task sheets; does nothing when they are empty or absent. */
export function assertPhaseTasks(sheets) {
  const tasksSheet = sheetNamed(sheets, 'Phase tasks');
  const allocationsSheet = sheetNamed(sheets, 'Phase task allocations');
  if (!tasksSheet && !allocationsSheet) {
    return;
  }
  const phaseIds = idsOf(sheets, 'Phase packs', 'phase id');
  const skillIds = idsOf(sheets, 'Skills', 'skill id');
  // The activities come from the estimating catalog now that the factor table is gone. Reading
  // it here rather than taking it as an argument keeps loadSeed's signature as it was.
  const packageIds = new Set(parseActivities(readFileSync(DEFAULT_CATALOG, 'utf8')).keys());

  const taskLines = new Map();
  const driverLines = new Map();
  const tasks = [];
  if (tasksSheet) {
    const at = (name) => columnOf(tasksSheet, name);
    for (const { row, line } of rowsOf(tasksSheet)) {
      if (isBlank(row)) {
        continue;
      }
      const where = `${tasksSheet.file}: row ${line}`;
      const cell = (name) => clean(row[at(name)]);
      const taskId = cell('task id');
      const phaseId = cell('phase id');
      if (phaseId === '') {
        throw new Error(`${where}: "phase id" is blank`);
      }
      if (taskId === '') {
        throw new Error(`${where}: "task id" is blank`);
      }
      if (cell('name') === '') {
        throw new Error(`${where}: "name" is blank`);
      }
      if (!phaseIds.has(phaseId)) {
        throw new Error(`${where}: phase id "${phaseId}" is not on phase-packs.csv`);
      }
      if (taskLines.has(taskId)) {
        throw new Error(`${where}: task id "${taskId}" repeats the one on row ${taskLines.get(taskId)}`);
      }
      taskLines.set(taskId, line);

      const kind = cell('kind').toLowerCase() || 'task';
      if (!TASK_KINDS.includes(kind)) {
        throw new Error(`${where}: "kind" value "${cell('kind')}" must be task or milestone, or blank`);
      }
      const startWeek = asNumber(cell('start week'));
      if (startWeek !== undefined && !(Number.isInteger(startWeek) && startWeek >= 1)) {
        throw new Error(`${where}: "start week" value "${cell('start week')}" must be a whole number of 1 or more, or blank`);
      }
      if (startWeek !== undefined && startWeek > MAX_TASK_WEEKS) {
        throw new Error(`${where}: "start week" value "${cell('start week')}" must be at most ${MAX_TASK_WEEKS}`);
      }
      const duration = asNumber(cell('duration weeks'));
      if (duration !== undefined && !(Number.isFinite(duration) && duration >= 0)) {
        throw new Error(`${where}: "duration weeks" value "${cell('duration weeks')}" must be a number of 0 or more, or blank`);
      }
      if (duration !== undefined && duration > MAX_TASK_WEEKS) {
        throw new Error(`${where}: "duration weeks" value "${cell('duration weeks')}" must be at most ${MAX_TASK_WEEKS}`);
      }
      const hours = asNumber(cell('hours'));
      if (hours !== undefined && !(Number.isFinite(hours) && hours >= 0)) {
        throw new Error(`${where}: "hours" value "${cell('hours')}" must be a number of 0 or more, or blank`);
      }
      const basis = cell('basis').toLowerCase();
      if (kind === 'milestone') {
        if (basis !== '') {
          throw new Error(`${where}: "basis" must be blank on a milestone`);
        }
        if (hours !== undefined) {
          throw new Error(`${where}: "hours" must be blank on a milestone`);
        }
      } else {
        if (!TASK_BASES.includes(basis)) {
          throw new Error(`${where}: "basis" value "${cell('basis')}" must be driver, capacity or fixed`);
        }
        if (basis === 'fixed' && hours === undefined) {
          throw new Error(`${where}: "hours" is required when basis is fixed`);
        }
      }
      const packageId = cell('work package id');
      if (kind !== 'milestone' && basis === 'driver') {
        if (packageId === '') {
          throw new Error(`${where}: "work package id" is required when basis is driver`);
        }
        if (driverLines.has(packageId)) {
          throw new Error(
            `${where}: work package "${packageId}" is already bound by the driver task on row ${driverLines.get(packageId)}`
          );
        }
        driverLines.set(packageId, line);
      }
      if (packageId !== '' && !packageIds.has(packageId)) {
        throw new Error(`${where}: work package id "${packageId}" is not an activity in the estimating catalog`);
      }
      cell('owner skills')
        .split(';')
        .map(clean)
        .filter((id) => id !== '')
        .forEach((skillId) => {
          if (!skillIds.has(skillId)) {
            throw new Error(`${where}: owner skill "${skillId}" is not on skills.csv`);
          }
        });
      const calendarBound = cell('calendar-bound').toLowerCase();
      if (calendarBound !== '' && calendarBound !== 'yes') {
        throw new Error(`${where}: "calendar-bound" value "${cell('calendar-bound')}" must be yes, or blank`);
      }
      tasks.push({ taskId, kind, basis, line });
    }
  }

  const allocationCounts = new Map();
  if (allocationsSheet) {
    const at = (name) => columnOf(allocationsSheet, name);
    for (const { row, line } of rowsOf(allocationsSheet)) {
      if (isBlank(row)) {
        continue;
      }
      const where = `${allocationsSheet.file}: row ${line}`;
      const cell = (name) => clean(row[at(name)]);
      const taskId = cell('task id');
      const skillId = cell('skill id');
      if (taskId === '') {
        throw new Error(`${where}: "task id" is blank`);
      }
      if (skillId === '') {
        throw new Error(`${where}: "skill id" is blank`);
      }
      if (!taskLines.has(taskId)) {
        throw new Error(`${where}: task id "${taskId}" is not on phase-tasks.csv`);
      }
      if (!skillIds.has(skillId)) {
        throw new Error(`${where}: skill id "${skillId}" is not on skills.csv`);
      }
      const fte = asNumber(cell('fte'));
      if (fte === undefined || !(Number.isFinite(fte) && fte >= 0)) {
        throw new Error(`${where}: "fte" value "${cell('fte')}" must be a number of 0 or more`);
      }
      allocationCounts.set(taskId, (allocationCounts.get(taskId) ?? 0) + 1);
    }
  }

  for (const task of tasks) {
    const count = allocationCounts.get(task.taskId) ?? 0;
    const where = `${tasksSheet.file}: row ${task.line}`;
    if (task.kind === 'milestone' && count > 0) {
      throw new Error(`${where}: milestone "${task.taskId}" must have no rows on phase-task-allocations.csv`);
    }
    if (task.kind !== 'milestone' && task.basis === 'capacity' && count === 0) {
      throw new Error(`${where}: capacity task "${task.taskId}" needs at least one row on phase-task-allocations.csv`);
    }
  }
}
