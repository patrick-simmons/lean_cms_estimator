/**
 * Check for the hub library sheets (Assumption, Dependency, Risk) in the factors workbook.
 *
 * It works on loadSeed-shaped sheets: { name, file, headers, rows, lines? } where rows hold raw CSV
 * text and lines holds the file line of each row (row numbers fall back to index + 2).
 * It imports nothing from seed.mjs because loadSeed imports this module.
 * Contract: docs/spfx/context-sidecar.md ("Hub libraries") and docs/spfx/delivery-defaults.md.
 */

/** Platforms a library entry may carry. Adding a platform starts here, then hub content. */
export const KNOWN_PLATFORMS = ['all', 'aem', 'aem-eds', 'aep'];

// These mirror tools/blueprint/validate-context.mjs; a test fails if they drift apart.
export const LEVELS = ['low', 'medium', 'high'];
export const PRIORITIES = ['high', 'medium', 'low'];
export const ASSUMPTION_CATEGORIES = [
  'scope',
  'architecture',
  'dependency',
  'resource',
  'delivery',
  'estimate'
];

/** Columns every library sheet starts with, by header text. */
export const COMMON_COLUMNS = ['library id', 'platform', 'match hints'];
const [ID, PLATFORM, HINTS] = COMMON_COLUMNS;
const ALL_PLATFORM = 'all';
const KEBAB_CASE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const WHOLE_NUMBER = /^[1-9][0-9]*$/;
// trim() leaves zero-width characters in place, so strip them before a blank check.
const ZERO_WIDTH = /[\u200B-\u200D\u2060\uFEFF]/g;

/**
 * Per sheet: id prefix, mandatory text columns, enum columns (mandatory too, in the order checked)
 * and the optional whole-number column. Columns are found by header text.
 */
export const LIBRARY_SPECS = {
  'Assumption library': {
    prefix: 'asm-',
    text: ['statement', 'if it fails'],
    enums: [
      { column: 'category', values: ASSUMPTION_CATEGORIES },
      { column: 'confidence', values: LEVELS }
    ]
  },
  'Dependency library': {
    prefix: 'dep-',
    text: ['statement', 'owner', 'needed', 'impact if missing'],
    enums: [{ column: 'priority', values: PRIORITIES }],
    week: 'required week'
  },
  'Risk library': {
    prefix: 'risk-',
    text: ['statement', 'impact', 'mitigation'],
    enums: [
      { column: 'likelihood', values: LEVELS },
      { column: 'severity', values: LEVELS }
    ]
  }
};

/** Every column header a spec reads, so callers can check them against the sheet definition. */
export function libraryColumns(spec) {
  return [
    ...COMMON_COLUMNS,
    ...spec.text,
    ...spec.enums.map((entry) => entry.column),
    ...(spec.week ? [spec.week] : [])
  ];
}

function clean(text) {
  return (text ?? '').replace(ZERO_WIDTH, '').trim();
}

function columnIndex(sheet, header) {
  const index = sheet.headers.indexOf(header);
  if (index < 0) {
    throw new Error(`${sheet.name}: the library check expects a "${header}" column`);
  }
  return index;
}

/** Errors for one library sheet, in row order. Sheets that are not libraries return no errors. */
export function validateLibrarySheet(sheet) {
  const spec = LIBRARY_SPECS[sheet.name];
  if (!spec) {
    return [];
  }
  // Resolve every column first, so a missing one fails even when the sheet has no rows.
  const columns = {};
  libraryColumns(spec).forEach((header) => {
    columns[header] = columnIndex(sheet, header);
  });
  if (sheet.rows.length === 0) {
    return [`${sheet.file}: the sheet has no entries`];
  }

  const errors = [];
  const firstRowById = new Map();

  sheet.rows.forEach((row, index) => {
    const rowNumber = sheet.lines ? sheet.lines[index] : index + 2;
    const fail = (message) => errors.push(`${sheet.file}: row ${rowNumber}: ${message}`);
    const cell = (header) => clean(row[columns[header]]);

    const id = cell(ID);
    if (id === '') {
      fail('library id is blank');
    } else {
      if (!id.startsWith(spec.prefix) || !KEBAB_CASE.test(id)) {
        fail(`library id "${id}" must be lowercase kebab-case starting with "${spec.prefix}"`);
      }
      const first = firstRowById.get(id);
      if (first === undefined) {
        firstRowById.set(id, rowNumber);
      } else {
        fail(`duplicate library id "${id}" (first on row ${first})`);
      }
    }

    const platform = cell(PLATFORM);
    if (KNOWN_PLATFORMS.indexOf(platform) < 0) {
      fail(`platform "${platform}" is not recognised (expected ${KNOWN_PLATFORMS.join(', ')})`);
    }

    const hints = cell(HINTS);
    if (hints === '') {
      if (platform !== ALL_PLATFORM) {
        fail(`match hints are blank (only platform "${ALL_PLATFORM}" may leave them blank)`);
      }
    } else if (hints.split(';').some((hint) => clean(hint) === '')) {
      fail('match hints contain an empty entry');
    }

    spec.text.forEach((header) => {
      if (cell(header) === '') {
        fail(`"${header}" is blank`);
      }
    });

    spec.enums.forEach(({ column, values }) => {
      const value = cell(column);
      if (value === '') {
        fail(`"${column}" is blank`);
      } else if (values.indexOf(value) < 0) {
        fail(`"${column}" value "${value}" must be one of ${values.join(', ')}`);
      }
    });

    if (spec.week) {
      const week = cell(spec.week);
      if (week !== '' && !WHOLE_NUMBER.test(week)) {
        fail(`"${spec.week}" value "${week}" must be a whole number of 1 or more, or blank`);
      }
    }
  });

  return errors;
}

/** Errors for every library sheet in the list; other sheets are ignored. */
export function validateLibraries(sheets) {
  return sheets.flatMap((sheet) => validateLibrarySheet(sheet));
}

/**
 * Errors when the list does not match the specs: a spec with no sheet, or a library file whose
 * sheet has no spec. Without this, renaming a sheet would switch its check off silently.
 */
export function validateLibrarySet(sheets) {
  const errors = [];
  Object.keys(LIBRARY_SPECS).forEach((name) => {
    if (!sheets.some((sheet) => sheet.name === name)) {
      errors.push(`library check: the "${name}" sheet was not loaded`);
    }
  });
  sheets.forEach((sheet) => {
    if (!LIBRARY_SPECS[sheet.name] && /-library\.csv$/.test(sheet.file ?? '')) {
      errors.push(`${sheet.file}: sheet "${sheet.name}" has no library check; add it to LIBRARY_SPECS`);
    }
  });
  return errors;
}

/** Throws one Error listing every problem, or returns when the libraries are valid. */
export function assertLibraries(sheets) {
  const errors = [...validateLibrarySet(sheets), ...validateLibraries(sheets)];
  if (errors.length > 0) {
    throw new Error(errors.join('\n'));
  }
}
