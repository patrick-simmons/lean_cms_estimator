import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { describe, it } from 'node:test';
import { fileURLToPath } from 'node:url';
import { SHEETS, loadSeed } from './seed.mjs';
import {
  ASSUMPTION_CATEGORIES,
  KNOWN_PLATFORMS,
  LEVELS,
  LIBRARY_SPECS,
  PRIORITIES,
  assertLibraries,
  libraryColumns,
  validateLibraries,
  validateLibrarySet,
  validateLibrarySheet
} from './validate-libraries.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const ASSUMPTIONS = 'Assumption library';
const DEPENDENCIES = 'Dependency library';
const RISKS = 'Risk library';

const seed = Object.fromEntries(loadSeed().map((sheet) => [sheet.name, sheet]));

/** A copy of a seed sheet with the given rows (default: the seed rows). */
function sheetWith(name, rows = seed[name].rows) {
  return { ...seed[name], rows: rows.map((row) => row.slice()) };
}

/** Seed sheet with row `rowNumber` (2 = first data row) changing one named column. */
function withCell(name, rowNumber, header, value) {
  const sheet = sheetWith(name);
  sheet.rows[rowNumber - 2][sheet.headers.indexOf(header)] = value;
  return sheet;
}

function assertErrors(sheet, ...expected) {
  assert.deepEqual(validateLibrarySheet(sheet), expected);
}

describe('library check on the committed seeds', () => {
  it('passes', () => {
    assert.deepEqual(validateLibraries(Object.values(seed)), []);
    assert.doesNotThrow(() => assertLibraries(Object.values(seed)));
  });

  it('ignores sheets that are not libraries', () => {
    assert.deepEqual(validateLibrarySheet(seed.Skills), []);
    assert.deepEqual(validateLibrarySheet(seed['Phase packs']), []);
  });
});

describe('library ids', () => {
  it('reports a blank id', () => {
    assertErrors(withCell(ASSUMPTIONS, 2, 'library id', ' '), 'assumption-library.csv: row 2: library id is blank');
  });

  it('reports a duplicate id, naming the first row', () => {
    const first = seed[ASSUMPTIONS].rows[0][0];
    assertErrors(
      withCell(ASSUMPTIONS, 4, 'library id', first),
      `assumption-library.csv: row 4: duplicate library id "${first}" (first on row 2)`
    );
  });

  it('reports the wrong prefix for the sheet', () => {
    assertErrors(
      withCell(RISKS, 3, 'library id', 'dep-key-person'),
      'risk-library.csv: row 3: library id "dep-key-person" must be lowercase kebab-case starting with "risk-"'
    );
  });

  it('reports ids that are not lowercase kebab-case', () => {
    ['dep-Env-access', 'dep_env_access', 'dep-env--access', 'dep-', 'dep-env access'].forEach((id) => {
      const errors = validateLibrarySheet(withCell(DEPENDENCIES, 2, 'library id', id));
      assert.equal(errors.length, 1, id);
      assert.match(errors[0], /^dependency-library\.csv: row 2: library id ".*" must be lowercase kebab-case/);
    });
  });
});

describe('platform and match hints', () => {
  it('reports an unknown, blank or wrong-case platform and lists the known ones', () => {
    ['aemm', 'AEM', ''].forEach((platform) => {
      assertErrors(
        withCell(RISKS, 2, 'platform', platform),
        `risk-library.csv: row 2: platform "${platform}" is not recognised (expected all, aem, aem-eds, aep)`
      );
    });
  });

  it('allows blank hints for platform all, and only there', () => {
    const hinted = seed[ASSUMPTIONS].rows.findIndex((row) => row[1] === 'all' && row[2].trim() !== '') + 2;
    assert.deepEqual(validateLibrarySheet(withCell(ASSUMPTIONS, hinted, 'match hints', '')), []);
    const aemRow = seed[ASSUMPTIONS].rows.findIndex((row) => row[1] === 'aem') + 2;
    assertErrors(
      withCell(ASSUMPTIONS, aemRow, 'match hints', ''),
      `assumption-library.csv: row ${aemRow}: match hints are blank (only platform "all" may leave them blank)`
    );
  });

  it('reports an empty hint entry', () => {
    ['a;;b', 'a; b;', ';a', ' ; '].forEach((hints) => {
      assertErrors(
        withCell(DEPENDENCIES, 3, 'match hints', hints),
        'dependency-library.csv: row 3: match hints contain an empty entry'
      );
    });
  });
});

describe('statements and defaults', () => {
  it('treats zero-width characters like blanks', () => {
    ['\u200B', '\u2060\u200C', '\uFEFF '].forEach((blank) => {
      assert.deepEqual(validateLibrarySheet(withCell(RISKS, 2, 'statement', blank)), [
        'risk-library.csv: row 2: "statement" is blank'
      ]);
    });
    assertErrors(
      withCell(DEPENDENCIES, 3, 'match hints', 'a;\u200B'),
      'dependency-library.csv: row 3: match hints contain an empty entry'
    );
    assertErrors(
      withCell(DEPENDENCIES, 2, 'library id', '\u200B'),
      'dependency-library.csv: row 2: library id is blank'
    );
  });

  it('reports a blank statement', () => {
    [ASSUMPTIONS, DEPENDENCIES, RISKS].forEach((name) => {
      const errors = validateLibrarySheet(withCell(name, 2, 'statement', '  '));
      assert.deepEqual(errors, [`${seed[name].file}: row 2: "statement" is blank`]);
    });
  });

  it('reports each blank mandatory column', () => {
    const cases = [
      [ASSUMPTIONS, ['if it fails', 'category', 'confidence']],
      [DEPENDENCIES, ['owner', 'needed', 'impact if missing', 'priority']],
      [RISKS, ['impact', 'likelihood', 'severity', 'mitigation']]
    ];
    cases.forEach(([name, columns]) => {
      columns.forEach((column) => {
        assert.deepEqual(validateLibrarySheet(withCell(name, 2, column, '')), [
          `${seed[name].file}: row 2: "${column}" is blank`
        ]);
      });
    });
  });

  it('reports an out-of-range enum with the allowed values', () => {
    assertErrors(
      withCell(ASSUMPTIONS, 2, 'category', 'commercial'),
      'assumption-library.csv: row 2: "category" value "commercial" must be one of scope, architecture, dependency, resource, delivery, estimate'
    );
    assertErrors(
      withCell(ASSUMPTIONS, 2, 'confidence', 'certain'),
      'assumption-library.csv: row 2: "confidence" value "certain" must be one of low, medium, high'
    );
    assertErrors(
      withCell(DEPENDENCIES, 2, 'priority', 'urgent'),
      'dependency-library.csv: row 2: "priority" value "urgent" must be one of high, medium, low'
    );
    assertErrors(
      withCell(RISKS, 2, 'likelihood', 'Medium'),
      'risk-library.csv: row 2: "likelihood" value "Medium" must be one of low, medium, high'
    );
    assertErrors(
      withCell(RISKS, 2, 'severity', 'extreme'),
      'risk-library.csv: row 2: "severity" value "extreme" must be one of low, medium, high'
    );
  });
});

describe('required week', () => {
  it('accepts a blank or a whole number of 1 or more', () => {
    assert.deepEqual(validateLibrarySheet(withCell(DEPENDENCIES, 2, 'required week', '')), []);
    assert.deepEqual(validateLibrarySheet(withCell(DEPENDENCIES, 2, 'required week', '12')), []);
  });

  it('rejects zero, negatives, decimals, text, exponents and leading zeros', () => {
    ['0', '-1', '2.5', 'abc', '1e1', '01'].forEach((week) => {
      assertErrors(
        withCell(DEPENDENCIES, 2, 'required week', week),
        `dependency-library.csv: row 2: "required week" value "${week}" must be a whole number of 1 or more, or blank`
      );
    });
  });
});

describe('error reporting', () => {
  it('numbers rows from 2 and reports every problem in row order', () => {
    const sheet = withCell(RISKS, 4, 'statement', '');
    sheet.rows[0][sheet.headers.indexOf('severity')] = 'bad';
    assert.deepEqual(validateLibrarySheet(sheet), [
      'risk-library.csv: row 2: "severity" value "bad" must be one of low, medium, high',
      'risk-library.csv: row 4: "statement" is blank'
    ]);
  });

  it('collects errors from several sheets into one thrown message', () => {
    const sheets = [
      withCell(ASSUMPTIONS, 2, 'statement', ''),
      sheetWith(DEPENDENCIES),
      withCell(RISKS, 2, 'platform', 'nope')
    ];
    assert.throws(
      () => assertLibraries(sheets),
      (error) => {
        const lines = error.message.split('\n');
        assert.equal(lines.length, 2);
        assert.match(lines[0], /^assumption-library\.csv: row 2:/);
        assert.match(lines[1], /^risk-library\.csv: row 2:/);
        return true;
      }
    );
  });

  it('reports the file line of a row, not its position, when lines are present', () => {
    const sheet = withCell(RISKS, 3, 'statement', '');
    sheet.lines = sheet.lines.map((line, index) => (index === 1 ? 9 : line));
    assertErrors(sheet, 'risk-library.csv: row 9: "statement" is blank');
  });

  it('reports a library sheet with no entries', () => {
    assertErrors(sheetWith(RISKS, []), 'risk-library.csv: the sheet has no entries');
  });

  it('fails loudly when a spec column is missing from the sheet headers', () => {
    const sheet = sheetWith(RISKS);
    sheet.headers = sheet.headers.filter((header) => header !== 'mitigation');
    assert.throws(() => validateLibrarySheet(sheet), /expects a "mitigation" column/);
    assert.throws(() => validateLibrarySheet({ ...sheet, rows: [] }), /expects a "mitigation" column/);
  });
});

describe('library set', () => {
  it('reports a spec whose sheet was not loaded', () => {
    assert.deepEqual(validateLibrarySet([seed[ASSUMPTIONS], seed[DEPENDENCIES]]), [
      'library check: the "Risk library" sheet was not loaded'
    ]);
    assert.throws(() => assertLibraries([seed[ASSUMPTIONS]]), /"Dependency library" sheet was not loaded/);
  });

  it('reports a library file whose sheet has no spec, instead of skipping it', () => {
    const renamed = { ...seed[RISKS], name: 'Risks library' };
    const errors = validateLibrarySet([seed[ASSUMPTIONS], seed[DEPENDENCIES], renamed]);
    assert.deepEqual(errors, [
      'library check: the "Risk library" sheet was not loaded',
      'risk-library.csv: sheet "Risks library" has no library check; add it to LIBRARY_SPECS'
    ]);
  });

  it('accepts the committed sheets, other sheets included', () => {
    assert.deepEqual(validateLibrarySet(Object.values(seed)), []);
  });
});

describe('library contract', () => {
  it('names every spec column in the matching SHEETS entry', () => {
    Object.keys(LIBRARY_SPECS).forEach((name) => {
      const definition = SHEETS.find((sheet) => sheet.name === name);
      assert.ok(definition, `${name} is on SHEETS`);
      libraryColumns(LIBRARY_SPECS[name]).forEach((column) => {
        assert.ok(definition.headers.indexOf(column) >= 0, `${name} has column "${column}"`);
      });
    });
  });

  it('pins the known platforms and covers every platform the libraries name', () => {
    assert.deepEqual(KNOWN_PLATFORMS, ['all', 'aem', 'aem-eds', 'aep']);
    Object.keys(LIBRARY_SPECS).forEach((name) => {
      seed[name].rows.forEach((row) => {
        assert.ok(KNOWN_PLATFORMS.indexOf(row[1].trim()) >= 0, `${name} platform ${row[1]}`);
      });
    });
  });

  it('keeps the enum lists equal to validate-context.mjs', () => {
    const source = readFileSync(join(here, '../blueprint/validate-context.mjs'), 'utf8');
    // Reads the quoted strings of `const NAME = [ ... ]`, whatever the quote style, spacing or
    // line breaks. Compared as sorted sets: the values are the contract, not their order.
    const list = (name) => {
      const match = new RegExp(`^\\s*(?:export\\s+)?const ${name}\\s*=\\s*\\[([^\\]]*)\\]`, 'm').exec(source);
      assert.ok(match, `${name} found in validate-context.mjs`);
      return Array.from(match[1].matchAll(/(['"])(.*?)\1/g), (m) => m[2]).sort();
    };
    assert.deepEqual([...LEVELS].sort(), list('LEVELS'));
    assert.deepEqual([...PRIORITIES].sort(), list('PRIORITIES'));
    assert.deepEqual([...ASSUMPTION_CATEGORIES].sort(), list('ASSUMPTION_CATEGORIES'));
  });
});
