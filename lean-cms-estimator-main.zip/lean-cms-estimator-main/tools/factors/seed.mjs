import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertLibraries } from './validate-libraries.mjs';
import { assertPhaseTasks } from './validate-phase-tasks.mjs';

/**
 * The delivery defaults the catalog owner maintains: CSV sheet definitions, the CSV parser and
 * loadSeed. The CSVs in samples/factors/seed are the surface people edit. There was once an .xlsx
 * built from them as well, but nothing read it back, so a second copy of the same data could only
 * ever go stale (story B-15). Contract: docs/spfx/delivery-defaults.md.
 */

// Keep in step with MAX_LAG_WEEKS in src/webparts/blueprint/projects/workingFile.ts.
const MAX_LAG_WEEKS = 520;

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '../..');
export const SEED_DIR = join(root, 'samples/factors/seed');

/** @typedef {{ name: string, file: string, headers: string[], numeric: Set<string> }} SheetDef */

/** @type {SheetDef[]} */
export const SHEETS = [
  {
    name: 'Skills',
    file: 'skills.csv',
    headers: ['skill id', 'name', 'category', 'inference hints'],
    numeric: new Set()
  },
  {
    name: 'Phase packs',
    file: 'phase-packs.csv',
    headers: [
      'phase id',
      'name',
      'default duration weeks',
      'after phase',
      'lag weeks'
    ],
    numeric: new Set(['default duration weeks', 'lag weeks'])
  },
  {
    name: 'Phase allocations',
    file: 'phase-allocations.csv',
    headers: ['phase id', 'skill id', 'fte'],
    numeric: new Set(['fte'])
  },
  {
    name: 'Phase ramps',
    file: 'phase-ramps.csv',
    headers: ['phase id', 'skill id', 'after milestone', 'fte'],
    numeric: new Set(['fte'])
  },
  {
    name: 'Blended rate',
    file: 'blended-rate.csv',
    headers: [
      'delivery mix name',
      'hourly blended rate',
      'default',
      'country',
      'monthly hours'
    ],
    numeric: new Set(['hourly blended rate', 'monthly hours'])
  },
  {
    name: 'Assumption library',
    file: 'assumption-library.csv',
    headers: [
      'library id',
      'platform',
      'match hints',
      'statement',
      'category',
      'confidence',
      'if it fails'
    ],
    numeric: new Set()
  },
  {
    name: 'Dependency library',
    file: 'dependency-library.csv',
    headers: [
      'library id',
      'platform',
      'match hints',
      'statement',
      'owner',
      'needed',
      'impact if missing',
      'priority',
      'required week'
    ],
    numeric: new Set(['required week'])
  },
  {
    name: 'Risk library',
    file: 'risk-library.csv',
    headers: [
      'library id',
      'platform',
      'match hints',
      'statement',
      'impact',
      'likelihood',
      'severity',
      'mitigation'
    ],
    numeric: new Set()
  },
  {
    name: 'Phase tasks',
    file: 'phase-tasks.csv',
    headers: [
      'phase id',
      'task id',
      'name',
      'kind',
      'start week',
      'duration weeks',
      'basis',
      'work package id',
      'owner skills',
      'hours',
      'deliverable',
      'scope',
      'calendar-bound'
    ],
    numeric: new Set(['start week', 'duration weeks', 'hours'])
  },
  {
    name: 'Phase task allocations',
    file: 'phase-task-allocations.csv',
    headers: ['task id', 'skill id', 'fte'],
    numeric: new Set(['fte'])
  },
  {
    name: 'Lanes',
    file: 'lanes.csv',
    headers: ['lane id', 'phase id', 'name', 'offset weeks', 'duration weeks', 'activities'],
    numeric: new Set(['offset weeks', 'duration weeks'])
  }
];

/**
 * Parse a simple CSV with optional double-quoted fields. Blank rows are dropped. The result has a
 * `lineNumbers` array with the file line each kept row starts on, so errors can name the real row.
 * A quote inside an unquoted field, or text after a closing quote, is an error.
 */
export function parseCsv(text) {
  const rows = [];
  const rowLines = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  let afterQuote = false;
  let line = 1;
  let rowLine = 1;
  const input = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (inQuotes) {
      if (ch === '"') {
        if (input[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
          afterQuote = true;
        }
      } else {
        if (ch === '\n') {
          line++;
        }
        field += ch;
      }
      continue;
    }
    if (afterQuote && ch !== ',' && ch !== '\n' && ch !== '\r') {
      throw new Error(`CSV line ${line} has text after a closing quote`);
    }
    if (ch === '"') {
      if (field.length > 0) {
        throw new Error(`CSV line ${line} has a quote inside an unquoted field`);
      }
      inQuotes = true;
      continue;
    }
    if (ch === ',') {
      row.push(field);
      field = '';
      afterQuote = false;
      continue;
    }
    if (ch === '\n') {
      row.push(field);
      rows.push(row);
      rowLines.push(rowLine);
      row = [];
      field = '';
      afterQuote = false;
      line++;
      rowLine = line;
      continue;
    }
    if (ch === '\r') {
      continue;
    }
    field += ch;
  }
  if (inQuotes) {
    throw new Error('CSV has an unclosed quote');
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
    rowLines.push(rowLine);
  }
  const kept = [];
  kept.lineNumbers = [];
  rows.forEach((r, index) => {
    if (r.some((cell) => cell.trim() !== '')) {
      kept.push(r);
      kept.lineNumbers.push(rowLines[index]);
    }
  });
  return kept;
}

export function cellValue(raw, header, numericHeaders, context) {
  const text = (raw ?? '').trim();
  if (text === '') {
    return null;
  }
  if (numericHeaders.has(header)) {
    const n = Number(text);
    if (!Number.isFinite(n)) {
      throw new Error(`${context}: "${header}" value "${text}" is not a number`);
    }
    return n;
  }
  return text;
}

export function loadSeed(seedDir = SEED_DIR) {
  const sheets = SHEETS.map((sheet) => {
    let rows;
    try {
      rows = parseCsv(readFileSync(join(seedDir, sheet.file), 'utf8'));
    } catch (error) {
      throw new Error(`${sheet.file}: ${error.message}`);
    }
    const [header, ...data] = rows;
    const lines = rows.lineNumbers.slice(1);
    if (!header || header.length !== sheet.headers.length) {
      throw new Error(`${sheet.file}: expected ${sheet.headers.length} header columns`);
    }
    for (let i = 0; i < sheet.headers.length; i++) {
      if (header[i].trim() !== sheet.headers[i]) {
        throw new Error(`${sheet.file}: column ${i + 1} is "${header[i]}", expected "${sheet.headers[i]}"`);
      }
    }
    data.forEach((row, index) => {
      if (row.length !== sheet.headers.length) {
        throw new Error(
          `${sheet.file}: row ${lines[index]} has ${row.length} columns, expected ${sheet.headers.length}`
        );
      }
      const lagIndex = sheet.headers.indexOf('lag weeks');
      if (lagIndex >= 0) {
        const lag = row[lagIndex].trim();
        if (lag !== '' && !/^-?\d+$/.test(lag)) {
          throw new Error(
            `${sheet.file}: row ${lines[index]}: "lag weeks" value "${lag}" must be a whole number, or blank`
          );
        }
        if (Math.abs(Number(lag)) > MAX_LAG_WEEKS) {
          throw new Error(
            `${sheet.file}: row ${lines[index]}: "lag weeks" value "${lag}" must be from -${MAX_LAG_WEEKS} to ${MAX_LAG_WEEKS}`
          );
        }
      }
    });
    return {
      name: sheet.name,
      headers: sheet.headers,
      numeric: sheet.numeric,
      file: sheet.file,
      rows: data,
      lines
    };
  });
  // Runs after every file is structurally valid, so a header or width error is reported first.
  assertLibraries(sheets);
  assertPhaseTasks(sheets);
  return sheets;
}
