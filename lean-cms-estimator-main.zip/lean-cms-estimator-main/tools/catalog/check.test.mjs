import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';
import { checkCatalogs, countReferences } from './check.mjs';
import { buildCmkCatalog } from './cmk-model.mjs';
import { renderCmkCatalog } from './cmk-render.mjs';
import {
  baseSummaries, buildFiles, buildToolkitFiles, estimatingV2Text, META, TOOLKIT_META, TOOLKIT_PLUGINS,
  V2_ACTIVITIES, V2_CAPABILITIES, V2_METHODS
} from './fixtures.mjs';
import { parseCmkCatalog, parseEstimatingCatalog } from './parse.mjs';
import { buildToolkitCatalog } from './toolkit-model.mjs';
import { parseToolkitCatalog } from './toolkit-parse.mjs';
import { renderToolkitCatalog } from './toolkit-render.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const cmk = parseCmkCatalog(renderCmkCatalog(buildCmkCatalog(buildFiles(), META, baseSummaries())));
const toolkit = parseToolkitCatalog(renderToolkitCatalog(buildToolkitCatalog(buildToolkitFiles(), TOOLKIT_META, TOOLKIT_PLUGINS)));
const pins = { cmkPin: { commit: META.commit }, toolkitPin: { commit: TOOLKIT_META.commit } };

function replaced(rows, index, from, to) {
  const copy = rows.slice();
  if (copy[index].indexOf(from) === -1) {
    throw new Error(`fixture row ${index} has no ${from}`);
  }
  copy[index] = copy[index].replace(from, to);
  return copy;
}

function errorsFor(options = {}, overrides = {}) {
  return checkCatalogs({ cmk, toolkit, estimating: parseEstimatingCatalog(estimatingV2Text(options)), ...pins, ...overrides });
}

function expectError(options, pattern, overrides) {
  const errors = errorsFor(options, overrides);
  assert.ok(errors.some((error) => pattern.test(error)), `${pattern}\n${errors.join('\n')}`);
}

const act = (index, from, to) => ({ activities: replaced(V2_ACTIVITIES, index, from, to) });
const cap = (index, from, to) => ({ capabilities: replaced(V2_CAPABILITIES, index, from, to) });
const method = (from, to) => ({ methods: replaced(V2_METHODS, 0, from, to) });

describe('checkCatalogs', () => {
  it('accepts a valid catalog, with human-led packages and CMK all-platform ids in platform rows', () => {
    assert.deepEqual(errorsFor(), []);
    assert.deepEqual(errorsFor(cap(2, '`vshared-share` (opt-in)', '`vshared-share` (opt-in), `cmk-beta`')), []);
    assert.deepEqual(errorsFor(cap(2, '`vshared-share` (opt-in)', '`vlocal-ops`')), []);
  });

  const failures = [
    ['an unknown id', cap(1, '`vone-build`', '`vone-missing`'), /shape-build plat-a: vone-missing is not in either generated catalog/],
    ['an id from another platform', cap(2, '`vshared-share` (opt-in)', '`vone-build`'), /shape-build plat-c: vone-build exists only on plat-a/],
    ['an unavailable id', cap(2, '`vshared-share` (opt-in)', '`voff-gone`'), /shape-build plat-c: voff-gone is unavailable at this commit/],
    ['a missing opt-in marker', cap(1, '`vtwo-deploy` (opt-in)', '`vtwo-deploy`'), /vtwo-deploy is opt-in and must be marked/],
    ['a spurious opt-in marker', cap(1, '`vone-build`', '`vone-build` (opt-in)'), /vone-build is a default capability/],
    ['a marked all-platform id', cap(0, '`cmk-alpha`', '`cmk-alpha` (opt-in)'), /shape-build all: cmk-alpha applies to all platforms/],
    ['an id listed twice in a row', cap(0, '`cmk-alpha`', '`cmk-alpha`, `cmk-alpha`'), /shape-build all: cmk-alpha is listed twice/],
    ['a malformed activity id', act(0, '`shape-build`', '`Shape Build`'), /^Shape Build: activity ids must be lower-case words joined by hyphens/],
    ['a duplicate activity id', act(1, '`shape-design`', '`shape-build`'), /^shape-build: duplicate activity id$/],
    ['a blank activity name', act(0, '| Build | Build |', '|  | Build |'), /^shape-build: name is blank$/],
    ['an unknown phase', act(0, '| Build | per-unit |', '| Delivery | per-unit |'), /^shape-build: phase delivery is not one of discover, design, build, assure, launch, run$/],
    ['an unknown shape', act(0, 'per-unit', 'per-widget'), /^shape-build: shape per-widget is not one of per-unit, tiered, proportional$/],
    ['an unknown owner', act(0, '| us |', '| them |'), /^shape-build: owner them is not one of us, shared$/],
    ['client as a default owner', act(0, '| us |', '| client |'), /^shape-build: owner client is not one of us, shared$/],
    ['a bad activity unit', act(0, '| component |', '| widget |'), /^shape-build: unit widget is not one of/],
    ['a per-unit activity with no unit', act(0, '| component |', '| — |'), /^shape-build: unit \(blank\) is not one of/],
    ['a unit on a tiered activity', act(1, '| tiered | — |', '| tiered | component |'), /^shape-design: only a per-unit activity has a unit$/],
    ['a proportional activity with no share set', act(2, '`shape-build`, `shape-design`', '—'), /^shape-manage: a proportional activity needs the activities it is a share of$/],
    ['a share set on a per-unit activity', act(0, '| partly | — |', '| partly | `shape-design` |'), /^shape-build: only a proportional activity is a share of other activities$/],
    ['a share of something that is not an activity', act(2, '`shape-design`', '`shape-missing`'), /^shape-manage: share of shape-missing, which is not an activity$/],
    ['everything-else mixed with named activities', act(3, '`everything-else`', '`everything-else`, `shape-build`'), /^shape-report: everything-else cannot be combined with named activities$/],
    ['an activity that is a share of itself', act(2, '`shape-build`, `shape-design`', '`shape-manage`'), /^shape-manage: share set is circular, through shape-manage -> shape-manage$/],
    ['two activities that are shares of each other', {
      activities: [
        '| `shape-build` | Build | Build | per-unit | component | Components | us | partly | — |',
        '| `shape-design` | Design | Design | proportional | — | Share of manage | us | human-led | `shape-manage` |',
        '| `shape-manage` | Manage | Run | proportional | — | Share of design | us | human-led | `shape-design` |'
      ]
    }, /share set is circular, through shape-design -> shape-manage -> shape-design/],
    ['no activities', { activities: [] }, /^estimating catalog has no activities$/],
    ['a missing Activities table', { omit: ['Activities'] }, /^no Activities table$/],
    ['a bad coverage', act(0, '| partly |', '| mostly |'), /^shape-build: default coverage mostly is not one of/],
    ['an accelerated activity with no ids', act(1, '| human-led |', '| accelerated |'), /^shape-design plat-a: a accelerated activity needs at least one capability$/],
    ['a blank sizing driver', act(0, '| Components |', '|  |'), /^shape-build: sizing driver is blank$/],
    ['a duplicate activity name whatever its case', act(1, '| Design |', '| build |'), /^shape-design: duplicate activity name build$/],
    ['an unknown opt-in coverage', cap(1, '| accelerated |', '| fast |'), /shape-build plat-a opt-in coverage: fast is not one of/],
    ['opt-in coverage without opt-in ids', cap(1, ', `vtwo-deploy` (opt-in)', ''), /set, but the plat-a cell has no \(opt-in\) capability/],
    ['opt-in coverage not higher', cap(1, '| accelerated |', '| partly |'), /must be higher than the default partly; use — when opt-in/],
    ['a blank opt-in coverage cell', cap(1, '| accelerated |', '|  |'), /shape-build plat-a opt-in coverage: empty cell/],
    ['a blank method coverage cell', cap(0, '| accelerated |', '|  |'), /shape-build all method coverage: empty cell/],
    ['an empty capability cell', cap(2, '`vshared-share` (opt-in)', ''), /shape-build plat-c: empty capability cell/],
    ['an id without backticks', cap(1, '`vone-build`', 'vone-build'), /shape-build plat-a: unreadable capability "vone-build"/],
    ['a misspelled opt-in marker', cap(1, '(opt-in)', '(optin)'), /shape-build plat-a: unreadable capability "`vtwo-deploy` \(optin\)"/],
    ['an extra cell', cap(0, '| accelerated |', '| accelerated | extra |'), /line \d+: has 6 cells, expected 5/],
    ['a vendor id in the all row', cap(0, '`cmk-alpha`', '`cmk-alpha`, `vone-build`'), /shape-build all: vone-build is specific to plat-a; move it to a platform row/],
    ['a toolkit id in a platform row', cap(1, '`vone-build`', '`vone-build`, `alpha:alpha-flow`'), /shape-build plat-a: alpha:alpha-flow is a toolkit id; list it in the all row or a delivery method/],
    ['a deprecated toolkit id', cap(0, '`alpha:alpha-plan`', '`alpha:alpha-old`'), /shape-build all: alpha:alpha-old is deprecated at toolkit fedcba9/],
    ['a toolkit id marked opt-in', cap(0, '`alpha:alpha-plan`', '`alpha:alpha-plan` (opt-in)'), /shape-build all: alpha:alpha-plan applies to all platforms and must not be marked \(opt-in\)/],
    ['an id in both the all row and a platform row', cap(1, '`vone-build`', '`vone-build`, `cmk-alpha`'), /shape-build plat-a: cmk-alpha is also in the all row/],
    ['a platform that is not a pilot', { capabilities: V2_CAPABILITIES.concat('| shape-build | plat-b | — | — | — |') }, /shape-build plat-b: platform must be all or a pilot platform \(plat-a, plat-c\)/],
    ['a row listed twice', { capabilities: V2_CAPABILITIES.concat('| shape-build | plat-a | — | — | — |') }, /shape-build plat-a: listed twice/],
    ['a missing row', { capabilities: V2_CAPABILITIES.slice(0, 5) }, /shape-design plat-c: missing row; use — for none/],
    ['opt-in coverage on the all row', cap(0, '| — | accelerated |', '| accelerated | accelerated |'), /shape-build all opt-in coverage: must be —/],
    ['method coverage on a platform row', cap(2, '| — | — |', '| — | accelerated |'), /shape-build plat-c method coverage: must be —; method coverage belongs on the all row/],
    ['method coverage not higher', cap(0, '| accelerated |', '| partly |'), /shape-build all method coverage: partly must be higher than the default partly; use — when methods make no difference/],
    ['an unknown method coverage', cap(0, '| accelerated |', '| fast |'), /shape-build all method coverage: fast is not one of/],
    ['method coverage with no method', method('`shape-build`, `shape-design`', '`shape-build`'), /shape-design all method coverage: set, but no delivery method applies to shape-design/],
    ['a bad method id', method('`build-loop`', '`Build Loop`'), /line \d+: method id Build Loop must be lowercase words joined by hyphens/],
    ['a duplicate method', { methods: V2_METHODS.concat(V2_METHODS[0]) }, /method build-loop: listed twice/],
    ['a method with no capabilities', method('`beta:beta-build`, `beta:beta-checker`, `cmk-alpha-agent`', '—'), /method build-loop: needs at least one capability/],
    ['a vendor id in a method', method('`cmk-alpha-agent`', '`vone-build`'), /method build-loop: vone-build is specific to plat-a; methods apply to every platform/],
    ['an opt-in marker in a method', method('`cmk-alpha-agent`', '`cmk-alpha-agent` (opt-in)'), /method build-loop: cmk-alpha-agent must not be marked \(opt-in\)/],
    ['a deprecated id in a method', method('`cmk-alpha-agent`', '`alpha:alpha-old`'), /method build-loop: alpha:alpha-old is deprecated at toolkit fedcba9/],
    ['an unknown id in a method', method('`cmk-alpha-agent`', '`gamma:nothing`'), /method build-loop: gamma:nothing is not in either generated catalog/],
    ['an id twice in a method', method('`cmk-alpha-agent`', '`beta:beta-build`'), /method build-loop: beta:beta-build is listed twice/],
    ['a method for an unknown activity', method('`shape-build`, `shape-design`', '`shape-build`, `shape-design`, `shape-ghost`'), /method build-loop: activity shape-ghost is not in the Activities table/],
    ['a method for no activity', method('`shape-build`, `shape-design`', '—'), /method build-loop: applies to no activity/],
    ['an activity listed twice in a method', method('`shape-build`, `shape-design`', '`shape-build`, `shape-design`, `shape-build`'), /method build-loop: shape-build is listed twice/],
    ['a default that is not yes or no', method('| yes |', '| maybe |'), /method build-loop: Default must be yes or no/],
    ['blank prerequisites', method('A ticket per change', '—'), /method build-loop: prerequisites are blank/],
    ['a toolkit id in an all row and a method', cap(0, '`alpha:alpha-plan`', '`alpha:alpha-plan`, `beta:beta-build`'), /shape-build all: beta:beta-build is also in method build-loop; list it once/],
    ['a toolkit id in two all rows', cap(3, '| all | — |', '| all | `alpha:alpha-plan` |'), /shape-design all: alpha:alpha-plan is also in the shape-build all row/],
    ['a wrong catalog name', { front: { catalog: 'other' } }, /must say catalog: estimating-catalog/],
    ['a v1 version', { front: { version: 1 } }, /version must be a whole number of 2 or more for the three-table format/],
    ['a fractional version', { front: { version: 1.5 } }, /version must be a whole number of 2 or more/],
    ['no pilot platforms', { front: { pilotPlatforms: undefined } }, /estimating catalog has no pilotPlatforms/],
    ['a missing toolkitCommit', { front: { toolkitCommit: undefined } }, /estimating catalog toolkitCommit \(none\) does not match the pin fedcba98/],
    ['a cmkCommit that does not match the pin', { front: { cmkCommit: 'f'.repeat(40) } }, /estimating catalog cmkCommit f{40} does not match the pin 01234567/],
    ['swapped activity columns', { headers: { Activities: '| Name | Id | Phase | Shape | Unit | Sizing driver | Owner | Default coverage | Share of |' } }, /Activities columns must be: Id \| Name/],
    ['a capabilities table with old columns', { headers: { Capabilities: '| Activity | Platform | Capabilities | Opt-in coverage | Notes |' } }, /Capabilities columns must be: Activity/],
    ['a missing Delivery methods table', { omit: ['Delivery methods'] }, /^no Delivery methods table$/],
    ['rows cut off by a blank line', { activities: V2_ACTIVITIES.slice(0, 1).concat('', V2_ACTIVITIES.slice(1)) }, /^Activities: rows on line 17, 18, 19 are cut off from the table/],
    ['capability rows cut off by a blank line', { capabilities: V2_CAPABILITIES.slice(0, 1).concat('', V2_CAPABILITIES.slice(1)) }, /^Capabilities: rows on line 26, 27, 28, /],
    ['method rows cut off by a blank line', { methods: [''].concat(V2_METHODS) }, /^Delivery methods: rows on line 42 are cut off from the table/],
    ['no delivery methods', { methods: [] }, /^estimating catalog has no delivery methods$/],
    ['an unknown id in the all row', cap(0, '`cmk-alpha`', '`cmk-missing`'), /^shape-build all: cmk-missing is not in either generated catalog$/],
    ['an unknown activity on its line', { capabilities: V2_CAPABILITIES.concat('| `shape-ghost` | all | — | — | — |') }, /^line 36: activity shape-ghost is not in the Activities table$/],
    ['a bad method id on its line', method('`build-loop`', '`Build Loop`'), /^line 41: method id Build Loop must be/],
    ['an unreadable id in a method', method('`cmk-alpha-agent`', 'cmk-alpha-agent'), /^method build-loop: unreadable capability "cmk-alpha-agent"$/],
    ['an empty prerequisites cell', method('A ticket per change', ''), /^method build-loop: prerequisites are blank$/],
    ['a pilot platform named all', { front: { pilotPlatforms: '[plat-a, all]' } }, /^pilot platform all is reserved for rows that apply to every platform$/],
    ['a CMK pin that is not a full SHA', { front: { cmkCommit: 'main' } }, /^CMK pin commit main must be a full 40-character commit SHA$/, { cmkPin: { commit: 'main' } }]
  ];
  failures.forEach(([name, options, pattern, overrides]) => {
    it(`reports ${name}`, () => expectError(options, pattern, overrides));
  });

  it('allows an id in more than one method, and a CMK id in both an all row and a method', () => {
    const second = '| `review-loop` | `beta:beta-build`, `cmk-alpha-agent` | `shape-build` | A reviewer per change | no |';
    assert.deepEqual(errorsFor({ methods: V2_METHODS.concat(second) }), []);
    assert.deepEqual(errorsFor(cap(0, '`cmk-alpha`', '`cmk-alpha`, `cmk-alpha-agent`')), []);
  });

  it('reports problems found while parsing the generated catalogs', () => {
    const cmkText = renderCmkCatalog(buildCmkCatalog(buildFiles(), META, baseSummaries()));
    const row = cmkText.split('\n').find((line) => line.startsWith('| `vend-one` |'));
    const brokenCmk = parseCmkCatalog(cmkText.split('\n').filter((line) => line !== row).join('\n'));
    expectError({}, /^CMK catalog plat-a capability vone-build: asset vend-one has no Vendor assets row/, { cmk: brokenCmk });
    const toolkitText = renderToolkitCatalog(buildToolkitCatalog(buildToolkitFiles(), TOOLKIT_META, TOOLKIT_PLUGINS));
    const brokenToolkit = parseToolkitCatalog(toolkitText.replace('| `alpha:alpha-old` | deprecated |', '| `alpha:alpha-old` | active |'));
    expectError({}, /^toolkit catalog front matter says 1 deprecated but the tables have 0/, { toolkit: brokenToolkit });
  });

  it('reports a pilot platform the generated catalog does not have', () => {
    const capabilities = V2_CAPABILITIES.map((row) => row.replace('| plat-c |', '| plat-z |'));
    expectError({ front: { pilotPlatforms: '[plat-a, plat-z]' }, capabilities }, /pilot platform plat-z is not in the generated CMK catalog/);
  });

  it('reports stale generated catalogs and pins that are not full SHAs', () => {
    const staleCmk = { ...cmk, frontMatter: { ...cmk.frontMatter, cmkCommit: 'f'.repeat(40) } };
    expectError({}, /generated CMK catalog is for f{40}, not the pin .*run npm run catalog:cmk/, { cmk: staleCmk });
    const staleToolkit = { ...toolkit, frontMatter: { ...toolkit.frontMatter, toolkitCommit: 'e'.repeat(40) } };
    expectError({}, /generated toolkit catalog is for e{40}, not the pin .*run npm run catalog:toolkit/, { toolkit: staleToolkit });
    expectError({ front: { toolkitCommit: 'HEAD' } }, /toolkit pin commit HEAD must be a full 40-character commit SHA/, { toolkitPin: { commit: 'HEAD' } });
  });

  it('reports an id that is in both generated catalogs', () => {
    const capabilities = new Map(toolkit.capabilities);
    capabilities.set('cmk-alpha', { plugin: 'alpha', kind: 'skill', status: 'active', description: 'Clash.' });
    expectError({}, /cmk-alpha is in both generated catalogs/, { toolkit: { ...toolkit, capabilities } });
  });

  it('counts references in capability rows and methods', () => {
    assert.equal(countReferences(parseEstimatingCatalog(estimatingV2Text())), 5 + 3);
  });
});

/**
 * The v1 work packages, each against the activities that now carry its capabilities. Two of
 * them split, so the check is that the union is unchanged: no capability was dropped on the
 * way across. Where a package's capabilities went is not always where its sizing went —
 * WP-13's skills are workflow and editorial skills, so they sit with those activities.
 */
const V1_CAPABILITIES = {
  'WP-01': { now: ['discovery-audit'], aem: ['cmk-audit', 'aem-cloud-code-assessment', 'aem-cloud-ensure-agents-md'], 'aem-eds': ['cmk-audit', 'aem-eds-content-audit', 'aem-eds-block-inventory', 'aem-eds-sitemap-audit'] },
  'WP-02': { now: ['content-model'], aem: ['cmk-model-content', 'cmk-validate-model', 'cmk-schema-deploy'], 'aem-eds': ['cmk-model-content', 'cmk-validate-model', 'aem-eds-content-modeling', 'aem-eds-ue-component-model'] },
  'WP-03': {
    now: ['component-build'],
    aem: ['cmk-scaffold-component', 'cmk-figma', 'aem-cloud-create-component'],
    'aem-eds': ['cmk-scaffold-component', 'cmk-figma', 'aem-eds-building-blocks', 'aem-eds-content-driven-development', 'aem-eds-block-collection-and-party', 'aem-eds-figma-to-content (opt-in)']
  },
  'WP-04': { now: ['component-review', 'accessibility-audit'], aem: ['cmk-review-component', 'cmk-a11y'], 'aem-eds': ['cmk-review-component', 'cmk-a11y', 'aem-eds-code-review', 'aem-eds-accessibility-fix (opt-in)'] },
  'WP-05': { now: ['integrations'], aem: [], 'aem-eds': [] },
  'WP-06': {
    now: ['content-migration'],
    aem: ['cmk-migration-assess', 'cmk-migration-plan', 'cmk-migration-script', 'cmk-seo-architect'],
    'aem-eds': ['cmk-migration-assess', 'cmk-migration-plan', 'cmk-migration-script', 'cmk-seo-architect', 'aem-eds-page-import (opt-in)', 'aem-eds-generate-import-html (opt-in)', 'aem-eds-preview-import (opt-in)']
  },
  'WP-07': { now: ['seo'], aem: ['cmk-seo-architect'], 'aem-eds': ['cmk-seo-architect', 'aem-eds-sitemap-audit', 'aem-eds-structured-data (opt-in)'] },
  'WP-08': { now: ['search'], aem: ['cmk-search-design'], 'aem-eds': ['cmk-search-design'] },
  'WP-09': { now: ['localization'], aem: ['cmk-localization-design'], 'aem-eds': ['cmk-localization-design'] },
  'WP-10': { now: ['multisite'], aem: ['cmk-multisite-design'], 'aem-eds': ['cmk-multisite-design', 'aem-eds-create-site'] },
  'WP-11': { now: ['qa-automation'], aem: ['cmk-qa-generate-cms-tests', 'cmk-perf-audit'], 'aem-eds': ['cmk-qa-generate-cms-tests', 'cmk-perf-audit', 'aem-eds-testing-blocks'] },
  'WP-12': { now: ['environments-devops'], aem: ['aem-cloud-dispatcher', 'aem-cloud-rde (opt-in)', 'aem-cloud-content-distribution (opt-in)', 'aem-cloud-migration (opt-in)'], 'aem-eds': ['aem-eds-cli'] },
  'WP-13': { now: ['workflow-governance', 'editorial-production'], aem: ['cmk-govern-workflow', 'cmk-workflow-implement', 'cmk-editorial-qa', 'aem-cloud-workflow'], 'aem-eds': ['cmk-govern-workflow', 'cmk-editorial-qa'] },
  'WP-15': { now: ['frontend-delivery'], aem: ['cmk-headless-design'], 'aem-eds': ['cmk-headless-design', 'aem-eds-cwv-optimizer (opt-in)'] }
};

describe('committed catalogs', () => {
  const read = (name) => readFileSync(join(root, 'docs', 'catalogs', name), 'utf8');
  const realPins = {
    cmkPin: JSON.parse(readFileSync(join(root, 'tools', 'cmk-catalog.pin.json'), 'utf8')),
    toolkitPin: JSON.parse(readFileSync(join(root, 'tools', 'toolkit-catalog.pin.json'), 'utf8'))
  };
  const real = parseEstimatingCatalog(read('estimating-catalog.md'));

  it('pass the check with 25 activities, 75 capability rows and five methods', () => {
    const errors = checkCatalogs({ cmk: parseCmkCatalog(read('cmk-capability-catalog.md')), toolkit: parseToolkitCatalog(read('toolkit-capability-catalog.md')), estimating: real, ...realPins });
    assert.deepEqual(errors, []);
    assert.equal(real.frontMatter.version, 4);
    assert.equal(real.activities.length, 25);
    assert.equal(real.capabilities.length, 75);
    assert.deepEqual(real.methods.map((item) => item.id), ['cdk-loop', 'pdk-product', 'ld-quality', 'ld-bug', 'adr']);
    assert.deepEqual(real.methods.filter((item) => item.isDefault === 'yes').map((item) => item.id), ['cdk-loop', 'ld-quality']);
  });

  it('keep every v1 CMK and vendor capability, and the v1 opt-in coverage', () => {
    const label = (item) => `${item.id}${item.optIn ? ' (opt-in)' : ''}`;
    Object.keys(V1_CAPABILITIES).forEach((wp) => {
      const rows = real.capabilities.filter((row) => V1_CAPABILITIES[wp].now.indexOf(row.wp) !== -1);
      ['aem', 'aem-eds'].forEach((platform) => {
        const kept = rows.filter((row) => row.platform === 'all' || row.platform === platform);
        const actual = [...new Set(kept.flatMap((row) => row.items).filter((item) => item.id.indexOf(':') === -1).map(label))].sort();
        assert.deepEqual(actual, V1_CAPABILITIES[wp][platform].slice().sort(), `${wp} ${platform}`);
      });
    });
    const optIn = real.capabilities.filter((row) => row.optInCoverage !== '').map((row) => `${row.wp} ${row.platform} ${row.optInCoverage}`);
    assert.deepEqual(optIn, ['frontend-delivery aem-eds accelerated', 'environments-devops aem accelerated']);
  });

  it('carry the accepted method coverage', () => {
    const method = real.capabilities.filter((row) => row.methodCoverage !== '').map((row) => `${row.wp} ${row.methodCoverage}`);
    assert.deepEqual(method, ['frontend-delivery accelerated', 'integrations accelerated', 'search accelerated']);
  });
});
