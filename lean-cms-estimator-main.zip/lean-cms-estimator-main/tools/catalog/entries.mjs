import { CatalogError, isMapping, splitFrontMatter } from './text.mjs';

export function byId(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}

export function normalizeText(value) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function readFrontMatter(text, path) {
  const { data } = splitFrontMatter(text, path);
  if (data === undefined) {
    throw new CatalogError(`${path} has no frontmatter`);
  }
  if (!isMapping(data)) {
    throw new CatalogError(`${path} frontmatter is not a mapping`);
  }
  return data;
}

export function readEntries(files, pattern, { matchDirectory }) {
  const entries = [];
  for (const [path, text] of files) {
    if (!pattern.test(path)) {
      continue;
    }
    const data = readFrontMatter(text, path);
    const id = normalizeText(data.name);
    if (id.length === 0) {
      throw new CatalogError(`${path} has no name`);
    }
    if (matchDirectory && path.split('/')[1] !== id) {
      throw new CatalogError(`${path} name ${id} does not match its directory`);
    }
    entries.push({ id, description: normalizeText(data.description) });
  }
  return entries.sort((a, b) => byId(a.id, b.id));
}
