const CODE = /^`([^`]+)`$/;
const HEADING = /^(#{1,6})\s+(.*)$/;

export function cell(text) {
  return String(text).replace(/\|/g, '\\|');
}

export function code(id) {
  return `\`${id}\``;
}

export function table(header, rows) {
  const lines = [`| ${header.join(' | ')} |`, `| ${header.map(() => '---').join(' | ')} |`];
  rows.forEach((row) => lines.push(`| ${row.map(cell).join(' | ')} |`));
  return lines;
}

export function splitRow(line) {
  const inner = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  const cells = [];
  let current = '';
  for (let index = 0; index < inner.length; index++) {
    const char = inner[index];
    if (char === '\\' && inner[index + 1] === '|') {
      current += '|';
      index++;
    } else if (char === '|') {
      cells.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  cells.push(current.trim());
  return cells;
}

export function parseTables(body) {
  const tables = [];
  const headings = [];
  const lines = body.split('\n');
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];
    const heading = HEADING.exec(line);
    if (heading) {
      headings[heading[1].length] = heading[2].trim();
      headings.length = heading[1].length + 1;
      continue;
    }
    if (line.trim().startsWith('|') && (lines[index + 1] ?? '').trim().startsWith('| ---')) {
      const start = index;
      const header = splitRow(line);
      const rows = [];
      index += 2;
      while (index < lines.length && lines[index].trim().startsWith('|')) {
        rows.push(splitRow(lines[index]));
        index++;
      }
      tables.push({ headings: headings.filter((item) => item !== undefined), header, rows, start, end: index });
      index--;
    }
  }
  return tables;
}

export function sectionRange(lines, title) {
  const start = lines.findIndex((line) => {
    const heading = HEADING.exec(line);
    return Boolean(heading) && heading[1].length === 2 && heading[2].trim() === title;
  });
  if (start === -1) {
    return undefined;
  }
  const next = lines.findIndex((line, index) => {
    const heading = HEADING.exec(line);
    return index > start && Boolean(heading) && heading[1].length <= 2;
  });
  return { start, end: next === -1 ? lines.length : next };
}

export function strayRows(lines, table, bodyLine, title) {
  const range = sectionRange(lines, title);
  if (!range) {
    return [];
  }
  const stray = [];
  for (let index = range.start; index < range.end; index++) {
    if (lines[index].trim().startsWith('|') && (index < table.start || index >= table.end)) {
      stray.push(bodyLine + index + 1);
    }
  }
  return stray;
}

export function unwrapCode(value) {
  const match = CODE.exec(value.trim());
  return match ? match[1] : value.trim();
}
