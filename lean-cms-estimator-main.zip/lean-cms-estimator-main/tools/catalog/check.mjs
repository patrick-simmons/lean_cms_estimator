import { EVERYTHING_ELSE, referenceSetOf } from '../blueprint/proportional.mjs';
import { COMMIT_SHA } from './text.mjs';

export const UNITS = ['page', 'template', 'content-type', 'component', 'integration', 'site', 'locale', 'environment', 'author', 'asset', 'week'];
export const COVERAGE = ['human-led', 'partly', 'accelerated'];
export const ALL_PLATFORMS = 'all';
export const PHASES = ['discover', 'design', 'build', 'assure', 'launch', 'run'];
export const SHAPES = ['per-unit', 'tiered', 'proportional'];

/** `client` is a decision made on an estimate, never a default in the catalog. */
export const OWNERS = ['us', 'shared'];

/** Stands for every activity that does not itself use it, so the reporting activities do not size each other. */
export { EVERYTHING_ELSE };

const SLUG = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;

function rank(coverage) {
  return COVERAGE.indexOf(coverage);
}

export function pilotPlatforms(estimating) {
  const value = estimating.frontMatter.pilotPlatforms;
  return Array.isArray(value) ? value.map(String) : [];
}

function vendorPlatforms(cmk) {
  const found = new Map();
  cmk.platforms.forEach((capabilities, platform) => {
    capabilities.forEach((entry, id) => {
      found.set(id, (found.get(id) ?? []).concat(platform));
    });
  });
  return found;
}

function checkFrontMatter(ctx, errors) {
  const front = ctx.estimating.frontMatter;
  const pilots = pilotPlatforms(ctx.estimating);
  if (pilots.length === 0) {
    errors.push('estimating catalog has no pilotPlatforms');
  }
  if (front.catalog !== 'estimating-catalog') {
    errors.push('estimating catalog front matter must say catalog: estimating-catalog');
  }
  if (!Number.isInteger(front.version) || front.version < 2) {
    errors.push('estimating catalog version must be a whole number of 2 or more for the three-table format');
  }
  pilots.forEach((platform) => {
    if (platform === ALL_PLATFORMS) {
      errors.push(`pilot platform ${ALL_PLATFORMS} is reserved for rows that apply to every platform`);
    } else if (!ctx.cmk.platforms.has(platform)) {
      errors.push(`pilot platform ${platform} is not in the generated CMK catalog`);
    }
  });
  return pilots.filter((platform) => platform !== ALL_PLATFORMS);
}

function checkSource(source, errors) {
  const { name, pin, field, generated, script } = source;
  if (!COMMIT_SHA.test(String(pin.commit ?? ''))) {
    errors.push(`${name} pin commit ${pin.commit ?? '(none)'} must be a full 40-character commit SHA`);
  }
  if (String(source.estimated ?? '') !== pin.commit) {
    errors.push(`estimating catalog ${field} ${source.estimated ?? '(none)'} does not match the pin ${pin.commit}`);
  }
  if (String(generated ?? '') !== pin.commit) {
    errors.push(`generated ${name} catalog is for ${generated ?? '(none)'}, not the pin ${pin.commit}; run npm run ${script}`);
  }
}

function checkSources(ctx, errors) {
  const front = ctx.estimating.frontMatter;
  checkSource({ name: 'CMK', pin: ctx.cmkPin, field: 'cmkCommit', estimated: front.cmkCommit, generated: ctx.cmk.frontMatter.cmkCommit, script: 'catalog:cmk' }, errors);
  checkSource({ name: 'toolkit', pin: ctx.toolkitPin, field: 'toolkitCommit', estimated: front.toolkitCommit, generated: ctx.toolkit.frontMatter.toolkitCommit, script: 'catalog:toolkit' }, errors);
  const cmkIds = new Set(Array.from(ctx.cmk.allPlatforms.keys()).concat(Array.from(ctx.vendors.keys())).map((id) => id.toLowerCase()));
  ctx.toolkit.capabilities.forEach((entry, id) => {
    if (cmkIds.has(id.toLowerCase())) {
      errors.push(`${id} is in both generated catalogs`);
    }
  });
}

/**
 * A share set has to be resolvable in the fixed pass order, which means it must name activities
 * that exist and must not lead back to itself. A cycle here would be a runtime surprise in
 * `estimate`, where it would show up as hours that never settle.
 */
function checkShareSets(activities, errors) {
  const edges = new Map();
  activities.forEach((activity, id) => {
    if (activity.shape !== 'proportional') {
      edges.set(id, []);
      return;
    }
    if (activity.shareOf.includes(EVERYTHING_ELSE) && activity.shareOf.length > 1) {
      errors.push(`${id}: ${EVERYTHING_ELSE} cannot be combined with named activities`);
    }
    // The same expansion the estimate uses, so a set that checks out here resolves there.
    const references = referenceSetOf(id, activities);
    references
      .filter((reference) => !activities.has(reference))
      .forEach((reference) => errors.push(`${id}: share of ${reference}, which is not an activity`));
    edges.set(id, references.filter((reference) => activities.has(reference)));
  });

  const state = new Map();
  const walk = (id, trail) => {
    if (state.get(id) === 'done') {
      return;
    }
    if (state.get(id) === 'open') {
      errors.push(`${id}: share set is circular, through ${trail.join(' -> ')}`);
      return;
    }
    state.set(id, 'open');
    (edges.get(id) ?? []).forEach((next) => walk(next, trail.concat(next)));
    state.set(id, 'done');
  };
  activities.forEach((activity, id) => walk(id, [id]));
}

function checkActivities(ctx, errors) {
  const activities = new Map();
  const names = new Set();
  if (ctx.estimating.activities.length === 0) {
    errors.push('estimating catalog has no activities');
  }
  ctx.estimating.activities.forEach((activity) => {
    const where = activity.id || '(blank)';
    if (!SLUG.test(activity.id)) {
      errors.push(`${where}: activity ids must be lower-case words joined by hyphens, like content-migration`);
    } else if (activities.has(activity.id)) {
      errors.push(`${where}: duplicate activity id`);
    } else {
      activities.set(activity.id, activity);
    }
    if (activity.name.length === 0) {
      errors.push(`${where}: name is blank`);
    }
    if (PHASES.indexOf(activity.phase) === -1) {
      errors.push(`${where}: phase ${activity.phase || '(blank)'} is not one of ${PHASES.join(', ')}`);
    }
    if (SHAPES.indexOf(activity.shape) === -1) {
      errors.push(`${where}: shape ${activity.shape || '(blank)'} is not one of ${SHAPES.join(', ')}`);
    }
    if (OWNERS.indexOf(activity.owner) === -1) {
      errors.push(`${where}: owner ${activity.owner || '(blank)'} is not one of ${OWNERS.join(', ')}`);
    }
    if (activity.shape === 'per-unit') {
      if (UNITS.indexOf(activity.unit) === -1) {
        errors.push(`${where}: unit ${activity.unit || '(blank)'} is not one of ${UNITS.join(', ')}`);
      }
    } else if (activity.unit.length > 0) {
      errors.push(`${where}: only a per-unit activity has a unit`);
    }
    if (activity.shape === 'proportional') {
      if (activity.shareOf.length === 0) {
        errors.push(`${where}: a proportional activity needs the activities it is a share of`);
      }
    } else if (activity.shareOf.length > 0) {
      errors.push(`${where}: only a proportional activity is a share of other activities`);
    }
    if (activity.driver.length === 0) {
      errors.push(`${where}: sizing driver is blank`);
    }
    if (rank(activity.coverage) === -1) {
      errors.push(`${where}: default coverage ${activity.coverage || '(blank)'} is not one of ${COVERAGE.join(', ')}`);
    }
    if (names.has(activity.name.toLowerCase())) {
      errors.push(`${where}: duplicate activity name ${activity.name}`);
    }
    names.add(activity.name.toLowerCase());
  });
  checkShareSets(activities, errors);
  return activities;
}

function checkDeprecated(where, id, entry, ctx, errors) {
  if (entry.status === 'deprecated') {
    errors.push(`${where} ${id} is deprecated at toolkit ${ctx.toolkitShort}`);
  }
}

function checkItems(where, platform, items, ctx, errors) {
  const seen = new Set();
  let optInCount = 0;
  items.forEach((item) => {
    if (seen.has(item.id)) {
      errors.push(`${where} ${item.id} is listed twice`);
      return;
    }
    seen.add(item.id);
    const toolkitEntry = ctx.toolkit.capabilities.get(item.id);
    const everywhere = ctx.cmk.allPlatforms.has(item.id) || toolkitEntry !== undefined;
    if (everywhere && item.optIn) {
      errors.push(`${where} ${item.id} applies to all platforms and must not be marked (opt-in)`);
    }
    if (toolkitEntry) {
      if (platform !== ALL_PLATFORMS) {
        errors.push(`${where} ${item.id} is a toolkit id; list it in the all row or a delivery method`);
        return;
      }
      checkDeprecated(where, item.id, toolkitEntry, ctx, errors);
      return;
    }
    if (everywhere) {
      return;
    }
    const elsewhere = ctx.vendors.get(item.id) ?? [];
    if (platform === ALL_PLATFORMS) {
      errors.push(elsewhere.length > 0
        ? `${where} ${item.id} is specific to ${elsewhere.join(', ')}; move it to a platform row`
        : `${where} ${item.id} is not in either generated catalog`);
      return;
    }
    const entry = (ctx.cmk.platforms.get(platform) ?? new Map()).get(item.id);
    if (!entry) {
      errors.push(elsewhere.length > 0
        ? `${where} ${item.id} exists only on ${elsewhere.join(', ')}`
        : `${where} ${item.id} is not in either generated catalog`);
      return;
    }
    if (entry.status === 'unavailable') {
      errors.push(`${where} ${item.id} is unavailable at this commit`);
      return;
    }
    const isOptIn = entry.mode === 'opt_in';
    if (isOptIn) {
      optInCount++;
    }
    if (isOptIn && !item.optIn) {
      errors.push(`${where} ${item.id} is opt-in and must be marked (opt-in)`);
    } else if (!isOptIn && item.optIn) {
      errors.push(`${where} ${item.id} is a default capability and must not be marked (opt-in)`);
    }
  });
  return optInCount;
}

function checkCoverage(pkg, row, value, rule, errors) {
  if (value === '') {
    return;
  }
  const where = `${pkg.id} ${row.platform} ${rule.label}:`;
  if (rule.wrongRow) {
    errors.push(`${where} must be —; ${rule.wrongRow}`);
    return;
  }
  if (rank(value) === -1) {
    errors.push(`${where} ${value} is not one of ${COVERAGE.join(', ')}`);
    return;
  }
  if (rule.notApplicable) {
    errors.push(`${where} ${rule.notApplicable}`);
    return;
  }
  if (rank(pkg.coverage) !== -1 && rank(value) <= rank(pkg.coverage)) {
    errors.push(`${where} ${value} must be higher than the default ${pkg.coverage}; use — when ${rule.noDifference}`);
  }
}

function checkOptInCoverage(pkg, row, optInCount, errors) {
  checkCoverage(pkg, row, row.optInCoverage, {
    label: 'opt-in coverage',
    wrongRow: row.platform === ALL_PLATFORMS ? 'opt-in skills belong to a platform' : '',
    notApplicable: optInCount === 0 ? `set, but the ${row.platform} cell has no (opt-in) capability` : '',
    noDifference: 'opt-in makes no difference'
  }, errors);
}

function checkMethodCoverage(pkg, row, ctx, errors) {
  const applies = ctx.estimating.methods.some((method) => method.appliesTo.indexOf(pkg.id) !== -1);
  checkCoverage(pkg, row, row.methodCoverage, {
    label: 'method coverage',
    wrongRow: row.platform !== ALL_PLATFORMS ? 'method coverage belongs on the all row' : '',
    notApplicable: applies ? '' : `set, but no delivery method applies to ${pkg.id}`,
    noDifference: 'methods make no difference'
  }, errors);
}

function groupRows(ctx, activities, pilots, errors) {
  const grouped = new Map();
  ctx.estimating.capabilities.forEach((row) => {
    if (!activities.has(row.wp)) {
      errors.push(`line ${row.line}: activity ${row.wp || '(blank)'} is not in the Activities table`);
      return;
    }
    if (row.platform !== ALL_PLATFORMS && pilots.indexOf(row.platform) === -1) {
      errors.push(`${row.wp} ${row.platform || '(blank)'}: platform must be all or a pilot platform (${pilots.join(', ')})`);
      return;
    }
    const rows = grouped.get(row.wp) ?? new Map();
    grouped.set(row.wp, rows);
    if (rows.has(row.platform)) {
      errors.push(`${row.wp} ${row.platform}: listed twice`);
      return;
    }
    rows.set(row.platform, row);
  });
  return grouped;
}

function checkCapabilityRows(ctx, activities, pilots, errors) {
  const grouped = groupRows(ctx, activities, pilots, errors);
  activities.forEach((pkg, wp) => {
    const rows = grouped.get(wp) ?? new Map();
    [ALL_PLATFORMS].concat(pilots).forEach((platform) => {
      if (!rows.has(platform)) {
        errors.push(`${wp} ${platform}: missing row; use — for none`);
      }
    });
    const allRow = rows.get(ALL_PLATFORMS);
    const shared = new Set((allRow ? allRow.items : []).map((item) => item.id));
    if (allRow) {
      checkItems(`${wp} all:`, ALL_PLATFORMS, allRow.items, ctx, errors);
      checkOptInCoverage(pkg, allRow, 0, errors);
      checkMethodCoverage(pkg, allRow, ctx, errors);
    }
    pilots.forEach((platform) => {
      const row = rows.get(platform);
      if (!row) {
        return;
      }
      row.items.forEach((item) => {
        if (shared.has(item.id)) {
          errors.push(`${wp} ${platform}: ${item.id} is also in the all row`);
        }
      });
      const optInCount = checkItems(`${wp} ${platform}:`, platform, row.items, ctx, errors);
      if (pkg.coverage !== 'human-led' && shared.size === 0 && row.items.length === 0) {
        errors.push(`${wp} ${platform}: a ${pkg.coverage || '(blank)'} activity needs at least one capability`);
      }
      checkOptInCoverage(pkg, row, optInCount, errors);
      checkMethodCoverage(pkg, row, ctx, errors);
    });
  });
}

function checkMethodItems(where, method, ctx, errors) {
  const seen = new Set();
  method.items.forEach((item) => {
    if (seen.has(item.id)) {
      errors.push(`${where} ${item.id} is listed twice`);
      return;
    }
    seen.add(item.id);
    if (item.optIn) {
      errors.push(`${where} ${item.id} must not be marked (opt-in); methods apply to every platform`);
    }
    if (ctx.cmk.allPlatforms.has(item.id)) {
      return;
    }
    const entry = ctx.toolkit.capabilities.get(item.id);
    if (entry) {
      checkDeprecated(where, item.id, entry, ctx, errors);
      return;
    }
    const elsewhere = ctx.vendors.get(item.id) ?? [];
    errors.push(elsewhere.length > 0
      ? `${where} ${item.id} is specific to ${elsewhere.join(', ')}; methods apply to every platform`
      : `${where} ${item.id} is not in either generated catalog`);
  });
}

function checkMethods(ctx, activities, errors) {
  if (ctx.estimating.methods.length === 0) {
    errors.push('estimating catalog has no delivery methods');
  }
  const ids = new Set();
  ctx.estimating.methods.forEach((method) => {
    const where = `method ${method.id || '(blank)'}:`;
    if (!SLUG.test(method.id)) {
      errors.push(`line ${method.line}: method id ${method.id || '(blank)'} must be lowercase words joined by hyphens`);
    } else if (ids.has(method.id)) {
      errors.push(`${where} listed twice`);
    }
    ids.add(method.id);
    if (method.items.length === 0) {
      errors.push(`${where} needs at least one capability`);
    }
    checkMethodItems(where, method, ctx, errors);
    if (method.appliesTo.length === 0) {
      errors.push(`${where} applies to no activity`);
    }
    const seenPackages = new Set();
    method.appliesTo.forEach((wp) => {
      if (!activities.has(wp)) {
        errors.push(`${where} activity ${wp} is not in the Activities table`);
      } else if (seenPackages.has(wp)) {
        errors.push(`${where} ${wp} is listed twice`);
      }
      seenPackages.add(wp);
    });
    if (method.isDefault !== 'yes' && method.isDefault !== 'no') {
      errors.push(`${where} Default must be yes or no`);
    }
    if (method.prerequisites.length === 0) {
      errors.push(`${where} prerequisites are blank`);
    }
  });
}

function checkToolkitExclusive(ctx, errors) {
  const inMethods = new Map();
  ctx.estimating.methods.forEach((method) => {
    method.items.forEach((item) => {
      if (!inMethods.has(item.id)) {
        inMethods.set(item.id, method.id);
      }
    });
  });
  const inRows = new Map();
  ctx.estimating.capabilities
    .filter((row) => row.platform === ALL_PLATFORMS)
    .forEach((row) => {
      row.items
        .filter((item) => ctx.toolkit.capabilities.has(item.id))
        .forEach((item) => {
          if (inMethods.has(item.id)) {
            errors.push(`${row.wp} all: ${item.id} is also in method ${inMethods.get(item.id)}; list it once`);
          }
          if (inRows.has(item.id) && inRows.get(item.id) !== row.wp) {
            errors.push(`${row.wp} all: ${item.id} is also in the ${inRows.get(item.id)} all row; list it once or use a delivery method`);
          }
          if (!inRows.has(item.id)) {
            inRows.set(item.id, row.wp);
          }
        });
    });
}

export function checkCatalogs({ cmk, toolkit, estimating, cmkPin, toolkitPin }) {
  const ctx = {
    cmk,
    toolkit,
    estimating,
    cmkPin,
    toolkitPin,
    vendors: vendorPlatforms(cmk),
    toolkitShort: String(toolkitPin.commit ?? '').slice(0, 7)
  };
  const errors = cmk.errors.concat(toolkit.errors, estimating.errors);
  const pilots = checkFrontMatter(ctx, errors);
  checkSources(ctx, errors);
  const activities = checkActivities(ctx, errors);
  checkCapabilityRows(ctx, activities, pilots, errors);
  checkMethods(ctx, activities, errors);
  checkToolkitExclusive(ctx, errors);
  return errors;
}

export function countReferences(estimating) {
  const rows = estimating.capabilities.reduce((sum, row) => sum + row.items.length, 0);
  return estimating.methods.reduce((sum, method) => sum + method.items.length, rows);
}
