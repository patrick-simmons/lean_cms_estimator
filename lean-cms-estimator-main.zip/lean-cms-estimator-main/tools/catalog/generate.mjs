import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { buildCmkCatalog } from './cmk-model.mjs';
import { renderCmkCatalog } from './cmk-render.mjs';
import { normalizeToolkitPlugins, readPluginFiles, readToolkitFiles } from './git-tree.mjs';
import { CatalogError, isMapping, parseJson } from './text.mjs';
import { buildToolkitCatalog } from './toolkit-model.mjs';
import { renderToolkitCatalog } from './toolkit-render.mjs';

export function readJsonFile(path) {
  return parseJson(readFileSync(path, 'utf8'), path);
}

export function loadInputs(root) {
  return {
    pin: readJsonFile(join(root, 'tools', 'cmk-catalog.pin.json')),
    summaries: readJsonFile(join(root, 'tools', 'cmk-vendor-summaries.json'))
  };
}

export function validateToolkitPin(pin, path) {
  if (!isMapping(pin)) {
    throw new CatalogError(`${path} must be a JSON object`);
  }
  for (const key of ['repository', 'localPath']) {
    if (typeof pin[key] !== 'string' || pin[key].trim().length === 0) {
      throw new CatalogError(`${path} ${key} must be a non-empty string`);
    }
  }
  return { ...pin, ...normalizeToolkitPlugins(pin) };
}

export function loadToolkitPin(root) {
  const path = join(root, 'tools', 'toolkit-catalog.pin.json');
  return validateToolkitPin(readJsonFile(path), path);
}

export function generateCmkCatalog(tree, pin, summaries) {
  const files = readPluginFiles(tree, pin.pluginPath);
  const model = buildCmkCatalog(files, { repository: pin.repository, commit: pin.commit, commitDate: tree.commitDate }, summaries);
  return { files, model, text: renderCmkCatalog(model) };
}

export function generateToolkitCatalog(tree, pin) {
  const files = readToolkitFiles(tree, pin);
  const model = buildToolkitCatalog(files, { repository: pin.repository, commit: pin.commit, commitDate: tree.commitDate }, pin.plugins);
  return { files, model, text: renderToolkitCatalog(model) };
}
