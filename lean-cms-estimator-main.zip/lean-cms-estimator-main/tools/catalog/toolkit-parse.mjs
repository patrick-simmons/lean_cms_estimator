import { parseTables } from './markdown.mjs';
import { isMapping, splitFrontMatter } from './text.mjs';
import { TOOLKIT_COLUMNS } from './toolkit-render.mjs';

const CODE = /^`([^`]+)`$/;
const STATUSES = ['active', 'deprecated'];
const REGENERATE = 'regenerate it with npm run catalog:toolkit';

function checkCounts(frontMatter, capabilities, tallies, errors) {
  const entries = Array.from(capabilities.values());
  const actual = {
    skills: entries.filter((entry) => entry.kind === 'skill').length,
    agents: entries.filter((entry) => entry.kind === 'agent').length,
    deprecated: entries.filter((entry) => entry.status === 'deprecated').length
  };
  const declared = isMapping(frontMatter.counts) ? frontMatter.counts : {};
  ['skills', 'agents', 'deprecated'].forEach((key) => {
    if (declared[key] !== actual[key]) {
      errors.push(`toolkit catalog front matter says ${declared[key] ?? '(none)'} ${key} but the tables have ${actual[key]}; ${REGENERATE}`);
    }
  });
  const plugins = isMapping(frontMatter.plugins) ? frontMatter.plugins : {};
  const ids = new Set(Object.keys(plugins).concat(Array.from(tallies.keys())));
  ids.forEach((id) => {
    const listed = isMapping(plugins[id]) ? plugins[id] : {};
    const tally = tallies.get(id) ?? { skills: 0, agents: 0 };
    if (listed.skills !== tally.skills || listed.agents !== tally.agents) {
      errors.push(`toolkit catalog plugin ${id}: front matter and tables disagree on its skills and agents; ${REGENERATE}`);
    }
  });
}

export function parseToolkitCatalog(text) {
  const { data, body } = splitFrontMatter(text, 'toolkit-capability-catalog.md');
  const frontMatter = isMapping(data) ? data : {};
  const capabilities = new Map();
  const tallies = new Map();
  const errors = [];
  let tables = 0;
  for (const table of parseTables(body)) {
    const path = table.headings;
    if (path[1] !== 'Plugins' || (path[3] !== 'Skills' && path[3] !== 'Agents')) {
      continue;
    }
    tables++;
    const plugin = path[2];
    const kind = path[3] === 'Skills' ? 'skill' : 'agent';
    const where = `toolkit catalog ${plugin} ${path[3]}`;
    if (table.header.join(' | ') !== TOOLKIT_COLUMNS.join(' | ')) {
      errors.push(`${where} columns must be: ${TOOLKIT_COLUMNS.join(' | ')}`);
    }
    const tally = tallies.get(plugin) ?? { skills: 0, agents: 0 };
    tallies.set(plugin, tally);
    table.rows.forEach((row, index) => {
      if (row.length !== TOOLKIT_COLUMNS.length) {
        errors.push(`${where} row ${index + 1}: has ${row.length} cells, expected ${TOOLKIT_COLUMNS.length}`);
        return;
      }
      const match = CODE.exec(row[0]);
      if (!match) {
        errors.push(`${where} row ${index + 1}: capability id must be in backticks`);
        return;
      }
      const id = match[1];
      if (STATUSES.indexOf(row[1]) === -1) {
        errors.push(`toolkit catalog ${id}: status ${row[1] || '(blank)'} must be active or deprecated`);
      }
      if (row[2].length === 0) {
        errors.push(`toolkit catalog ${id}: description is blank`);
      }
      if (capabilities.has(id)) {
        errors.push(`toolkit catalog ${id}: listed twice`);
        return;
      }
      capabilities.set(id, { plugin, kind, status: row[1], description: row[2] });
      tally[kind === 'skill' ? 'skills' : 'agents']++;
    });
  }
  if (tables === 0) {
    errors.push(`toolkit catalog has no capability tables under ## Plugins; ${REGENERATE}`);
  } else {
    checkCounts(frontMatter, capabilities, tallies, errors);
  }
  return { frontMatter, capabilities, errors };
}
