import { byId, normalizeText, readEntries } from './entries.mjs';
import { AGENT_FILE, SKILL_FILE } from './git-tree.mjs';
import { CatalogError, isMapping, parseYaml } from './text.mjs';

export const TOOLKIT_GENERATOR_VERSION = 1;

const NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const DEPRECATED = /^\W*deprecated\b/i;

function pluginFiles(files, plugin) {
  const prefix = `${plugin}/`;
  const scoped = new Map();
  for (const [path, text] of files) {
    if (path.startsWith(prefix)) {
      scoped.set(path.slice(prefix.length), text);
    }
  }
  return scoped;
}

function readVersion(scoped, plugin) {
  const path = `${plugin}/plugin.yaml`;
  const text = scoped.get('plugin.yaml');
  if (text === undefined) {
    throw new CatalogError(`${path} is missing at the pinned commit`);
  }
  const manifest = parseYaml(text, path);
  const version = isMapping(manifest) ? manifest.version : undefined;
  if (version === undefined || version === null || typeof version === 'object' || String(version).trim().length === 0) {
    throw new CatalogError(`${path} has no version`);
  }
  return String(version).trim();
}

function readKind(scoped, plugin, pattern, kind) {
  let entries;
  try {
    entries = readEntries(scoped, pattern, { matchDirectory: false });
  } catch (error) {
    if (error instanceof CatalogError) {
      throw new CatalogError(`${plugin}/${error.message}`);
    }
    throw error;
  }
  return entries.map((entry) => {
    if (!NAME.test(entry.id)) {
      throw new CatalogError(`${plugin} ${kind} ${entry.id} has an invalid name`);
    }
    if (entry.description.length === 0) {
      throw new CatalogError(`${plugin} ${kind} ${entry.id} has no description`);
    }
    return {
      id: `${plugin}:${entry.id}`,
      kind,
      status: DEPRECATED.test(entry.description) ? 'deprecated' : 'active',
      description: normalizeText(entry.description)
    };
  });
}

export function buildToolkitCatalog(files, meta, plugins) {
  const taken = new Map();
  const claim = (entry) => {
    const key = entry.id.toLowerCase();
    if (taken.has(key)) {
      throw new CatalogError(`capability id ${entry.id} collides with ${taken.get(key)}`);
    }
    taken.set(key, entry.id);
  };
  const built = plugins.map((plugin) => {
    const scoped = pluginFiles(files, plugin);
    const version = readVersion(scoped, plugin);
    const skills = readKind(scoped, plugin, SKILL_FILE, 'skill');
    const agents = readKind(scoped, plugin, AGENT_FILE, 'agent');
    if (skills.length === 0 && agents.length === 0) {
      throw new CatalogError(`${plugin} has no skills or agents at the pinned commit; check plugins and pluginRoot in the toolkit pin`);
    }
    skills.concat(agents).forEach(claim);
    return { id: plugin, version, skills, agents };
  }).sort((a, b) => byId(a.id, b.id));

  const all = built.flatMap((plugin) => plugin.skills.concat(plugin.agents));
  return {
    meta: {
      repository: meta.repository,
      commit: meta.commit,
      commitShort: meta.commit.slice(0, 7),
      commitDate: meta.commitDate,
      generatorVersion: TOOLKIT_GENERATOR_VERSION
    },
    plugins: built,
    counts: {
      skills: built.reduce((sum, plugin) => sum + plugin.skills.length, 0),
      agents: built.reduce((sum, plugin) => sum + plugin.agents.length, 0),
      deprecated: all.filter((entry) => entry.status === 'deprecated').length,
      byPlugin: built.map((plugin) => ({ id: plugin.id, version: plugin.version, skills: plugin.skills.length, agents: plugin.agents.length }))
    }
  };
}
