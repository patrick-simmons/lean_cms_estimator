import { ALL_PLATFORMS, pilotPlatforms } from './check.mjs';
import { byId } from './entries.mjs';
import { code } from './markdown.mjs';
import { CatalogError, isMapping } from './text.mjs';

export const TOP_N = 5;

export const ALTERNATIVE_IDS = Object.freeze(['pdk:pdk-code-review', 'pdk:pdk-dev-story', 'pdk:pdk-quick-dev']);

export const STOP_WORDS = Object.freeze(new Set([
  'and', 'the', 'for', 'with', 'from', 'into', 'that', 'this', 'are', 'not', 'any', 'all', 'its', 'their', 'then',
  'than', 'via', 'per', 'out', 'over', 'each', 'one', 'can', 'will', 'own', 'new', 'also', 'more', 'only', 'what',
  'use', 'user', 'asks', 'when', 'skill', 'agent', 'step', 'run', 'runs', 'loop',
  'cmk', 'cdk', 'pdk', 'adr', 'aem', 'eds', 'cloud', 'launch', 'delivery'
]));

function stem(token) {
  if (token.endsWith('ies') && token.length > 4) {
    return `${token.slice(0, -3)}y`;
  }
  if (token.endsWith('ing') && token.length > 5) {
    return token.slice(0, -3);
  }
  if (token.endsWith('ed') && token.length > 4) {
    return token.slice(0, -2);
  }
  if (token.endsWith('s') && !token.endsWith('ss') && token.length > 3) {
    return token.slice(0, -1);
  }
  return token;
}

export function tokenize(text) {
  return new Set(String(text ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .split(' ')
    .filter((token) => token.length >= 3 && !STOP_WORDS.has(token))
    .map(stem));
}

export function validateKeywords(keywords, activityIds) {
  if (!isMapping(keywords)) {
    throw new CatalogError('suggest keywords must be an object keyed by activity id');
  }
  const known = new Set(activityIds);
  Object.keys(keywords).sort(byId).forEach((key) => {
    if (!known.has(key)) {
      throw new CatalogError(`suggest keywords ${key} is not an activity in the estimating catalog`);
    }
    const value = keywords[key];
    if (!Array.isArray(value) || value.some((word) => typeof word !== 'string')) {
      throw new CatalogError(`suggest keywords ${key} must be a list of words`);
    }
  });
}

function score(query, id, description) {
  const idTokens = tokenize(id.replace(/[:-]/g, ' '));
  const descriptionTokens = tokenize(description);
  let total = 0;
  query.forEach((token) => {
    if (idTokens.has(token)) {
      total += 2;
    } else if (descriptionTokens.has(token)) {
      total += 1;
    }
  });
  return total;
}

function rank(query, candidates, skip) {
  return candidates
    .filter((candidate) => !skip.has(candidate.id))
    .map((candidate) => ({ id: candidate.id, score: score(query, candidate.id, candidate.description) }))
    .filter((candidate) => candidate.score > 0)
    .sort((a, b) => b.score - a.score || byId(a.id, b.id))
    .slice(0, TOP_N);
}

function line(target, candidates) {
  if (candidates.length === 0) {
    return `${target}: no suggestions`;
  }
  return `${target}: ${candidates.map((candidate) => `${code(candidate.id)} (${candidate.score})`).join(', ')}`;
}

function checkInputs({ cmk, toolkit, estimating }) {
  const problems = cmk.errors.concat(toolkit.errors, estimating.errors);
  if (problems.length > 0) {
    throw new CatalogError(`fix the catalogs first (npm run catalog:check):\n${problems.join('\n')}`);
  }
  if (estimating.activities.length === 0) {
    throw new CatalogError('the estimating catalog has no activities to suggest for');
  }
  if (toolkit.capabilities.size === 0) {
    throw new CatalogError('the toolkit catalog has no capabilities; run npm run catalog:toolkit');
  }
}

function cmkDescription(cmk, id) {
  const description = cmk.descriptions.get(id);
  if (description === undefined) {
    throw new CatalogError(`the CMK catalog has no description for ${id}; run npm run catalog:cmk`);
  }
  return description;
}

export function suggest({ cmk, toolkit, estimating, keywords }) {
  checkInputs({ cmk, toolkit, estimating });
  const activityIds = estimating.activities.map((pkg) => pkg.id);
  validateKeywords(keywords, activityIds);
  const pilots = pilotPlatforms(estimating);
  const taken = new Set(ALTERNATIVE_IDS
    .concat(estimating.methods.flatMap((method) => method.items.map((item) => item.id)))
    .concat(estimating.capabilities
      .filter((row) => row.platform === ALL_PLATFORMS)
      .flatMap((row) => row.items.map((item) => item.id))
      .filter((id) => toolkit.capabilities.has(id))));
  const shared = Array.from(cmk.allPlatforms.keys())
    .map((id) => ({ id, description: cmkDescription(cmk, id) }))
    .concat(Array.from(toolkit.capabilities.entries())
      .filter(([id, entry]) => entry.status !== 'deprecated' && !taken.has(id))
      .map(([id, entry]) => ({ id, description: entry.description })));
  const vendor = (platform) => Array.from((cmk.platforms.get(platform) ?? new Map()).entries())
    .filter(([, entry]) => entry.status === 'supported')
    .map(([id]) => ({ id, description: cmkDescription(cmk, id) }));

  const sections = estimating.activities.map((pkg) => {
    const query = tokenize([pkg.name, pkg.driver].concat(keywords[pkg.id] ?? []).join(' '));
    const listed = new Set(estimating.capabilities
      .filter((row) => row.wp === pkg.id)
      .flatMap((row) => row.items.map((item) => item.id)));
    const rows = [{ target: ALL_PLATFORMS, candidates: rank(query, shared, listed) }]
      .concat(pilots.map((platform) => ({ target: platform, candidates: rank(query, vendor(platform), listed) })));
    return { wp: pkg.id, name: pkg.name, rows };
  });

  const text = sections
    .map((section) => [`## ${section.wp} ${section.name}`, ''].concat(section.rows.map((row) => line(row.target, row.candidates))).join('\n'))
    .join('\n\n');
  return { sections, text: `${text}\n` };
}
