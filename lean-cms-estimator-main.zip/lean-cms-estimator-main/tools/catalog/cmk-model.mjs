import { ADAPTER_FILE, AGENT_FILE, SKILL_FILE } from './git-tree.mjs';
import { byId, normalizeText, readEntries } from './entries.mjs';
import { CatalogError, isMapping, parseJson, parseYaml } from './text.mjs';

export { byId, normalizeText, readFrontMatter } from './entries.mjs';

export const GENERATOR_VERSION = 1;
export const MODES = ['default', 'opt_in'];
export const STATUSES = ['supported', 'local-only', 'unavailable'];
export const REASON_MESSAGES = {
  activation_unavailable: 'Asset is unavailable under its activation or redistribution policy',
  distributable_excluded: 'excluded from distributable output'
};

const GENERATED_NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const GENERATED_NAME_LIMIT = 64;
const SUMMARY_LIMIT = 160;
const REGISTRY_FILE = 'vendor-assets.yaml';
const LOCK_FILE = 'vendor-assets.lock.json';

function policyOf(assetId, asset, source) {
  const contracts = Object.values(asset.primitive_contracts ?? {});
  const primitive = contracts.length > 0 ? contracts[0].license : undefined;
  const license = primitive ?? source.license;
  if (!isMapping(license)) {
    throw new CatalogError(`asset ${assetId} has no license on its primitive contract or its source ${asset.source}`);
  }
  const redistributable = license.redistribution === 'permitted';
  return {
    redistribution: license.redistribution,
    evidence: license.evidence,
    usageScope: primitive?.usage_scope ?? (redistributable ? 'redistributable' : 'internal_use'),
    externalDistribution: primitive?.external_distribution ?? (redistributable ? 'permitted' : 'prohibited')
  };
}

function admissible(policy, source) {
  if (!source.license?.evidence || !policy.evidence) {
    return false;
  }
  if (policy.usageScope === 'internal_use') {
    return policy.externalDistribution === 'prohibited' && source.retention === 'local_only';
  }
  return policy.redistribution === 'permitted' && policy.externalDistribution === 'permitted';
}

function unavailable(reasonCode) {
  return { status: 'unavailable', reasonCode, reason: REASON_MESSAGES[reasonCode] };
}

export function assetStatus(asset, source, assetId) {
  if (!source) {
    return unavailable('activation_unavailable');
  }
  if (asset.activation === 'unavailable' || !admissible(policyOf(assetId, asset, source), source)) {
    return unavailable('activation_unavailable');
  }
  if (source.retention === 'local_only') {
    return { status: 'local-only', reasonCode: 'distributable_excluded', reason: REASON_MESSAGES.distributable_excluded };
  }
  return { status: 'supported', reasonCode: '', reason: '' };
}

export function generatedNames(assetId, asset) {
  const selected = asset.selection?.primitives;
  if (!Array.isArray(selected) || selected.length === 0) {
    throw new CatalogError(`asset ${assetId} has no selection.primitives`);
  }
  const namespace = asset.distribution?.namespace;
  if (typeof namespace !== 'string' || namespace.length === 0) {
    throw new CatalogError(`asset ${assetId} has no distribution.namespace`);
  }
  return selected.map((entry) => {
    const id = String(entry?.id ?? '');
    if (!asset.primitive_contracts || !Object.prototype.hasOwnProperty.call(asset.primitive_contracts, id)) {
      throw new CatalogError(`asset ${assetId} selects ${id || '(no id)'} without a primitive contract`);
    }
    const name = `${namespace}-${id}`;
    if (!GENERATED_NAME.test(name) || name.length > GENERATED_NAME_LIMIT) {
      throw new CatalogError(`asset ${assetId} generates an invalid capability id ${name}`);
    }
    return name;
  }).sort(byId);
}

export function validateSummaries(summaries, assetIds) {
  const errors = [];
  const known = new Set(assetIds);
  for (const id of assetIds) {
    if (!Object.prototype.hasOwnProperty.call(summaries, id)) {
      errors.push(`missing summary for vendor asset ${id}`);
    }
  }
  for (const id of Object.keys(summaries).sort(byId)) {
    if (!known.has(id)) {
      errors.push(`summary ${id} does not match a vendor asset`);
      continue;
    }
    const text = summaries[id];
    if (typeof text !== 'string' || text.trim().length === 0) {
      errors.push(`summary for ${id} is empty`);
    } else if (/[\r\n]/.test(text)) {
      errors.push(`summary for ${id} must be one line`);
    } else if (text.indexOf('|') !== -1) {
      errors.push(`summary for ${id} must not contain |`);
    } else if (text.length > SUMMARY_LIMIT) {
      errors.push(`summary for ${id} is longer than ${SUMMARY_LIMIT} characters`);
    } else if (!text.endsWith('.')) {
      errors.push(`summary for ${id} must end with a full stop`);
    }
  }
  return errors;
}

function readAdapters(files) {
  const adapters = [];
  for (const [path, text] of files) {
    if (!ADAPTER_FILE.test(path)) {
      continue;
    }
    const data = parseYaml(text, path);
    if (!isMapping(data)) {
      throw new CatalogError(`${path} is not a mapping`);
    }
    const id = String(data.platform ?? '');
    const file = path.slice(path.lastIndexOf('/') + 1);
    if (file !== `${id}.yaml`) {
      throw new CatalogError(`${path} declares platform ${id || '(none)'}`);
    }
    const vendorAssets = data.vendor_assets ?? [];
    if (!Array.isArray(vendorAssets)) {
      throw new CatalogError(`${path} vendor_assets must be a list`);
    }
    adapters.push({
      id,
      displayName: normalizeText(data.display_name),
      extends: data.extends ? String(data.extends) : '',
      vendorAssets: vendorAssets.map((entry) => ({ asset: String(entry?.asset ?? ''), mode: String(entry?.mode ?? '') }))
    });
  }
  return adapters.sort((a, b) => byId(a.id, b.id));
}

function required(files, path) {
  const text = files.get(path);
  if (text === undefined) {
    throw new CatalogError(`${path} is missing at the pinned commit`);
  }
  return text;
}

export function buildCmkCatalog(files, meta, summaries) {
  const skills = readEntries(files, SKILL_FILE, { matchDirectory: true });
  const agents = readEntries(files, AGENT_FILE, { matchDirectory: false });
  const adapters = readAdapters(files);
  const registry = parseYaml(required(files, REGISTRY_FILE), REGISTRY_FILE);
  if (!isMapping(registry) || !isMapping(registry.assets) || !isMapping(registry.sources)) {
    throw new CatalogError(`${REGISTRY_FILE} must have assets and sources mappings`);
  }
  const lock = parseJson(required(files, LOCK_FILE), LOCK_FILE);
  const registryAssets = registry.assets;
  const sources = registry.sources;
  const assetIds = Object.keys(registryAssets).sort(byId);

  const summaryErrors = validateSummaries(summaries, assetIds);
  if (summaryErrors.length > 0) {
    throw new CatalogError(summaryErrors.join('\n'));
  }

  const taken = new Map();
  const claim = (name, owner) => {
    const key = name.toLowerCase();
    if (taken.has(key)) {
      throw new CatalogError(`capability id ${name} from ${owner} collides with ${taken.get(key)}`);
    }
    taken.set(key, owner);
  };
  skills.forEach((skill) => claim(skill.id, 'a CMK skill'));
  agents.forEach((agent) => claim(agent.id, 'a CMK agent'));

  const assets = new Map();
  for (const assetId of assetIds) {
    const asset = registryAssets[assetId];
    if (!isMapping(asset)) {
      throw new CatalogError(`asset ${assetId} is not a mapping`);
    }
    if (!Object.prototype.hasOwnProperty.call(sources, asset.source)) {
      throw new CatalogError(`asset ${assetId} references unknown source ${asset.source ?? '(none)'}`);
    }
    const status = assetStatus(asset, sources[asset.source], assetId);
    if (status.status === 'supported' && (!lock.sources?.[asset.source] || !lock.assets?.[assetId])) {
      throw new CatalogError(`available asset ${assetId} is not locked`);
    }
    const capabilities = generatedNames(assetId, asset);
    capabilities.forEach((name) => claim(name, `vendor asset ${assetId}`));
    assets.set(assetId, {
      assetId,
      displayName: normalizeText(asset.display_name),
      ...status,
      summary: summaries[assetId],
      capabilities
    });
  }

  const platforms = adapters.map((adapter) => {
    const listed = adapter.vendorAssets.map((entry) => {
      const asset = assets.get(entry.asset);
      if (!asset) {
        throw new CatalogError(`platform ${adapter.id} lists unknown vendor asset ${entry.asset}`);
      }
      if (MODES.indexOf(entry.mode) === -1) {
        throw new CatalogError(`platform ${adapter.id} lists ${entry.asset} with invalid mode ${entry.mode || '(none)'}`);
      }
      return { ...asset, mode: entry.mode };
    }).sort((a, b) => byId(a.assetId, b.assetId));
    return { id: adapter.id, displayName: adapter.displayName, extends: adapter.extends, assets: listed };
  });

  const all = Array.from(assets.values());
  const statusCounts = (list, valueOf) => Object.fromEntries(STATUSES.map((status) => [
    status,
    list.filter((asset) => asset.status === status).reduce((sum, asset) => sum + valueOf(asset), 0)
  ]));
  const assetCounts = statusCounts(all, () => 1);
  const capabilityCounts = statusCounts(all, (asset) => asset.capabilities.length);
  const counts = {
    skills: skills.length,
    agents: agents.length,
    platforms: platforms.length,
    vendorAssets: all.length,
    vendorAssetsSupported: assetCounts.supported,
    vendorAssetsLocalOnly: assetCounts['local-only'],
    vendorAssetsUnavailable: assetCounts.unavailable,
    vendorCapabilitiesSupported: capabilityCounts.supported,
    vendorCapabilitiesLocalOnly: capabilityCounts['local-only'],
    vendorCapabilitiesUnavailable: capabilityCounts.unavailable,
    byPlatform: platforms.map((platform) => {
      const platformCounts = statusCounts(platform.assets, (asset) => asset.capabilities.length);
      return {
        id: platform.id,
        vendorAssets: platform.assets.length,
        supportedCapabilities: platformCounts.supported,
        localOnlyCapabilities: platformCounts['local-only'],
        unavailableCapabilities: platformCounts.unavailable
      };
    })
  };

  return {
    meta: { ...meta, commitShort: meta.commit.slice(0, 7), generatorVersion: GENERATOR_VERSION },
    skills,
    agents,
    platforms,
    counts
  };
}
