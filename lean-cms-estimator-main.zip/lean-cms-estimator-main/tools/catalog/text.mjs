import { parse } from 'yaml';

export const DASH = '—';
export const COMMIT_SHA = /^[0-9a-f]{40}$/;

const FRONT_MATTER = /^---\n([\s\S]*?)\n---(?:\n|$)/;

export class CatalogError extends Error {
  constructor(message, code = '') {
    super(message);
    this.name = 'CatalogError';
    this.code = code;
  }
}

export function cleanText(text) {
  return String(text).replace(/^﻿/, '').replace(/\r\n/g, '\n');
}

export function isMapping(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

export function parseYaml(text, path) {
  try {
    return parse(text);
  } catch (error) {
    throw new CatalogError(`${path}: ${error.message}`);
  }
}

export function parseJson(text, path) {
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new CatalogError(`${path}: ${error.message}`);
  }
}

export function splitFrontMatter(text, path) {
  const clean = cleanText(text);
  const match = FRONT_MATTER.exec(clean);
  if (!match) {
    return { data: undefined, body: clean, bodyLine: 0 };
  }
  return {
    data: parseYaml(match[1], path),
    body: clean.slice(match[0].length),
    bodyLine: match[0].split('\n').length - 1
  };
}

export function errorText(error) {
  if (error instanceof CatalogError || String(error?.code ?? '').startsWith('ERR_PARSE_ARGS')) {
    return error.message;
  }
  return error instanceof Error ? (error.stack ?? error.message) : String(error);
}
