import { parseTables, strayRows, unwrapCode } from './markdown.mjs';
import { DASH, isMapping, splitFrontMatter } from './text.mjs';

export { parseTables, unwrapCode } from './markdown.mjs';

export const ACTIVITY_COLUMNS = ['Id', 'Name', 'Phase', 'Shape', 'Unit', 'Sizing driver', 'Owner', 'Default coverage', 'Share of'];
export const CAPABILITY_COLUMNS = ['Activity', 'Platform', 'Capabilities', 'Opt-in coverage', 'Method coverage'];
export const METHOD_COLUMNS = ['Method', 'Capabilities', 'Applies to', 'Prerequisites', 'Default'];

const SECTIONS = [
  ['Capabilities', CAPABILITY_COLUMNS],
  ['Delivery methods', METHOD_COLUMNS],
  ['Activities', ACTIVITY_COLUMNS]
];

export function parseCmkCatalog(text) {
  const { data, body } = splitFrontMatter(text, 'cmk-capability-catalog.md');
  const allPlatforms = new Map();
  const platforms = new Map();
  const descriptions = new Map();
  const assets = new Map();
  const errors = [];
  const sized = (where, rows, size) => rows.filter((row, index) => {
    if (row.length !== size) {
      errors.push(`CMK catalog ${where} row ${index + 1}: has ${row.length} cells, expected ${size}`);
      return false;
    }
    return true;
  });
  const tables = parseTables(body);
  for (const table of tables) {
    const path = table.headings;
    if (path[1] === 'All platforms' && (path[2] === 'Skills' || path[2] === 'Agents')) {
      sized(path[2], table.rows, 2).forEach((row) => {
        allPlatforms.set(unwrapCode(row[0]), path[2] === 'Skills' ? 'skill' : 'agent');
        descriptions.set(unwrapCode(row[0]), row[1]);
      });
    }
    if (path[1] === 'Platforms' && path[3] === 'Vendor assets') {
      sized(`${path[2]} Vendor assets`, table.rows, 6).forEach((row) => assets.set(unwrapCode(row[0]), `${row[1]}. ${row[5]}`));
    }
  }
  for (const table of tables) {
    const path = table.headings;
    if (path[1] === 'Platforms' && path[3] === 'Vendor capabilities') {
      const platformId = path[2];
      const capabilities = platforms.get(platformId) ?? new Map();
      sized(`${platformId} Vendor capabilities`, table.rows, 4).forEach((row) => {
        const id = unwrapCode(row[0]);
        const assetId = unwrapCode(row[1]);
        capabilities.set(id, { assetId, mode: row[2], status: row[3] });
        if (assets.has(assetId)) {
          descriptions.set(id, assets.get(assetId));
        } else {
          errors.push(`CMK catalog ${platformId} capability ${id}: asset ${assetId} has no Vendor assets row; regenerate it with npm run catalog:cmk`);
        }
      });
      platforms.set(platformId, capabilities);
    }
  }
  for (const line of body.split('\n')) {
    const heading = /^###\s+(\S+)$/.exec(line);
    if (heading && !platforms.has(heading[1]) && heading[1] !== 'Skills' && heading[1] !== 'Agents') {
      platforms.set(heading[1], new Map());
    }
  }
  return { frontMatter: isMapping(data) ? data : {}, allPlatforms, platforms, descriptions, errors };
}

export function parseCapabilityCell(value) {
  const text = value.trim();
  if (text === DASH || text === '') {
    return { items: [], errors: text === '' ? ['empty capability cell'] : [] };
  }
  const items = [];
  const errors = [];
  for (const part of text.split(',')) {
    const match = /^`([^`]+)`(\s+\(opt-in\))?$/.exec(part.trim());
    if (!match) {
      errors.push(`unreadable capability "${part.trim()}"`);
      continue;
    }
    items.push({ id: match[1], optIn: Boolean(match[2]) });
  }
  return { items, errors };
}

function coverageCell(value, where, label, reason, errors) {
  if (value === '') {
    errors.push(`${where} ${label}: empty cell; use ${DASH} when ${reason}`);
  }
  return value === DASH ? '' : value;
}

function listCell(value) {
  if (value === DASH) {
    return [];
  }
  return value.split(',').map((item) => item.trim()).filter((item) => item.length > 0);
}

function readSection(lines, tables, bodyLine, title, columns, errors) {
  const table = tables.find((item) => item.headings[1] === title);
  if (!table) {
    errors.push(`no ${title} table`);
    return [];
  }
  const stray = strayRows(lines, table, bodyLine, title);
  if (stray.length > 0) {
    errors.push(`${title}: rows on line ${stray.join(', ')} are cut off from the table; remove blank or other lines between rows`);
  }
  if (table.header.join(' | ') !== columns.join(' | ')) {
    errors.push(`${title} columns must be: ${columns.join(' | ')}`);
  }
  return table.rows.map((cells, index) => {
    const line = bodyLine + table.start + 3 + index;
    if (cells.length !== columns.length) {
      errors.push(`line ${line}: has ${cells.length} cells, expected ${columns.length}`);
    }
    return { cells: columns.map((column, offset) => (cells[offset] ?? '').trim()), line };
  });
}

export function parseEstimatingCatalog(text) {
  const { data, body, bodyLine } = splitFrontMatter(text, 'estimating-catalog.md');
  const frontMatter = isMapping(data) ? data : {};
  const lines = body.split('\n');
  const tables = parseTables(body);
  const errors = [];
  const [capabilityRows, methodRows, activityRows] = SECTIONS.map(([title, columns]) => readSection(lines, tables, bodyLine, title, columns, errors));

  const activities = activityRows.map(({ cells, line }) => ({
    id: unwrapCode(cells[0]),
    name: cells[1],
    // The table reads Discover; everything downstream keys on the slug.
    phase: cells[2].toLowerCase(),
    shape: cells[3],
    unit: cells[4] === DASH ? '' : cells[4],
    driver: cells[5],
    owner: cells[6],
    coverage: cells[7],
    shareOf: listCell(cells[8]).map(unwrapCode),
    line
  }));

  const capabilities = capabilityRows.map(({ cells, line }) => {
    const [wpCell, platform, list, optIn, method] = cells;
    const wp = unwrapCode(wpCell);
    const parsed = parseCapabilityCell(list);
    parsed.errors.forEach((error) => errors.push(`${wp} ${platform}: ${error}`));
    return {
      wp,
      platform,
      items: parsed.items,
      optInCoverage: coverageCell(optIn, `${wp} ${platform}`, 'opt-in coverage', 'opt-in makes no difference', errors),
      methodCoverage: coverageCell(method, `${wp} ${platform}`, 'method coverage', 'methods make no difference', errors),
      line
    };
  });

  const methods = methodRows.map(({ cells, line }) => {
    const id = unwrapCode(cells[0]);
    const parsed = parseCapabilityCell(cells[1]);
    parsed.errors.forEach((error) => errors.push(`method ${id}: ${error}`));
    return {
      id,
      items: parsed.items,
      appliesTo: listCell(cells[2]).map(unwrapCode),
      prerequisites: cells[3] === DASH ? '' : cells[3],
      isDefault: cells[4],
      line
    };
  });

  return { frontMatter, activities, capabilities, methods, errors };
}
