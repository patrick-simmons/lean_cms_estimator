import { stringify } from 'yaml';

export const META = {
  repository: 'https://example.test/cmk.git',
  commit: '0123456789abcdef0123456789abcdef01234567',
  commitDate: '2026-10-06T10:58:59-05:00'
};

export const REGISTRY_TEXT = ['Registry description that must not be copied.', 'Registry scope that must not be copied.'];

export function baseRegistry() {
  const contract = { kind: 'skill' };
  const internal = {
    kind: 'skill',
    license: {
      expression: 'Proprietary',
      redistribution: 'prohibited',
      evidence: 'SKILL.md frontmatter license',
      usage_scope: 'internal_use',
      external_distribution: 'prohibited'
    }
  };
  const asset = (source, namespace, ids, extra = {}) => ({
    source,
    path: 'skills',
    format: 'agent_skills',
    selection: { primitives: ids.map((id) => ({ path: `${id}/SKILL.md`, id })) },
    display_name: `Display ${namespace}`,
    description: REGISTRY_TEXT[0],
    activation: 'default',
    scope: REGISTRY_TEXT[1],
    primitive_contracts: Object.fromEntries(ids.map((id) => [id, extra.contract ?? contract])),
    distribution: { namespace },
    ...extra.fields
  });
  return {
    schema_version: 1,
    sources: {
      open: { retention: 'reviewed_snapshot', license: { expression: 'Apache-2.0', redistribution: 'permitted', evidence: 'LICENSE' } },
      closed: { retention: 'local_only', license: { expression: 'MIT', redistribution: 'permission_required', evidence: 'LICENSE' } }
    },
    assets: {
      'vend-two': asset('open', 'vtwo', ['deploy', 'check']),
      'vend-one': asset('open', 'vone', ['build']),
      'vend-shared': asset('open', 'vshared', ['share']),
      'vend-local': asset('closed', 'vlocal', ['ops'], { contract: internal }),
      'vend-off': asset('open', 'voff', ['gone'], { fields: { activation: 'unavailable' } })
    }
  };
}

export function baseAdapters() {
  return {
    'plat-a': { platform: 'plat-a', display_name: 'Platform A', vendor_assets: [
      { asset: 'vend-two', mode: 'opt_in' },
      { asset: 'vend-one', mode: 'default' },
      { asset: 'vend-shared', mode: 'default' }
    ] },
    'plat-b': { platform: 'plat-b', display_name: 'Platform B', extends: 'plat-a', vendor_assets: [] },
    'plat-c': { platform: 'plat-c', display_name: 'Platform C', vendor_assets: [
      { asset: 'vend-shared', mode: 'opt_in' },
      { asset: 'vend-local', mode: 'default' },
      { asset: 'vend-off', mode: 'default' }
    ] }
  };
}

export function baseLock(registry = baseRegistry()) {
  return {
    schema_version: 1,
    generated_at: '2026-10-06T00:00:00.000Z',
    sources: Object.fromEntries(Object.keys(registry.sources).map((id) => [id, { commit: 'abc' }])),
    assets: Object.fromEntries(Object.keys(registry.assets).map((id) => [id, { resolved_version: 'abc' }]))
  };
}

export function baseSummaries(registry = baseRegistry()) {
  return Object.fromEntries(Object.keys(registry.assets).map((id) => [id, `Our summary of ${id}.`]));
}

const SKILLS = [
  ['cmk-beta', 'Has a pipe | inside and an em dash — here.'],
  ['cmk-alpha', 'First line of the description\n  continues on a second line']
];
const AGENTS = [
  ['beta.md', 'cmk-beta-agent', 'Beta agent description.'],
  ['alpha-agent.md', 'cmk-alpha-agent', 'Alpha agent\n  description.']
];

export function skillFile(name, description) {
  const folded = description.split('\n').map((line) => `  ${line.trim()}`).join('\n');
  return `---\nname: ${name}\ndescription: >-\n${folded}\n---\n\n# ${name}\n`;
}

export function buildFiles(options = {}) {
  const registry = options.registry ?? baseRegistry();
  const adapters = options.adapters ?? baseAdapters();
  const lock = options.lock ?? baseLock(registry);
  const entries = [];
  SKILLS.forEach(([name, description]) => entries.push([`skills/${name}/SKILL.md`, skillFile(name, description)]));
  AGENTS.forEach(([file, name, description]) => entries.push([`agents/${file}`, skillFile(name, description)]));
  Object.keys(adapters).forEach((id) => entries.push([`skills/cmk-init/adapters/${id}.yaml`, stringify(adapters[id])]));
  entries.push(['vendor-assets.yaml', stringify(registry)]);
  entries.push(['vendor-assets.lock.json', JSON.stringify(lock, null, 2)]);
  entries.push(...(options.extra ?? []));
  const omit = options.omit ?? [];
  const kept = entries.filter(([path]) => omit.indexOf(path) === -1);
  if (options.reverse) {
    kept.reverse();
  }
  return new Map(kept);
}

export const TOOLKIT_META = {
  repository: 'https://example.test/toolkit.git',
  commit: 'fedcba9876543210fedcba9876543210fedcba98',
  commitDate: '2026-10-13T09:48:14-05:00'
};

export const TOOLKIT_PLUGINS = ['alpha', 'beta'];

export function buildToolkitFiles(options = {}) {
  const entries = [
    ['alpha/plugin.yaml', 'name: alpha\nversion: 1.2.0\n'],
    ['alpha/skills/workflow/SKILL.md', skillFile('alpha-flow', 'Runs the alpha flow | with a pipe.')],
    ['alpha/skills/alpha-plan/SKILL.md', skillFile('alpha-plan', 'Plans the alpha work\n  over two lines.')],
    ['alpha/skills/alpha-old/SKILL.md', skillFile('alpha-old', 'DEPRECATED - kept for reference only.')],
    ['beta/plugin.yaml', 'name: beta\nversion: 0.3.0\n'],
    ['beta/skills/beta-build/SKILL.md', skillFile('beta-build', 'Builds beta components with tests.')],
    ['beta/agents/checker.md', skillFile('beta-checker', 'Checks the beta build.')]
  ];
  entries.push(...(options.extra ?? []));
  const omit = options.omit ?? [];
  const kept = entries.filter(([path]) => omit.indexOf(path) === -1);
  if (options.reverse) {
    kept.reverse();
  }
  return new Map(kept);
}

export const V2_ACTIVITIES = [
  '| `shape-build` | Build | Build | per-unit | component | Components | us | partly | — |',
  '| `shape-design` | Design | Design | tiered | — | Site complexity | shared | human-led | — |',
  '| `shape-manage` | Manage | Run | proportional | — | Share of build | us | human-led | `shape-build`, `shape-design` |',
  '| `shape-report` | Report | Run | proportional | — | Share of the rest | us | human-led | `everything-else` |'
];

export const V2_CAPABILITIES = [
  '| `shape-build` | all | `cmk-alpha`, `alpha:alpha-plan` | — | accelerated |',
  '| `shape-build` | plat-a | `vone-build`, `vtwo-deploy` (opt-in) | accelerated | — |',
  '| `shape-build` | plat-c | `vshared-share` (opt-in) | — | — |',
  '| `shape-design` | all | — | — | partly |',
  '| `shape-design` | plat-a | — | — | — |',
  '| `shape-design` | plat-c | — | — | — |',
  '| `shape-manage` | all | — | — | — |',
  '| `shape-manage` | plat-a | — | — | — |',
  '| `shape-manage` | plat-c | — | — | — |',
  '| `shape-report` | all | — | — | — |',
  '| `shape-report` | plat-a | — | — | — |',
  '| `shape-report` | plat-c | — | — | — |'
];

export const V2_METHODS = [
  '| `build-loop` | `beta:beta-build`, `beta:beta-checker`, `cmk-alpha-agent` | `shape-build`, `shape-design` | A ticket per change | yes |'
];

const V2_HEADERS = {
  Activities: '| Id | Name | Phase | Shape | Unit | Sizing driver | Owner | Default coverage | Share of |',
  Capabilities: '| Activity | Platform | Capabilities | Opt-in coverage | Method coverage |',
  'Delivery methods': '| Method | Capabilities | Applies to | Prerequisites | Default |'
};

export function estimatingV2Text(options = {}) {
  const front = {
    catalog: 'estimating-catalog',
    version: 2,
    cmkCommit: META.commit,
    toolkitCommit: TOOLKIT_META.commit,
    pilotPlatforms: '[plat-a, plat-c]',
    ...options.front
  };
  const lines = ['---'];
  Object.keys(front).filter((key) => front[key] !== undefined).forEach((key) => lines.push(`${key}: ${front[key]}`));
  lines.push('---', '', '# Estimating catalog');
  const sections = [
    ['Activities', options.activities ?? V2_ACTIVITIES],
    ['Capabilities', options.capabilities ?? V2_CAPABILITIES],
    ['Delivery methods', options.methods ?? V2_METHODS]
  ];
  const headers = { ...V2_HEADERS, ...options.headers };
  sections
    .filter(([title]) => (options.omit ?? []).indexOf(title) === -1)
    .forEach(([title, rows]) => {
      const header = headers[title];
      lines.push('', `## ${title}`, '', header, `|${header.split('|').slice(1, -1).map(() => ' --- ').join('|')}|`);
      rows.forEach((row) => lines.push(row));
    });
  return `${lines.join('\n')}\n`;
}
