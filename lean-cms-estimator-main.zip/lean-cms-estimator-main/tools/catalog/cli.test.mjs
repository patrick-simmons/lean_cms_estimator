import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, readdirSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { readCatalogDocs } from './cli.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const scratch = mkdtempSync(join(tmpdir(), 'cmk-cli-'));

function run(script, args = []) {
  return spawnSync(process.execPath, [join(root, 'tools', script), ...args], { cwd: root, encoding: 'utf8' });
}

after(() => rmSync(scratch, { recursive: true, force: true }));

describe('npm run catalog:check', () => {
  it('reports ok for the committed catalogs', () => {
    const result = run('check-catalogs.mjs');
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /^ok: 25 activities, \d+ capability references checked against CMK e81d7ff · toolkit 5d1f76e · catalog v4\n$/);
  });

  it('rejects arguments it does not know', () => {
    const result = run('check-catalogs.mjs', ['--fix']);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /--fix/);
  });
});

describe('npm run catalog:cmk', () => {
  it('fails without writing anything when the CMK checkout is missing', () => {
    const output = join(scratch, 'catalog.md');
    const result = run('cmk-catalog.mjs', ['--cmk', join(scratch, 'no-cmk'), '--out', output]);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /^CMK checkout not found at .*pass --cmk <path>\.\n$/);
    assert.equal(existsSync(output), false);
  });

  it('rejects an option with no value, and unknown options', () => {
    for (const args of [['--cmk'], ['--cmk', '--out', join(scratch, 'x.md')], ['--cmkk', '.']]) {
      const result = run('cmk-catalog.mjs', args);
      assert.equal(result.status, 1, args.join(' '));
      assert.match(result.stderr, /--cmk/, args.join(' '));
      assert.doesNotMatch(result.stderr, /\n\s+at /, args.join(' '));
    }
    assert.equal(existsSync(join(scratch, 'x.md')), false);
  });
});

describe('npm run catalog:toolkit', () => {
  it('fails without writing anything when the toolkit checkout is missing', () => {
    const output = join(scratch, 'toolkit.md');
    const result = run('toolkit-catalog.mjs', ['--toolkit', join(scratch, 'no-toolkit'), '--out', output]);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /^ai-dev-toolkit checkout not found at .*clone the ai-dev-toolkit repository there or pass --toolkit <path>\.\n$/);
    assert.equal(existsSync(output), false);
  });

  it('rejects an option with no value, and unknown options', () => {
    for (const args of [['--toolkit'], ['--toolkitt', '.']]) {
      const result = run('toolkit-catalog.mjs', args);
      assert.equal(result.status, 1, args.join(' '));
      assert.match(result.stderr, /--toolkit/, args.join(' '));
      assert.doesNotMatch(result.stderr, /\n\s+at /, args.join(' '));
    }
  });
});

describe('npm run catalog:suggest', () => {
  const watched = () => [join(root, 'docs', 'catalogs'), join(root, 'tools')]
    .flatMap((dir) => readdirSync(dir).filter((name) => /\.(md|json)$/.test(name)).map((name) => join(dir, name)))
    .map((path) => `${path} ${statSync(path).mtimeMs}`);

  it('prints a section per activity, the same every time, and writes nothing', () => {
    const before = watched();
    const first = run('suggest-catalog.mjs');
    const second = run('suggest-catalog.mjs');
    assert.equal(first.status, 0, first.stderr);
    assert.equal((first.stdout.match(/^## [a-z][a-z0-9-]* /gm) ?? []).length, readCatalogDocs(root).estimating.activities.length);
    assert.equal(first.stdout, second.stdout);
    assert.deepEqual(watched(), before);
  });

  it('takes no options', () => {
    const result = run('suggest-catalog.mjs', ['--write']);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /--write/);
  });
});
