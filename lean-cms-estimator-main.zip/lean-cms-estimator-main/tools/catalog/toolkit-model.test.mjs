import assert from 'node:assert/strict';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import { buildToolkitFiles, skillFile, TOOLKIT_META, TOOLKIT_PLUGINS } from './fixtures.mjs';
import { validateToolkitPin } from './generate.mjs';
import { openPinnedTree, readToolkitFiles, TOOLKIT_TREE_OPTIONS } from './git-tree.mjs';
import { CatalogError } from './text.mjs';
import { buildToolkitCatalog } from './toolkit-model.mjs';
import { parseToolkitCatalog } from './toolkit-parse.mjs';
import { renderToolkitCatalog } from './toolkit-render.mjs';

function build(options = {}, plugins = TOOLKIT_PLUGINS) {
  return buildToolkitCatalog(buildToolkitFiles(options), TOOLKIT_META, plugins);
}

function catalogError(pattern) {
  return (error) => error instanceof CatalogError && pattern.test(error.message);
}

describe('buildToolkitCatalog', () => {
  it('names capabilities plugin:frontmatter-name, whatever the folder', () => {
    const ids = build().plugins.flatMap((plugin) => plugin.skills.concat(plugin.agents).map((entry) => entry.id));
    assert.deepEqual(ids, ['alpha:alpha-flow', 'alpha:alpha-old', 'alpha:alpha-plan', 'beta:beta-build', 'beta:beta-checker']);
  });

  it('marks descriptions that start with DEPRECATED, and counts by plugin', () => {
    const model = build();
    const alpha = model.plugins.find((plugin) => plugin.id === 'alpha');
    assert.equal(alpha.skills.find((entry) => entry.id === 'alpha:alpha-old').status, 'deprecated');
    assert.equal(alpha.skills.find((entry) => entry.id === 'alpha:alpha-plan').status, 'active');
    assert.equal(alpha.skills.find((entry) => entry.id === 'alpha:alpha-plan').description, 'Plans the alpha work over two lines.');
    assert.deepEqual(model.counts, {
      skills: 4,
      agents: 1,
      deprecated: 1,
      byPlugin: [
        { id: 'alpha', version: '1.2.0', skills: 3, agents: 0 },
        { id: 'beta', version: '0.3.0', skills: 1, agents: 1 }
      ]
    });
  });

  it('spots deprecation in any case, but not the word later in a description', () => {
    const statusOf = (description) => build({ extra: [['beta/skills/beta-x/SKILL.md', skillFile('beta-x', description)]] })
      .plugins.find((plugin) => plugin.id === 'beta').skills.find((entry) => entry.id === 'beta:beta-x').status;
    assert.equal(statusOf('Deprecated: use beta-build instead.'), 'deprecated');
    assert.equal(statusOf('[DEPRECATED] kept for reference.'), 'deprecated');
    assert.equal(statusOf('Replaces the deprecated beta flow.'), 'active');
  });

  it('sorts plugins whatever order the pin lists them in', () => {
    assert.equal(renderToolkitCatalog(build({}, ['beta', 'alpha'])), renderToolkitCatalog(build()));
  });

  it('throws a CatalogError naming each problem', () => {
    const cases = [
      [{ omit: ['beta/plugin.yaml'] }, /beta\/plugin.yaml is missing at the pinned commit/],
      [{ extra: [['beta/plugin.yaml', 'name: beta\n']] }, /beta\/plugin.yaml has no version/],
      [{ extra: [['beta/plugin.yaml', 'version: ""\n']] }, /beta\/plugin.yaml has no version/],
      [{ extra: [['alpha/skills/bare/SKILL.md', '# No front matter\n']] }, /^alpha\/skills\/bare\/SKILL.md has no frontmatter/],
      [{ extra: [['alpha/skills/blank/SKILL.md', '---\ndescription: Something.\n---\n']] }, /^alpha\/skills\/blank\/SKILL.md has no name/],
      [{ extra: [['beta/agents/odd.md', '---\n- a list\n---\n']] }, /^beta\/agents\/odd.md frontmatter is not a mapping/],
      [{ extra: [['alpha/skills/bad/SKILL.md', skillFile('Bad_Name', 'Something.')]] }, /alpha skill Bad_Name has an invalid name/],
      [{ extra: [['alpha/skills/empty/SKILL.md', '---\nname: alpha-empty\n---\n']] }, /alpha skill alpha-empty has no description/],
      [{ extra: [['alpha/agents/flow.md', skillFile('alpha-flow', 'Same name as a skill.')]] }, /capability id alpha:alpha-flow collides with alpha:alpha-flow/],
      [{ extra: [['beta/plugin.yaml', 'version: [1\n']] }, /^beta\/plugin.yaml: /],
      [{ omit: ['beta/skills/beta-build/SKILL.md', 'beta/agents/checker.md'] }, /^beta has no skills or agents at the pinned commit/]
    ];
    cases.forEach(([options, pattern]) => {
      assert.throws(() => build(options), catalogError(pattern), String(pattern));
    });
  });
});

describe('renderToolkitCatalog', () => {
  it('gives the same text whatever the file order, with LF, escaped pipes and quoted SHAs', () => {
    const forward = renderToolkitCatalog(build());
    assert.equal(forward, renderToolkitCatalog(build({ reverse: true })));
    assert.equal(forward.indexOf('\r'), -1);
    assert.ok(forward.endsWith('|\n') && !forward.endsWith('\n\n'));
    assert.ok(forward.indexOf('Runs the alpha flow \\| with a pipe.') !== -1);
    assert.ok(forward.indexOf('No agents at this commit.') !== -1);
    assert.ok(forward.indexOf('toolkitCommitShort: "fedcba9"') !== -1);
    assert.deepEqual(forward.match(/\d{4}-\d{2}-\d{2}T[\d:.+-]+/g), [TOOLKIT_META.commitDate]);
  });

  it('says when a plugin has no skills', () => {
    const text = renderToolkitCatalog(build({ omit: ['beta/skills/beta-build/SKILL.md'] }));
    assert.ok(text.indexOf('### beta\n\nVersion: 0.3.0\n\n#### Skills\n\nNo skills at this commit.') !== -1);
  });

  it('parses back to the same ids, kinds, statuses and descriptions, with no errors', () => {
    const parsed = parseToolkitCatalog(renderToolkitCatalog(build()));
    assert.deepEqual(parsed.errors, []);
    assert.equal(parsed.frontMatter.toolkitCommit, TOOLKIT_META.commit);
    assert.equal(parsed.frontMatter.toolkitCommitShort, 'fedcba9');
    assert.deepEqual(parsed.capabilities.get('beta:beta-checker'), { plugin: 'beta', kind: 'agent', status: 'active', description: 'Checks the beta build.' });
    assert.equal(parsed.capabilities.get('alpha:alpha-old').status, 'deprecated');
    assert.equal(parsed.capabilities.size, 5);
  });
});

describe('parseToolkitCatalog', () => {
  const good = renderToolkitCatalog(build());
  const errorsAfter = (from, to) => {
    if (good.indexOf(from) === -1) {
      throw new Error(`fixture text has no ${from}`);
    }
    return parseToolkitCatalog(good.replace(from, to)).errors;
  };
  const cases = [
    ['an unknown status', '| `alpha:alpha-plan` | active |', '| `alpha:alpha-plan` | zzz |', /toolkit catalog alpha:alpha-plan: status zzz must be active or deprecated/],
    ['a hand-edited deprecated status', '| `alpha:alpha-old` | deprecated |', '| `alpha:alpha-old` | active |', /front matter says 1 deprecated but the tables have 0; regenerate it/],
    ['a blank description', 'Checks the beta build.', '', /toolkit catalog beta:beta-checker: description is blank/],
    ['a missing cell', '| `beta:beta-checker` | active | Checks the beta build. |', '| `beta:beta-checker` | active |', /beta Agents row 1: has 2 cells, expected 3/],
    ['an id without backticks', '| `beta:beta-build` |', '| beta:beta-build |', /beta Skills row 1: capability id must be in backticks/],
    ['an extra row', '| `beta:beta-build` |', '| `beta:beta-extra` | active | Extra. |\n| `beta:beta-build` |', /plugin beta: front matter and tables disagree/],
    ['a renamed Plugins section', '## Plugins', '## Plug-ins', /toolkit catalog has no capability tables under ## Plugins/],
    ['a changed header', '| Capability id | Status | Description |', '| Capability id | State | Description |', /columns must be: Capability id \| Status \| Description/]
  ];
  cases.forEach(([name, from, to, pattern]) => {
    it(`reports ${name}`, () => {
      const errors = errorsAfter(from, to);
      assert.ok(errors.some((error) => pattern.test(error)), `${pattern}\n${errors.join('\n')}`);
    });
  });
});

describe('readToolkitFiles', () => {
  const pin = { pluginRoot: 'src/plugins', plugins: ['alpha'] };
  const LISTINGS = {
    skills: ['skills/a/SKILL.md', 'skills/a/agents/helper.md', 'skills/a/notes.md'],
    agents: ['agents/x.md'],
    'plugin.yaml': ['plugin.yaml']
  };
  const fakeTree = (listed, listings = LISTINGS, base = 'src/plugins/alpha/') => ({
    sha: TOOLKIT_META.commit,
    list(dir) {
      listed.push(dir);
      const key = Object.keys(listings).find((name) => dir.endsWith(`/${name}`));
      return (listings[key] ?? []).map((path) => `${base}${path}`);
    },
    read(path) {
      return `text of ${path}\r\n`;
    }
  });

  it('reads only skills, top-level agents and plugin.yaml of the listed plugins', () => {
    const listed = [];
    const files = readToolkitFiles(fakeTree(listed), pin);
    assert.deepEqual(listed, ['src/plugins/alpha/skills', 'src/plugins/alpha/agents', 'src/plugins/alpha/plugin.yaml']);
    assert.deepEqual(Array.from(files.keys()), ['alpha/skills/a/SKILL.md', 'alpha/agents/x.md', 'alpha/plugin.yaml']);
    assert.equal(files.get('alpha/plugin.yaml'), 'text of src/plugins/alpha/plugin.yaml\n');
  });

  it('accepts ./ and a trailing slash on pluginRoot, and rejects paths that leave the repository', () => {
    for (const pluginRoot of ['./src/plugins', 'src/plugins/', ' ./src/plugins/ ']) {
      const listed = [];
      readToolkitFiles(fakeTree(listed), { ...pin, pluginRoot });
      assert.equal(listed[0], 'src/plugins/alpha/skills', pluginRoot);
    }
    for (const pluginRoot of ['../src/plugins', '/src/plugins', 'src\\plugins', 'src/./plugins']) {
      assert.throws(() => readToolkitFiles(fakeTree([]), { ...pin, pluginRoot }), catalogError(/must be a relative path inside the repository/), pluginRoot);
    }
  });

  it('rejects a bad plugin list or root', () => {
    const tree = fakeTree([]);
    assert.throws(() => readToolkitFiles(tree, { ...pin, plugins: [] }), catalogError(/plugins must be a non-empty list/));
    assert.throws(() => readToolkitFiles(tree, { ...pin, plugins: ['alpha', 'alpha'] }), catalogError(/lists a plugin twice/));
    assert.throws(() => readToolkitFiles(tree, { ...pin, plugins: ['../cmk'] }), catalogError(/plugin \.\.\/cmk is not a valid plugin id/));
    assert.throws(() => readToolkitFiles(tree, { ...pin, pluginRoot: '' }), catalogError(/pluginRoot must be a non-empty path/));
  });

  it('names a plugin that is not at the commit, instead of reading it', () => {
    const reads = [];
    const tree = { ...fakeTree([], {}), read: (path) => reads.push(path) };
    assert.throws(() => readToolkitFiles(tree, pin), catalogError(/toolkit pin plugin alpha is not under src\/plugins at fedcba9; check plugins and pluginRoot/));
    assert.deepEqual(reads, []);
  });

  it('skips a missing plugin.yaml so the model can name it', () => {
    const files = readToolkitFiles(fakeTree([], { skills: ['skills/a/SKILL.md'] }), pin);
    assert.deepEqual(Array.from(files.keys()), ['alpha/skills/a/SKILL.md']);
  });

  it('refuses skill folders with no SKILL.md, nested agents, and listings outside the plugin', () => {
    assert.throws(() => readToolkitFiles(fakeTree([], { ...LISTINGS, skills: ['skills/a/SKILL.md', 'skills/b/skill.md'] }), pin),
      catalogError(/alpha\/skills\/b has no SKILL.md/));
    assert.throws(() => readToolkitFiles(fakeTree([], { ...LISTINGS, agents: ['agents/group/x.md'] }), pin),
      catalogError(/alpha\/agents\/group\/x.md is not a top-level agent file/));
    assert.throws(() => readToolkitFiles(fakeTree([], LISTINGS, 'elsewhere/'), pin),
      catalogError(/git listed elsewhere\/skills\/a\/SKILL.md outside src\/plugins\/alpha\//));
  });

  it('wraps git failures in list and read with the path and commit', () => {
    const sha = TOOLKIT_META.commit;
    const run = (command, args) => {
      if (args.indexOf('cat-file') !== -1) {
        return 'commit\n';
      }
      if (args.indexOf('-s') !== -1) {
        return '2026-10-13T09:48:14-05:00\n';
      }
      throw Object.assign(new Error('Command failed'), { stderr: "fatal: path 'src/plugins/nope/plugin.yaml' does not exist\n" });
    };
    const tree = openPinnedTree('.', sha, run, TOOLKIT_TREE_OPTIONS);
    assert.throws(() => tree.read('src/plugins/nope/plugin.yaml'),
      catalogError(/^ai-dev-toolkit git could not read src\/plugins\/nope\/plugin.yaml at fedcba9: fatal: path/));
    assert.throws(() => tree.list('src/plugins/nope/skills'), catalogError(/^ai-dev-toolkit git could not list src\/plugins\/nope\/skills at fedcba9/));
  });

  it('labels pinned-tree errors for the toolkit, and keeps the CMK wording by default', () => {
    const missing = join(tmpdir(), 'no-such-toolkit-checkout');
    const sha = TOOLKIT_META.commit;
    assert.throws(() => openPinnedTree(missing, sha, () => 'commit\n', TOOLKIT_TREE_OPTIONS),
      (error) => error.code === 'missing_checkout' && /^ai-dev-toolkit checkout not found at .*clone the ai-dev-toolkit repository there or pass --toolkit <path>\.$/.test(error.message));
    assert.throws(() => openPinnedTree('.', sha, () => {
      throw new Error('fatal: Not a valid object name');
    }, TOOLKIT_TREE_OPTIONS), (error) => error.code === 'missing_commit' && /^ai-dev-toolkit commit fedcba9 is not in/.test(error.message));
    assert.throws(() => openPinnedTree(missing, sha, () => 'commit\n'), /CMK checkout not found at .*clone the CMK repository there or pass --cmk <path>\.$/);
  });
});

describe('validateToolkitPin', () => {
  const pin = { repository: 'https://example.test/toolkit.git', commit: TOOLKIT_META.commit, localPath: '../toolkit', pluginRoot: './src/plugins/', plugins: ['alpha'] };

  it('normalizes pluginRoot and keeps the other fields', () => {
    assert.deepEqual(validateToolkitPin(pin, 'pin.json'), { ...pin, pluginRoot: 'src/plugins' });
  });

  it('names a pin that is not an object, or has no repository or localPath', () => {
    assert.throws(() => validateToolkitPin([], 'pin.json'), catalogError(/^pin.json must be a JSON object/));
    assert.throws(() => validateToolkitPin({ ...pin, repository: undefined }, 'pin.json'), catalogError(/^pin.json repository must be a non-empty string/));
    assert.throws(() => validateToolkitPin({ ...pin, localPath: ' ' }, 'pin.json'), catalogError(/^pin.json localPath must be a non-empty string/));
  });
});
