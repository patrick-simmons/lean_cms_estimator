import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { loadToolkitPin, readJsonFile } from './generate.mjs';
import { parseCmkCatalog, parseEstimatingCatalog } from './parse.mjs';
import { CatalogError, errorText } from './text.mjs';
import { parseToolkitCatalog } from './toolkit-parse.mjs';

export function runCli(main) {
  try {
    main();
  } catch (error) {
    console.error(errorText(error));
    process.exitCode = 1;
  }
}

export function writeCatalog(output, text) {
  mkdirSync(dirname(output), { recursive: true });
  writeFileSync(output, text, 'utf8');
  console.log(`wrote ${output}`);
}

export function readCatalogDocs(root) {
  const read = (name) => readFileSync(join(root, 'docs', 'catalogs', name), 'utf8');
  return {
    cmk: parseCmkCatalog(read('cmk-capability-catalog.md')),
    toolkit: parseToolkitCatalog(read('toolkit-capability-catalog.md')),
    estimating: parseEstimatingCatalog(read('estimating-catalog.md'))
  };
}

/**
 * The tags the bundled starter files are made and checked for: the estimating catalog's version and the two
 * pinned commits. Throws when one is missing, so a broken catalog or pin cannot be bundled as "vundefined".
 */
export function bundledTags(root) {
  const { estimating } = readCatalogDocs(root);
  const tags = {
    estimatingVersion: estimating.frontMatter.version,
    cmkCommit: readJsonFile(join(root, 'tools', 'cmk-catalog.pin.json')).commit,
    toolkitCommit: loadToolkitPin(root).commit
  };
  const present = (value) => (typeof value === 'string' && value.trim() !== '') || (typeof value === 'number' && Number.isFinite(value));
  for (const [name, value] of Object.entries(tags)) {
    if (!present(value)) {
      throw new CatalogError(`cannot tell the bundled starter files what ${name} is: it is missing from the estimating catalog front matter or the pin file`);
    }
  }
  return tags;
}