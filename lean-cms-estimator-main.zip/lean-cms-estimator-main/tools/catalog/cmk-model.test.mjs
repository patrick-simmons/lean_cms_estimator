import assert from 'node:assert/strict';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import { STATUSES, assetStatus, buildCmkCatalog, generatedNames, validateSummaries } from './cmk-model.mjs';
import { renderCmkCatalog } from './cmk-render.mjs';
import { baseAdapters, baseLock, baseRegistry, baseSummaries, buildFiles, META, REGISTRY_TEXT, skillFile } from './fixtures.mjs';
import { openPinnedTree, readPluginFiles } from './git-tree.mjs';
import { parseCmkCatalog } from './parse.mjs';
import { CatalogError } from './text.mjs';

function catalogError(pattern) {
  return (error) => error instanceof CatalogError && pattern.test(error.message);
}

function build(options = {}) {
  const registry = options.registry ?? baseRegistry();
  return buildCmkCatalog(buildFiles({ ...options, registry }), META, options.summaries ?? baseSummaries(registry));
}

function platform(model, id) {
  return model.platforms.find((item) => item.id === id);
}

describe('assetStatus', () => {
  const registry = baseRegistry();
  const { open, closed } = registry.sources;

  it('exports the three catalog statuses', () => {
    assert.deepEqual(STATUSES, ['supported', 'local-only', 'unavailable']);
  });

  it('supports a permitted source', () => {
    assert.deepEqual(assetStatus(registry.assets['vend-one'], open), { status: 'supported', reasonCode: '', reason: '' });
  });

  it('keeps an admissible local-only internal source usable but excluded from distributable output', () => {
    assert.deepEqual(assetStatus(registry.assets['vend-local'], closed), {
      status: 'local-only',
      reasonCode: 'distributable_excluded',
      reason: 'excluded from distributable output'
    });
  });

  it('marks unavailable activation and a missing source', () => {
    assert.equal(assetStatus(registry.assets['vend-off'], open).reasonCode, 'activation_unavailable');
    assert.equal(assetStatus(registry.assets['vend-one'], undefined).reasonCode, 'activation_unavailable');
  });

  it('honours a licence set on the primitive contract', () => {
    const asset = registry.assets['vend-one'];
    const overridden = { ...asset, primitive_contracts: { build: { kind: 'skill', license: { redistribution: 'prohibited', evidence: 'x' } } } };
    assert.equal(assetStatus(overridden, open).reasonCode, 'activation_unavailable');
  });

  it('names the asset when neither its contract nor its source has a licence', () => {
    const asset = { ...registry.assets['vend-one'], primitive_contracts: { build: { kind: 'skill' } } };
    assert.throws(() => assetStatus(asset, { retention: 'reviewed_snapshot' }, 'vend-one'), catalogError(/asset vend-one has no license/));
  });
});

describe('generatedNames', () => {
  it('joins the namespace and the selected id, sorted', () => {
    assert.deepEqual(generatedNames('vend-two', baseRegistry().assets['vend-two']), ['vtwo-check', 'vtwo-deploy']);
  });

  it('rejects invalid, over-long and uncontracted names, and a missing selection', () => {
    const asset = baseRegistry().assets['vend-one'];
    assert.throws(() => generatedNames('x', { ...asset, distribution: { namespace: 'Bad_Name' } }), /invalid capability id/);
    assert.throws(() => generatedNames('x', { ...asset, distribution: { namespace: 'a'.repeat(70) } }), /invalid capability id/);
    assert.throws(() => generatedNames('x', { ...asset, primitive_contracts: {} }), /without a primitive contract/);
    assert.throws(() => generatedNames('x', { ...asset, selection: {} }), /no selection.primitives/);
  });
});

describe('validateSummaries', () => {
  it('names every missing and extra key in one list', () => {
    const errors = validateSummaries({ 'vend-one': 'Fine.', stray: 'Nope.' }, ['vend-one', 'vend-two']);
    assert.deepEqual(errors, ['missing summary for vendor asset vend-two', 'summary stray does not match a vendor asset']);
  });

  it('rejects empty, multi-line, piped, long and unpunctuated summaries', () => {
    const cases = { a: ' ', b: 'Two\nlines.', c: 'A | B.', d: `${'x'.repeat(161)}.`, e: 'No full stop' };
    assert.equal(validateSummaries(cases, Object.keys(cases)).length, 5);
  });
});

describe('buildCmkCatalog', () => {
  it('reads skills and agents by frontmatter name, on one line', () => {
    const model = build();
    assert.deepEqual(model.skills.map((skill) => skill.id), ['cmk-alpha', 'cmk-beta']);
    assert.equal(model.skills[0].description, 'First line of the description continues on a second line');
    assert.deepEqual(model.agents.map((agent) => agent.id), ['cmk-alpha-agent', 'cmk-beta-agent']);
  });

  it('keeps each adapter to its own vendor assets and shares an asset across platforms', () => {
    const model = build();
    assert.deepEqual(platform(model, 'plat-b').assets, []);
    assert.equal(platform(model, 'plat-a').assets.find((asset) => asset.assetId === 'vend-shared').mode, 'default');
    assert.equal(platform(model, 'plat-c').assets.find((asset) => asset.assetId === 'vend-shared').mode, 'opt_in');
  });

  it('counts supported, local-only and unavailable capabilities', () => {
    const { counts } = build();
    assert.equal(counts.vendorAssets, 5);
    assert.equal(counts.vendorAssetsSupported, 3);
    assert.equal(counts.vendorAssetsLocalOnly, 1);
    assert.equal(counts.vendorAssetsUnavailable, 1);
    assert.equal(counts.vendorCapabilitiesSupported, 4);
    assert.equal(counts.vendorCapabilitiesLocalOnly, 1);
    assert.equal(counts.vendorCapabilitiesUnavailable, 1);
    assert.deepEqual(counts.byPlatform.find((item) => item.id === 'plat-c'), {
      id: 'plat-c', vendorAssets: 3, supportedCapabilities: 1, localOnlyCapabilities: 1, unavailableCapabilities: 1
    });
  });

  it('does not require lock entries for a local-only asset or its source', () => {
    const lock = baseLock();
    delete lock.sources.closed;
    delete lock.assets['vend-local'];
    assert.equal(platform(build({ lock }), 'plat-c').assets.find((asset) => asset.assetId === 'vend-local').status, 'local-only');
  });

  it('throws on registry problems', () => {
    const unlocked = baseLock();
    delete unlocked.assets['vend-one'];
    assert.throws(() => build({ lock: unlocked }), /available asset vend-one is not locked/);

    const unknown = baseAdapters();
    unknown['plat-a'].vendor_assets.push({ asset: 'nope', mode: 'default' });
    assert.throws(() => build({ adapters: unknown }), /unknown vendor asset nope/);

    const badMode = baseAdapters();
    badMode['plat-a'].vendor_assets[0].mode = 'sometimes';
    assert.throws(() => build({ adapters: badMode }), /invalid mode sometimes/);

    const misnamed = baseAdapters();
    misnamed['plat-a'].platform = 'other';
    assert.throws(() => build({ adapters: misnamed }), /declares platform other/);

    const colliding = baseRegistry();
    colliding.assets['vend-one'].distribution.namespace = 'cmk';
    colliding.assets['vend-one'].selection.primitives[0].id = 'alpha';
    colliding.assets['vend-one'].primitive_contracts = { alpha: { kind: 'skill' } };
    assert.throws(() => build({ registry: colliding }), /collides with a CMK skill/);
  });

  it('throws a CatalogError naming each further registry problem', () => {
    const withAsset = (namespace, id) => {
      const registry = baseRegistry();
      Object.assign(registry.assets['vend-one'], {
        distribution: { namespace },
        selection: { primitives: [{ id }] },
        primitive_contracts: { [id]: { kind: 'skill' } }
      });
      return registry;
    };
    const unknownSource = baseRegistry();
    unknownSource.assets['vend-one'].source = 'opne';
    const noSources = baseRegistry();
    delete noSources.sources;
    const notAList = baseAdapters();
    notAList['plat-a'].vendor_assets = { asset: 'vend-one' };
    const cases = [
      [{ registry: withAsset('vtwo', 'deploy') }, /vtwo-deploy from vendor asset vend-two collides with vendor asset vend-one/],
      [{ registry: withAsset('cmk', 'alpha-agent') }, /cmk-alpha-agent from vendor asset vend-one collides with a CMK agent/],
      [{ registry: unknownSource }, /asset vend-one references unknown source opne/],
      [{ registry: noSources, lock: baseLock() },/vendor-assets.yaml must have assets and sources mappings/],
      [{ adapters: notAList }, /plat-a.yaml vendor_assets must be a list/],
      [{ omit: ['vendor-assets.yaml'] }, /vendor-assets.yaml is missing at the pinned commit/],
      [{ omit: ['vendor-assets.lock.json'] }, /vendor-assets.lock.json is missing at the pinned commit/],
      [{ extra: [['skills/wrong/SKILL.md', skillFile('cmk-gamma', 'Gamma.')]] }, /skills\/wrong\/SKILL.md name cmk-gamma does not match its directory/],
      [{ extra: [['skills/cmk-gamma/SKILL.md', '# No front matter\n']] }, /skills\/cmk-gamma\/SKILL.md has no frontmatter/],
      [{ extra: [['skills/cmk-init/adapters/plat-z.yaml', 'platform: [plat-z\n']] }, /^skills\/cmk-init\/adapters\/plat-z.yaml: /]
    ];
    cases.forEach(([options, pattern]) => {
      assert.throws(() => build(options), catalogError(pattern), String(pattern));
    });
  });

  it('throws one error naming every summary problem', () => {
    const summaries = baseSummaries();
    delete summaries['vend-two'];
    summaries.extra = 'Extra.';
    assert.throws(() => build({ summaries }), (error) => /vend-two/.test(error.message) && /extra/.test(error.message));
  });
});

describe('renderCmkCatalog', () => {
  it('gives the same text whatever the file order', () => {
    const forward = renderCmkCatalog(build());
    const reversed = renderCmkCatalog(buildCmkCatalog(buildFiles({ reverse: true }), META, baseSummaries()));
    assert.equal(forward, reversed);
  });

  it('writes LF, one trailing newline, no registry text, and escapes pipes', () => {
    const text = renderCmkCatalog(build());
    assert.equal(text.indexOf('\r'), -1);
    assert.ok(text.endsWith('|\n') && !text.endsWith('\n\n'));
    REGISTRY_TEXT.forEach((value) => assert.equal(text.indexOf(value), -1));
    assert.ok(text.indexOf('Has a pipe \\| inside') !== -1);
    assert.ok(text.indexOf('No vendor assets at this commit.') !== -1);
    assert.ok(text.indexOf('`vend-off` | Display voff | default | unavailable | activation_unavailable') !== -1);
    assert.ok(text.indexOf('`vend-local` | Display vlocal | default | local-only | distributable_excluded') !== -1);
  });

  it('parses back to the same ids, modes and statuses', () => {
    const parsed = parseCmkCatalog(renderCmkCatalog(build()));
    assert.deepEqual(Array.from(parsed.allPlatforms.keys()).sort(), ['cmk-alpha', 'cmk-alpha-agent', 'cmk-beta', 'cmk-beta-agent']);
    assert.equal(parsed.allPlatforms.get('cmk-alpha-agent'), 'agent');
    assert.deepEqual(parsed.platforms.get('plat-a').get('vtwo-deploy'), { assetId: 'vend-two', mode: 'opt_in', status: 'supported' });
    assert.deepEqual(parsed.platforms.get('plat-c').get('vlocal-ops'), { assetId: 'vend-local', mode: 'default', status: 'local-only' });
    assert.equal(parsed.platforms.get('plat-b').size, 0);
    assert.equal(parsed.frontMatter.counts.vendorCapabilitiesSupported, 4);
    assert.equal(parsed.frontMatter.counts.vendorCapabilitiesLocalOnly, 1);
  });
});

describe('git reader', () => {
  const sha = '0123456789abcdef0123456789abcdef01234567';

  it('refuses vendor snapshot paths without calling git', () => {
    const calls = [];
    const tree = openPinnedTree('.', sha, (command, args) => {
      calls.push(args.join(' '));
      return args.indexOf('cat-file') !== -1 ? 'commit\n' : '2026-10-06T10:58:59-05:00\n';
    });
    const before = calls.length;
    assert.throws(() => tree.read('plugin/vendor-snapshots/x/SKILL.md'), /vendor snapshots/);
    assert.throws(() => tree.list('plugin/vendor-snapshots'), /vendor snapshots/);
    assert.equal(calls.length, before);
  });

  it('says how to fetch a missing commit', () => {
    assert.throws(() => openPinnedTree('.', sha, () => {
      throw new Error('fatal: Not a valid object name');
    }), (error) => error.code === 'missing_commit' && /CMK commit 0123456 is not in .*fetch origin/.test(error.message));
    assert.throws(() => openPinnedTree('.', sha, () => 'tree\n'), (error) => error.code === 'missing_commit');
  });

  it('requires a full commit SHA and an existing checkout before calling git', () => {
    let calls = 0;
    const run = () => {
      calls++;
      return 'commit\n';
    };
    assert.throws(() => openPinnedTree('.', 'HEAD', run), catalogError(/CMK pin HEAD must be a full 40-character commit SHA/));
    assert.throws(() => openPinnedTree(join(tmpdir(), 'no-such-cmk-checkout'), sha, run), (error) => error.code === 'missing_checkout'
      && /CMK checkout not found at .*pass --cmk <path>/.test(error.message));
    assert.equal(calls, 0);
  });

  it('reports other git failures as they are, not as a missing commit', () => {
    const failure = Object.assign(new Error('Command failed'), { stderr: 'fatal: detected dubious ownership in repository\n' });
    assert.throws(() => openPinnedTree('.', sha, () => {
      throw failure;
    }), (error) => /git could not read .*dubious ownership/.test(error.message) && !/fetch origin/.test(error.message));
  });

  it('lists only skills and agents, and reads the two fixed files', () => {
    const listed = [];
    const run = (command, args) => {
      if (args.indexOf('cat-file') !== -1) {
        return 'commit\n';
      }
      if (args.indexOf('ls-tree') !== -1) {
        const dir = args[args.length - 1];
        listed.push(dir);
        return dir.endsWith('/skills')
          ? 'p/skills/cmk-a/SKILL.md\np/skills/cmk-a/notes.md\np/skills/cmk-init/adapters/x.yaml\n'
          : 'p/agents/a.md\n';
      }
      if (args.indexOf('-s') !== -1) {
        return '2026-10-06T10:58:59-05:00\n';
      }
      return 'text\r\n';
    };
    const tree = openPinnedTree('.', sha, run);
    const files = readPluginFiles(tree, 'p');
    assert.deepEqual(listed, ['p/skills', 'p/agents']);
    assert.deepEqual(Array.from(files.keys()), [
      'skills/cmk-a/SKILL.md',
      'skills/cmk-init/adapters/x.yaml',
      'agents/a.md',
      'vendor-assets.yaml',
      'vendor-assets.lock.json'
    ]);
    assert.equal(files.get('agents/a.md'), 'text\n');
  });
});
