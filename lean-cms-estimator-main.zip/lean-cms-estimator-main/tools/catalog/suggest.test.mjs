import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';
import { buildCmkCatalog } from './cmk-model.mjs';
import { renderCmkCatalog } from './cmk-render.mjs';
import { baseSummaries, buildFiles, buildToolkitFiles, estimatingV2Text, META, TOOLKIT_META, TOOLKIT_PLUGINS } from './fixtures.mjs';
import { parseCmkCatalog, parseEstimatingCatalog } from './parse.mjs';
import { ALTERNATIVE_IDS, suggest, tokenize, TOP_N } from './suggest.mjs';
import { CatalogError } from './text.mjs';
import { buildToolkitCatalog } from './toolkit-model.mjs';
import { parseToolkitCatalog } from './toolkit-parse.mjs';
import { renderToolkitCatalog } from './toolkit-render.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const cmk = parseCmkCatalog(renderCmkCatalog(buildCmkCatalog(buildFiles(), META, baseSummaries())));
const toolkit = parseToolkitCatalog(renderToolkitCatalog(buildToolkitCatalog(buildToolkitFiles(), TOOLKIT_META, TOOLKIT_PLUGINS)));
const estimating = parseEstimatingCatalog(estimatingV2Text());

function rowsFor(result, wp) {
  return Object.fromEntries(result.sections.find((section) => section.wp === wp).rows.map((row) => [row.target, row.candidates]));
}

describe('tokenize', () => {
  it('lowercases, drops stop words and short tokens, and stems lightly', () => {
    assert.deepEqual(Array.from(tokenize('Testing the Deployed stories, Components and class: run CMK ux')).sort(),
      ['class', 'component', 'deploy', 'story', 'test']);
  });
});

describe('suggest', () => {
  it('ranks id matches above description matches and skips listed, method and deprecated ids', () => {
    const result = suggest({ cmk, toolkit, estimating, keywords: { 'shape-build': ['alpha', 'pipe', 'old', 'build'] } });
    const all = rowsFor(result, 'shape-build').all;
    assert.deepEqual(all, [
      { id: 'alpha:alpha-flow', score: 3 },
      { id: 'cmk-alpha-agent', score: 2 },
      { id: 'cmk-beta', score: 1 }
    ]);
  });

  it('offers vendor ids only for their own pilot, only when supported, and says when nothing matches', () => {
    const result = suggest({ cmk, toolkit, estimating, keywords: { 'shape-design': ['share', 'ops', 'gone', 'build'] } });
    const rows = rowsFor(result, 'shape-design');
    assert.deepEqual(rows['plat-c'].map((candidate) => candidate.id), ['vshared-share']);
    assert.deepEqual(rows['plat-a'].map((candidate) => candidate.id).sort(), ['vone-build', 'vshared-share']);
    assert.ok(result.text.indexOf('## shape-design Design\n\nall: no suggestions\n') !== -1, result.text);
  });

  it('skips toolkit ids already in another activity, and the alternatives to cdk-loop', () => {
    const capabilities = new Map(toolkit.capabilities);
    ALTERNATIVE_IDS.forEach((id) => capabilities.set(id, { plugin: 'pdk', kind: 'skill', status: 'active', description: 'Plans the alpha work.' }));
    const result = suggest({ cmk, toolkit: { ...toolkit, capabilities }, estimating, keywords: { 'shape-design': ['alpha', 'plan', 'work'] } });
    const ids = rowsFor(result, 'shape-design').all.map((candidate) => candidate.id);
    assert.ok(ids.indexOf('alpha:alpha-plan') === -1, ids.join(', '));
    ALTERNATIVE_IDS.forEach((id) => assert.ok(ids.indexOf(id) === -1, id));
    assert.ok(ids.indexOf('alpha:alpha-flow') !== -1, ids.join(', '));
  });

  it('refuses catalogs that have parse errors or nothing to work with', () => {
    const broken = { ...estimating, errors: ['no Capabilities table'] };
    assert.throws(() => suggest({ cmk, toolkit, estimating: broken, keywords: {} }),
      (error) => error instanceof CatalogError && /fix the catalogs first \(npm run catalog:check\):\nno Capabilities table/.test(error.message));
    assert.throws(() => suggest({ cmk, toolkit, estimating: { ...estimating, activities: [] }, keywords: {} }),
      (error) => error instanceof CatalogError && /no activities to suggest for/.test(error.message));
    assert.throws(() => suggest({ cmk, toolkit: { ...toolkit, capabilities: new Map() }, estimating, keywords: {} }),
      (error) => error instanceof CatalogError && /toolkit catalog has no capabilities/.test(error.message));
    const descriptions = new Map(cmk.descriptions);
    descriptions.delete('cmk-beta');
    assert.throws(() => suggest({ cmk: { ...cmk, descriptions }, toolkit, estimating, keywords: {} }),
      (error) => error instanceof CatalogError && /no description for cmk-beta/.test(error.message));
  });

  it(`keeps the top ${TOP_N}, breaking ties by id`, () => {
    const capabilities = new Map(['g', 'b', 'f', 'a', 'e', 'c', 'd'].map((letter) => [`t:match-${letter}`, { plugin: 't', kind: 'skill', status: 'active', description: '' }]));
    const stubEstimating = { frontMatter: { pilotPlatforms: [] }, activities: [{ id: 'shape-build', name: 'Match', driver: '' }], capabilities: [], methods: [], errors: [] };
    const stubCmk = { allPlatforms: new Map(), platforms: new Map(), descriptions: new Map(), errors: [] };
    const result = suggest({ cmk: stubCmk, toolkit: { capabilities, errors: [] }, estimating: stubEstimating, keywords: {} });
    assert.deepEqual(rowsFor(result, 'shape-build').all.map((candidate) => candidate.id), ['t:match-a', 't:match-b', 't:match-c', 't:match-d', 't:match-e']);
  });

  it('rejects keywords for unknown activities and values that are not word lists', () => {
    assert.throws(() => suggest({ cmk, toolkit, estimating, keywords: { 'shape-ghost': ['x'] } }),
      (error) => error instanceof CatalogError && /suggest keywords shape-ghost is not an activity/.test(error.message));
    assert.throws(() => suggest({ cmk, toolkit, estimating, keywords: { 'shape-build': 'build' } }),
      (error) => error instanceof CatalogError && /suggest keywords shape-build must be a list of words/.test(error.message));
  });

  it('gives one section per committed activity, the same text every time', () => {
    const read = (name) => readFileSync(join(root, 'docs', 'catalogs', name), 'utf8');
    const inputs = () => ({
      cmk: parseCmkCatalog(read('cmk-capability-catalog.md')),
      toolkit: parseToolkitCatalog(read('toolkit-capability-catalog.md')),
      estimating: parseEstimatingCatalog(read('estimating-catalog.md')),
      keywords: JSON.parse(readFileSync(join(root, 'tools', 'catalog-suggest-keywords.json'), 'utf8'))
    });
    const first = suggest(inputs());
    assert.equal(first.sections.length, inputs().estimating.activities.length);
    assert.equal(first.text, suggest(inputs()).text);
  });
});
