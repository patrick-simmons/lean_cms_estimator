import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { before, describe, it } from 'node:test';
import { generateToolkitCatalog, loadToolkitPin } from './generate.mjs';
import { openPinnedTree, TOOLKIT_TREE_OPTIONS } from './git-tree.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const pin = loadToolkitPin(root);
const toolkitPath = resolve(root, pin.localPath);
const gitCalls = [];

function recordingRun(command, args, options) {
  gitCalls.push(args);
  return execFileSync(command, args, options);
}

function openTree() {
  if (!existsSync(toolkitPath)) {
    return { skip: `no ai-dev-toolkit checkout at ${toolkitPath}` };
  }
  try {
    return { tree: openPinnedTree(toolkitPath, pin.commit, recordingRun, TOOLKIT_TREE_OPTIONS), skip: false };
  } catch (error) {
    if (error.code === 'missing_commit') {
      return { skip: error.message };
    }
    throw error;
  }
}

const { tree, skip } = openTree();

describe('toolkit catalog at the pinned commit', { skip }, () => {
  let first;
  let second;

  before(() => {
    first = generateToolkitCatalog(tree, pin);
    second = generateToolkitCatalog(tree, pin);
  });

  it('generates the committed file, byte for byte, every time', () => {
    assert.equal(first.text, second.text);
    assert.equal(first.text, readFileSync(join(root, 'docs', 'catalogs', 'toolkit-capability-catalog.md'), 'utf8'));
  });

  it('has the expected counts, the one deprecated skill, and adr:adr', () => {
    const { counts, plugins } = first.model;
    assert.deepEqual([counts.skills, counts.agents, counts.deprecated], [78, 12, 1]);
    const byPlugin = Object.fromEntries(counts.byPlugin.map((item) => [item.id, [item.skills, item.agents]]));
    assert.deepEqual(byPlugin, { adr: [1, 3], cdk: [13, 9], 'launch-delivery': [22, 0], pdk: [42, 0] });
    const entries = plugins.flatMap((plugin) => plugin.skills.concat(plugin.agents));
    assert.deepEqual(entries.filter((entry) => entry.status === 'deprecated').map((entry) => entry.id), ['launch-delivery:test-plan']);
    assert.ok(entries.some((entry) => entry.id === 'adr:adr'));
  });

  it('runs only cat-file, show and ls-tree, and only under the listed plugins', () => {
    assert.ok(gitCalls.length > 0);
    const roots = pin.plugins.map((plugin) => `${pin.pluginRoot}/${plugin}/`);
    for (const args of gitCalls) {
      const verb = args[2];
      assert.ok(['cat-file', 'show', 'ls-tree'].indexOf(verb) !== -1, args.join(' '));
      assert.equal(args.some((arg) => arg.indexOf('sample-plugin') !== -1 || arg.indexOf('vendor-snapshots') !== -1), false, args.join(' '));
      if (verb === 'ls-tree') {
        assert.ok(roots.some((prefix) => args[args.length - 1].startsWith(prefix)), args.join(' '));
      }
      if (verb === 'show' && args[3] !== '-s') {
        const path = args[3].slice(args[3].indexOf(':') + 1);
        assert.ok(roots.some((prefix) => path.startsWith(prefix)), args.join(' '));
      }
    }
  });
});
