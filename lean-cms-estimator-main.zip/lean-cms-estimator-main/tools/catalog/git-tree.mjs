import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { CatalogError, cleanText, COMMIT_SHA } from './text.mjs';

export const SKILL_FILE = /^skills\/[^/]+\/SKILL\.md$/;
export const AGENT_FILE = /^agents\/[^/]+\.md$/;
export const ADAPTER_FILE = /^skills\/cmk-init\/adapters\/[^/]+\.yaml$/;

const FIXED_FILES = ['vendor-assets.yaml', 'vendor-assets.lock.json'];
const MAX_BUFFER = 64 * 1024 * 1024;
const MISSING_OBJECT = /not a valid object name|could not get object info/i;
const PLUGIN_ID = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const ROOT_SEGMENT = /^[A-Za-z0-9._-]+$/;

export const CMK_TREE_OPTIONS = { label: 'CMK', flag: '--cmk' };
export const TOOLKIT_TREE_OPTIONS = { label: 'ai-dev-toolkit', flag: '--toolkit' };

export function assertSafePath(path) {
  if (path.indexOf('vendor-snapshots') !== -1) {
    throw new CatalogError(`refusing to read ${path}: vendor snapshots hold upstream text`);
  }
}

function gitDetail(error) {
  const stderr = String(error?.stderr ?? '').trim();
  return stderr || (error instanceof Error ? error.message : String(error));
}

export function openPinnedTree(repoPath, sha, run = execFileSync, options = CMK_TREE_OPTIONS) {
  const { label, flag } = options;
  if (!COMMIT_SHA.test(String(sha ?? ''))) {
    throw new CatalogError(`${label} pin ${sha} must be a full 40-character commit SHA.`);
  }
  if (!existsSync(repoPath)) {
    throw new CatalogError(`${label} checkout not found at ${repoPath}; clone the ${label} repository there or pass ${flag} <path>.`, 'missing_checkout');
  }
  const short = sha.slice(0, 7);
  const exec = (args) => run('git', ['-C', repoPath, ...args], { encoding: 'utf8', maxBuffer: MAX_BUFFER, stdio: ['ignore', 'pipe', 'pipe'] });
  const git = (args, what) => {
    try {
      return String(exec(args));
    } catch (error) {
      throw new CatalogError(`${label} git could not ${what} at ${short}: ${gitDetail(error)}`);
    }
  };
  const missing = () => new CatalogError(`${label} commit ${short} is not in ${repoPath}; run git -C ${repoPath} fetch origin.`, 'missing_commit');
  let type;
  try {
    type = String(exec(['cat-file', '-t', sha])).trim();
  } catch (error) {
    const detail = gitDetail(error);
    if (MISSING_OBJECT.test(detail)) {
      throw missing();
    }
    throw new CatalogError(`git could not read ${repoPath}: ${detail}`);
  }
  if (type !== 'commit') {
    throw missing();
  }
  const commitDate = git(['show', '-s', '--format=%cI', sha], 'read the commit date').trim();
  return {
    sha,
    commitDate,
    list(dir) {
      assertSafePath(dir);
      return git(['ls-tree', '-r', '--name-only', sha, dir], `list ${dir}`)
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line.length > 0);
    },
    read(path) {
      assertSafePath(path);
      return git(['show', `${sha}:${path}`], `read ${path}`);
    }
  };
}

function listUnder(tree, prefix, dir) {
  return tree.list(`${prefix}${dir}`).map((path) => {
    if (!path.startsWith(prefix)) {
      throw new CatalogError(`git listed ${path} outside ${prefix}; check the path in the pin`);
    }
    return path.slice(prefix.length);
  });
}

function listPluginEntries(tree, prefix, patterns) {
  return listUnder(tree, prefix, 'skills')
    .concat(listUnder(tree, prefix, 'agents'))
    .filter((path) => patterns.some((pattern) => pattern.test(path)));
}

export function readPluginFiles(tree, pluginPath) {
  const prefix = `${pluginPath}/`;
  const files = new Map();
  for (const path of listPluginEntries(tree, prefix, [SKILL_FILE, AGENT_FILE, ADAPTER_FILE]).concat(FIXED_FILES)) {
    files.set(path, cleanText(tree.read(`${prefix}${path}`)));
  }
  return files;
}

export function normalizeToolkitPlugins(pin) {
  const plugins = pin.plugins;
  if (!Array.isArray(plugins) || plugins.length === 0) {
    throw new CatalogError('toolkit pin plugins must be a non-empty list');
  }
  for (const plugin of plugins) {
    if (typeof plugin !== 'string' || !PLUGIN_ID.test(plugin)) {
      throw new CatalogError(`toolkit pin plugin ${plugin} is not a valid plugin id`);
    }
  }
  if (new Set(plugins).size !== plugins.length) {
    throw new CatalogError('toolkit pin lists a plugin twice');
  }
  if (typeof pin.pluginRoot !== 'string' || pin.pluginRoot.trim().length === 0) {
    throw new CatalogError('toolkit pin pluginRoot must be a non-empty path');
  }
  const pluginRoot = pin.pluginRoot.trim().replace(/^(\.\/)+/, '').replace(/\/+$/, '');
  const segments = pluginRoot.split('/');
  if (segments.some((segment) => !ROOT_SEGMENT.test(segment) || segment === '.' || segment === '..')) {
    throw new CatalogError(`toolkit pin pluginRoot ${pin.pluginRoot} must be a relative path inside the repository, with / separators`);
  }
  return { pluginRoot, plugins };
}

function checkToolkitLayout(plugin, skills, agents) {
  const skillDirs = new Set(skills.map((path) => path.split('/')[1]));
  skillDirs.forEach((dir) => {
    if (skills.indexOf(`skills/${dir}/SKILL.md`) === -1) {
      throw new CatalogError(`${plugin}/skills/${dir} has no SKILL.md`);
    }
  });
  const stray = agents.find((path) => path.endsWith('.md') && !AGENT_FILE.test(path));
  if (stray) {
    throw new CatalogError(`${plugin}/${stray} is not a top-level agent file (agents/<name>.md)`);
  }
}

export function readToolkitFiles(tree, pin) {
  const { pluginRoot, plugins } = normalizeToolkitPlugins(pin);
  const files = new Map();
  for (const plugin of plugins) {
    const prefix = `${pluginRoot}/${plugin}/`;
    const skills = listUnder(tree, prefix, 'skills');
    const agents = listUnder(tree, prefix, 'agents');
    const manifest = listUnder(tree, prefix, 'plugin.yaml');
    if (skills.length === 0 && agents.length === 0 && manifest.length === 0) {
      throw new CatalogError(`toolkit pin plugin ${plugin} is not under ${pluginRoot} at ${String(tree.sha).slice(0, 7)}; check plugins and pluginRoot in tools/toolkit-catalog.pin.json`);
    }
    checkToolkitLayout(plugin, skills, agents);
    const wanted = skills.concat(agents).filter((path) => SKILL_FILE.test(path) || AGENT_FILE.test(path));
    for (const path of wanted.concat(manifest)) {
      files.set(`${plugin}/${path}`, cleanText(tree.read(`${prefix}${path}`)));
    }
  }
  return files;
}
