import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { before, describe, it } from 'node:test';
import { parse } from 'yaml';
import { generateCmkCatalog, loadInputs } from './generate.mjs';
import { openPinnedTree } from './git-tree.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const { pin, summaries } = loadInputs(root);
const cmkPath = resolve(root, pin.localPath);
const gitCalls = [];

function recordingRun(command, args, options) {
  gitCalls.push(args);
  return execFileSync(command, args, options);
}

function openTree() {
  if (!existsSync(cmkPath)) {
    return { skip: `no CMK checkout at ${cmkPath}` };
  }
  try {
    return { tree: openPinnedTree(cmkPath, pin.commit, recordingRun), skip: false };
  } catch (error) {
    if (error.code === 'missing_commit') {
      return { skip: error.message };
    }
    throw error;
  }
}

const { tree, skip } = openTree();

describe('CMK catalog at the pinned commit', { skip }, () => {
  let first;
  let second;

  before(() => {
    first = generateCmkCatalog(tree, pin, summaries);
    second = generateCmkCatalog(tree, pin, summaries);
  });

  it('generates the committed file, byte for byte, every time', () => {
    assert.equal(first.text, second.text);
    assert.equal(first.text, readFileSync(join(root, 'docs', 'catalogs', 'cmk-capability-catalog.md'), 'utf8'));
  });

  it('has the expected counts', () => {
    const { counts } = first.model;
    assert.deepEqual(
      [counts.skills, counts.agents, counts.platforms, counts.vendorAssets,
        counts.vendorAssetsSupported, counts.vendorAssetsLocalOnly, counts.vendorAssetsUnavailable,
        counts.vendorCapabilitiesSupported, counts.vendorCapabilitiesLocalOnly, counts.vendorCapabilitiesUnavailable],
      [28, 9, 15, 30, 24, 6, 0, 78, 25, 0]
    );
    const byPlatform = Object.fromEntries(counts.byPlatform.map((item) => [item.id,
      [item.vendorAssets, item.supportedCapabilities, item.localOnlyCapabilities, item.unavailableCapabilities]]));
    assert.deepEqual(byPlatform.aem, [8, 8, 0, 0]);
    assert.deepEqual(byPlatform['aem-eds'], [7, 37, 0, 0]);
    assert.deepEqual(byPlatform['aem-65'], [5, 5, 0, 0]);
    assert.deepEqual(byPlatform['sitecore-xm-cloud'], [4, 28, 0, 0]);
    assert.deepEqual(byPlatform.acquia, [5, 0, 17, 0]);
    assert.deepEqual(byPlatform['acquia-meo'], [1, 0, 8, 0]);
    assert.deepEqual(byPlatform.drupal, [1, 0, 2, 0]);
  });

  it('runs only cat-file, show and ls-tree, and never names vendor snapshots', () => {
    assert.ok(gitCalls.length > 0);
    for (const args of gitCalls) {
      assert.ok(['cat-file', 'show', 'ls-tree'].indexOf(args[2]) !== -1, args.join(' '));
      assert.equal(args.some((arg) => arg.indexOf('vendor-snapshots') !== -1), false, args.join(' '));
    }
  });

  it('never copies registry text', () => {
    const registry = parse(first.files.get('vendor-assets.yaml'));
    for (const asset of Object.values(registry.assets)) {
      for (const value of [asset.description, asset.scope]) {
        if (typeof value === 'string' && value.trim().length > 0) {
          assert.equal(first.text.indexOf(value.trim()), -1, value);
        }
      }
    }
  });
});
