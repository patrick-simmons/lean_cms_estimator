#!/usr/bin/env node
/**
 * The case library tool. `validate` is story A-03, `list` is A-04 and `derive` is B-06.
 * Every command defaults to the library in `cases/`.
 *
 *   node tools/cases/cases.mjs validate [file-or-directory]
 *   node tools/cases/cases.mjs list [directory]
 *   node tools/cases/cases.mjs derive <platform> [directory]
 */
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { derive } from './derive.mjs';
import { renderMarkdown } from './list.mjs';
import { validateCase } from './validate.mjs';

const USAGE = 'Usage: node tools/cases/cases.mjs validate|list [file-or-directory]\n'
  + '       node tools/cases/cases.mjs derive <platform> [directory]';
const LIBRARY = 'cases';

/** A library that does not exist yet is an empty one. The tools have to work before the first case. */
function casePaths(target) {
  if (!existsSync(target)) {
    return [];
  }
  if (statSync(target).isDirectory()) {
    return readdirSync(target)
      .filter((name) => name.endsWith('.json'))
      .sort()
      .map((name) => join(target, name));
  }
  return [target];
}

/** @returns {{value: object|undefined, problems: string[]}} problems already name their file */
function readCase(path) {
  const name = basename(path);
  let value;
  try {
    value = JSON.parse(readFileSync(path, 'utf8'));
  } catch (error) {
    return { value: undefined, problems: [`${name}: not valid JSON (${error.message})`] };
  }
  const problems = validateCase(value, basename(path, '.json')).map((problem) => `${name}: ${problem}`);
  return { value, problems };
}

function report(problems, count) {
  for (const problem of problems) {
    console.error(problem);
  }
  console.error(`\n${problems.length} problem(s) in ${count} case file(s)`);
  return 1;
}

/** @returns {{cases: object[]|undefined, code: number}} cases only when every file validates */
function readLibrary(target) {
  const read = casePaths(target).map(readCase);
  const problems = read.flatMap((result) => result.problems);
  if (problems.length > 0) {
    console.error('the library does not validate, so there is nothing trustworthy to report:\n');
    return { cases: undefined, code: report(problems, read.length) };
  }
  return { cases: read.map((result) => result.value), code: 0 };
}

function validateCommand([target = LIBRARY]) {
  const paths = casePaths(resolve(target));
  if (paths.length === 0) {
    console.log(`no case files in ${target}`);
    return 0;
  }
  const problems = paths.flatMap((path) => readCase(path).problems);
  if (problems.length > 0) {
    return report(problems, paths.length);
  }
  console.log(`OK: ${paths.length} case file(s)`);
  return 0;
}

/** Counting an invalid case would print a table that quietly disagrees with the library. */
function listCommand([target = LIBRARY]) {
  const { cases, code } = readLibrary(resolve(target));
  if (!cases) {
    return code;
  }
  console.log(renderMarkdown(cases));
  return 0;
}

/** The platform is required: a rate is derived for a platform, preferring cases from it. */
function deriveCommand([platform, target = LIBRARY]) {
  if (!platform) {
    console.error(USAGE);
    return 2;
  }
  const { cases, code } = readLibrary(resolve(target));
  if (!cases) {
    return code;
  }
  console.log(JSON.stringify(derive(cases, platform), null, 2));
  return 0;
}

const COMMANDS = { validate: validateCommand, list: listCommand, derive: deriveCommand };

function main(argv) {
  const [command, ...rest] = argv.slice(2);
  const run = COMMANDS[command];
  if (!run) {
    console.error(USAGE);
    return 2;
  }
  try {
    return run(rest);
  } catch (error) {
    console.error(`cannot read the case library: ${error.message}`);
    return 1;
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  process.exit(main(process.argv));
}
