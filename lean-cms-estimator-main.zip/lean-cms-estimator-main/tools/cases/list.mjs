/**
 * What the library holds, activity by activity: how much evidence there is, and the best
 * rung that evidence can reach. This is the input to the stage B stop condition (story A-04).
 */
import { ACTIVITIES } from './activities.mjs';
import { ENOUGH_CASES, median, rateOf } from './derive.mjs';

export { ENOUGH_CASES };

/**
 * Rung 1 wants three cases on one platform, so the deciding number is the best-covered
 * platform's count, not the total across all of them.
 */
function rungFor(platforms) {
  const counts = [...platforms.values()];
  if (counts.length === 0) {
    return 'derived';
  }
  return Math.max(...counts) >= ENOUGH_CASES ? 'cases' : 'cases-adjusted';
}

/**
 * @param {object[]} cases valid cases, as `cases.mjs validate` accepts them
 * @returns {object[]} one row per activity, in phase order
 */
export function summarise(cases) {
  return ACTIVITIES.map((activity) => {
    const recorded = cases
      .map((value) => ({ platform: value.platform, entry: value.activities.find((a) => a.activity === activity.id) }))
      .filter((found) => found.entry);

    const platforms = new Map();
    const rates = [];
    for (const { platform, entry } of recorded) {
      const rate = entry.hours > 0 ? rateOf(activity.shape, entry) : undefined;
      if (rate === undefined) {
        continue;
      }
      rates.push(rate);
      platforms.set(platform, (platforms.get(platform) ?? 0) + 1);
    }
    rates.sort((a, b) => a - b);

    return {
      id: activity.id,
      phase: activity.phase,
      unit: activity.unit,
      // Cases that can produce a rate. A zero is evidence the work did not happen, not evidence of its size.
      cases: rates.length,
      zeros: recorded.filter(({ entry }) => entry.hours === 0).length,
      platforms: [...platforms.keys()].sort(),
      low: rates[0],
      median: rates.length > 0 ? median(rates) : undefined,
      high: rates[rates.length - 1],
      rung: rungFor(platforms)
    };
  });
}

/**
 * Three significant figures, not three decimal places: asset migration is fractional hours per
 * asset, and a fixed-decimal rate would round it to 0, which reads as no evidence at all.
 */
function num(value) {
  return Number(value.toPrecision(3)).toString();
}

function spreadCell(row) {
  if (row.cases === 0) {
    return '—';
  }
  const suffix = row.unit ? ` h/${row.unit}` : ' h';
  if (row.cases === 1) {
    return `${num(row.median)}${suffix}`;
  }
  return `${num(row.median)} (${num(row.low)}–${num(row.high)})${suffix}`;
}

export function renderMarkdown(cases) {
  const rows = summarise(cases);
  if (cases.length === 0) {
    return [
      '# Case library',
      '',
      'The library is empty. Every activity would resolve at rung 3, `derived`: the agent sizes it,',
      'the estimator accepts the figure at a checkpoint, and every one of them raises a client question.',
      '',
      'Record the first cases with the sheet in `docs/workshop/case-capture-sheet.md`.'
    ].join('\n');
  }

  const ready = rows.filter((row) => row.rung === 'cases').length;
  const thin = rows.filter((row) => row.rung === 'cases-adjusted').length;
  const none = rows.filter((row) => row.rung === 'derived').length;

  return [
    '# Case library',
    '',
    `${cases.length} case(s). ${ready} of ${rows.length} activities can reach rung 1; ${thin} are thin and ${none} have no evidence at all.`,
    '',
    '| Activity | Phase | Cases | Zeros | Platforms | Hours, median (low–high) | Best rung |',
    '| --- | --- | ---: | ---: | --- | --- | --- |',
    ...rows.map((row) => [
      '',
      `\`${row.id}\``,
      row.phase,
      String(row.cases),
      row.zeros === 0 ? '' : String(row.zeros),
      row.platforms.join(', ') || '—',
      spreadCell(row),
      `\`${row.rung}\``,
      ''
    ].join(' | ').trim()),
    '',
    `**Cases** counts only cases that can produce a rate. **Zeros** are cases that recorded the activity as not happening: evidence, but not evidence of size.`,
    `**Best rung** is the best any single platform can reach. Anything below \`cases\` needs ${ENOUGH_CASES} cases on one platform to climb, and raises a client question until it does.`
  ].join('\n');
}
