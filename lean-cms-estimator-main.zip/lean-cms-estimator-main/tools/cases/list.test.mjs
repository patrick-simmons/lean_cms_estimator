import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { ACTIVITIES } from './activities.mjs';
import { renderMarkdown, summarise } from './list.mjs';
import { repoRoot, workedExample } from './test-helpers.mjs';

/** Only the fields `summarise` reads, so a stats test says what it is about. */
function aCase(platform, activities) {
  return { platform, activities };
}

function rowFor(rows, id) {
  return rows.find((row) => row.id === id);
}

test('an empty library reports rather than fails, and says what that means', () => {
  const report = renderMarkdown([]);
  assert.match(report, /The library is empty/);
  assert.match(report, /rung 3, `derived`/);
});

test('every activity gets a row, in phase order, even with no evidence', () => {
  const rows = summarise([]);
  assert.deepEqual(rows.map((row) => row.id), ACTIVITIES.map((activity) => activity.id));
  assert.equal(rows.every((row) => row.cases === 0 && row.rung === 'derived'), true);
});

test('a per-unit activity is measured in hours per unit, not hours', () => {
  const rows = summarise([
    aCase('aem', [{ activity: 'component-build', hours: 100, volume: 10 }]),
    aCase('aem', [{ activity: 'component-build', hours: 600, volume: 20 }]),
    aCase('aem', [{ activity: 'component-build', hours: 150, volume: 10 }])
  ]);
  const row = rowFor(rows, 'component-build');
  assert.deepEqual([row.low, row.median, row.high], [10, 15, 30]);
  assert.equal(row.unit, 'component');
});

test('a tiered or proportional activity is measured in hours, having nothing to divide by', () => {
  const rows = summarise([
    aCase('aem', [{ activity: 'qa-automation', hours: 300 }]),
    aCase('aem', [{ activity: 'qa-automation', hours: 500 }])
  ]);
  const row = rowFor(rows, 'qa-automation');
  assert.deepEqual([row.low, row.median, row.high], [300, 400, 500]);
  assert.equal(row.unit, undefined);
});

test('three cases on one platform reach rung 1', () => {
  const entry = [{ activity: 'search', hours: 100 }];
  const rows = summarise([aCase('aem', entry), aCase('aem', entry), aCase('aem', entry)]);
  assert.equal(rowFor(rows, 'search').rung, 'cases');
});

test('three cases spread across platforms do not, because rung 1 is per platform', () => {
  const entry = [{ activity: 'search', hours: 100 }];
  const rows = summarise([aCase('aem', entry), aCase('drupal', entry), aCase('aem-eds', entry)]);
  const row = rowFor(rows, 'search');
  assert.equal(row.cases, 3);
  assert.equal(row.rung, 'cases-adjusted');
  assert.deepEqual(row.platforms, ['aem', 'aem-eds', 'drupal']);
});

test('fewer than three cases is marked as thin', () => {
  const rows = summarise([aCase('aem', [{ activity: 'search', hours: 100 }])]);
  assert.equal(rowFor(rows, 'search').rung, 'cases-adjusted');
});

test('a zero counts as evidence the work did not happen, not as evidence of its size', () => {
  const rows = summarise([
    aCase('aem', [{ activity: 'localization', hours: 0, zeroReason: 'not-needed' }]),
    aCase('aem', [{ activity: 'localization', hours: 80, volume: 4 }])
  ]);
  const row = rowFor(rows, 'localization');
  assert.equal(row.cases, 1);
  assert.equal(row.zeros, 1);
  assert.equal(row.median, 20);
});

test('a per-unit activity with no volume produces no rate rather than dividing by zero', () => {
  const rows = summarise([aCase('aem', [{ activity: 'component-build', hours: 100, volume: 0 }])]);
  const row = rowFor(rows, 'component-build');
  assert.equal(row.cases, 0);
  assert.equal(row.rung, 'derived');
});

test('an activity nobody recorded is not the same as one recorded as zero', () => {
  const rows = summarise([aCase('aem', [{ activity: 'search', hours: 100 }])]);
  const absent = rowFor(rows, 'localization');
  assert.equal(absent.cases, 0);
  assert.equal(absent.zeros, 0);
});

test('the table reports the spread, the platforms and the rung for each activity', () => {
  const report = renderMarkdown([workedExample()]);
  assert.match(report, /1 case\(s\)\. 0 of 25 activities can reach rung 1/);
  assert.match(report, /\| `component-build` \| build \| 1 \| +\| aem \| 23\.3 h\/component \| `cases-adjusted` \|/);
  assert.match(report, /\| `editorial-production` \| build \| 0 \| 1 \| — \| — \| `derived` \|/);
});

test('a rate well below one hour per unit keeps its figures instead of rounding to zero', () => {
  const report = renderMarkdown([workedExample()]);
  assert.match(report, /`asset-migration` .* 0\.00583 h\/asset/);
});

test('list exits 0 on a missing library, so it works before the first case is recorded', () => {
  const cli = join(repoRoot, 'tools', 'cases', 'cases.mjs');
  const dir = join(mkdtempSync(join(tmpdir(), 'cases-')), 'not-created-yet');
  assert.match(execFileSync(process.execPath, [cli, 'list', dir], { encoding: 'utf8' }), /The library is empty/);
});

test('list refuses to report on a library that does not validate', () => {
  const cli = join(repoRoot, 'tools', 'cases', 'cases.mjs');
  const dir = mkdtempSync(join(tmpdir(), 'cases-'));
  const broken = workedExample();
  delete broken.platform;
  writeFileSync(join(dir, 'C-003.json'), JSON.stringify(broken));
  assert.throws(
    () => execFileSync(process.execPath, [cli, 'list', dir], { encoding: 'utf8', stdio: 'pipe' }),
    (error) => error.status === 1 && /does not validate/.test(error.stderr) && /platform: required/.test(error.stderr)
  );
});
