/**
 * The activity registry, read from the Activities table in the estimating catalog. The catalog
 * is the one place the list is written down, so a case and an estimate cannot disagree about
 * what the activities are. `npm run catalog:check` is what validates it.
 */
import { readFileSync } from 'node:fs';
// The table is read with the estimate's own reader rather than the catalog validator, which
// pulls in a YAML parser for the front matter. The skill pack ships without node_modules, and
// an estimate it cannot run is worse than a catalog it cannot fully validate here;
// `npm run catalog:check` is what validates the document.
import { DEFAULT_CATALOG, parseActivities } from '../blueprint/rank-questions.mjs';

const activities = parseActivities(readFileSync(DEFAULT_CATALOG, 'utf8'));

if (activities.size === 0) {
  throw new Error('the estimating catalog has no Activities table, so the activities cannot be read.');
}

export const ACTIVITIES = Array.from(activities.entries()).map(([id, { name, phase, shape, unit }]) => ({
  id,
  name,
  phase,
  shape,
  ...(unit === '' ? {} : { unit })
}));

export const ACTIVITY_BY_ID = new Map(ACTIVITIES.map((activity) => [activity.id, activity]));
