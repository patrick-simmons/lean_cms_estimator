import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { ACTIVITIES } from './activities.mjs';
import { repoRoot as root, workedExample } from './test-helpers.mjs';
import { validateCase } from './validate.mjs';

/** The example with one thing wrong, so each rejection is tested against an otherwise valid case. */
function broken(change) {
  const value = workedExample();
  change(value);
  return value;
}

function entry(value, activity) {
  return value.activities.find((a) => a.activity === activity);
}

/** Asserts exactly the expected problem is reported, so a rule cannot pass by failing for another reason. */
function assertRejects(value, expected) {
  const problems = validateCase(value, 'C-003');
  assert.deepEqual(problems, [expected]);
}

test('the worked example in the contract is valid', () => {
  assert.deepEqual(validateCase(workedExample(), 'C-003'), []);
});

test('the worked example covers all 25 activities', () => {
  const recorded = workedExample().activities.map((a) => a.activity);
  assert.deepEqual(recorded.sort(), ACTIVITIES.map((a) => a.id).sort());
});

test('the activity list matches the capture sheet the workshop fills in', () => {
  const sheet = readFileSync(join(root, 'docs', 'workshop', 'case-capture-sheet.csv'), 'utf8');
  const ids = new Set(ACTIVITIES.map((a) => a.id));
  const rows = sheet
    .split(/\r?\n/)
    .map((line) => line.split(','))
    .filter((cells) => ids.has(cells[1]))
    .map(([phase, id, shape, unit]) => ({
      id,
      phase: phase.toLowerCase(),
      shape,
      ...(unit === '—' ? {} : { unit })
    }));
  // The sheet has no Name column, so compare the columns it does carry.
  const registry = ACTIVITIES.map(({ name, ...columns }) => columns);
  assert.deepEqual(rows, registry);
});

test('a case that is not an object is rejected', () => {
  assert.deepEqual(validateCase('C-003'), ['(root): expected an object']);
});

test('an unknown field is rejected rather than ignored', () => {
  assertRejects(broken((v) => { v.clientName = 'Fabrikam'; }), 'clientName: unknown field');
});

test('a missing source kind is rejected', () => {
  assertRejects(
    broken((v) => { delete v.source.kind; }),
    'source.kind: expected one of actuals, signed-estimate, architect-recall'
  );
});

test('free text where an enum belongs is rejected', () => {
  assertRejects(
    broken((v) => { v.context.frontend = 'mostly headless'; }),
    'context.frontend: expected one of traditional, headless, hybrid'
  );
});

test('an activity id outside the 25 is rejected', () => {
  assertRejects(
    broken((v) => { entry(v, 'search').activity = 'site-search'; }),
    'activities[7].activity: "site-search" is not one of the 25 activities'
  );
});

test('a label that looks like a client name is rejected', () => {
  assertRejects(
    broken((v) => { v.label = 'Fabrikam Inc replatform'; }),
    'label: looks like a client name. Use a coded description, such as "Outdoor retailer replatform"'
  );
});

test('a case id that does not match its file name is rejected', () => {
  const problems = validateCase(workedExample(), 'C-009');
  assert.deepEqual(problems, ['caseId: C-003 does not match the file name, which says C-009']);
});

test('hours that do not sum to the recorded total are rejected', () => {
  assertRejects(
    broken((v) => { v.totalHours = 7000; }),
    'totalHours: 7000 does not match the activities, which sum to 5920'
  );
});

test('rounding within an hour is accepted', () => {
  assert.deepEqual(validateCase(broken((v) => { v.totalHours = 5920.5; }), 'C-003'), []);
});

test('a per-unit activity may record hours the volume behind them was never recovered for', () => {
  assert.deepEqual(
    validateCase(broken((v) => {
      const row = entry(v, 'component-build');
      delete row.volume;
      delete row.unit;
    }), 'C-003'),
    []
  );
});

test('a per-unit volume and its unit are kept or dropped together, never one of each', () => {
  assertRejects(
    broken((v) => { delete entry(v, 'component-build').volume; }),
    'activities[4].volume: expected a number of 0 or more, or leave volume and unit out together'
  );
  assertRejects(
    broken((v) => { delete entry(v, 'component-build').unit; }),
    'activities[4].unit: expected component'
  );
});

test('a per-unit activity measured in the wrong unit is rejected', () => {
  assertRejects(
    broken((v) => { entry(v, 'component-build').unit = 'template'; }),
    'activities[4].unit: expected component'
  );
});

test('a tiered activity with no band is rejected', () => {
  assertRejects(
    broken((v) => { delete entry(v, 'design-system').band; }),
    'activities[3].band: expected one of small, medium, large'
  );
});

test('a band on a proportional activity is rejected', () => {
  assertRejects(
    broken((v) => { entry(v, 'qa-automation').band = 'large'; }),
    'activities[17].band: only a tiered activity has a band'
  );
});

test('a volume on a proportional activity is rejected', () => {
  assertRejects(
    broken((v) => { entry(v, 'uat-support').volume = 12; }),
    'activities[18].volume: a proportional activity is not sized by volume'
  );
});

test('zero hours with no reason is rejected', () => {
  assertRejects(
    broken((v) => { delete entry(v, 'editorial-production').zeroReason; }),
    'activities[14].zeroReason: expected one of out-of-scope, client-delivered, not-needed, absorbed-elsewhere'
  );
});

test('a reason on an activity with hours is rejected', () => {
  assertRejects(
    broken((v) => { entry(v, 'search').zeroReason = 'not-needed'; }),
    'activities[7].zeroReason: only an activity with 0 hours has a reason'
  );
});

test('client-delivered work that is not owned by the client is rejected', () => {
  assertRejects(
    broken((v) => { entry(v, 'editorial-production').owner = 'shared'; }),
    'activities[14].owner: expected client when zeroReason is client-delivered'
  );
});

test('absorbed work that does not say where it went is rejected', () => {
  assertRejects(
    broken((v) => { delete entry(v, 'delivery-governance').note; }),
    'activities[24].note: required when zeroReason is absorbed-elsewhere, naming the activity carrying the hours'
  );
});

test('an activity recorded twice is rejected', () => {
  assertRejects(
    broken((v) => {
      const duplicate = { ...entry(v, 'search') };
      v.activities.push(duplicate);
      v.totalHours += duplicate.hours;
    }),
    'activities[25].activity: search recorded twice'
  );
});

test('a missing aiToolingUsed is rejected, so doubt is recorded rather than assumed to be none', () => {
  assertRejects(
    broken((v) => { delete entry(v, 'component-build').aiToolingUsed; }),
    'activities[4].aiToolingUsed: expected one of none, partial, full, unknown'
  );
});

test('an absent activity is accepted: absence means not recorded', () => {
  const value = broken((v) => {
    const removed = entry(v, 'search');
    v.activities = v.activities.filter((a) => a.activity !== 'search');
    v.totalHours -= removed.hours;
  });
  assert.deepEqual(validateCase(value, 'C-003'), []);
});

test('validate exits 0 on a valid case and 1 on a broken one, naming the file and field', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cases-'));
  const cli = join(root, 'tools', 'cases', 'cases.mjs');
  writeFileSync(join(dir, 'C-003.json'), JSON.stringify(workedExample()));
  assert.match(execFileSync(process.execPath, [cli, 'validate', dir], { encoding: 'utf8' }), /OK: 1 case/);

  writeFileSync(join(dir, 'C-004.json'), JSON.stringify(broken((v) => { v.caseId = 'C-004'; delete v.platform; })));
  assert.throws(
    () => execFileSync(process.execPath, [cli, 'validate', dir], { encoding: 'utf8', stdio: 'pipe' }),
    (error) => error.status === 1 && /C-004\.json: platform: required/.test(error.stderr)
  );
});
