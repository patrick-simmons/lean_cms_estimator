import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { ACTIVITIES } from './activities.mjs';
import { derive, deriveRate } from './derive.mjs';
import { repoRoot, workedExample } from './test-helpers.mjs';

const BUILD = ACTIVITIES.find((activity) => activity.id === 'component-build');
const AUDIT = ACTIVITIES.find((activity) => activity.id === 'accessibility-audit');

/** Only the fields the rate math reads, so a stats test says what it is about. */
function aCase(caseId, platform, activities) {
  return { caseId, platform, activities };
}

function builds(...rates) {
  return rates.map(([caseId, platform, hours, volume]) =>
    aCase(caseId, platform, [{ activity: 'component-build', hours, volume }]));
}

test('no case covering the activity returns nothing rather than a number', () => {
  assert.equal(deriveRate([], BUILD, 'aem'), undefined);
  assert.equal(deriveRate(builds(['C-001', 'aem', 100, 10]), AUDIT, 'aem'), undefined);
});

test('a per-unit rate is hours per unit, and the likely figure is the median', () => {
  const rate = deriveRate(builds(
    ['C-001', 'aem', 100, 10],
    ['C-002', 'aem', 600, 20],
    ['C-003', 'aem', 150, 10]
  ), BUILD, 'aem');
  assert.equal(rate.likely, 15);
  assert.equal(rate.unit, 'component');
  assert.equal(rate.n, 3);
});

test('an activity that is not per-unit keeps its hours, having nothing to divide by', () => {
  const audit = [
    aCase('C-001', 'aem', [{ activity: 'accessibility-audit', hours: 40 }]),
    aCase('C-002', 'aem', [{ activity: 'accessibility-audit', hours: 60 }])
  ];
  assert.equal(deriveRate(audit, AUDIT, 'aem').likely, 50);
});

test('three or more cases give quartiles, so one unusual project widens the range rather than setting it', () => {
  const rate = deriveRate(builds(
    ['C-001', 'aem', 10, 1],
    ['C-002', 'aem', 20, 1],
    ['C-003', 'aem', 30, 1],
    ['C-004', 'aem', 40, 1],
    ['C-005', 'aem', 500, 1]
  ), BUILD, 'aem');
  assert.deepEqual([rate.low, rate.likely, rate.high], [20, 30, 40]);
  assert.equal(rate.spread, 'quartiles');
});

test('below three cases the spread is the whole of what was seen, with low confidence and a question owed', () => {
  const two = deriveRate(builds(['C-001', 'aem', 10, 1], ['C-002', 'aem', 90, 1]), BUILD, 'aem');
  assert.deepEqual([two.low, two.likely, two.high], [10, 50, 90]);
  assert.equal(two.spread, 'observed');
  assert.equal(two.confidence, 'low');
  assert.equal(two.questionOwed, true);

  const one = deriveRate(builds(['C-001', 'aem', 10, 1]), BUILD, 'aem');
  assert.deepEqual([one.low, one.likely, one.high], [10, 10, 10]);
  assert.equal(one.n, 1);
});

test('cases from the asked-for platform are used alone when there are any', () => {
  const rate = deriveRate(builds(
    ['C-001', 'aem', 10, 1],
    ['C-002', 'aem', 20, 1],
    ['C-003', 'aem', 30, 1],
    ['C-004', 'aem-eds', 900, 1]
  ), BUILD, 'aem');
  assert.equal(rate.platformMatch, 'same');
  assert.equal(rate.likely, 20);
  assert.deepEqual(rate.caseIds, ['C-001', 'C-002', 'C-003']);
  assert.equal(rate.basis, 'cases');
  assert.equal(rate.questionOwed, false);
});

test('with nothing on the platform it falls back to every case and says so', () => {
  const rate = deriveRate(builds(
    ['C-001', 'aem-eds', 10, 1],
    ['C-002', 'aem-eds', 20, 1],
    ['C-003', 'aem-eds', 30, 1]
  ), BUILD, 'drupal');
  assert.equal(rate.platformMatch, 'cross');
  assert.equal(rate.basis, 'cases-adjusted');
  assert.equal(rate.confidence, 'medium');
  assert.equal(rate.questionOwed, true);
});

test('rung 1 needs both: enough cases and the right platform', () => {
  const thin = deriveRate(builds(['C-001', 'aem', 10, 1], ['C-002', 'aem', 20, 1]), BUILD, 'aem');
  assert.equal(thin.basis, 'cases-adjusted');
  assert.equal(thin.confidence, 'low');
});

test('a zero is evidence the work did not happen, not evidence of its size', () => {
  const rate = deriveRate(builds(
    ['C-001', 'aem', 0, 10],
    ['C-002', 'aem', 100, 10],
    ['C-003', 'aem', 200, 10]
  ), BUILD, 'aem');
  assert.equal(rate.n, 2);
  assert.deepEqual(rate.caseIds, ['C-002', 'C-003']);
});

test('a per-unit case with no volume cannot produce a rate and is left out', () => {
  const rate = deriveRate([
    aCase('C-001', 'aem', [{ activity: 'component-build', hours: 100 }]),
    aCase('C-002', 'aem', [{ activity: 'component-build', hours: 100, volume: 10 }])
  ], BUILD, 'aem');
  assert.equal(rate.n, 1);
  assert.deepEqual(rate.caseIds, ['C-002']);
});

test('the same library returns the same answer, whatever order the cases arrive in', () => {
  const cases = builds(['C-003', 'aem', 30, 1], ['C-001', 'aem', 10, 1], ['C-002', 'aem', 20, 1]);
  const forwards = deriveRate(cases, BUILD, 'aem');
  const backwards = deriveRate(cases.slice().reverse(), BUILD, 'aem');
  assert.deepEqual(forwards, backwards);
  assert.deepEqual(forwards.caseIds, ['C-001', 'C-002', 'C-003']);
});

test('derive covers every activity, naming the ones with no evidence rather than rating them', () => {
  const result = derive(builds(['C-001', 'aem', 100, 10]), 'aem');
  assert.deepEqual(Object.keys(result.rates), ['component-build']);
  assert.equal(result.noEvidence.length, ACTIVITIES.length - 1);
  assert.equal(result.noEvidence.indexOf('component-build'), -1);
  assert.equal(result.platform, 'aem');
  assert.equal(result.cases, 1);
});

test('the contract worked example derives without complaint', () => {
  const result = derive([workedExample()], 'aem');
  assert.ok(Object.keys(result.rates).length > 0);
  assert.equal(Object.values(result.rates).every((rate) => rate.confidence === 'low'), true);
});

test('the command needs a platform, and reports an invalid library instead of rating it', () => {
  const run = (args, cwd) => {
    try {
      const stdout = execFileSync(process.execPath, ['tools/cases/cases.mjs', ...args], { cwd: cwd ?? repoRoot, encoding: 'utf8', stdio: 'pipe' });
      return { code: 0, stdout };
    } catch (error) {
      return { code: error.status, stdout: error.stdout, stderr: error.stderr };
    }
  };
  assert.equal(run(['derive']).code, 2);

  const dir = mkdtempSync(join(tmpdir(), 'cases-derive-'));
  writeFileSync(join(dir, 'C-001.json'), JSON.stringify({ caseId: 'C-001' }));
  const broken = run(['derive', 'aem', dir]);
  assert.equal(broken.code, 1);
  assert.match(broken.stderr, /does not validate/);

  const empty = run(['derive', 'aem', join(dir, 'nothing-here')]);
  assert.equal(empty.code, 0);
  assert.deepEqual(JSON.parse(empty.stdout).rates, {});
});
