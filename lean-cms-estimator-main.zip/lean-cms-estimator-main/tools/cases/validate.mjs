/**
 * Checks a case against docs/case-contract.md. Returns an array of `field: problem`
 * strings; empty means valid. The caller adds the file name.
 */
import { ACTIVITY_BY_ID } from './activities.mjs';

const CASE_ID = /^C-\d{3}$/;
const QUARTER = /^\d{4}-Q[1-4]$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Legal-entity suffixes in `label`. A tripwire for the obvious slip, not a guarantee:
 * the contract makes the label a review question because no check can catch a bare name.
 */
const ENTITY_SUFFIX = /\b(inc|llc|ltd|limited|plc|gmbh|corp|corporation|pty|llp|srl|spa)\b\.?/i;

/** Activity hours may be off the recorded total by this much before it counts as a mismatch. */
const TOTAL_TOLERANCE = 1;

const ROOT_KEYS = ['caseId', 'label', 'platform', 'deliveredIn', 'source', 'context', 'activities', 'totalHours', 'schedule', 'variance'];
const SOURCE_KEYS = ['kind', 'confidence', 'enteredBy', 'enteredAt'];
const CONTEXT_KEYS = ['projectType', 'frontend', 'siteCount', 'locales', 'integrationCount', 'migrationSource', 'designSystem', 'wcag', 'compliance'];
const ACTIVITY_KEYS = ['activity', 'hours', 'owner', 'volume', 'unit', 'altVolume', 'altUnit', 'band', 'aiToolingUsed', 'zeroReason', 'note'];
const SCHEDULE_KEYS = ['totalWeeks', 'phaseWeeks'];
const VARIANCE_KEYS = ['estimatedHours', 'actualHours', 'note'];

const SOURCE_KINDS = ['actuals', 'signed-estimate', 'architect-recall'];
const CONFIDENCES = ['high', 'medium', 'low'];
const OWNERS = ['us', 'shared', 'client'];
const BANDS = ['small', 'medium', 'large'];
const AI_TOOLING = ['none', 'partial', 'full', 'unknown'];
const ZERO_REASONS = ['out-of-scope', 'client-delivered', 'not-needed', 'absorbed-elsewhere'];

const CONTEXT_ENUMS = {
  projectType: ['greenfield', 'replatform-same-vendor', 'replatform-cross-vendor', 'enhancement'],
  frontend: ['traditional', 'headless', 'hybrid'],
  migrationSource: ['none', 'api', 'cms-export', 'database', 'scrape', 'manual'],
  designSystem: ['ready', 'partial', 'net-new'],
  wcag: ['none-stated', 'a', 'aa', 'aaa']
};
const CONTEXT_COUNTS = ['siteCount', 'locales', 'integrationCount'];

function isObject(value) {
  return typeof value === 'object' && !!value && !Array.isArray(value);
}

function isText(value) {
  return typeof value === 'string' && value.trim() !== '';
}

function isNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function isCount(value) {
  return isNumber(value) && Number.isInteger(value) && value >= 0;
}

/** Unknown fields are rejected everywhere: a misspelled field is data the resolver silently loses. */
function checkKeys(value, allowed, prefix, errors) {
  for (const key of Object.keys(value)) {
    if (!allowed.includes(key)) {
      errors.push(`${prefix}${key}: unknown field`);
    }
  }
}

function checkEnum(value, allowed, path, errors) {
  if (!allowed.includes(value)) {
    errors.push(`${path}: expected one of ${allowed.join(', ')}`);
  }
}

function checkSource(source, errors) {
  if (!isObject(source)) {
    errors.push('source: required object');
    return;
  }
  checkKeys(source, SOURCE_KEYS, 'source.', errors);
  checkEnum(source.kind, SOURCE_KINDS, 'source.kind', errors);
  checkEnum(source.confidence, CONFIDENCES, 'source.confidence', errors);
  if (!isText(source.enteredBy)) {
    errors.push('source.enteredBy: required');
  }
  if (!isText(source.enteredAt) || !ISO_DATE.test(source.enteredAt)) {
    errors.push('source.enteredAt: expected YYYY-MM-DD');
  }
}

function checkContext(context, errors) {
  if (!isObject(context)) {
    errors.push('context: required object');
    return;
  }
  checkKeys(context, CONTEXT_KEYS, 'context.', errors);
  for (const [field, allowed] of Object.entries(CONTEXT_ENUMS)) {
    checkEnum(context[field], allowed, `context.${field}`, errors);
  }
  for (const field of CONTEXT_COUNTS) {
    if (!isCount(context[field])) {
      errors.push(`context.${field}: expected a whole number of 0 or more`);
    }
  }
  if (!Array.isArray(context.compliance) || !context.compliance.every(isText)) {
    errors.push('context.compliance: expected an array of names, [] when none');
  }
}

/** Which of volume, unit and band an entry needs, and which it must not carry, comes from its shape. */
function checkShape(entry, shape, path, errors) {
  const hasVolume = entry.volume !== undefined || entry.unit !== undefined;
  if (shape === 'per-unit') {
    // The hours of a past project are a fact; the count behind them is sometimes not recoverable,
    // and a case that refused the row would lose the hours rather than the gap. Such a row still
    // counts towards the case total and still contributes no rate: derive.mjs has nothing to
    // divide by, so it is left out of the rates and the rate ladder never sees an invented figure.
    if (hasVolume) {
      if (!isNumber(entry.volume) || entry.volume < 0) {
        errors.push(`${path}.volume: expected a number of 0 or more, or leave volume and unit out together`);
      }
      const expected = ACTIVITY_BY_ID.get(entry.activity).unit;
      if (entry.unit !== expected) {
        errors.push(`${path}.unit: expected ${expected}`);
      }
    }
  } else if (hasVolume) {
    errors.push(`${path}.volume: a ${shape} activity is not sized by volume`);
  }

  if (shape === 'tiered') {
    if (entry.hours !== 0) {
      checkEnum(entry.band, BANDS, `${path}.band`, errors);
    }
  } else if (entry.band !== undefined) {
    errors.push(`${path}.band: only a tiered activity has a band`);
  }

  if ((entry.altVolume === undefined) !== (entry.altUnit === undefined)) {
    errors.push(`${path}.altVolume: altVolume and altUnit go together`);
  }
}

/** Zero is a recorded decision, absence is not. See "Zero is not blank" in the contract. */
function checkZero(entry, path, errors) {
  if (entry.hours === 0) {
    checkEnum(entry.zeroReason, ZERO_REASONS, `${path}.zeroReason`, errors);
    if (entry.zeroReason === 'client-delivered' && entry.owner !== 'client') {
      errors.push(`${path}.owner: expected client when zeroReason is client-delivered`);
    }
    if (entry.zeroReason === 'absorbed-elsewhere' && !isText(entry.note)) {
      errors.push(`${path}.note: required when zeroReason is absorbed-elsewhere, naming the activity carrying the hours`);
    }
  } else if (entry.zeroReason !== undefined) {
    errors.push(`${path}.zeroReason: only an activity with 0 hours has a reason`);
  }
}

function checkActivities(activities, errors) {
  if (!Array.isArray(activities) || activities.length === 0) {
    errors.push('activities: expected a non-empty array');
    return;
  }
  const seen = new Set();
  activities.forEach((entry, index) => {
    const path = `activities[${index}]`;
    if (!isObject(entry)) {
      errors.push(`${path}: expected object`);
      return;
    }
    checkKeys(entry, ACTIVITY_KEYS, `${path}.`, errors);

    const known = ACTIVITY_BY_ID.get(entry.activity);
    if (!known) {
      errors.push(`${path}.activity: ${JSON.stringify(entry.activity)} is not one of the 25 activities`);
      return;
    }
    if (seen.has(entry.activity)) {
      errors.push(`${path}.activity: ${entry.activity} recorded twice`);
    }
    seen.add(entry.activity);

    if (!isNumber(entry.hours) || entry.hours < 0) {
      errors.push(`${path}.hours: required, 0 or more. Leave the activity out to mean "not recorded"`);
      return;
    }
    checkEnum(entry.owner, OWNERS, `${path}.owner`, errors);
    checkEnum(entry.aiToolingUsed, AI_TOOLING, `${path}.aiToolingUsed`, errors);
    if (entry.note !== undefined && !isText(entry.note)) {
      errors.push(`${path}.note: expected a non-empty string when present`);
    }
    checkShape(entry, known.shape, path, errors);
    checkZero(entry, path, errors);
  });
}

function checkTotal(value, errors) {
  if (!isNumber(value.totalHours) || value.totalHours < 0) {
    errors.push('totalHours: required, 0 or more');
    return;
  }
  if (!Array.isArray(value.activities)) {
    return;
  }
  const sum = value.activities.reduce((total, entry) => total + (isObject(entry) && isNumber(entry.hours) ? entry.hours : 0), 0);
  if (Math.abs(sum - value.totalHours) > TOTAL_TOLERANCE) {
    errors.push(`totalHours: ${value.totalHours} does not match the activities, which sum to ${sum}`);
  }
}

function checkOptionalBlocks(value, errors) {
  if (value.schedule !== undefined) {
    if (!isObject(value.schedule)) {
      errors.push('schedule: expected object');
    } else {
      checkKeys(value.schedule, SCHEDULE_KEYS, 'schedule.', errors);
      if (!isNumber(value.schedule.totalWeeks) || value.schedule.totalWeeks <= 0) {
        errors.push('schedule.totalWeeks: expected a number above 0');
      }
    }
  }
  if (value.variance !== undefined) {
    if (!isObject(value.variance)) {
      errors.push('variance: expected object');
      return;
    }
    checkKeys(value.variance, VARIANCE_KEYS, 'variance.', errors);
    for (const field of ['estimatedHours', 'actualHours']) {
      if (!isNumber(value.variance[field]) || value.variance[field] < 0) {
        errors.push(`variance.${field}: required, 0 or more`);
      }
    }
  }
}

/**
 * @param {unknown} value the parsed case
 * @param {string} [caseId] the id the file name implies, checked against the record
 * @returns {string[]}
 */
export function validateCase(value, caseId) {
  if (!isObject(value)) {
    return ['(root): expected an object'];
  }
  const errors = [];
  checkKeys(value, ROOT_KEYS, '', errors);

  if (!isText(value.caseId) || !CASE_ID.test(value.caseId)) {
    errors.push('caseId: expected C- and three digits, such as C-003');
  } else if (caseId && value.caseId !== caseId) {
    errors.push(`caseId: ${value.caseId} does not match the file name, which says ${caseId}`);
  }
  if (!isText(value.label)) {
    errors.push('label: required, a coded description with no client name');
  } else if (ENTITY_SUFFIX.test(value.label)) {
    errors.push('label: looks like a client name. Use a coded description, such as "Outdoor retailer replatform"');
  }
  if (!isText(value.platform)) {
    errors.push('platform: required');
  }
  if (!isText(value.deliveredIn) || !QUARTER.test(value.deliveredIn)) {
    errors.push('deliveredIn: expected YYYY-Qn, such as 2025-Q3');
  }

  checkSource(value.source, errors);
  checkContext(value.context, errors);
  checkActivities(value.activities, errors);
  checkTotal(value, errors);
  checkOptionalBlocks(value, errors);

  return errors;
}
