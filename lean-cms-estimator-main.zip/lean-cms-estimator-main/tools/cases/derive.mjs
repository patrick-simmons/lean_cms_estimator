/**
 * Rates from recorded work (story B-06). One activity, one platform, one answer: the likely
 * hours per unit, the spread the cases support, and how much of that is evidence.
 *
 * The rate math lives here because this is what it is for; `list.mjs` reports on the same
 * numbers and imports them rather than keeping a second copy that could drift.
 */
import { ACTIVITIES } from './activities.mjs';

/** Rung 1 needs this many cases on one platform. Below it the rate is adjusted and a question is owed. */
export const ENOUGH_CASES = 3;

/** Hours per unit for a per-unit activity; plain hours for the rest, which have nothing to divide by. */
export function rateOf(shape, entry) {
  if (shape !== 'per-unit') {
    return entry.hours;
  }
  return typeof entry.volume === 'number' && entry.volume > 0 ? entry.hours / entry.volume : undefined;
}

export function median(sorted) {
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

/**
 * The value at `fraction` through the sorted rates, interpolating between the two neighbours.
 * Quartiles rather than the full span once there are enough cases, so that one unusual project
 * widens the range it belongs in instead of setting it.
 */
function quantile(sorted, fraction) {
  const position = (sorted.length - 1) * fraction;
  const below = Math.floor(position);
  const above = Math.ceil(position);
  return below === above ? sorted[below] : sorted[below] + (sorted[above] - sorted[below]) * (position - below);
}

/** Cases that recorded this activity with hours worth dividing. A zero means the work did not happen. */
function ratesFor(cases, activity) {
  return cases
    .map((value) => ({ caseId: value.caseId, platform: value.platform, entry: value.activities.find((a) => a.activity === activity.id) }))
    .filter((found) => found.entry && found.entry.hours > 0)
    .map((found) => ({ ...found, rate: rateOf(activity.shape, found.entry) }))
    .filter((found) => found.rate !== undefined);
}

/**
 * @returns {object|undefined} the rate for one activity on one platform, or undefined when no
 * case covers it. Undefined rather than a guess: an activity with no evidence is a thing the
 * estimator has to decide, and returning a number here would hide that.
 */
export function deriveRate(cases, activity, platform) {
  const all = ratesFor(cases, activity);
  if (all.length === 0) {
    return undefined;
  }
  const own = all.filter((found) => found.platform === platform);
  const used = own.length > 0 ? own : all;
  const platformMatch = own.length > 0 ? 'same' : 'cross';

  // Sorted by rate for the statistics, but the case ids are reported in library order, so the
  // same library always names them the same way.
  const rates = used.map((found) => found.rate).sort((a, b) => a - b);
  const enough = rates.length >= ENOUGH_CASES;

  return {
    activity: activity.id,
    unit: activity.unit,
    likely: median(rates),
    // Below three cases a quartile would be an interpolation between two points pretending to
    // be a distribution, so the honest answer is the whole of what was seen.
    low: enough ? quantile(rates, 0.25) : rates[0],
    high: enough ? quantile(rates, 0.75) : rates[rates.length - 1],
    spread: enough ? 'quartiles' : 'observed',
    n: rates.length,
    caseIds: used.map((found) => found.caseId).sort(),
    platformMatch,
    basis: platformMatch === 'same' && enough ? 'cases' : 'cases-adjusted',
    confidence: !enough ? 'low' : platformMatch === 'same' ? 'high' : 'medium',
    // Rung 1 is the only rung that does not owe the client a question about where the rate came from.
    questionOwed: !(platformMatch === 'same' && enough)
  };
}

/**
 * The share one activity took of a named set of others, across the cases that recorded both
 * (story B-10).
 *
 * A share is measured per case and then taken across cases, not as total over total: a single
 * large project would otherwise set the percentage for every small one. A case that recorded
 * the activity but none of its reference set is not evidence of a share, because there is
 * nothing for it to be a share of.
 *
 * @returns {object|undefined} undefined when no case covers it, which is the caller's cue to
 *   fall back to a published ratio and say so.
 */
export function deriveShare(cases, activity, referenceSet, platform) {
  const references = new Set(referenceSet);
  const found = [];
  for (const value of cases) {
    const entry = value.activities.find((row) => row.activity === activity.id);
    const over = value.activities
      .filter((row) => references.has(row.activity))
      .reduce((total, row) => total + row.hours, 0);
    if (entry && entry.hours > 0 && over > 0) {
      found.push({ caseId: value.caseId, platform: value.platform, share: entry.hours / over });
    }
  }
  if (found.length === 0) {
    return undefined;
  }
  const own = found.filter((row) => row.platform === platform);
  const used = own.length > 0 ? own : found;
  const platformMatch = own.length > 0 ? 'same' : 'cross';
  const shares = used.map((row) => row.share).sort((a, b) => a - b);
  const enough = shares.length >= ENOUGH_CASES;

  return {
    activity: activity.id,
    likely: median(shares),
    low: enough ? quantile(shares, 0.25) : shares[0],
    high: enough ? quantile(shares, 0.75) : shares[shares.length - 1],
    spread: enough ? 'quartiles' : 'observed',
    n: shares.length,
    caseIds: used.map((row) => row.caseId).sort(),
    platformMatch,
    basis: platformMatch === 'same' && enough ? 'cases' : 'cases-adjusted'
  };
}

/**
 * Every activity, for one platform. Activities with no evidence are named rather than given a
 * rate, because which ones are missing is the thing worth knowing.
 */
export function derive(cases, platform) {
  const rates = {};
  const noEvidence = [];
  for (const activity of ACTIVITIES) {
    const rate = deriveRate(cases, activity, platform);
    if (rate) {
      rates[activity.id] = rate;
    } else {
      noEvidence.push(activity.id);
    }
  }
  return { platform, cases: cases.length, rates, noEvidence };
}
