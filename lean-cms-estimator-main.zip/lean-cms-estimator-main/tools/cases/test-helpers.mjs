import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const repoRoot = join(dirname(fileURLToPath(import.meta.url)), '..', '..');

/**
 * The worked example in the contract, used as the fixture by every case test. Keeping one copy
 * means the page the workshop copies from cannot drift away from what the validator accepts.
 */
export function workedExample() {
  const page = readFileSync(join(repoRoot, 'docs', 'case-contract.md'), 'utf8');
  const block = page.match(/```json\r?\n([\s\S]*?)```/);
  assert.ok(block, 'docs/case-contract.md should hold a worked example in a json block');
  return JSON.parse(block[1]);
}
