/**
 * What goes into the Blueprint skill pack, in one place: build-skill-pack.mjs copies it and
 * check-skill-pack.mjs requires it, so a tool added to a list here is both shipped and checked.
 */
import { readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

export const SKILLS = ['estimate', 'blueprint-offline', 'blueprint-parse', 'blueprint-extract-map', 'blueprint-enrich', 'blueprint-design-sketch', 'blueprint-gap-sweep', 'blueprint-lever-advice', 'blueprint-second-opinion', 'blueprint-validate', 'blueprint-infer-skills'];

/** Bundled with esbuild into one file each (so the pack needs no node_modules and no function build). */
export const BUNDLED_TOOLS = ['parse-local', 'prepare-folder', 'xlsx-fill'];

/** Copied as they are; every relative import of a bundled or copied tool must resolve to one of these. */
export const COPIED_TOOLS = ['activity-ids', 'ai-plan', 'assemble-drivers', 'assemble-working-file', 'band', 'build-workbook', 'citation-label', 'derive-capabilities', 'driver-quantity', 'estimate-model', 'gap-sweep', 'lever-advice', 'list-requirements', 'match-library', 'ownership', 'pack-info', 'plan', 'proportional', 'rank-questions', 'rate-ladder',
  'review-stats', 'run-record', 'second-opinion', 'source-candidates', 'suppression', 'validate-context', 'validate-proposals', 'validate-working-file', 'workbook-rows', 'write-file-atomic'];

export const FACTORS_TOOLS = ['seed', 'validate-libraries', 'validate-phase-tasks'];

/**
 * The case library reader the estimate's rates come from. The pack carries no `cases/` folder,
 * so a pack estimate finds no evidence and lands on the derived rung; the code still has to
 * ship for the estimate to load at all.
 */
export const CASES_TOOLS = ['activities', 'derive', 'validate'];

/** Repository path to path inside the pack. The docs ship flat under docs/. */
export const DOCS = [
  ['docs/spfx/working-file.md', 'docs/working-file.md'],
  ['docs/spfx/context-sidecar.md', 'docs/context-sidecar.md'],
  ['docs/spfx/agent-contract.md', 'docs/agent-contract.md'],
  ['docs/spfx/plan-contract.md', 'docs/plan-contract.md'],
  ['docs/spfx/workbook-template.md', 'docs/workbook-template.md'],
  ['docs/spfx/offline-blueprint-skill-pack.md', 'docs/offline-blueprint-skill-pack.md'],
  ['docs/standalone/agent-run-evaluation.md', 'docs/agent-run-evaluation.md'],
  ['docs/spfx/delivery-skills.md', 'docs/delivery-skills.md']
];

/** The install guide ships as the pack's README.md. */
export const README_SOURCE = 'docs/standalone/agent-skill-pack.md';

/** Files that must exist in a built pack besides the skills, tools and docs above. */
export const OTHER_REQUIRED = [
  'pack.json',
  'README.md',
  '.claude-plugin/plugin.json',
  'tools/blueprint/templates/AGENTS.md',
  'tools/blueprint/data/implied-scope.json',
  'tools/blueprint/data/lever-evidence.json',
  'tools/cmk-catalog.pin.json',
  'tools/toolkit-catalog.pin.json',
  'docs/catalogs/estimating-catalog.md',
  'docs/catalogs/cmk-capability-catalog.md',
  'docs/catalogs/toolkit-capability-catalog.md',
  'samples/factors/seed/assumption-library.csv',
  'samples/workbook/Estimate_Template.xlsx',
  'skills/blueprint-extract-map/references/system-message.md',
  'skills/blueprint-extract-map/references/response-format.md'
];

/** Every path a complete pack carries, relative to its root with forward slashes. */
export function requiredPackFiles() {
  return [
    ...OTHER_REQUIRED,
    ...SKILLS.map((name) => `skills/${name}/SKILL.md`),
    ...[...BUNDLED_TOOLS, ...COPIED_TOOLS].map((name) => `tools/blueprint/${name}.mjs`),
    ...FACTORS_TOOLS.map((name) => `tools/factors/${name}.mjs`),
    ...CASES_TOOLS.map((name) => `tools/cases/${name}.mjs`),
    ...DOCS.map(([, to]) => to)
  ];
}

/** All files under `dir`, relative to it with forward slashes, in name order. */
export function listFiles(dir, base = dir, out = []) {
  for (const entry of readdirSync(dir).sort()) {
    const file = join(dir, entry);
    if (statSync(file).isDirectory()) {
      listFiles(file, base, out);
    } else {
      out.push(relative(base, file).replace(/\\/g, '/'));
    }
  }
  return out;
}
