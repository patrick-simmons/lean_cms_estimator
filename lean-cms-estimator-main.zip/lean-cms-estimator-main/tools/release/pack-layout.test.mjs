import assert from 'node:assert/strict';
import { readdirSync, existsSync, readFileSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { test } from 'node:test';
import { BUNDLED_TOOLS, CASES_TOOLS, COPIED_TOOLS, FACTORS_TOOLS, SKILLS } from './pack-layout.mjs';

const repoRoot = fileURLToPath(new URL('../..', import.meta.url));

test('every blueprint skill and the estimate skill in the repository is in the pack, and every skill in the pack exists', () => {
  const onDisk = readdirSync(join(repoRoot, '.claude', 'skills'), { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && (entry.name.startsWith('blueprint-') || entry.name === 'estimate'))
    .map((entry) => entry.name)
    .sort();
  assert.deepEqual([...SKILLS].sort(), onDisk, 'a new blueprint-* skill (or the estimate skill) has to be added to SKILLS in pack-layout.mjs, or it is not shipped');
});

test('every tool the pack copies exists', () => {
  for (const tool of COPIED_TOOLS) {
    const from = join('tools', 'blueprint', `${tool}.mjs`);
    assert.ok(existsSync(join(repoRoot, from)), `${from} is listed in COPIED_TOOLS but is not in the repository`);
  }
});

const RELATIVE_IMPORT = /\b(?:from|import)\s*\(?\s*['"](\.{1,2}\/[^'"]+)['"]/g;
const BARE_IMPORT = /\bfrom\s*['"]([^.'"][^'"]*)['"]/g;

function copiedFiles() {
  return [
    ...COPIED_TOOLS.map((name) => join('tools', 'blueprint', `${name}.mjs`)),
    ...FACTORS_TOOLS.map((name) => join('tools', 'factors', `${name}.mjs`)),
    ...CASES_TOOLS.map((name) => join('tools', 'cases', `${name}.mjs`))
  ];
}

/**
 * The pack is built from a file list, so an import added to a shipped tool can start reaching
 * for a file the list does not carry. Building the pack catches it, but only on a clean tree
 * and with a function build in place, which is how B-07 shipped a pack that could not load.
 * These two read the repository instead, so the break surfaces the moment the import is added.
 */
test('every relative import of a copied tool resolves to another file the pack carries', () => {
  // A bundled tool arrives at the same path with its own imports already inlined, so a copied
  // tool may import one.
  const shipped = new Set([...copiedFiles(), ...BUNDLED_TOOLS.map((name) => join('tools', 'blueprint', `${name}.mjs`))]);
  for (const from of copiedFiles()) {
    const text = readFileSync(join(repoRoot, from), 'utf8');
    RELATIVE_IMPORT.lastIndex = 0;
    let match;
    while ((match = RELATIVE_IMPORT.exec(text)) !== null) {
      const target = relative(repoRoot, resolve(dirname(join(repoRoot, from)), match[1]));
      assert.ok(shipped.has(target), `${from} imports "${match[1]}", which the pack does not carry. Add ${target.split(sep).join('/')} to pack-layout.mjs, or do not import it.`);
    }
  }
});

test('no copied tool imports a package, because the pack ships without node_modules', () => {
  for (const from of copiedFiles()) {
    const text = readFileSync(join(repoRoot, from), 'utf8');
    BARE_IMPORT.lastIndex = 0;
    let match;
    while ((match = BARE_IMPORT.exec(text)) !== null) {
      assert.ok(match[1].startsWith('node:'), `${from} imports "${match[1]}", which is not a node builtin and is not in the pack`);
    }
  }
});
