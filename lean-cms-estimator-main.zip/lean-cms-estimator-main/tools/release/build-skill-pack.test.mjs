/**
 * Builds the pack into a temporary folder and uses it from a working directory outside the repository,
 * the way an estimator without a checkout would (SAPP-015).
 */
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, before, describe, it } from 'node:test';
import { unzipSync } from 'fflate';
import { parseCmkCatalog } from '../catalog/parse.mjs';
import { buildSkillPack, checkReferences, PACK_PREAMBLE, rewriteDocLinks, rewriteSkill } from './build-skill-pack.mjs';
import { checkDocLinks, checkPackReferences, checkSkillPack, checkSkillText, checkToolImports } from './check-skill-pack.mjs';
import { BUNDLED_TOOLS, COPIED_TOOLS, requiredPackFiles } from './pack-layout.mjs';

const repoRoot = fileURLToPath(new URL('../..', import.meta.url));
const scratch = mkdtempSync(join(tmpdir(), 'skill-pack-'));
const elsewhere = join(scratch, 'elsewhere');
let built;

function node(args, options = {}) {
  return spawnSync(process.execPath, args, {
    cwd: options.cwd || elsewhere,
    encoding: 'utf8',
    env: { ...process.env, BLUEPRINT_PACK: built.dir, HOME: join(scratch, 'nohome'), USERPROFILE: join(scratch, 'nohome'), ...(options.env || {}) }
  });
}

/** A fresh copy of the built pack to damage. */
function damaged(name) {
  const copy = join(scratch, 'damaged', name);
  cpSync(built.dir, copy, { recursive: true });
  return copy;
}

function projectFolder(name) {
  const folder = join(scratch, 'projects', name);
  cpSync(join(built.dir, 'samples', 'sources', 'synthetic-aem'), folder, { recursive: true });
  return folder;
}

before(() => {
  // A local build from a working tree that may have uncommitted changes.
  built = buildSkillPack({ out: join(scratch, 'out'), now: new Date('2026-11-09T12:00:00Z'), allowDirty: true });
  cpSync(join(built.dir, 'samples', 'sources', 'synthetic-aem'), elsewhere, { recursive: true });
});

after(() => rmSync(scratch, { recursive: true, force: true }));

describe('skill pack build', () => {
  it('stamps the version, commit and catalog pins', () => {
    assert.match(built.pack.version, /^\d+\.\d+\.\d+$/);
    assert.match(built.pack.commit, /^[0-9a-f]{40}(-dirty)?$|^unknown$/);
    assert.equal(built.pack.builtAt, '2026-11-09T12:00:00.000Z');
    assert.equal(built.pack.catalogs.estimatingVersion, '4');
    assert.match(built.pack.catalogs.cmkCommit, /^[0-9a-f]{40}$/);
    assert.match(built.pack.catalogs.toolkitCommit, /^[0-9a-f]{40}$/);
    assert.match(built.pack.catalogs.estimatingFrontMatter.cmkCommit, /^[0-9a-f]{40}$/);
    assert.deepEqual(built.pack.schemas, JSON.parse(readFileSync(join(built.dir, 'pack.json'), 'utf8')).schemas);
    assert.ok(existsSync(built.zip));
    assert.ok(existsSync(join(built.dir, '.claude-plugin', 'plugin.json')));
    assert.ok(existsSync(join(built.dir, 'README.md')));
  });

  it('passes the check script and carries no test, node_modules or .cdk content', () => {
    assert.deepEqual(checkSkillPack(built.dir, { allowDirty: true }), []);
    assert.ok(!built.files.some((f) => f.includes('node_modules') || f.endsWith('.test.mjs') || f.includes('.cdk')));
    for (const required of requiredPackFiles()) {
      assert.ok(built.files.includes(required), required);
    }
    for (const tool of [...BUNDLED_TOOLS, ...COPIED_TOOLS]) {
      assert.ok(built.files.includes(`tools/blueprint/${tool}.mjs`), tool);
    }
  });

  it('ships local-only catalog metadata but no local-only capability implementation', () => {
    const catalog = parseCmkCatalog(readFileSync(join(built.dir, 'docs/catalogs/cmk-capability-catalog.md'), 'utf8'));
    assert.deepEqual(catalog.errors, []);
    const placements = Array.from(catalog.platforms.values()).flatMap((capabilities) =>
      Array.from(capabilities.entries()).filter(([, entry]) => entry.status === 'local-only'));
    const capabilityIds = new Set(placements.map(([id]) => id));
    const assetIds = new Set(placements.map(([, entry]) => entry.assetId));
    assert.equal(placements.length, 27);
    assert.equal(capabilityIds.size, 25);
    assert.equal(assetIds.size, 6);

    const implementsLocalOnly = (path) => {
      const match = /^skills\/([^/]+)\//.exec(path);
      return match ? capabilityIds.has(match[1]) : false;
    };
    assert.deepEqual(requiredPackFiles().filter(implementsLocalOnly), []);
    assert.deepEqual(built.files.filter(implementsLocalOnly), []);
  });

  it('writes a zip with every pack file and the version marker', () => {
    const zip = unzipSync(new Uint8Array(readFileSync(built.zip)));
    const name = built.pack.name;
    const entries = Object.keys(zip).filter((entry) => !entry.endsWith('/')).sort();
    assert.deepEqual(entries, [...built.files.map((f) => `${name}/${f}`), `${name}/.pack-version`].sort());
    assert.equal(Buffer.from(zip[`${name}/.pack-version`]).toString('utf8'), `${built.pack.version}\n`);
    assert.equal(JSON.parse(Buffer.from(zip[`${name}/pack.json`]).toString('utf8')).version, built.pack.version);
  });

  it('leaves no temporary build folder behind and lists no warnings it did not earn', () => {
    assert.deepEqual(readdirSync(join(scratch, 'out')).filter((entry) => entry.includes('.building-')), []);
    assert.ok(Array.isArray(built.warnings));
  });

  it('refuses an unknown or uncommitted source commit unless allowed, and a refused build leaves no pack', () => {
    const out = join(scratch, 'strict');
    if (/-dirty$|^unknown$/.test(built.pack.commit)) {
      assert.throws(() => buildSkillPack({ out, zip: false }), /not releasable[\s\S]*commit/);
      assert.ok(!existsSync(join(out, built.pack.name)), 'no half-built pack');
      assert.deepEqual(readdirSync(out).filter((entry) => entry.includes('.building-')), [], 'no temporary folder');
    } else {
      assert.doesNotThrow(() => buildSkillPack({ out, zip: false }));
    }
  });

  it('keeps an earlier good pack when a later build fails', () => {
    const out = join(scratch, 'keep');
    const first = buildSkillPack({ out, zip: false, allowDirty: true });
    writeFileSync(join(first.dir, 'marker.txt'), 'earlier pack');
    if (/-dirty$|^unknown$/.test(first.pack.commit)) {
      assert.throws(() => buildSkillPack({ out, zip: false }), /not releasable/);
      assert.equal(readFileSync(join(first.dir, 'marker.txt'), 'utf8'), 'earlier pack');
    }
  });

  it('checks that the shipped extraction references are present and ignores the .cdk drafts', () => {
    assert.deepEqual(checkReferences(), []);
    assert.ok(!built.warnings.some((line) => /drift|\.cdk/.test(line)));
  });
});

describe('rewriteSkill', () => {
  it('rewrites repo paths in skills to the pack root', () => {
    const text = rewriteSkill('---\nname: x\n---\n\nRun `node tools/blueprint/validate-context.mjs a.json`.\nAttach docs/catalogs/estimating-catalog.md and [the schema](../../../docs/spfx/working-file.md). Seeds: samples/factors/seed/.\n');
    assert.match(text, /node "\$BLUEPRINT_PACK\/tools\/blueprint\/validate-context\.mjs" a\.json/);
    assert.match(text, /\$BLUEPRINT_PACK\/docs\/catalogs\/estimating-catalog\.md/);
    assert.match(text, /\(\$BLUEPRINT_PACK\/docs\/working-file\.md\)/);
    assert.match(text, /\$BLUEPRINT_PACK\/samples\/factors\/seed\//);
    assert.match(text, /Pack location/);
    assert.deepEqual(checkSkillText(text, 'x.md'), []);
    assert.ok(checkSkillText('see .cdk/SPMVP-008/x.md', 'y.md').length > 0);
    assert.ok(checkSkillText('run node tools/blueprint/x.mjs', 'y.md').length > 0);
    assert.deepEqual(checkSkillText('run node "$BLUEPRINT_PACK/tools/blueprint/x.mjs"', 'y.md'), []);
  });

  it('points a `./tools/...` import in an inline node -e snippet at the pack', () => {
    const snippet = `node --input-type=module -e "import { citationLabel } from './tools/blueprint/citation-label.mjs'; console.log(citationLabel('a.pdf', {}));"`;
    const text = rewriteSkill(`---\nname: x\n---\n\n${snippet}\n`);
    assert.match(text, /from '\$BLUEPRINT_PACK\/tools\/blueprint\/citation-label\.mjs'/);
    assert.doesNotMatch(text, /'\.\/tools/);
    assert.deepEqual(checkSkillText(text, 'x.md'), []);
    assert.ok(checkSkillText(snippet, 'x.md').length > 0, 'the unrewritten snippet is a finding');
  });

  it('rewrites the real skills so the check script finds nothing', () => {
    const parse = readFileSync(join(built.dir, 'skills', 'blueprint-parse', 'SKILL.md'), 'utf8');
    assert.match(parse, /from '\$BLUEPRINT_PACK\/tools\/blueprint\/citation-label\.mjs'/);
  });

  it('is idempotent: a rewritten skill is not rewritten or prefaced again', () => {
    const source = '---\nname: x\n---\n\nSee docs/spfx/agent-contract.md and docs/standalone/agent-run-evaluation.md, [x](../../../docs/spfx/working-file.md).\n' +
      'Run node tools/blueprint/run-record.mjs <folder>. Use .claude/skills/blueprint-parse/SKILL.md, samples/offline/ and tools/release/pack.config.json.\n';
    const once = rewriteSkill(source);
    assert.equal(rewriteSkill(once), once);
    assert.equal(once.split('**Pack location.**').length, 2, 'one preamble');
    assert.ok(once.includes(PACK_PREAMBLE.trim().split('\n')[0]));
  });

  it('handles a skill without front matter and CRLF text', () => {
    const plain = rewriteSkill('Run node tools/blueprint/x.mjs\r\nnext line\r\n');
    assert.ok(plain.startsWith('> **Pack location.**'));
    assert.ok(!plain.includes('\r'));
    assert.match(plain, /node "\$BLUEPRINT_PACK\/tools\/blueprint\/x\.mjs"/);
  });
});

describe('rewriteDocLinks', () => {
  const exists = (path) => ['docs/agent-run-evaluation.md', 'docs/working-file.md', 'README.md', 'docs/catalogs/estimating-catalog.md'].includes(path);

  it('re-points links between shipped docs, keeps anchors and URLs, and drops links to files the pack lacks', () => {
    const text = 'See [run](../standalone/agent-run-evaluation.md#checks), [format](working-file.md), [site](https://example.com/x), [top](#here), ' +
      '[ticket](../../backlog/SAPP-001.md) and [cat](../catalogs/estimating-catalog.md).';
    const out = rewriteDocLinks(text, 'docs/spfx/agent-contract.md', 'docs/agent-contract.md', exists);
    assert.equal(out, 'See [run](agent-run-evaluation.md#checks), [format](working-file.md), [site](https://example.com/x), [top](#here), ticket and [cat](catalogs/estimating-catalog.md).');
  });

  it('points the README at the shipped docs folder', () => {
    const out = rewriteDocLinks('[contract](../spfx/working-file.md)', 'docs/standalone/agent-skill-pack.md', 'README.md', exists);
    assert.equal(out, '[contract](docs/working-file.md)');
  });

  it('leaves the shipped docs with links that resolve', () => {
    for (const rel of built.files.filter((f) => /^docs\/[^/]+\.md$/.test(f))) {
      assert.deepEqual(checkDocLinks(readFileSync(join(built.dir, rel), 'utf8'), rel, built.dir), [], rel);
    }
  });
});

describe('check-skill-pack finds what would break outside the repository', () => {
  it('a tool import that leaves the pack, does not exist, or is a bare or dynamic import', () => {
    const pack = damaged('imports');
    writeFileSync(join(pack, 'tools/blueprint/evil.mjs'), [
      "import '../../../outside.mjs';",
      "import { a } from './nope.mjs';",
      "const b = await import('../x/missing.mjs');",
      "export * from './also-missing.mjs';"
    ].join('\n'));
    const findings = checkSkillPack(pack, { allowDirty: true });
    assert.ok(findings.some((f) => /import "\.\.\/\.\.\/\.\.\/outside\.mjs" leaves the pack/.test(f)), findings.join('\n'));
    assert.ok(findings.some((f) => /import "\.\/nope\.mjs" is not in the pack/.test(f)));
    assert.ok(findings.some((f) => /import "\.\.\/x\/missing\.mjs"/.test(f)));
    assert.ok(findings.some((f) => /also-missing/.test(f)));
  });

  it('an import of function/dist, static or dynamic', () => {
    const pack = damaged('function-dist');
    writeFileSync(join(pack, 'tools/blueprint/uses-dist.mjs'), "const x = await import('../../function/dist/src/parse.js');\n");
    assert.ok(checkSkillPack(pack, { allowDirty: true }).some((f) => /function\/dist/.test(f)));
    const file = join(pack, 'tools/blueprint/uses-dist2.mjs');
    writeFileSync(file, "import { p } from '../../function/dist/src/parse.js';\n");
    assert.ok(checkToolImports(file, pack).some((f) => /function\/dist/.test(f)));
  });

  it('a missing required file, from the skills, tools, templates, docs and catalogs', () => {
    for (const required of ['tools/blueprint/run-record.mjs', 'tools/blueprint/write-file-atomic.mjs', 'tools/blueprint/source-candidates.mjs',
      'tools/blueprint/templates/AGENTS.md', 'docs/agent-contract.md', 'skills/blueprint-parse/SKILL.md']) {
      const pack = damaged(`missing-${required.replace(/\W/g, '-')}`);
      rmSync(join(pack, required));
      assert.ok(checkSkillPack(pack, { allowDirty: true }).some((f) => f === `${required} is missing`), required);
    }
  });

  it('a shipped test file or node_modules folder', () => {
    const pack = damaged('shipped');
    writeFileSync(join(pack, 'tools/blueprint/thing.test.mjs'), '');
    mkdirSync(join(pack, 'tools/node_modules/x'), { recursive: true });
    writeFileSync(join(pack, 'tools/node_modules/x/index.js'), '');
    const findings = checkSkillPack(pack, { allowDirty: true });
    assert.ok(findings.some((f) => /thing\.test\.mjs: should not be shipped/.test(f)));
    assert.ok(findings.some((f) => /node_modules\/x\/index\.js: should not be shipped/.test(f)));
  });

  it('an empty or missing pack.json field, including nested catalog pins', () => {
    const pack = damaged('pack-json');
    const file = join(pack, 'pack.json');
    const json = JSON.parse(readFileSync(file, 'utf8'));
    json.version = '';
    delete json.builtAt;
    json.catalogs.cmkCommit = '';
    delete json.catalogs.toolkitCommit;
    json.schemas = {};
    writeFileSync(file, JSON.stringify(json));
    const findings = checkSkillPack(pack, { allowDirty: true });
    for (const expected of ['pack.json: version is missing', 'pack.json: builtAt is missing', 'pack.json: catalogs.cmkCommit is missing',
      'pack.json: catalogs.toolkitCommit is missing', 'pack.json: schemas must list the schema versions']) {
      assert.ok(findings.includes(expected), `${expected}\n${findings.join('\n')}`);
    }
  });

  it('a pack.json that is not valid JSON, and a missing one', () => {
    const pack = damaged('bad-json');
    writeFileSync(join(pack, 'pack.json'), '{ not json');
    assert.ok(checkSkillPack(pack, { allowDirty: true }).some((f) => /pack\.json is not valid JSON/.test(f)));
    rmSync(join(pack, 'pack.json'));
    assert.ok(checkSkillPack(pack, { allowDirty: true }).includes('pack.json is missing'));
  });

  it('an unknown or uncommitted commit, unless allowed', () => {
    const pack = damaged('commits');
    const file = join(pack, 'pack.json');
    const json = JSON.parse(readFileSync(file, 'utf8'));
    for (const [commit, pattern] of [['unknown', /commit is unknown/], [`${'a'.repeat(40)}-dirty`, /uncommitted changes/]]) {
      writeFileSync(file, JSON.stringify({ ...json, commit }));
      assert.ok(checkSkillPack(pack).some((f) => pattern.test(f)), commit);
      assert.deepEqual(checkSkillPack(pack, { allowDirty: true }), [], `${commit} passes with allowDirty`);
    }
    writeFileSync(file, JSON.stringify({ ...json, commit: 'a'.repeat(40) }));
    assert.deepEqual(checkSkillPack(pack), []);
  });

  it('a repo path, a .cdk reference, a ./tools path or a dangling $BLUEPRINT_PACK path in a skill', () => {
    const pack = damaged('skill-paths');
    const skill = join(pack, 'skills/blueprint-parse/SKILL.md');
    writeFileSync(skill, `${readFileSync(skill, 'utf8')}\nRun node tools/blueprint/parse-local.mjs, see .cdk/x.md, import './tools/blueprint/y.mjs', and $BLUEPRINT_PACK/samples/review/README.md.\n`);
    const findings = checkSkillPack(pack, { allowDirty: true });
    assert.ok(findings.some((f) => /path "tools\/blueprint\/parse-local\.mjs" is not anchored/.test(f)), findings.join('\n'));
    assert.ok(findings.some((f) => /refers to \.cdk\//.test(f)));
    assert.ok(findings.some((f) => /path "\.\/tools\/blueprint\/y\.mjs" is not anchored/.test(f)));
    assert.ok(findings.some((f) => /\$BLUEPRINT_PACK\/samples\/review\/README\.md, which the pack does not carry/.test(f)));
    assert.deepEqual(checkPackReferences('$BLUEPRINT_PACK/pack.json and $BLUEPRINT_PACK/skills/', 'x.md', pack), []);
  });

  it('a shipped doc whose link leaves the pack or points at a missing file', () => {
    const pack = damaged('doc-links');
    const doc = join(pack, 'docs/agent-contract.md');
    writeFileSync(doc, `${readFileSync(doc, 'utf8')}\n[ticket](../../backlog/x.md) [gone](missing.md) [ok](working-file.md) [web](https://example.com)\n`);
    const findings = checkSkillPack(pack, { allowDirty: true });
    assert.ok(findings.some((f) => /link "\.\.\/\.\.\/backlog\/x\.md" leaves the pack/.test(f)), findings.join('\n'));
    assert.ok(findings.some((f) => /link "missing\.md" points at a file the pack does not carry/.test(f)));
    assert.ok(!findings.some((f) => /working-file\.md|example\.com/.test(f)));
  });

  it('the command line exits 0 for a clean pack, 1 for a damaged one and 2 for bad arguments', () => {
    const script = join(repoRoot, 'tools/release/check-skill-pack.mjs');
    assert.equal(spawnSync(process.execPath, [script, built.dir, '--allow-dirty'], { encoding: 'utf8' }).status, 0);
    const pack = damaged('cli');
    rmSync(join(pack, 'tools/blueprint/run-record.mjs'));
    const bad = spawnSync(process.execPath, [script, pack, '--allow-dirty'], { encoding: 'utf8' });
    assert.equal(bad.status, 1);
    assert.match(bad.stderr, /run-record\.mjs is missing/);
    assert.equal(spawnSync(process.execPath, [script], { encoding: 'utf8' }).status, 2);
  });
});

describe('the built pack works from outside the repository', () => {
  it('validates its own samples', () => {
    for (const [tool, args] of [
      ['validate-working-file', [join(built.dir, 'samples/offline/Synthetic_AEM_Blueprint.json')]],
      ['validate-context', [join(built.dir, 'samples/offline/Synthetic_AEM_Context.json'), '--blueprint', join(built.dir, 'samples/offline/Synthetic_AEM_Blueprint.json')]],
      ['validate-working-file', [join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json')]],
      ['validate-proposals', [join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Proposals.json'), '--blueprint', join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json')]]
    ]) {
      const result = node([join(built.dir, 'tools/blueprint', `${tool}.mjs`), ...args]);
      assert.equal(result.status, 0, `${tool}: ${result.stderr}`);
    }
  });

  it('matches libraries from its own seed', () => {
    const result = node([join(built.dir, 'tools/blueprint/match-library.mjs'), join(built.dir, 'samples/offline/Synthetic_AEM_Blueprint.json')]);
    assert.equal(result.status, 0, result.stderr);
    const output = JSON.parse(result.stdout);
    assert.ok(output.deliveryRisks.entries.length > 0);
  });

  it('sweeps for gaps from its own checklist', () => {
    const result = node([join(built.dir, 'tools/blueprint/gap-sweep.mjs'), join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json')]);
    assert.equal(result.status, 0, result.stderr);
    assert.ok(JSON.parse(result.stdout).gaps.length > 0);
  });

  it('reports review decisions across project folders', () => {
    const folder = join(scratch, 'review-stats-projects');
    for (const name of ['Alpha', 'Beta']) {
      mkdirSync(join(folder, name), { recursive: true });
      writeFileSync(join(folder, name, `${name}_Context.json`), JSON.stringify({
        meta: { schemaVersion: '2' },
        assumptions: [{ id: 'AS-001', statement: 'S', libraryId: 'LIB-X', review: { status: 'dismissed' } }]
      }));
    }
    const result = node([join(built.dir, 'tools/blueprint/review-stats.mjs'), folder, '--min-decisions', '2']);
    assert.equal(result.status, 0, result.stderr);
    const report = JSON.parse(result.stdout);
    assert.equal(report.projects, 2);
    assert.deepEqual(report.suppress.map((entry) => entry.key), ['LIB-X']);
  });

  it('advises levers from its own catalog and evidence file', () => {
    const blocks = join(scratch, 'lever-blocks.json');
    writeFileSync(blocks, JSON.stringify([{ id: 'b1', label: 'Brief', text: 'The client runs AEM 6.5 on premise and moves to the cloud.' }]));
    const result = node([
      join(built.dir, 'tools/blueprint/lever-advice.mjs'),
      '--blueprint', join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json'), '--blocks', blocks
    ]);
    assert.equal(result.status, 0, result.stderr);
    assert.ok(JSON.parse(result.stdout).advised.some((item) => item.id === 'aem-cloud-migration'));
  });

  it('checks a design sketch against blocks with its own catalog', () => {
    const out = join(scratch, 'design-sketch.json');
    const input = join(scratch, 'design-input.json');
    writeFileSync(input, JSON.stringify({
      drivers: [{
        workPackageId: 'multisite', quantity: 3, basis: 'counted', items: ['corporate site', 'dealer locator', 'seasonal campaign microsites'],
        blockIds: ['src-fabrikam-rfp-2027#p1.1'], confidence: 'low'
      }]
    }));
    const build = node([
      join(built.dir, 'tools/blueprint/assemble-drivers.mjs'),
      '--input', input,
      '--blocks', join(built.dir, 'samples/agent-run/.blueprint/parsed/blocks.json'),
      '--out', out
    ]);
    assert.equal(build.status, 0, build.stderr);
    assert.equal(node([join(built.dir, 'tools/blueprint/assemble-drivers.mjs'), '--check', out, '--blocks', join(built.dir, 'samples/agent-run/.blueprint/parsed/blocks.json')]).status, 0);
  });

  it('compares two reads of the documents with its own catalog', () => {
    const input = join(scratch, 'second-input.json');
    const sketch = join(scratch, 'second-sketch.json');
    writeFileSync(input, JSON.stringify({
      drivers: [{
        workPackageId: 'multisite', quantity: 3, basis: 'counted', items: ['corporate site', 'dealer locator', 'seasonal campaign microsites'],
        blockIds: ['src-fabrikam-rfp-2027#p1.1'], confidence: 'low'
      }]
    }));
    const blocks = join(built.dir, 'samples/agent-run/.blueprint/parsed/blocks.json');
    const sketchTwo = join(scratch, 'second-sketch-two.json');
    for (const out of [sketch, sketchTwo]) {
      assert.equal(node([join(built.dir, 'tools/blueprint/assemble-drivers.mjs'), '--input', input, '--blocks', blocks, '--out', out]).status, 0);
    }
    const result = node([
      join(built.dir, 'tools/blueprint/second-opinion.mjs'),
      '--blueprint', join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json'),
      '--first', sketch, '--second', sketchTwo, '--blocks', blocks, '--markdown'
    ]);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /Agree: multisite \(3\)/);
  });

  it('ranks questions with its own catalog', () => {
    const result = node([join(built.dir, 'tools/blueprint/rank-questions.mjs'), join(built.dir, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json'), '--markdown']);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /Client clarification list/);
  });

  it('assembles, summarises, accepts and validates a plan file with the pack\'s own tools and catalog', () => {
    const folder = join(scratch, 'plan-folder');
    mkdirSync(join(folder, '.blueprint'), { recursive: true });
    cpSync(join(built.dir, 'samples/agent-run/.blueprint/parsed'), join(folder, '.blueprint/parsed'), { recursive: true });
    writeFileSync(join(folder, '.blueprint/extract.json'), JSON.stringify({
      requirements: [{
        statement: 'Migrate the legacy content.', blockIds: ['src-fabrikam-rfp-2027#p1.1'], workPackage: 'content-migration',
        coverage: 'accelerated', question: null, duplicateOf: null
      }],
      platform: { id: null, blockId: null },
      notes: null
    }));
    const plan = join(folder, 'Plan Project_Plan.json');
    const assemble = node([join(built.dir, 'tools/blueprint/plan.mjs'), 'assemble', folder, '--project', 'Plan Project']);
    assert.equal(assemble.status, 0, `${assemble.stdout}\n${assemble.stderr}`);
    assert.equal(node([join(built.dir, 'tools/blueprint/plan.mjs'), 'accept', plan, '--all']).status, 0);
    const validate = node([join(built.dir, 'tools/blueprint/plan.mjs'), 'validate', plan, '--blocks', join(folder, '.blueprint/parsed/blocks.json')]);
    assert.equal(validate.status, 0, validate.stderr);
    const summary = node([join(built.dir, 'tools/blueprint/plan.mjs'), 'summary', plan, '--markdown']);
    assert.equal(summary.status, 0, summary.stderr);
    assert.match(summary.stdout, /1 requirement in 1 workstream/);
  });

  it('prepares and parses a project folder with the bundled tools, with no function build and no node_modules', () => {
    const prepare = node([join(built.dir, 'tools/blueprint/prepare-folder.mjs'), elsewhere, '--project', 'Fabrikam Outdoor', '--require-pack']);
    assert.equal(prepare.status, 0, `${prepare.stdout}\n${prepare.stderr}`);
    assert.match(prepare.stdout, /skill pack found at/);
    const agents = readFileSync(join(elsewhere, 'AGENTS.md'), 'utf8');
    assert.match(agents, new RegExp(`Expected pack version: ${built.pack.version.replace(/\./g, '\\.')}`));
    const parse = node([join(built.dir, 'tools/blueprint/parse-local.mjs'), elsewhere, '--quiet']);
    assert.equal(parse.status, 0, `${parse.stdout}\n${parse.stderr}`);
    const manifest = JSON.parse(readFileSync(join(elsewhere, '.blueprint/parsed/manifest.json'), 'utf8'));
    assert.equal(manifest.files.length, 6);
    assert.equal(manifest.files.find((f) => f.name === 'Fabrikam_RFP_2027.pdf').read, 'read');
    assert.equal(manifest.files.find((f) => f.name === 'Signed_NDA_scan.pdf').read, 'not read');
    const record = JSON.parse(readFileSync(join(elsewhere, '.blueprint/run.json'), 'utf8'));
    assert.equal(record.pack.layout, 'pack');
    assert.equal(record.pack.version, built.pack.version);
    assert.equal(record.pack.commit, built.pack.commit);
    assert.ok(record.stages.prepared, 'prepare-folder recorded its stage');
    assert.ok(record.stages.parse, 'parse-local recorded its stage');
  });

  it('runs the bundled tools with several --select values, one, or none, and never runs the run-record command line by mistake', () => {
    const names = ['Workshop_Notes.docx', 'Fabrikam_RFP_2027.pdf', 'Content_Inventory.xlsx'];
    for (const [label, select] of [['several', names], ['one', names.slice(0, 1)], ['none', []]]) {
      const folder = projectFolder(`select-${label}`);
      const args = select.length ? ['--select', ...select] : [];
      const prepare = node([join(built.dir, 'tools/blueprint/prepare-folder.mjs'), folder, '--project', 'P', ...args], { cwd: folder });
      assert.equal(prepare.status, 0, `${label} prepare: ${prepare.stdout}\n${prepare.stderr}`);
      assert.doesNotMatch(prepare.stdout + prepare.stderr, /Usage: node tools\/blueprint\/run-record\.mjs|run\.json \(stage/, `${label}: no run-record output from prepare-folder`);
      const afterPrepare = JSON.parse(readFileSync(join(folder, '.blueprint/run.json'), 'utf8'));
      assert.equal(afterPrepare.stage, 'prepared', label);
      assert.ok(afterPrepare.stages.prepared, `${label}: the prepared stage is recorded`);
      const expected = select.length ? select : readdirSync(folder).filter((f) => /\.(pdf|docx|pptx|xlsx|doc)$/.test(f));
      const written = JSON.parse(readFileSync(join(folder, '.blueprint/sources.json'), 'utf8')).sources.map((s) => s.name);
      assert.deepEqual([...written].sort(), [...expected].sort(), `${label}: selection written`);

      const parse = node([join(built.dir, 'tools/blueprint/parse-local.mjs'), folder, '--select', ...(select.length ? select : names)], { cwd: folder });
      assert.equal(parse.status, 0, `${label} parse: ${parse.stdout}\n${parse.stderr}`);
      assert.doesNotMatch(parse.stdout + parse.stderr, /Usage: node tools\/blueprint\/run-record\.mjs|run\.json \(stage/, `${label}: no run-record output from parse-local`);
      const manifest = JSON.parse(readFileSync(join(folder, '.blueprint/parsed/manifest.json'), 'utf8'));
      assert.equal(manifest.files.length, (select.length ? select : names).length, label);
      const afterParse = JSON.parse(readFileSync(join(folder, '.blueprint/run.json'), 'utf8'));
      assert.equal(afterParse.stage, 'parse', label);
      assert.ok(afterParse.stages.prepared && afterParse.stages.parse, `${label}: both stages recorded`);
    }
  });

  it('runs the real run-record command line from the pack', () => {
    const folder = projectFolder('cli-record');
    const result = node([join(built.dir, 'tools/blueprint/run-record.mjs'), folder, '--stage', 'parse', '--note', 'from the pack'], { cwd: folder });
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /wrote .*run\.json \(stage parse, pack /);
    assert.equal(node([join(built.dir, 'tools/blueprint/run-record.mjs'), folder, '--bogus'], { cwd: folder }).status, 2);
  });

  it('assembles a Blueprint from the pack with the pack catalog', () => {
    const extract = join(elsewhere, 'extract.json');
    writeFileSync(extract, JSON.stringify({
      requirements: [{ statement: 'All public pages meet WCAG 2.2 AA.', blockIds: ['src-fabrikam-rfp-2027#p4.1'], workPackage: 'component-review', coverage: 'accelerated', question: null, duplicateOf: null }],
      platform: { id: 'aem', blockId: 'src-fabrikam-rfp-2027#p1.1' }
    }));
    const out = join(elsewhere, 'Fabrikam Outdoor_Blueprint.json');
    const result = node([
      join(built.dir, 'tools/blueprint/assemble-working-file.mjs'),
      '--extract', extract, '--blocks', join(elsewhere, '.blueprint/parsed/blocks.json'), '--sources', join(elsewhere, '.blueprint/parsed/sources.json'),
      '--estimating', join(built.dir, 'docs/catalogs/estimating-catalog.md'),
      '--project-id', 'p', '--project-name', 'Fabrikam Outdoor', '--out', out
    ]);
    assert.equal(result.status, 0, result.stderr);
    const validate = node([join(built.dir, 'tools/blueprint/validate-working-file.mjs'), out]);
    assert.equal(validate.status, 0, validate.stderr);
    const working = JSON.parse(readFileSync(out, 'utf8'));
    assert.equal(working.catalog.estimatingVersion, '4');
    assert.ok(working.requirements[0].capabilities.length > 0);
  });
});
