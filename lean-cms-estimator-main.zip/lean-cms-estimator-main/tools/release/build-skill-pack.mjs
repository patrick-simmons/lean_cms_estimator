#!/usr/bin/env node
/**
 * Builds the portable Blueprint skill pack from this repository (SAPP-015).
 *
 * The pack is a folder (and a zip) an estimator installs without a checkout. It keeps the repository's
 * relative layout under its root, so the Node tools find the catalogs and libraries exactly as they do
 * here, and the skills point at that root through `$BLUEPRINT_PACK`:
 *
 *   pack.json                  version, commit, build time, catalog pins, schema versions
 *   README.md                  the install guide (docs/standalone/agent-skill-pack.md)
 *   .claude-plugin/plugin.json Claude Code plugin manifest; `skills/` is the plugin's skills folder
 *   skills/<name>/SKILL.md     the skills, repo paths rewritten to $BLUEPRINT_PACK, plus their references/
 *   tools/blueprint/*.mjs      the tools; parse-local and prepare-folder are bundled so no node_modules or
 *                              function build is needed; the rest are copied as they are
 *   tools/factors/*.mjs        the seed loader match-library needs
 *   docs/                      catalogs (with their pins), the file contracts, the evaluation checklist; their
 *                              relative links are rewritten to the flat layout, and links to files the pack
 *                              does not carry become plain text
 *   samples/                   seed libraries, offline samples, the agent run sample, the synthetic sources
 *
 * Nobody edits the pack by hand: the skills in .claude/skills/ and the tools in tools/ are the source.
 * The pack is built in a temporary folder next to the output and moved into place only when it passes the
 * check script, so a failed build never leaves a broken pack behind. The build fails
 *   - when a shipped extraction reference under .claude/skills/blueprint-extract-map/references/ is missing
 *     (those files are the source; the old .cdk/SPMVP-008/ drafts are not compared, see SAPP-015)
 *   - when the check script finds a repo path, a missing file or a stale commit in the result. The commit
 *     must be a clean one: `unknown` (no git) and `-dirty` (uncommitted changes) need `--allow-dirty`.
 *
 * Usage: node tools/release/build-skill-pack.mjs [--out <dir>] [--no-zip] [--allow-dirty]
 */
import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { basename, dirname, join, posix, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { strToU8, zipSync } from 'fflate';
import { catalogPins } from '../blueprint/derive-capabilities.mjs';
import { checkSkillPack } from './check-skill-pack.mjs';
import { BUNDLED_TOOLS, CASES_TOOLS, COPIED_TOOLS, DOCS, FACTORS_TOOLS, listFiles, README_SOURCE, SKILLS } from './pack-layout.mjs';

export { BUNDLED_TOOLS, CASES_TOOLS, COPIED_TOOLS, FACTORS_TOOLS, SKILLS } from './pack-layout.mjs';

const here = dirname(fileURLToPath(import.meta.url));
export const REPO_ROOT = join(here, '../..');

/** The extraction instructions the extract skill ships. They are the source, edited in this repository. */
const EXTRACTION_REFERENCES = [
  '.claude/skills/blueprint-extract-map/references/system-message.md',
  '.claude/skills/blueprint-extract-map/references/response-format.md'
];

export const PACK_PREAMBLE = [
  '> **Pack location.** This skill is part of the Blueprint skill pack. `$BLUEPRINT_PACK` below is the folder that holds the pack\'s',
  '> `pack.json` (the one that contains `skills/`, `tools/`, `docs/` and `samples/`). If the variable is not set in your shell, use the',
  '> path of that folder: for a skill loaded from `<pack>/skills/<name>/SKILL.md` it is `<pack>`. Every `node` command and every file',
  '> path in this skill is relative to it, except the project folder, which is the folder you were asked to work on.',
  ''
].join('\n');

function normalize(text) {
  return text.replace(/\r\n/g, '\n');
}

/** The commit being built and whether the tool, skill, catalog, sample or reader sources have uncommitted changes. */
function gitState() {
  try {
    const commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPO_ROOT, encoding: 'utf8' }).trim();
    const status = execFileSync('git', ['status', '--porcelain', '--', 'tools', '.claude/skills', 'docs/catalogs', 'samples', 'function/src'], { cwd: REPO_ROOT, encoding: 'utf8' });
    return { commit, dirty: status.trim().length > 0 };
  } catch {
    // No git or not a checkout: the commit is unknown, and the check script refuses an unknown commit.
    return { commit: 'unknown', dirty: false };
  }
}

/**
 * Each rule: [pattern, replacement, why]. They run in order. A path already anchored on $BLUEPRINT_PACK
 * never matches again, so rewriting an already rewritten skill changes nothing.
 */
export const SKILL_REWRITES = [
  [/\(\.\.\/\.\.\/\.\.\/docs\/spfx\/([\w-]+\.md)\)/g, '($BLUEPRINT_PACK/docs/$1)', 'markdown links out of .claude/skills/<name>/ into docs/spfx/ (docs ship flat)'],
  [/\[docs\/spfx\/([\w-]+\.md)\]/g, '[$1]', 'link text that shows a docs/spfx path'],
  [/\(\.\.\/\.\.\/\.\.\/docs\/([\w/-]+\.md)\)/g, '($BLUEPRINT_PACK/docs/$1)', 'markdown links into docs/'],
  [/`docs\/spfx\/([\w-]+\.md)`/g, '`$BLUEPRINT_PACK/docs/$1`', 'inline-code docs/spfx paths'],
  [/\bdocs\/spfx\/([\w-]+\.md)/g, '$BLUEPRINT_PACK/docs/$1', 'bare docs/spfx paths'],
  [/\[docs\/standalone\/([\w-]+\.md)\]/g, '[$1]', 'link text that shows a docs/standalone path'],
  [/(\$BLUEPRINT_PACK\/)?docs\/standalone\/([\w-]+\.md)/g, '$BLUEPRINT_PACK/docs/$2', 'docs/standalone pages ship flat under docs/ as well'],
  [/(^|[^$/\w])tools\/release\/pack\.config\.json/g, '$1$BLUEPRINT_PACK/pack.json', 'the pack\'s own manifest replaces the build config'],
  [/(^|[^$/\w])\.claude\/skills\//g, '$1$BLUEPRINT_PACK/skills/', 'the shipped skills folder'],
  [/(['"])\.\/((?:tools|docs|samples)\/)/g, '$1$BLUEPRINT_PACK/$2', 'a `./tools/...` specifier in an inline `node -e` snippet (the lookbehind of the generic rules skips a path after `/`)'],
  [/\bnode tools\/blueprint\/([\w-]+\.mjs)/g, 'node "$BLUEPRINT_PACK/tools/blueprint/$1"', 'node commands'],
  [/(^|[^$/\w])tools\/blueprint\//g, '$1$BLUEPRINT_PACK/tools/blueprint/', 'other tool paths'],
  [/(^|[^$/\w])docs\/catalogs\//g, '$1$BLUEPRINT_PACK/docs/catalogs/', 'catalog paths'],
  [/(^|[^$/\w])samples\/(factors|offline|review|agent-run|sources|workbook)\//g, '$1$BLUEPRINT_PACK/samples/$2/', 'sample folders']
];

/** Rewrites one skill body for the pack: repo paths anchored on $BLUEPRINT_PACK, and a preamble saying what that is. */
export function rewriteSkill(text) {
  let out = normalize(text);
  for (const [pattern, replacement] of SKILL_REWRITES) {
    out = out.replace(pattern, replacement);
  }
  if (out.includes('**Pack location.**')) {
    return out;
  }
  const fm = /^---\n[\s\S]*?\n---\n/.exec(out);
  if (fm) {
    return `${fm[0]}\n${PACK_PREAMBLE}\n${out.slice(fm[0].length).replace(/^\n+/, '')}`;
  }
  return `${PACK_PREAMBLE}${out}`;
}

/**
 * Rewrites the relative markdown links of a doc copied into the pack. `from` and `to` are the doc's path in
 * the repository and in the pack; `exists(path)` says whether the pack carries a path. A link to a shipped file
 * is re-pointed at its new place, and a link to anything else becomes its plain text.
 */
export function rewriteDocLinks(text, from, to, exists) {
  const shipped = new Map([...DOCS, [README_SOURCE, 'README.md']]);
  return normalize(text).replace(/\[([^\]]*)\]\(([^)\s]+)\)/g, (whole, label, target) => {
    if (/^[a-z][a-z0-9+.-]*:/i.test(target) || target.startsWith('#') || target.startsWith('/')) {
      return whole;
    }
    const [pathPart, ...anchor] = target.split('#');
    const repoPath = posix.normalize(posix.join(posix.dirname(from), pathPart));
    const packPath = shipped.get(repoPath) || repoPath;
    if (repoPath.startsWith('..') || !exists(packPath)) {
      return label;
    }
    const relativeLink = posix.relative(posix.dirname(to), packPath) || posix.basename(packPath);
    return `[${label}](${relativeLink}${anchor.length ? `#${anchor.join('#')}` : ''})`;
  });
}

function esbuildPath() {
  // esbuild comes with tsx under function/; the pack build is a repo task, so that is where we take it from.
  const requireFromFunction = createRequire(join(REPO_ROOT, 'function/package.json'));
  try {
    return requireFromFunction.resolve('esbuild/bin/esbuild');
  } catch {
    throw new Error('esbuild was not found under function/node_modules. Run: npm --prefix function install');
  }
}

function bundleTool(name, outFile) {
  const entry = join(REPO_ROOT, 'tools/blueprint', `${name}.mjs`);
  if (!existsSync(join(REPO_ROOT, 'function/dist/src/localParse.js'))) {
    throw new Error('function/dist is not built. Run: npm --prefix function run build');
  }
  execFileSync(process.execPath, [
    esbuildPath(), entry, '--bundle', '--platform=node', '--format=esm', '--target=node22',
    '--log-level=warning', '--legal-comments=none', `--outfile=${outFile}`,
    '--banner:js=// Bundled by tools/release/build-skill-pack.mjs from tools/blueprint/' + name + '.mjs and the function readers. Do not edit.'
  ], { cwd: REPO_ROOT, stdio: 'inherit' });
}

function copy(from, to) {
  mkdirSync(dirname(to), { recursive: true });
  cpSync(from, to, { recursive: true });
}

/**
 * Checks that the extraction references the extract skill ships are present.
 * @returns {string[]} one line per missing file
 * @throws {Error} listing the missing files
 */
export function checkReferences() {
  const missing = EXTRACTION_REFERENCES.filter((reference) => !existsSync(join(REPO_ROOT, reference)))
    .map((reference) => `${reference} is missing`);
  if (missing.length) {
    throw new Error(missing.join('\n'));
  }
  return missing;
}

/** Moves the finished pack into place; falls back to copy and delete when the rename is refused (a scanner holding a file). */
function moveIntoPlace(work, dir) {
  rmSync(dir, { recursive: true, force: true });
  try {
    renameSync(work, dir);
  } catch {
    cpSync(work, dir, { recursive: true });
    rmSync(work, { recursive: true, force: true });
  }
}

/**
 * @param {{ out?: string, zip?: boolean, allowDirty?: boolean, now?: Date }} [options]
 * @returns {{ dir: string, zip?: string, pack: object, files: string[], warnings: string[] }}
 */
export function buildSkillPack(options = {}) {
  const config = JSON.parse(readFileSync(join(REPO_ROOT, 'tools/release/pack.config.json'), 'utf8'));
  const outRoot = resolve(options.out || join(REPO_ROOT, 'release'));
  const dir = join(outRoot, config.name);
  const work = join(outRoot, `.${config.name}.building-${process.pid}`);
  const now = options.now || new Date();
  const warnings = [];

  checkReferences();

  mkdirSync(outRoot, { recursive: true });
  rmSync(work, { recursive: true, force: true });
  mkdirSync(work, { recursive: true });
  try {
    // Skills.
    for (const skill of SKILLS) {
      const from = join(REPO_ROOT, '.claude/skills', skill);
      const to = join(work, 'skills', skill);
      for (const file of listFiles(from)) {
        const target = join(to, file);
        mkdirSync(dirname(target), { recursive: true });
        const text = readFileSync(join(from, file), 'utf8');
        writeFileSync(target, file.endsWith('.md') ? rewriteSkill(text) : text);
      }
    }

    // Tools.
    for (const name of COPIED_TOOLS) {
      copy(join(REPO_ROOT, 'tools/blueprint', `${name}.mjs`), join(work, 'tools/blueprint', `${name}.mjs`));
    }
    for (const name of FACTORS_TOOLS) {
      copy(join(REPO_ROOT, 'tools/factors', `${name}.mjs`), join(work, 'tools/factors', `${name}.mjs`));
    }
    for (const name of CASES_TOOLS) {
      copy(join(REPO_ROOT, 'tools/cases', `${name}.mjs`), join(work, 'tools/cases', `${name}.mjs`));
    }
    copy(join(REPO_ROOT, 'tools/blueprint/templates'), join(work, 'tools/blueprint/templates'));
    copy(join(REPO_ROOT, 'tools/blueprint/data'), join(work, 'tools/blueprint/data'));
    for (const name of BUNDLED_TOOLS) {
      bundleTool(name, join(work, 'tools/blueprint', `${name}.mjs`));
    }

    // Catalogs and pins.
    copy(join(REPO_ROOT, 'docs/catalogs'), join(work, 'docs/catalogs'));
    copy(join(REPO_ROOT, 'tools/cmk-catalog.pin.json'), join(work, 'tools/cmk-catalog.pin.json'));
    copy(join(REPO_ROOT, 'tools/toolkit-catalog.pin.json'), join(work, 'tools/toolkit-catalog.pin.json'));

    // Samples.
    copy(join(REPO_ROOT, 'samples/factors/seed'), join(work, 'samples/factors/seed'));
    copy(join(REPO_ROOT, 'samples/offline'), join(work, 'samples/offline'));
    copy(join(REPO_ROOT, 'samples/agent-run'), join(work, 'samples/agent-run'));
    copy(join(REPO_ROOT, 'samples/sources'), join(work, 'samples/sources'));
    copy(join(REPO_ROOT, 'samples/workbook/Estimate_Template.xlsx'), join(work, 'samples/workbook/Estimate_Template.xlsx'));
    rmSync(join(work, 'samples/sources/synthetic-aem/.blueprint'), { recursive: true, force: true });

    // Docs, after everything they may link to is in place.
    const inPack = (path) => existsSync(join(work, path));
    for (const [from, to] of [...DOCS, [README_SOURCE, 'README.md']]) {
      mkdirSync(dirname(join(work, to)), { recursive: true });
      writeFileSync(join(work, to), rewriteDocLinks(readFileSync(join(REPO_ROOT, from), 'utf8'), from, to, inPack));
    }

    // Manifests.
    const estimating = catalogPins(readFileSync(join(REPO_ROOT, 'docs/catalogs/estimating-catalog.md'), 'utf8'));
    for (const field of ['estimatingVersion', 'cmkCommit', 'toolkitCommit']) {
      if (!estimating[field]) {
        throw new Error(`docs/catalogs/estimating-catalog.md has no ${field} in its front matter`);
      }
    }
    const cmkPin = JSON.parse(readFileSync(join(REPO_ROOT, 'tools/cmk-catalog.pin.json'), 'utf8'));
    const toolkitPin = JSON.parse(readFileSync(join(REPO_ROOT, 'tools/toolkit-catalog.pin.json'), 'utf8'));
    const packageJson = JSON.parse(readFileSync(join(REPO_ROOT, 'package.json'), 'utf8'));
    const git = gitState();
    const pack = {
      name: config.name,
      version: config.version,
      commit: git.dirty ? `${git.commit}-dirty` : git.commit,
      builtAt: now.toISOString(),
      appBuild: { package: packageJson.version },
      node: packageJson.engines && packageJson.engines.node,
      parseToolVersion: config.parseToolVersion,
      schemas: config.schemas,
      catalogs: {
        estimatingVersion: estimating.estimatingVersion,
        cmkCommit: cmkPin.commit,
        toolkitCommit: toolkitPin.commit,
        estimatingFrontMatter: { cmkCommit: estimating.cmkCommit, toolkitCommit: estimating.toolkitCommit }
      },
      skills: SKILLS,
      tools: { bundled: BUNDLED_TOOLS, copied: COPIED_TOOLS }
    };
    writeFileSync(join(work, 'pack.json'), `${JSON.stringify(pack, null, 2)}\n`);
    mkdirSync(join(work, '.claude-plugin'), { recursive: true });
    writeFileSync(join(work, '.claude-plugin/plugin.json'), `${JSON.stringify({
      name: config.name,
      version: config.version,
      description: 'Launch CMS Blueprint offline skill pack: parse, extract and map, enrich and validate a project folder without Azure or Foundry.',
      author: { name: 'Launch CMS Blueprint' }
    }, null, 2)}\n`);

    const findings = checkSkillPack(work, { allowDirty: options.allowDirty === true });
    if (findings.length) {
      throw new Error(`the pack is not releasable:\n${findings.join('\n')}`);
    }

    const files = listFiles(work);
    moveIntoPlace(work, dir);
    let zip;
    if (options.zip !== false) {
      const entries = {};
      for (const file of files) {
        entries[`${config.name}/${file}`] = [readFileSync(join(dir, file)), { mtime: now }];
      }
      entries[`${config.name}/.pack-version`] = [strToU8(`${config.version}\n`), { mtime: now }];
      zip = join(outRoot, `${config.name}-${config.version}.zip`);
      writeFileSync(zip, zipSync(entries, { level: 6 }));
    }
    return { dir, zip, pack, files, warnings };
  } catch (error) {
    rmSync(work, { recursive: true, force: true });
    throw error;
  }
}

function parseArgs(argv) {
  const out = { zip: true, allowDirty: false };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === '--out' && argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) {
      out.out = argv[++i];
    } else if (argv[i] === '--no-zip') {
      out.zip = false;
    } else if (argv[i] === '--allow-dirty') {
      out.allowDirty = true;
    } else {
      return undefined;
    }
  }
  return out;
}

if (process.argv[1] && basename(process.argv[1]) === 'build-skill-pack.mjs' && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const args = parseArgs(process.argv.slice(2));
  if (!args) {
    console.error('Usage: node tools/release/build-skill-pack.mjs [--out <dir>] [--no-zip] [--allow-dirty]');
    process.exit(2);
  }
  try {
    const result = buildSkillPack(args);
    result.warnings.forEach((line) => console.error(`warning: ${line}`));
    console.log(`wrote ${result.dir} (${result.files.length} files)`);
    if (result.zip) {
      console.log(`wrote ${result.zip}`);
    }
    console.log(`pack ${result.pack.version} at ${result.pack.commit}, catalogs v${result.pack.catalogs.estimatingVersion}, CMK ${String(result.pack.catalogs.cmkCommit).slice(0, 7)}, toolkit ${String(result.pack.catalogs.toolkitCommit).slice(0, 7)}`);
  } catch (error) {
    console.error(`build-skill-pack: ${error.message}`);
    process.exit(1);
  }
}
