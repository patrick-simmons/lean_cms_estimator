#!/usr/bin/env node
/**
 * Checks a built skill pack for anything that only works inside this repository (SAPP-015):
 *
 *   - pack.json: present, valid JSON, every required field and nested pin (schemas, catalogs.estimatingVersion,
 *     cmkCommit, toolkitCommit) filled, and a commit that is a real clean one (not `unknown`, not `-dirty`)
 *     unless `--allow-dirty` says a local build is fine
 *   - every file the pack layout requires is there (skills, tools, templates, docs, catalogs, seeds)
 *   - a skill that names a repo path (`docs/`, `samples/`, `tools/`, `function/`, `src/`, `.cdk/`, `../`, `./tools/`)
 *     without the `$BLUEPRINT_PACK/` prefix, or any `.cdk/` reference at all
 *   - a skill that names a `$BLUEPRINT_PACK/...` path the pack does not carry
 *   - a tool whose relative import (`from`, bare `import`, dynamic `import()`) does not resolve inside the
 *     pack, or that imports `function/`
 *   - a shipped doc whose relative markdown link points outside the pack or at a file it lacks
 *   - a shipped test file or node_modules folder
 *
 * Usage: node tools/release/check-skill-pack.mjs <pack-dir> [--allow-dirty]
 * Exit 0 when clean; 1 with one line per finding otherwise; 2 on a bad command line.
 */
import { existsSync, readFileSync } from 'node:fs';
import { basename, dirname, join, posix, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { listFiles, requiredPackFiles } from './pack-layout.mjs';

const REPO_DIRS = '(?:docs|samples|tools|function|src|\\.claude|\\.cdk)';
const REPO_PATH = new RegExp(`(^|[^\\w$/.\\\\-])(${REPO_DIRS}/[\\w.-][\\w./-]*|\\.\\./[\\w.-][\\w./-]*)`, 'g');
/** `./tools/...` is a repo path too: the leading `./` hides it from REPO_PATH, whose lookbehind skips a path after `/`. */
const DOT_REPO_PATH = new RegExp(`(^|[^\\w$/.\\\\-])(\\./${REPO_DIRS}/[\\w.-][\\w./-]*)`, 'g');
const PACK_PREFIX = /\$BLUEPRINT_PACK\/$/;
const PACK_REFERENCE = /\$BLUEPRINT_PACK\/(\w[\w./-]*[\w/])/g;
const IMPORT = /\b(?:from|import)\s*\(?\s*['"](\.{1,2}\/[^'"]+)['"]/g;
const FUNCTION_IMPORT = /\b(?:from|import)\s*\(?\s*['"][^'"]*function\/dist/;
const MARKDOWN_LINK = /\[[^\]]*\]\(([^)\s]+)\)/g;
const REQUIRED_PACK_FIELDS = ['name', 'version', 'commit', 'builtAt', 'schemas', 'catalogs', 'parseToolVersion'];
const REQUIRED_CATALOG_FIELDS = ['estimatingVersion', 'cmkCommit', 'toolkitCommit'];

/** Findings for one skill file: repo paths that are not anchored on the pack. */
export function checkSkillText(text, name) {
  const findings = [];
  const lines = text.split(/\r?\n/);
  lines.forEach((line, index) => {
    if (line.includes('.cdk/')) {
      findings.push(`${name}:${index + 1}: refers to .cdk/ (a working-notes folder): ${line.trim()}`);
    }
    for (const pattern of [REPO_PATH, DOT_REPO_PATH]) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(line)) !== null) {
        const before = line.slice(0, match.index + match[1].length);
        if (PACK_PREFIX.test(before)) {
          continue;
        }
        findings.push(`${name}:${index + 1}: path "${match[2]}" is not anchored on $BLUEPRINT_PACK: ${line.trim()}`);
      }
    }
  });
  return findings;
}

/** Findings for one skill file: `$BLUEPRINT_PACK/...` paths that the pack does not carry. */
export function checkPackReferences(text, name, packDir) {
  const findings = [];
  text.split(/\r?\n/).forEach((line, index) => {
    PACK_REFERENCE.lastIndex = 0;
    let match;
    while ((match = PACK_REFERENCE.exec(line)) !== null) {
      if (!existsSync(join(packDir, match[1]))) {
        findings.push(`${name}:${index + 1}: refers to $BLUEPRINT_PACK/${match[1]}, which the pack does not carry`);
      }
    }
  });
  return findings;
}

/** Findings for one tool file: imports that leave the pack or do not exist. */
export function checkToolImports(file, packDir) {
  const findings = [];
  const text = readFileSync(file, 'utf8');
  let match;
  IMPORT.lastIndex = 0;
  while ((match = IMPORT.exec(text)) !== null) {
    const spec = match[1];
    const target = resolve(dirname(file), spec);
    const rel = relative(packDir, target);
    if (rel.startsWith('..')) {
      findings.push(`${relative(packDir, file)}: import "${spec}" leaves the pack`);
    } else if (!existsSync(target)) {
      findings.push(`${relative(packDir, file)}: import "${spec}" is not in the pack`);
    }
  }
  if (FUNCTION_IMPORT.test(text)) {
    findings.push(`${relative(packDir, file)}: imports function/dist, which the pack does not carry`);
  }
  return findings;
}

/** Findings for one shipped doc: relative markdown links that leave the pack or point at a missing file. */
export function checkDocLinks(text, name, packDir) {
  const findings = [];
  const docDir = posix.dirname(name);
  text.split(/\r?\n/).forEach((line, index) => {
    MARKDOWN_LINK.lastIndex = 0;
    let match;
    while ((match = MARKDOWN_LINK.exec(line)) !== null) {
      const target = match[1].split('#')[0];
      if (!target || /^[a-z][a-z0-9+.-]*:/i.test(target) || target.startsWith('/')) {
        continue;
      }
      const resolved = posix.normalize(posix.join(docDir, target));
      if (resolved.startsWith('..')) {
        findings.push(`${name}:${index + 1}: link "${target}" leaves the pack`);
      } else if (!existsSync(join(packDir, resolved))) {
        findings.push(`${name}:${index + 1}: link "${target}" points at a file the pack does not carry`);
      }
    }
  });
  return findings;
}

function isText(value) {
  return typeof value === 'string' && value.trim() !== '' && value !== 'undefined';
}

function checkPackJson(root, options) {
  const findings = [];
  const packJson = join(root, 'pack.json');
  if (!existsSync(packJson)) {
    return ['pack.json is missing'];
  }
  let pack;
  try {
    pack = JSON.parse(readFileSync(packJson, 'utf8'));
  } catch (error) {
    return [`pack.json is not valid JSON: ${error.message}`];
  }
  if (!pack || typeof pack !== 'object' || Array.isArray(pack)) {
    return ['pack.json is not a JSON object'];
  }
  for (const field of REQUIRED_PACK_FIELDS) {
    if (pack[field] === undefined || pack[field] === null || pack[field] === '') {
      findings.push(`pack.json: ${field} is missing`);
    }
  }
  if (pack.schemas !== undefined && (typeof pack.schemas !== 'object' || pack.schemas === null || Object.keys(pack.schemas).length === 0)) {
    findings.push('pack.json: schemas must list the schema versions');
  }
  if (pack.catalogs !== undefined) {
    for (const field of REQUIRED_CATALOG_FIELDS) {
      if (!pack.catalogs || !isText(pack.catalogs[field])) {
        findings.push(`pack.json: catalogs.${field} is missing`);
      }
    }
  }
  if (isText(pack.commit) && !options.allowDirty) {
    if (pack.commit === 'unknown') {
      findings.push('pack.json: commit is unknown (git was not available); build from a checkout, or pass --allow-dirty for a local build');
    } else if (pack.commit.endsWith('-dirty')) {
      findings.push(`pack.json: commit ${pack.commit} is from a working tree with uncommitted changes; commit first, or pass --allow-dirty for a local build`);
    }
  }
  return findings;
}

/**
 * @param {string} packDir
 * @param {{ allowDirty?: boolean }} [options]
 * @returns {string[]} one line per finding
 */
export function checkSkillPack(packDir, options = {}) {
  const root = resolve(packDir);
  if (!existsSync(root)) {
    return [`${root} does not exist`];
  }
  const findings = checkPackJson(root, options);
  for (const required of requiredPackFiles()) {
    if (!existsSync(join(root, required))) {
      findings.push(`${required} is missing`);
    }
  }
  for (const rel of listFiles(root)) {
    const file = join(root, rel);
    if (rel.startsWith('skills/') && rel.endsWith('.md')) {
      const text = readFileSync(file, 'utf8');
      findings.push(...checkSkillText(text, rel), ...checkPackReferences(text, rel, root));
    }
    if (rel.startsWith('tools/') && rel.endsWith('.mjs')) {
      findings.push(...checkToolImports(file, root));
    }
    if (/^docs\/[^/]+\.md$/.test(rel)) {
      findings.push(...checkDocLinks(readFileSync(file, 'utf8'), rel, root));
    }
    if (rel.includes('node_modules/') || rel.endsWith('.test.mjs')) {
      findings.push(`${rel}: should not be shipped`);
    }
  }
  return findings;
}

if (process.argv[1] && basename(process.argv[1]) === 'check-skill-pack.mjs' && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const args = process.argv.slice(2);
  const allowDirty = args.includes('--allow-dirty');
  const rest = args.filter((arg) => arg !== '--allow-dirty');
  if (rest.length !== 1 || rest[0].startsWith('--')) {
    console.error('Usage: node tools/release/check-skill-pack.mjs <pack-dir> [--allow-dirty]');
    process.exit(2);
  }
  const findings = checkSkillPack(rest[0], { allowDirty });
  if (findings.length) {
    findings.forEach((line) => console.error(line));
    console.error(`${findings.length} finding(s)`);
    process.exit(1);
  }
  console.log(`OK: ${resolve(rest[0])} refers only to the pack and the project folder`);
}
