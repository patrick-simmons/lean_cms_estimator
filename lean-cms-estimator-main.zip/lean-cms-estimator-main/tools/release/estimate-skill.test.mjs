/**
 * The estimate skill is prose, so nothing else in the build can tell when it drifts from what the tools
 * do. These are the few promises in it that cost the estimator something when they quietly stop being
 * true: how many times the run stops to ask, where ownership may be changed, and the refusal to invent a
 * figure. Story B-18.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const SKILL = readFileSync(fileURLToPath(new URL('../../.claude/skills/estimate/SKILL.md', import.meta.url)), 'utf8');

/** The body of each `### n. ...` step, keyed by its heading. */
function steps() {
  const found = new Map();
  const headings = [...SKILL.matchAll(/^### (\d+)\. (.+)$/gm)];
  headings.forEach((heading, index) => {
    const start = heading.index + heading[0].length;
    const end = index + 1 < headings.length ? headings[index + 1].index : SKILL.length;
    found.set(heading[2], SKILL.slice(start, end));
  });
  return found;
}

test('the run still stops at exactly four checkpoints, numbered in order', () => {
  const labelled = [...SKILL.matchAll(/^### \d+\. Checkpoint (\d+):/gm)].map((match) => Number(match[1]));
  assert.deepEqual(labelled, [1, 2, 3, 4], 'a fifth checkpoint means the estimator is doing the agent\'s work');
  assert.match(SKILL, /^description:.*four checkpoints/m, 'the description promises the same count');
  assert.match(SKILL, /Keep to the four checkpoints/, 'and the guardrails hold it');
});

test('ownership is offered at checkpoints 2 and 3, and nowhere else', () => {
  // Checkpoint 2 carries the command; checkpoint 3 offers the change and points back at it.
  const offers = [...steps()].filter(([, body]) => /plan\.mjs owner/.test(body)).map(([heading]) => heading);
  assert.deepEqual(offers, ['Checkpoint 2: only when needed', 'Checkpoint 3: the client questions']);
});

test('a band is shown, never asked', () => {
  const checkpoint3 = steps().get('Checkpoint 3: the client questions');
  assert.match(checkpoint3, /Complexity bands/, 'the band and its deciding signal are read out at checkpoint 3');
  assert.match(checkpoint3, /never a question to the estimator/);
  // A challenge is a statement to overturn. Turning it into a question is how a fifth checkpoint starts.
  assert.match(checkpoint3, /Challenge.*for the estimator, not the client/s);
});

test('scope caps are offered once, at checkpoint 3, and never set by the agent', () => {
  const offers = [...steps()].filter(([, body]) => /plan\.mjs assume/.test(body)).map(([heading]) => heading);
  assert.deepEqual(offers, ['Checkpoint 3: the client questions'], 'one question at one checkpoint, not a fifth');
  const checkpoint3 = steps().get('Checkpoint 3: the client questions');
  assert.match(checkpoint3, /as one question and not one per activity/);
  assert.match(SKILL.slice(SKILL.indexOf('## Guardrails')), /Do not set a scope cap on your own judgement/);
});

test('the guardrails still refuse to invent a volume, an hour or a band', () => {
  const guardrails = SKILL.slice(SKILL.indexOf('## Guardrails'));
  for (const invented of ['volume', 'hour', 'band', 'rate']) {
    assert.match(guardrails, new RegExp(`Do not invent[^.]*\\b${invented}`), `the agent may not invent a ${invented}`);
  }
});

test('the estimate step describes the rate ladder the tools actually use', () => {
  const estimate = steps().get('Estimate');
  for (const rung of ['cases', 'cases-adjusted', 'derived']) {
    assert.ok(estimate.includes(`\`${rung}\``), `rung ${rung} is named`);
  }
  assert.match(estimate, /low, likely and high/i, 'three-point is described');
  assert.match(estimate, /Likely is the number/, 'and likely is the one to lead with');
  // The seed's factor columns and the flat overhead placeholder are both gone (B-09, B-10, B-15).
  assert.doesNotMatch(estimate, /factors' explicit columns|ai saving percent/);
  assert.match(estimate, /\*\*shares\*\* of the activities they cover/, 'overhead is a share, not a placeholder');
});
