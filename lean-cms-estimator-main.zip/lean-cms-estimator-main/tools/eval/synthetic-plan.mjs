#!/usr/bin/env node
/**
 * Builds the synthetic plan file the stage 3 back-test runs on: the committed extract and design sketch of the
 * Fabrikam sample, assembled, accepted (all, via bulk) and estimated with the real plan tool functions, at a
 * fixed time so the file is the same every run. A test checks the committed copy against this.
 *
 * Usage: node tools/eval/synthetic-plan.mjs [out-file]   (default samples/eval/synthetic-aem-plan.json)
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { acceptRequirements, assemblePlan, estimatePlan } from '../blueprint/plan.mjs';
import { DEFAULT_CATALOG, parseActivities } from '../blueprint/rank-questions.mjs';
import { loadModelInputs } from '../blueprint/estimate-model.mjs';
import { writeFileAtomic } from '../blueprint/write-file-atomic.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const SYNTHETIC_PLAN_FILE = path.join(root, 'samples', 'eval', 'synthetic-aem-plan.json');
const FIXED_TIME = '2026-11-13T12:00:00.000Z';

function readJson(...parts) {
  return JSON.parse(fs.readFileSync(path.join(root, ...parts), 'utf8'));
}

export function buildSyntheticPlan() {
  const catalogMd = fs.readFileSync(DEFAULT_CATALOG, 'utf8');
  const workPackages = parseActivities(catalogMd);
  const { plan } = assemblePlan({
    extract: readJson('tools', 'samples', 'agent-run', 'extract-first.json'),
    blocks: readJson('samples', 'agent-run', '.blueprint', 'parsed', 'blocks.json'),
    parsedSources: readJson('samples', 'agent-run', '.blueprint', 'parsed', 'sources.json'),
    sketch: readJson('samples', 'eval', 'synthetic-aem-design-sketch.json'),
    catalogMd,
    projectName: 'Fabrikam Outdoor',
    now: FIXED_TIME
  });
  acceptRequirements(plan, { all: true, via: 'bulk', now: FIXED_TIME });
  estimatePlan(plan, loadModelInputs(), { workPackages, now: FIXED_TIME });
  return plan;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const out = path.resolve(process.argv[2] || SYNTHETIC_PLAN_FILE);
  writeFileAtomic(out, `${JSON.stringify(buildSyntheticPlan(), null, 2)}\n`);
  console.log(`wrote ${out}`);
}
