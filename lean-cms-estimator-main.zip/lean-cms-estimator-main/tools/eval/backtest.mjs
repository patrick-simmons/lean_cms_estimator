#!/usr/bin/env node
/**
 * Back-test: compare what the agent produced for a project with a reference taken from a past estimate.
 *
 * It answers the questions a person otherwise answers by eye: which requirements the past estimate had
 * that the run missed, whether the requirements landed in the same work package, and how far the sizing
 * quantities and hours are from the past figures. It judges nothing about wording and never calls a model.
 * The same numbers, recorded as a baseline, tell us whether a later change to a skill helped.
 *
 * Usage:
 *   node tools/eval/backtest.mjs <Project>_Blueprint.json --reference reference.json [--sketch design-sketch.json]
 *        [--second second-sketch.json]
 *        [--baseline metrics.json] [--record metrics.json] [--fail-on-regress] [--json]
 *   node tools/eval/backtest.mjs --suite suite.json [same options]
 *
 * A reference file and a suite manifest are described in docs/standalone/agent-backtest.md. Real references
 * hold client facts: keep them outside this repository (see `eval-private/` in .gitignore).
 *
 * Exit 0 on success. Exit 1 when a file cannot be read or is invalid, or with --fail-on-regress when a
 * metric is worse than the baseline by more than the tolerance. Exit 2 on bad usage.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractedQuantities, statedQuantity } from '../blueprint/driver-quantity.mjs';
import { writeFileAtomic } from '../blueprint/write-file-atomic.mjs';

export const REFERENCE_SCHEMA_VERSION = '1';
export const METRICS_SCHEMA_VERSION = '1';

/** How much worse than the baseline a metric may get before --fail-on-regress fails. */
export const TOLERANCE = 0.02;

const WP_ID = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;

// The quantity rule is the one the web part's Build uses, shared with the pack tools.
export { extractedQuantities, statedQuantity as extractDriverQuantity };

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function normalize(text) {
  return String(text || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

/** Field-path errors for a reference file; an empty list means it can be used. */
export function validateReference(value) {
  const errors = [];
  if (!isObject(value)) {
    return ['(root): expected an object'];
  }
  if (value.schemaVersion !== REFERENCE_SCHEMA_VERSION) {
    errors.push(`schemaVersion: expected "${REFERENCE_SCHEMA_VERSION}"`);
  }
  if (typeof value.name !== 'string' || value.name.trim() === '') {
    errors.push('name: expected non-empty text');
  }
  // A figure of zero cannot be a denominator, so it would drop out of the error metrics without a word.
  if (value.totalHours !== undefined && !(Number.isFinite(value.totalHours) && value.totalHours > 0)) {
    errors.push('totalHours: expected a number above zero');
  }
  if (value.workPackages !== undefined) {
    if (!isObject(value.workPackages)) {
      errors.push('workPackages: expected an object keyed by activity id');
    } else {
      for (const [id, entry] of Object.entries(value.workPackages)) {
        if (!WP_ID.test(id)) {
          errors.push(`workPackages.${id}: expected a key such as content-migration`);
        }
        if (!isObject(entry)) {
          errors.push(`workPackages.${id}: expected an object`);
          continue;
        }
        for (const field of ['quantity', 'hours']) {
          if (entry[field] !== undefined && !(Number.isFinite(entry[field]) && entry[field] > 0)) {
            errors.push(`workPackages.${id}.${field}: expected a number above zero`);
          }
        }
      }
    }
  }
  if (value.requirements !== undefined) {
    if (!Array.isArray(value.requirements)) {
      errors.push('requirements: expected an array');
    } else {
      const seen = new Set();
      value.requirements.forEach((entry, index) => {
        const where = `requirements[${index}]`;
        if (!isObject(entry)) {
          errors.push(`${where}: expected an object`);
          return;
        }
        if (typeof entry.id !== 'string' || entry.id.trim() === '') {
          errors.push(`${where}.id: expected non-empty text`);
        } else if (seen.has(entry.id)) {
          errors.push(`${where}.id: "${entry.id}" is used twice`);
        } else {
          seen.add(entry.id);
        }
        if (typeof entry.text !== 'string' || entry.text.trim() === '') {
          errors.push(`${where}.text: expected non-empty text`);
        }
        if (!Array.isArray(entry.match) || entry.match.length === 0 || entry.match.some((term) => typeof term !== 'string' || term.trim() === '')) {
          errors.push(`${where}.match: expected a non-empty list of terms that all appear in the matching requirement`);
        }
        if (entry.workPackage !== undefined && !WP_ID.test(entry.workPackage)) {
          errors.push(`${where}.workPackage: expected an activity id such as content-migration`);
        }
      });
    }
  }
  if (value.workPackages === undefined && value.requirements === undefined && value.totalHours === undefined) {
    errors.push('(root): expected at least one of workPackages, requirements or totalHours');
  }
  return errors;
}

function liveRequirements(working) {
  return (Array.isArray(working.requirements) ? working.requirements : [])
    .filter((row) => isObject(row) && typeof row.statement === 'string')
    .filter((row) => !(row.review && row.review.status === 'dismissed'));
}

/** A finite number, or undefined. A missing or non-numeric figure stays missing; it is never read as zero. */
function figure(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}

/**
 * Quantity and hours per work package from a plan file's workstreams (stage 3), if it has them. The quantity is
 * the volume the estimate used, placeholder or not: a placeholder that is far from the past estimate is an
 * error of the estimate, and the report says which packages rest on one. Hours are the traditional hours,
 * which is what a past estimate holds; the total includes the overhead workstreams.
 */
function workstreamFigures(working) {
  const workstreams = Array.isArray(working.workstreams) ? working.workstreams.filter(isObject) : [];
  if (workstreams.length === 0) {
    return undefined;
  }
  const packages = {};
  const placeholders = [];
  let totalHours = 0;
  for (const row of workstreams) {
    totalHours += figure(row.traditionalHours) || 0;
    if (row.kind === 'delivery' && typeof row.id === 'string') {
      packages[row.id] = { quantity: figure(row.volume), hours: figure(row.traditionalHours) };
      if (row.volumeBasis === 'placeholder') {
        placeholders.push(row.id);
      }
    }
  }
  return { packages, totalHours: Math.round(totalHours * 100) / 100, source: 'workstreams', placeholders };
}

/** The rungs of the rate ladder, best evidence first. A workstream's `rateBasis` names one of them. */
const RUNGS = ['cases', 'cases-adjusted', 'derived'];

/**
 * How many of a plan's workstreams sit on each rung of the rate ladder, and the share each rung holds.
 * This is what stage B was for: a rate on rung 1 is three or more past projects, and a rate on rung 3 is
 * nobody's evidence at all. Undefined for a Blueprint with no workstreams, which has no rates to report.
 */
function rungFigures(working) {
  const workstreams = Array.isArray(working.workstreams) ? working.workstreams.filter(isObject) : [];
  const rated = workstreams.filter((row) => RUNGS.indexOf(row.rateBasis) !== -1);
  if (rated.length === 0) {
    return undefined;
  }
  const counts = {};
  const shares = {};
  for (const rung of RUNGS) {
    counts[rung] = rated.filter((row) => row.rateBasis === rung).length;
    shares[rung] = round(counts[rung] / rated.length);
  }
  return { counts, shares, rated: rated.length, unrated: workstreams.length - rated.length };
}

/** Quantity and hours per work package from the estimate the app saved on the Blueprint, if it has one. */
function estimateFigures(working, warnings) {
  const estimate = working.estimate;
  if (!isObject(estimate) || !Array.isArray(estimate.packages)) {
    return workstreamFigures(working);
  }
  const packages = {};
  for (const entry of estimate.packages) {
    if (isObject(entry) && typeof entry.workPackageId === 'string') {
      packages[entry.workPackageId] = { quantity: figure(entry.quantity), hours: figure(entry.hours) };
      if (packages[entry.workPackageId].quantity === undefined || packages[entry.workPackageId].hours === undefined) {
        warnings.push(`the estimate has no usable quantity or hours for ${entry.workPackageId}`);
      }
    }
  }
  const totalHours = figure(estimate.totalHours);
  if (totalHours === undefined) {
    warnings.push('the estimate has no usable totalHours');
  }
  return { packages, totalHours };
}

/** Quantity per work package from a design sketch file (`drivers[]`), when one is given. */
function sketchQuantities(sketch) {
  const byPackage = {};
  const drivers = isObject(sketch) && Array.isArray(sketch.drivers) ? sketch.drivers : [];
  for (const driver of drivers) {
    const dismissed = isObject(driver) && isObject(driver.review) && driver.review.status === 'dismissed';
    if (isObject(driver) && !dismissed && typeof driver.workPackageId === 'string' && Number.isFinite(driver.quantity)) {
      byPackage[driver.workPackageId] = driver.quantity;
    }
  }
  return byPackage;
}

function ratio(top, bottom) {
  return bottom === 0 ? undefined : top / bottom;
}

function round(value) {
  return value === undefined ? undefined : Math.round(value * 1000) / 1000;
}

function mean(values) {
  return values.length === 0 ? undefined : values.reduce((sum, value) => sum + value, 0) / values.length;
}

/**
 * Compare one Blueprint with one reference. `options.sketch` swaps the quantities for a design sketch's.
 * Returns `{ name, metrics, details }`. A metric is undefined when the reference gives nothing to compare.
 */
export function compareToReference(working, reference, options = {}) {
  const rows = liveRequirements(working);
  const statements = rows.map((row) => normalize(row.statement));

  const refs = Array.isArray(reference.requirements) ? reference.requirements : [];
  const matched = [];
  const missed = [];
  const matchedRows = new Set();
  let agree = 0;
  let withPackage = 0;
  for (const ref of refs) {
    const terms = ref.match.map(normalize);
    const hits = [];
    statements.forEach((statement, index) => {
      if (terms.every((term) => statement.indexOf(term) !== -1)) {
        hits.push(index);
      }
    });
    if (hits.length === 0) {
      missed.push({ id: ref.id, text: ref.text, workPackage: ref.workPackage });
      continue;
    }
    hits.forEach((index) => matchedRows.add(index));
    const found = hits.map((index) => rows[index]);
    const entry = { id: ref.id, rows: found.map((row) => row.id), workPackage: ref.workPackage };
    if (ref.workPackage) {
      withPackage += 1;
      const same = found.some((row) => row.workPackage === ref.workPackage);
      if (same) {
        agree += 1;
      } else {
        entry.mappedTo = found.map((row) => row.workPackage);
      }
    }
    matched.push(entry);
  }
  const extras = rows.filter((_, index) => !matchedRows.has(index)).map((row) => ({ id: row.id, workPackage: row.workPackage, statement: row.statement }));

  const warnings = [];
  const rungs = rungFigures(working);
  const figures = estimateFigures(working, warnings);
  const sketch = options.sketch === undefined ? undefined : sketchQuantities(options.sketch);
  let quantitySource = 'extracted';
  let quantities = extractedQuantities(rows);
  if (sketch !== undefined) {
    quantitySource = 'sketch';
    quantities = sketch;
  } else if (figures) {
    quantitySource = figures.source || 'estimate';
    quantities = Object.fromEntries(
      Object.entries(figures.packages).filter(([, entry]) => entry.quantity !== undefined).map(([id, entry]) => [id, entry.quantity])
    );
  }
  if (options.secondSketch !== undefined && sketch === undefined) {
    warnings.push(`the second read is compared with quantities from ${quantitySource}, not from a design sketch (give --sketch for a like-for-like comparison)`);
  }

  const packages = [];
  const quantityErrors = [];
  const hoursErrors = [];
  for (const [id, ref] of Object.entries(reference.workPackages || {})) {
    const agentQuantity = quantities[id] === undefined ? 0 : quantities[id];
    const agentHours = figures && figures.packages[id] ? figures.packages[id].hours : undefined;
    const row = { workPackage: id, requirements: rows.filter((item) => item.workPackage === id).length };
    if (figures && Array.isArray(figures.placeholders) && figures.placeholders.indexOf(id) !== -1) {
      row.placeholderVolume = true;
    }
    // One rule for both: a package the agent did not size is a full miss (error 1), not a gap in the mean.
    // The reference holds figures above zero (validateReference), so the ratio always exists.
    if (ref.quantity !== undefined) {
      row.quantity = { reference: ref.quantity, agent: agentQuantity };
      const error = ratio(Math.abs(agentQuantity - ref.quantity), ref.quantity);
      row.quantity.error = round(error);
      quantityErrors.push(Math.min(error, 1));
    }
    if (ref.hours !== undefined && figures) {
      row.hours = { reference: ref.hours, agent: agentHours };
      const missing = figures.packages[id] === undefined;
      if (missing || agentHours !== undefined) {
        const error = missing ? 1 : ratio(Math.abs(agentHours - ref.hours), ref.hours);
        row.hours.error = round(error);
        hoursErrors.push(Math.min(error, 1));
      }
    } else if (ref.hours !== undefined) {
      row.hours = { reference: ref.hours, agent: undefined };
    }
    packages.push(row);
  }

  // The blind second read, when there is one: its own quantity error, and which read was closer where they differ.
  let secondQuantityError;
  const disagreements = [];
  if (options.secondSketch !== undefined) {
    const second = sketchQuantities(options.secondSketch);
    const secondErrors = [];
    for (const [id, ref] of Object.entries(reference.workPackages || {})) {
      if (ref.quantity !== undefined) {
        const error = ratio(Math.abs((second[id] === undefined ? 0 : second[id]) - ref.quantity), ref.quantity);
        secondErrors.push(Math.min(error, 1));
      }
    }
    secondQuantityError = round(mean(secondErrors));
    for (const id of Object.keys(second).sort()) {
      if (quantities[id] !== undefined && quantities[id] !== second[id]) {
        const ref = (reference.workPackages || {})[id];
        const target = ref && ref.quantity !== undefined ? ref.quantity : undefined;
        let closer;
        if (target !== undefined) {
          const firstGap = Math.abs(quantities[id] - target);
          const secondGap = Math.abs(second[id] - target);
          closer = firstGap === secondGap ? 'tie' : firstGap < secondGap ? 'first' : 'second';
        }
        disagreements.push({ workPackage: id, first: quantities[id], second: second[id], reference: target, closer });
      }
    }
  }

  const totalReference = reference.totalHours;
  const totalAgent = figures ? figures.totalHours : undefined;
  const totalError = totalReference !== undefined && totalAgent !== undefined
    ? (totalAgent - totalReference) / totalReference
    : undefined;

  const metrics = {
    requirementRecall: round(ratio(matched.length, refs.length)),
    workPackageAgreement: round(ratio(agree, withPackage)),
    // Measured against the run's own requirements, not the reference: it asks whether the catalog
    // gave the extraction somewhere to put each requirement, which is a question about the catalog
    // and the prompt rather than about how well this run matched a past estimate.
    unmappedShare: rows.length === 0 ? undefined : round(ratio(rows.filter((row) => row.workPackage === 'unmapped').length, rows.length)),
    rowPrecisionProxy: refs.length === 0 ? undefined : round(ratio(matchedRows.size, rows.length)),
    quantityError: round(mean(quantityErrors)),
    secondQuantityError,
    hoursError: round(mean(hoursErrors)),
    totalHoursError: round(totalError),
    // Two of the three rungs, because the three shares add to 1 and the middle rung has no direction:
    // a rate that moves from derived to cases-adjusted improved, one that moves from cases did not.
    casesShare: rungs && rungs.shares.cases,
    derivedShare: rungs && rungs.shares.derived
  };

  return {
    name: reference.name,
    metrics,
    details: {
      liveRequirements: rows.length,
      unmapped: rows.filter((row) => row.workPackage === 'unmapped').length,
      quantitySource,
      rungs,
      matched,
      missed,
      extras,
      packages,
      disagreements,
      warnings,
      totalHours: totalReference === undefined && totalAgent === undefined ? undefined : { reference: totalReference, agent: totalAgent }
    }
  };
}

const METRIC_ORDER = ['requirementRecall', 'workPackageAgreement', 'unmappedShare', 'rowPrecisionProxy', 'quantityError', 'secondQuantityError', 'hoursError', 'totalHoursError', 'casesShare', 'derivedShare'];

/** Whether a larger value of the metric is better. The error metrics are better when closer to zero. */
export const HIGHER_IS_BETTER = {
  requirementRecall: true,
  workPackageAgreement: true,
  unmappedShare: false,
  rowPrecisionProxy: true,
  quantityError: false,
  secondQuantityError: false,
  hoursError: false,
  totalHoursError: false,
  casesShare: true,
  derivedShare: false
};

/** The mean of each metric over the cases that have it. totalHoursError is compared by its size, not its sign. */
export function aggregateMetrics(results) {
  const out = {};
  for (const key of METRIC_ORDER) {
    const values = results
      .map((result) => result.metrics[key])
      .filter((value) => value !== undefined)
      .map((value) => (key === 'totalHoursError' ? Math.abs(value) : value));
    out[key] = round(mean(values));
  }
  return out;
}

/** Per metric: baseline, now, change, and whether it improved, stayed, or got worse beyond the tolerance. */
export function compareMetrics(baseline, now, options = {}) {
  const incomparable = new Set(options.incomparable || []);
  return METRIC_ORDER.map((key) => {
    const before = baseline[key];
    const after = now[key];
    if (incomparable.has(key)) {
      return { metric: key, baseline: before, now: after, verdict: 'not comparable', reason: 'the quantities come from a different source than the baseline' };
    }
    if (before !== undefined && after === undefined) {
      // The baseline had a figure and this run has none: the run lost something, which is a regression.
      return { metric: key, baseline: before, now: after, verdict: 'worse', reason: 'this run has no figure for it' };
    }
    if (before === undefined || after === undefined) {
      return { metric: key, baseline: before, now: after, verdict: 'not comparable' };
    }
    const change = round(after - before);
    const better = HIGHER_IS_BETTER[key] ? change : -change;
    let verdict = 'same';
    if (better > TOLERANCE) {
      verdict = 'better';
    } else if (better < -TOLERANCE) {
      verdict = 'worse';
    }
    return { metric: key, baseline: before, now: after, change, verdict };
  });
}

function percent(value) {
  return value === undefined ? 'n/a' : `${Math.round(value * 1000) / 10}%`;
}

function caseText(result) {
  const lines = [`Case: ${result.name}`];
  const m = result.metrics;
  lines.push(`  requirement recall      ${percent(m.requirementRecall)}   (${result.details.matched.length} found, ${result.details.missed.length} missed)`);
  lines.push(`  work package agreement  ${percent(m.workPackageAgreement)}`);
  lines.push(`  unmapped                ${percent(m.unmappedShare)}   (${result.details.unmapped} of ${result.details.liveRequirements} rows found no activity)`);
  lines.push(`  rows the reference backs ${percent(m.rowPrecisionProxy)}   (a floor: a reference is never complete; ${result.details.extras.length} of ${result.details.liveRequirements} rows have no match)`);
  lines.push(`  quantity error          ${percent(m.quantityError)}   (quantities from ${result.details.quantitySource})`);
  if (m.secondQuantityError !== undefined) {
    lines.push(`  second read quantity error ${percent(m.secondQuantityError)}`);
  }
  lines.push(`  hours error             ${percent(m.hoursError)}`);
  lines.push(`  total hours error       ${percent(m.totalHoursError)}`);
  if (result.details.rungs) {
    const { counts, shares, rated, unrated } = result.details.rungs;
    lines.push(`  rate ladder             ${RUNGS.map((rung) => `${rung} ${percent(shares[rung])} (${counts[rung]})`).join(', ')}   of ${rated} rated${unrated ? `, ${unrated} with no rung` : ''}`);
  }
  for (const message of result.details.warnings || []) {
    lines.push(`  warning: ${message}`);
  }
  for (const item of result.details.disagreements) {
    const reference = item.reference === undefined ? 'no reference figure' : `reference ${item.reference}, ${item.closer} read closer`;
    lines.push(`  reads differ ${item.workPackage}: first ${item.first}, second ${item.second} (${reference})`);
  }
  for (const item of result.details.missed) {
    lines.push(`  missed ${item.id}${item.workPackage ? ` (${item.workPackage})` : ''}: ${item.text}`);
  }
  for (const item of result.details.matched.filter((entry) => entry.mappedTo)) {
    lines.push(`  mapped differently ${item.id}: reference ${item.workPackage}, rows ${item.rows.join(', ')} are ${item.mappedTo.join(', ')}`);
  }
  for (const item of result.details.packages) {
    const parts = [];
    if (item.quantity) {
      parts.push(`quantity ${item.quantity.agent}${item.placeholderVolume ? ' (placeholder)' : ''} against ${item.quantity.reference}`);
    }
    if (item.hours) {
      parts.push(`hours ${item.hours.agent === undefined ? 'none' : item.hours.agent} against ${item.hours.reference}`);
    }
    lines.push(`  ${item.workPackage}: ${item.requirements} rows${parts.length ? '; ' + parts.join('; ') : ''}`);
  }
  return lines.join('\n');
}

export function formatReport(report) {
  const out = report.cases.map(caseText);
  if (report.cases.length > 1) {
    out.push(`Mean over ${report.cases.length} cases`);
    out.push(...METRIC_ORDER.map((key) => `  ${key.padEnd(24)}${percent(report.metrics[key])}`));
  }
  if (report.comparison) {
    out.push('Against the baseline');
    out.push(...report.comparison.map((row) => `  ${row.metric.padEnd(24)}${percent(row.baseline)} -> ${percent(row.now)}  ${row.verdict}`));
  }
  return out.join('\n\n');
}

function readJson(file, label) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    throw new Error(`${label} ${file}: ${error.message}`);
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new Error(`${label} ${file}: not JSON (${error.message})`);
  }
}

/** A sketch file with its shape checked: a wrong-shaped file would otherwise score as "no drivers". */
function readSketch(file, label) {
  const sketch = readJson(file, label);
  if (!isObject(sketch) || !Array.isArray(sketch.drivers)) {
    throw new Error(`${label} ${file}: expected an object with a drivers array`);
  }
  return sketch;
}

/** Runs one case from files. Paths in `spec` are used as given; the caller resolves them. */
export function runCase(spec) {
  const working = readJson(spec.blueprint, 'Blueprint');
  if (!isObject(working) || !Array.isArray(working.requirements)) {
    throw new Error(`Blueprint ${spec.blueprint}: expected an object with a requirements array`);
  }
  const reference = readJson(spec.reference, 'Reference');
  const errors = validateReference(reference);
  if (errors.length > 0) {
    throw new Error(`Reference ${spec.reference} is not valid:\n  ${errors.join('\n  ')}`);
  }
  const sketch = spec.sketch ? readSketch(spec.sketch, 'Design sketch') : undefined;
  const secondSketch = spec.secondSketch ? readSketch(spec.secondSketch, 'Second sketch') : undefined;
  return compareToReference(working, reference, { sketch, secondSketch });
}

/** The cases of a suite manifest, with paths resolved against the manifest's folder. */
export function readSuite(file) {
  const manifest = readJson(file, 'Suite');
  const folder = path.dirname(path.resolve(file));
  if (!isObject(manifest) || !Array.isArray(manifest.cases) || manifest.cases.length === 0) {
    throw new Error(`Suite ${file}: expected { "cases": [ ... ] } with at least one case`);
  }
  return manifest.cases.map((entry, index) => {
    if (!isObject(entry) || typeof entry.blueprint !== 'string' || typeof entry.reference !== 'string') {
      throw new Error(`Suite ${file}: cases[${index}] needs "blueprint" and "reference"`);
    }
    const resolve = (name) => path.resolve(folder, name);
    return {
      blueprint: resolve(entry.blueprint),
      reference: resolve(entry.reference),
      ...(typeof entry.sketch === 'string' ? { sketch: resolve(entry.sketch) } : {}),
      ...(typeof entry.secondSketch === 'string' ? { secondSketch: resolve(entry.secondSketch) } : {})
    };
  });
}

/** What --record writes: only the numbers, never a statement or a name from a client document. */
export function metricsRecord(report) {
  return {
    schemaVersion: METRICS_SCHEMA_VERSION,
    cases: report.cases.length,
    quantitySources: Array.from(new Set(report.cases.map((result) => result.details.quantitySource))).sort(),
    metrics: report.metrics,
    perCase: report.cases.map((result, index) => ({ case: index + 1, metrics: result.metrics }))
  };
}

const USAGE =
  'Usage: node tools/eval/backtest.mjs <Blueprint.json> --reference <reference.json> [--sketch <design-sketch.json>] [--second <second-sketch.json>] ' +
  '[--baseline <metrics.json>] [--record <metrics.json>] [--fail-on-regress] [--json]\n' +
  '       node tools/eval/backtest.mjs --suite <suite.json> [--baseline ...] [--record ...] [--fail-on-regress] [--json]';

function parseArgs(argv) {
  const options = { files: [] };
  const withValue = new Set(['--reference', '--sketch', '--second', '--suite', '--baseline', '--record']);
  const flags = new Set(['--fail-on-regress', '--json']);
  for (let index = 0; index < argv.length; index++) {
    const arg = argv[index];
    if (withValue.has(arg)) {
      if (index + 1 >= argv.length) {
        return { error: `${arg} needs a value` };
      }
      options[arg.slice(2)] = argv[++index];
    } else if (flags.has(arg)) {
      options[arg.slice(2)] = true;
    } else if (arg.startsWith('--')) {
      return { error: `Unknown option ${arg}` };
    } else {
      options.files.push(arg);
    }
  }
  if (options.suite) {
    if (options.files.length || options.reference || options.sketch || options.second) {
      return { error: '--suite takes no Blueprint, --reference, --sketch or --second' };
    }
  } else if (options.files.length !== 1 || !options.reference) {
    return { error: 'Give one Blueprint and --reference, or --suite' };
  }
  if (options['fail-on-regress'] && !options.baseline) {
    return { error: '--fail-on-regress needs --baseline: without one there is nothing to compare with' };
  }
  if (options.record && options.baseline && path.resolve(options.record) === path.resolve(options.baseline)) {
    return { error: '--record must not be the --baseline file: a regressed run would overwrite the baseline' };
  }
  return { options };
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (parsed.error) {
    console.error(parsed.error);
    console.error(USAGE);
    process.exit(2);
  }
  const { options } = parsed;
  let report;
  try {
    const specs = options.suite
      ? readSuite(path.resolve(options.suite))
      : [{ blueprint: path.resolve(options.files[0]), reference: path.resolve(options.reference), ...(options.sketch ? { sketch: path.resolve(options.sketch) } : {}), ...(options.second ? { secondSketch: path.resolve(options.second) } : {}) }];
    const cases = specs.map(runCase);
    report = { cases, metrics: cases.length === 1 ? cases[0].metrics : aggregateMetrics(cases) };
    if (cases.length === 1 && report.metrics.totalHoursError !== undefined) {
      report.metrics = { ...report.metrics, totalHoursError: Math.abs(report.metrics.totalHoursError) };
    }
    if (options.baseline) {
      const baseline = readJson(path.resolve(options.baseline), 'Baseline');
      if (!isObject(baseline) || !isObject(baseline.metrics)) {
        throw new Error(`Baseline ${options.baseline}: expected a file written by --record`);
      }
      // A baseline taken with quantities from another source (extracted, estimate, sketch) says nothing about this run's.
      const sources = Array.isArray(baseline.quantitySources) ? baseline.quantitySources.join(',') : undefined;
      const now = metricsRecord(report).quantitySources.join(',');
      const incomparable = sources !== undefined && sources !== now ? ['quantityError', 'secondQuantityError'] : [];
      report.comparison = compareMetrics(baseline.metrics, report.metrics, { incomparable });
    }
    for (const result of cases) {
      (result.details.warnings || []).forEach((message) => console.error(`warning: ${result.name}: ${message}`));
    }
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
  process.stdout.write(`${options.json ? JSON.stringify(report, null, 2) : formatReport(report)}\n`);
  const regressed = options['fail-on-regress'] && report.comparison.some((row) => row.verdict === 'worse');
  if (regressed) {
    // The record is not written: a failing run must not replace a good baseline.
    console.error('A metric is worse than the baseline.');
    process.exit(1);
  }
  if (options.record) {
    try {
      writeFileAtomic(path.resolve(options.record), `${JSON.stringify(metricsRecord(report), null, 2)}\n`);
    } catch (error) {
      console.error(`Cannot write ${path.resolve(options.record)}: ${error.message}`);
      process.exit(1);
    }
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
