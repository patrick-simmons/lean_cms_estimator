import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { buildSyntheticPlan, SYNTHETIC_PLAN_FILE } from './synthetic-plan.mjs';
import { compareToReference } from './backtest.mjs';
import { validatePlan } from '../blueprint/plan.mjs';
import { DEFAULT_CATALOG, parseActivities } from '../blueprint/rank-questions.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'eval', 'backtest.mjs');
const workPackages = parseActivities(fs.readFileSync(DEFAULT_CATALOG, 'utf8'));
const blocks = JSON.parse(fs.readFileSync(path.join(root, 'samples', 'agent-run', '.blueprint', 'parsed', 'blocks.json'), 'utf8'));
const reference = JSON.parse(fs.readFileSync(path.join(root, 'samples', 'eval', 'synthetic-aem-reference.json'), 'utf8'));

test('the committed synthetic plan is what the tools build from the committed extract and sketch', () => {
  const committed = JSON.parse(fs.readFileSync(SYNTHETIC_PLAN_FILE, 'utf8'));
  assert.deepEqual(committed, buildSyntheticPlan(), 'run: node tools/eval/synthetic-plan.mjs');
  assert.deepEqual(validatePlan(committed, { blocks, workPackages }), []);
  assert.ok(committed.workstreams.every((row) => row.traditionalHours > 0), 'no workstream at zero');
});

test('the back-test reads the quantities and hours of a plan file from its workstreams', () => {
  const result = compareToReference(buildSyntheticPlan(), reference);
  assert.equal(result.details.quantitySource, 'workstreams');
  const byPackage = Object.fromEntries(result.details.packages.map((item) => [item.workPackage, item]));
  assert.equal(byPackage['content-migration'].quantity.agent, 6400);
  assert.equal(byPackage['content-migration'].placeholderVolume, undefined);
  assert.equal(byPackage['discovery-audit'].quantity.agent, 5, 'the placeholder volume is what the estimate used');
  assert.equal(byPackage['discovery-audit'].placeholderVolume, true);
  assert.equal(byPackage['localization'].placeholderVolume, true);
});

test('the back-test compares hours and the total of a plan file with a reference that has them', () => {
  const plan = buildSyntheticPlan();
  const total = plan.workstreams.reduce((sum, row) => sum + row.traditionalHours, 0);
  const withHours = {
    ...reference,
    totalHours: total * 2,
    workPackages: { ...reference.workPackages, 'content-migration': { quantity: 6400, hours: 6400 } }
  };
  const { metrics, details } = compareToReference(plan, withHours);
  assert.equal(metrics.totalHoursError, -0.5);
  assert.equal(details.packages.find((item) => item.workPackage === 'content-migration').hours.agent, 12800);
  assert.equal(metrics.hoursError, 1, 'twice the reference hours is capped at a full miss');
});

test('the committed plan baseline matches: a change to the model that hurts a number shows up', () => {
  const run = spawnSync(
    process.execPath,
    [script, '--suite', path.join(root, 'samples', 'eval', 'suite-plan.json'), '--baseline', path.join(root, 'samples', 'eval', 'synthetic-plan-baseline.json'), '--fail-on-regress'],
    { encoding: 'utf8' }
  );
  assert.equal(run.status, 0, run.stdout + run.stderr);
  assert.match(run.stdout, /quantities from workstreams/);
});
