import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  aggregateMetrics,
  compareMetrics,
  compareToReference,
  extractDriverQuantity,
  extractedQuantities,
  formatReport,
  metricsRecord,
  readSuite,
  validateReference
} from './backtest.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'eval', 'backtest.mjs');

function row(id, workPackage, statement, status) {
  return { id, workPackage, statement, ...(status ? { review: { status } } : {}) };
}

function reference(extra = {}) {
  return {
    schemaVersion: '1',
    name: 'Case',
    requirements: [
      { id: 'REF-01', text: 'Migrate pages', workPackage: 'content-migration', match: ['migrate', 'pages'] },
      { id: 'REF-02', text: 'Search', workPackage: 'search', match: ['search'] },
      { id: 'REF-03', text: 'SSO', workPackage: 'integrations', match: ['single sign-on'] }
    ],
    ...extra
  };
}

test('the back-test reads a statement the way the web part does', () => {
  assert.equal(extractDriverQuantity('Migrate approximately 6,400 pages'), 6400);
  assert.deepEqual(
    extractedQuantities([row('R-1', 'integrations', 'Two systems, 3 feeds'), row('R-2', 'integrations', '4 APIs'), row('R-3', undefined, '9 things')]),
    { 'integrations': 7 }
  );
});

test('recall counts the reference items found and lists the missed ones', () => {
  const working = {
    requirements: [
      row('R-1', 'content-migration', 'Migrate the product pages'),
      row('R-2', 'search', 'Provide site search'),
      row('R-3', 'integrations', 'Single sign-on for authors', 'dismissed')
    ]
  };
  const result = compareToReference(working, reference());
  assert.equal(result.metrics.requirementRecall, 0.667);
  assert.deepEqual(result.details.missed.map((item) => item.id), ['REF-03']);
  assert.equal(result.metrics.workPackageAgreement, 1);
});

test('a reference item that the run mapped to another package lowers agreement', () => {
  const working = { requirements: [row('R-1', 'integrations', 'Migrate the pages'), row('R-2', 'search', 'Search')] };
  const result = compareToReference(working, reference());
  assert.equal(result.metrics.workPackageAgreement, 0.5);
  assert.deepEqual(result.details.matched[0].mappedTo, ['integrations']);
});

test('unmapped rows are a share of the run, counted whether or not the reference knows them', () => {
  const working = {
    requirements: [
      row('R-1', 'content-migration', 'Migrate the pages'),
      row('R-2', 'unmapped', 'Run a bake-off between two vendors'),
      row('R-3', 'unmapped', 'Sponsor the launch party'),
      row('R-4', 'search', 'Search')
    ]
  };
  const result = compareToReference(working, reference());
  assert.equal(result.metrics.unmappedShare, 0.5);
  assert.equal(result.details.unmapped, 2);
});

test('a run that maps everything has an unmapped share of zero, not n/a', () => {
  const working = { requirements: [row('R-1', 'content-migration', 'Migrate the pages')] };
  assert.equal(compareToReference(working, reference()).metrics.unmappedShare, 0);
});

test('rows with no reference match are listed as extras and give the precision floor', () => {
  const working = { requirements: [row('R-1', 'content-migration', 'Migrate the pages'), row('R-2', 'qa-automation', 'Page speed budget')] };
  const result = compareToReference(working, reference());
  assert.equal(result.metrics.rowPrecisionProxy, 0.5);
  assert.deepEqual(result.details.extras.map((item) => item.id), ['R-2']);
});

test('quantity error uses the extracted numbers when there is no estimate, and caps one package at 100%', () => {
  const working = { requirements: [row('R-1', 'content-migration', 'Migrate 5,000 pages'), row('R-2', 'localization', 'Four locales')] };
  const result = compareToReference(working, reference({ workPackages: { 'content-migration': { quantity: 6400 }, 'localization': { quantity: 4 } } }));
  assert.equal(result.details.quantitySource, 'extracted');
  assert.equal(result.metrics.quantityError, 0.609);
});

test('the saved estimate supplies quantity, hours and the total when the Blueprint has one', () => {
  const working = {
    requirements: [row('R-1', 'content-migration', 'Migrate pages')],
    estimate: { totalHours: 1100, packages: [{ workPackageId: 'content-migration', quantity: 800, hours: 1000 }] }
  };
  const result = compareToReference(
    working,
    reference({ totalHours: 1000, workPackages: { 'content-migration': { quantity: 1000, hours: 800 } } })
  );
  assert.equal(result.details.quantitySource, 'estimate');
  assert.equal(result.metrics.quantityError, 0.2);
  assert.equal(result.metrics.hoursError, 0.25);
  assert.equal(result.metrics.totalHoursError, 0.1);
});

test('a design sketch replaces the extracted quantities', () => {
  const working = { requirements: [row('R-1', 'localization', 'Four locales')] };
  const sketch = { drivers: [{ workPackageId: 'localization', quantity: 4 }] };
  const result = compareToReference(working, reference({ requirements: undefined, workPackages: { 'localization': { quantity: 4 } } }), { sketch });
  assert.equal(result.details.quantitySource, 'sketch');
  assert.equal(result.metrics.quantityError, 0);
});

test('a second read has its own quantity error, and the report says which read was closer where they differ', () => {
  const working = { requirements: [row('R-1', 'integrations', 'Integrate the systems')] };
  const refs = reference({ requirements: undefined, workPackages: { 'integrations': { quantity: 4 }, 'multisite': { quantity: 3 } } });
  const sketch = { drivers: [{ workPackageId: 'integrations', quantity: 4 }, { workPackageId: 'multisite', quantity: 2 }] };
  const secondSketch = { drivers: [{ workPackageId: 'integrations', quantity: 3 }, { workPackageId: 'multisite', quantity: 3 }] };
  const result = compareToReference(working, refs, { sketch, secondSketch });
  assert.equal(result.metrics.quantityError, 0.167);
  assert.equal(result.metrics.secondQuantityError, 0.125);
  assert.deepEqual(result.details.disagreements, [
    { workPackage: 'integrations', first: 4, second: 3, reference: 4, closer: 'first' },
    { workPackage: 'multisite', first: 2, second: 3, reference: 3, closer: 'second' }
  ]);
  assert.match(formatReport({ cases: [result], metrics: result.metrics }), /reads differ integrations: first 4, second 3 \(reference 4, first read closer\)/);
  assert.equal(compareToReference(working, refs, { sketch }).metrics.secondQuantityError, undefined);
});

test('the rate ladder is reported by rung, and the two rungs with a direction are metrics', () => {
  const working = {
    requirements: [row('R-1', 'content-migration', 'Migrate the pages')],
    workstreams: [
      { id: 'content-migration', rateBasis: 'cases' },
      { id: 'search', rateBasis: 'cases' },
      { id: 'seo', rateBasis: 'cases-adjusted' },
      { id: 'integrations', rateBasis: 'derived' }
    ]
  };
  const result = compareToReference(working, reference());
  assert.deepEqual(result.details.rungs.counts, { 'cases': 2, 'cases-adjusted': 1, 'derived': 1 });
  assert.equal(result.metrics.casesShare, 0.5);
  assert.equal(result.metrics.derivedShare, 0.25);
  // The middle rung is in the report but not in the metrics: it has no better direction.
  assert.equal(result.metrics.casesAdjustedShare, undefined);
  assert.equal(result.details.rungs.shares['cases-adjusted'], 0.25);
  assert.match(formatReport({ cases: [result], metrics: result.metrics }), /rate ladder\s+cases 50% \(2\), cases-adjusted 25% \(1\), derived 25% \(1\)/);
});

test('a workstream with no rung is reported as unrated rather than counted as evidence', () => {
  const working = {
    requirements: [row('R-1', 'content-migration', 'Migrate the pages')],
    workstreams: [{ id: 'content-migration', rateBasis: 'cases' }, { id: 'seo' }, { id: 'search', rateBasis: 'invented' }]
  };
  const result = compareToReference(working, reference());
  assert.equal(result.details.rungs.rated, 1, 'only the workstream naming a real rung is scored');
  assert.equal(result.details.rungs.unrated, 2);
  assert.equal(result.metrics.casesShare, 1);
});

test('a Blueprint with no workstreams has no rung figures at all, rather than zero on every rung', () => {
  const result = compareToReference({ requirements: [row('R-1', 'content-migration', 'x')] }, reference());
  assert.equal(result.details.rungs, undefined);
  assert.equal(result.metrics.casesShare, undefined);
  assert.equal(result.metrics.derivedShare, undefined);
});

test('a metric the reference cannot answer is undefined, not zero', () => {
  const result = compareToReference({ requirements: [row('R-1', 'content-migration', 'x')] }, { schemaVersion: '1', name: 'n', totalHours: 100 });
  assert.equal(result.metrics.requirementRecall, undefined);
  assert.equal(result.metrics.quantityError, undefined);
  assert.equal(result.metrics.totalHoursError, undefined);
});

test('validateReference names the field that is wrong', () => {
  assert.deepEqual(validateReference(reference()), []);
  const errors = validateReference({
    schemaVersion: '2',
    name: '',
    workPackages: { 'WP-6': { quantity: -1 } },
    requirements: [{ id: 'A', text: 't', match: [] }, { id: 'A', text: 't', match: ['x'], workPackage: 'Six Packs' }]
  });
  assert.ok(errors.some((text) => text.startsWith('schemaVersion')));
  assert.ok(errors.some((text) => text.startsWith('name')));
  assert.ok(errors.some((text) => text.startsWith('workPackages.WP-6')));
  assert.ok(errors.some((text) => text.startsWith('requirements[0].match')));
  assert.ok(errors.some((text) => text.includes('used twice')));
  assert.ok(errors.some((text) => text.startsWith('requirements[1].workPackage')));
  assert.ok(validateReference({ schemaVersion: '1', name: 'n' }).length > 0);
});

test('compareMetrics reads error metrics as lower is better and ignores noise inside the tolerance', () => {
  const rows = compareMetrics(
    { requirementRecall: 0.5, quantityError: 0.4, workPackageAgreement: 0.9, hoursError: undefined },
    { requirementRecall: 0.7, quantityError: 0.5, workPackageAgreement: 0.89, hoursError: 0.2 }
  );
  const verdict = Object.fromEntries(rows.map((item) => [item.metric, item.verdict]));
  assert.equal(verdict.requirementRecall, 'better');
  assert.equal(verdict.quantityError, 'worse');
  assert.equal(verdict.workPackageAgreement, 'same');
  assert.equal(verdict.hoursError, 'not comparable');
});

test('aggregate takes the mean over the cases that have the metric, and the size of the total error', () => {
  const metrics = aggregateMetrics([
    { metrics: { requirementRecall: 1, totalHoursError: -0.2 } },
    { metrics: { requirementRecall: 0.5, totalHoursError: 0.1 } },
    { metrics: {} }
  ]);
  assert.equal(metrics.requirementRecall, 0.75);
  assert.equal(metrics.totalHoursError, 0.15);
  assert.equal(metrics.hoursError, undefined);
});

test('the recorded metrics hold numbers only', () => {
  const working = { requirements: [row('R-1', 'content-migration', 'Migrate the pages for Acme Corp')] };
  const result = compareToReference(working, reference());
  const text = JSON.stringify(metricsRecord({ cases: [result], metrics: result.metrics }));
  assert.ok(!text.includes('Acme'));
  assert.ok(!text.includes('Migrate'));
});

test('the report names the missed items', () => {
  const result = compareToReference({ requirements: [row('R-1', 'content-migration', 'Migrate the pages')] }, reference());
  const text = formatReport({ cases: [result], metrics: result.metrics });
  assert.match(text, /missed REF-03/);
  assert.match(text, /requirement recall/);
});

function tempFolder() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'backtest-'));
}

test('the CLI scores the synthetic sample suite and exits 0', () => {
  const run = spawnSync(process.execPath, [script, '--suite', path.join(root, 'samples', 'eval', 'suite.json'), '--json'], { encoding: 'utf8' });
  assert.equal(run.status, 0, run.stderr);
  const report = JSON.parse(run.stdout);
  assert.equal(report.cases.length, 1);
  assert.equal(report.metrics.requirementRecall, 0.833);
});

test('the CLI scores the synthetic second read next to the first', () => {
  const run = spawnSync(process.execPath, [script, '--suite', path.join(root, 'samples', 'eval', 'suite-second.json'), '--json'], { encoding: 'utf8' });
  assert.equal(run.status, 0, run.stderr);
  const report = JSON.parse(run.stdout);
  assert.equal(report.metrics.quantityError, 0.4);
  assert.equal(report.metrics.secondQuantityError, 0.65);
  assert.deepEqual(report.cases[0].details.disagreements, [{ workPackage: 'integrations', first: 4, second: 3, reference: 4, closer: 'first' }]);
});

test('the committed synthetic baseline matches the sample, so a skill change that hurts a number shows up', () => {
  const run = spawnSync(
    process.execPath,
    [script, '--suite', path.join(root, 'samples', 'eval', 'suite.json'), '--baseline', path.join(root, 'samples', 'eval', 'synthetic-baseline.json'), '--fail-on-regress'],
    { encoding: 'utf8' }
  );
  assert.equal(run.status, 0, run.stdout + run.stderr);
});

test('--fail-on-regress exits 1 when a metric is worse than the baseline', () => {
  const folder = tempFolder();
  const baseline = path.join(folder, 'baseline.json');
  fs.writeFileSync(baseline, JSON.stringify({ metrics: { requirementRecall: 1 } }));
  const run = spawnSync(
    process.execPath,
    [script, '--suite', path.join(root, 'samples', 'eval', 'suite.json'), '--baseline', baseline, '--fail-on-regress'],
    { encoding: 'utf8' }
  );
  assert.equal(run.status, 1);
  assert.match(run.stdout, /worse/);
});

test('the CLI reports an invalid reference with the field and exits 1', () => {
  const folder = tempFolder();
  const file = path.join(folder, 'reference.json');
  fs.writeFileSync(file, JSON.stringify({ schemaVersion: '1', name: '', requirements: [] }));
  const blueprint = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json');
  const run = spawnSync(process.execPath, [script, blueprint, '--reference', file], { encoding: 'utf8' });
  assert.equal(run.status, 1);
  assert.match(run.stderr, /name: expected non-empty text/);
});

test('bad usage exits 2', () => {
  assert.equal(spawnSync(process.execPath, [script], { encoding: 'utf8' }).status, 2);
  assert.equal(spawnSync(process.execPath, [script, '--bogus'], { encoding: 'utf8' }).status, 2);
  assert.equal(spawnSync(process.execPath, [script, '--suite', 'x.json', 'y.json'], { encoding: 'utf8' }).status, 2);
});

test('a suite resolves its paths from the manifest folder and rejects a case with no reference', () => {
  const folder = tempFolder();
  const file = path.join(folder, 'suite.json');
  fs.writeFileSync(file, JSON.stringify({ cases: [{ blueprint: 'a/b.json', reference: 'r.json', sketch: 's.json' }] }));
  const [spec] = readSuite(file);
  assert.equal(spec.blueprint, path.join(folder, 'a', 'b.json'));
  assert.equal(spec.sketch, path.join(folder, 's.json'));
  fs.writeFileSync(file, JSON.stringify({ cases: [{ blueprint: 'a.json' }] }));
  assert.throws(() => readSuite(file), /cases\[0\] needs/);
});

const suiteFile = () => path.join(root, 'samples', 'eval', 'suite.json');
const run = (args) => spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });

test('--fail-on-regress without a baseline is a usage error, not a silent pass', () => {
  const result = run(['--suite', suiteFile(), '--fail-on-regress']);
  assert.equal(result.status, 2);
  assert.match(result.stderr, /--fail-on-regress needs --baseline/);
});

test('--record may not name the baseline file', () => {
  const folder = tempFolder();
  const file = path.join(folder, 'metrics.json');
  fs.writeFileSync(file, JSON.stringify({ metrics: {} }));
  const result = run(['--suite', suiteFile(), '--baseline', file, '--record', file]);
  assert.equal(result.status, 2);
  assert.match(result.stderr, /must not be the --baseline file/);
});

test('--record writes numbers only, and the round trip against the same run passes', () => {
  const folder = tempFolder();
  const record = path.join(folder, 'out', 'metrics.json');
  const first = run(['--suite', suiteFile(), '--record', record]);
  assert.equal(first.status, 0, first.stderr);
  const saved = JSON.parse(fs.readFileSync(record, 'utf8'));
  assert.equal(saved.schemaVersion, '1');
  assert.equal(saved.cases, 1);
  assert.deepEqual(saved.quantitySources, ['extracted']);
  assert.doesNotMatch(JSON.stringify(saved), /Fabrikam|migrate|pages/i);
  const second = run(['--suite', suiteFile(), '--baseline', record, '--fail-on-regress']);
  assert.equal(second.status, 0, second.stdout + second.stderr);
});

test('a regressing run does not write its record', () => {
  const folder = tempFolder();
  const baseline = path.join(folder, 'baseline.json');
  const record = path.join(folder, 'record.json');
  fs.writeFileSync(baseline, JSON.stringify({ metrics: { requirementRecall: 1 } }));
  const result = run(['--suite', suiteFile(), '--baseline', baseline, '--fail-on-regress', '--record', record]);
  assert.equal(result.status, 1);
  assert.equal(fs.existsSync(record), false);
});

test('a baseline without metrics exits 1 and names what was expected', () => {
  const folder = tempFolder();
  const file = path.join(folder, 'baseline.json');
  fs.writeFileSync(file, JSON.stringify({ nothing: true }));
  const result = run(['--suite', suiteFile(), '--baseline', file]);
  assert.equal(result.status, 1);
  assert.match(result.stderr, /expected a file written by --record/);
});

test('a metric the baseline had and this run lacks is worse, not "not comparable"', () => {
  const rows = compareMetrics({ hoursError: 0.1, quantityError: 0.1 }, { quantityError: 0.1 });
  const verdict = Object.fromEntries(rows.map((item) => [item.metric, item.verdict]));
  assert.equal(verdict.hoursError, 'worse');
  assert.equal(verdict.quantityError, 'same');
});

test('the tolerance boundary: 0.02 worse is still the same, 0.021 worse fails', () => {
  assert.equal(compareMetrics({ quantityError: 0.1 }, { quantityError: 0.12 }).find((item) => item.metric === 'quantityError').verdict, 'same');
  assert.equal(compareMetrics({ quantityError: 0.1 }, { quantityError: 0.121 }).find((item) => item.metric === 'quantityError').verdict, 'worse');
});

test('quantities from another source than the baseline are not comparable', () => {
  const rows = compareMetrics({ quantityError: 0.1, requirementRecall: 0.5 }, { quantityError: 0.9, requirementRecall: 0.5 }, { incomparable: ['quantityError'] });
  const verdict = Object.fromEntries(rows.map((item) => [item.metric, item.verdict]));
  assert.equal(verdict.quantityError, 'not comparable');
  assert.equal(verdict.requirementRecall, 'same');
});

test('a missing or non-numeric estimate figure stays missing and is warned about, never read as zero', () => {
  const working = {
    requirements: [row('R-1', 'content-migration', 'Migrate 100 pages')],
    estimate: { packages: [{ workPackageId: 'content-migration', quantity: 'many', hours: null }] }
  };
  const result = compareToReference(working, reference({ totalHours: 500, workPackages: { 'content-migration': { quantity: 100, hours: 200 } } }));
  assert.equal(result.metrics.totalHoursError, undefined);
  assert.equal(result.metrics.hoursError, undefined);
  assert.ok(result.details.warnings.some((message) => message.includes('totalHours')));
  assert.ok(result.details.warnings.some((message) => message.includes('content-migration')));
});

test('a package missing from the estimate is a full hours miss, as an unsized package is for quantity', () => {
  const working = { requirements: [row('R-1', 'content-migration', 'Migrate 100 pages')], estimate: { totalHours: 100, packages: [{ workPackageId: 'content-migration', quantity: 100, hours: 100 }] } };
  const result = compareToReference(working, reference({ workPackages: { 'content-migration': { hours: 100 }, 'search': { hours: 50 } } }));
  assert.equal(result.metrics.hoursError, 0.5);
});

test('dismissed drivers in a sketch do not count', () => {
  const sketch = { drivers: [{ workPackageId: 'content-migration', quantity: 100, review: { status: 'dismissed' } }, { workPackageId: 'search', quantity: 2 }] };
  const result = compareToReference({ requirements: [] }, reference({ workPackages: { 'content-migration': { quantity: 100 } } }), { sketch });
  assert.equal(result.metrics.quantityError, 1);
});

test('a wrong-shaped sketch or Blueprint is an error, not an empty result', () => {
  const folder = tempFolder();
  const sketch = path.join(folder, 'sketch.json');
  fs.writeFileSync(sketch, JSON.stringify({ nothing: true }));
  const blueprint = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json');
  const reference = path.join(root, 'samples', 'eval', 'synthetic-aem-reference.json');
  const bad = run([blueprint, '--reference', reference, '--sketch', sketch]);
  assert.equal(bad.status, 1);
  assert.match(bad.stderr, /expected an object with a drivers array/);
  const notBlueprint = path.join(folder, 'bp.json');
  fs.writeFileSync(notBlueprint, JSON.stringify({ requirements: 'none' }));
  assert.equal(run([notBlueprint, '--reference', reference]).status, 1);
});

test('a reference figure of zero is rejected because it could not be scored', () => {
  const errors = validateReference({ schemaVersion: '1', name: 'n', totalHours: 0, workPackages: { 'content-migration': { quantity: 0 } } });
  assert.ok(errors.some((message) => message.startsWith('totalHours')));
  assert.ok(errors.some((message) => message.startsWith('workPackages.content-migration.quantity')));
});

test('the second read compared without a sketch carries a warning', () => {
  const result = compareToReference({ requirements: [] }, reference({ workPackages: { 'content-migration': { quantity: 10 } } }), { secondSketch: { drivers: [] } });
  assert.ok(result.details.warnings.some((message) => message.includes('second read')));
});