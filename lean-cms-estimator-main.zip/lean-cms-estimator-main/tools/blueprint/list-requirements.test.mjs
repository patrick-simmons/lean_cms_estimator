import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { compactRequirements, formatRequirements } from './list-requirements.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'list-requirements.mjs');
const scratch = mkdtempSync(join(tmpdir(), 'list-req-'));
after(() => rmSync(scratch, { recursive: true, force: true }));

const working = {
  requirements: [
    { id: 'R-001', statement: 'Migrate pages.', workPackage: 'content-migration', coverage: 'accelerated', sources: [{ blockId: 'a#1' }, { blockId: 'a#2' }], review: { status: 'accepted' }, questionId: 'Q1' },
    { id: 'R-002', statement: 'Launch in four locales.', workPackage: 'localization', coverage: 'partly', sources: [{ blockId: 'b#1' }], review: { status: 'pending' } },
    // A row with no review state or sources still lists, as pending.
    { id: 'R-003', statement: 'Provide hypercare.', workPackage: 'qa-automation', coverage: 'human-led' }
  ],
  questions: [{ id: 'Q1', requirementId: 'R-001', text: 'How many pages?' }]
};

function run(args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

describe('list-requirements', () => {
  it('lists id, status, statement, work package, coverage, cited blocks and the question', () => {
    const rows = compactRequirements(working);
    assert.deepEqual(rows[0], {
      id: 'R-001', status: 'accepted', statement: 'Migrate pages.', workPackage: 'content-migration', coverage: 'accelerated', blockIds: ['a#1', 'a#2'], question: 'How many pages?'
    });
    assert.deepEqual(rows[2].blockIds, []);
    assert.equal(rows[2].status, 'pending');
    assert.match(formatRequirements(rows), /^R-001 \[accepted\] content-migration accelerated\n {4}Migrate pages\.\n {4}cites: a#1, a#2\n {4}question: How many pages\?/);
  });

  it('keeps only pending rows with --pending, including rows without review state', () => {
    assert.deepEqual(compactRequirements(working, { pendingOnly: true }).map((row) => row.id), ['R-002', 'R-003']);
  });

  it('prints JSON, and rejects unknown flags and missing files', () => {
    const file = join(scratch, 'Pilot_Blueprint.json');
    writeFileSync(file, JSON.stringify(working));
    const json = run([file, '--json', '--pending']);
    assert.equal(json.status, 0, json.stderr);
    assert.deepEqual(JSON.parse(json.stdout).map((row) => row.id), ['R-002', 'R-003']);
    const typo = run([file, '--pnding']);
    assert.equal(typo.status, 2);
    assert.match(typo.stderr, /Unknown option --pnding/);
    assert.equal(run([]).status, 2);
    assert.equal(run([join(scratch, 'missing.json')]).status, 1);
  });
});
