/**
 * Who does the work (story B-11).
 *
 * The catalog says who usually owns an activity, `us` or `shared`. An estimate can say
 * otherwise, because what the client is doing themselves changes what we are quoting for, and
 * `plan.mjs owner` is how that gets recorded. `client` is only ever a decision on an estimate,
 * never a catalog default: nothing is handed to the client unless a person said so.
 *
 * Ownership applies *after* sizing, not before. An activity is sized whole and then reduced to
 * our portion, so a client-run UAT does not shrink the project management that covers it - the
 * work still has to be managed, whoever runs it.
 *
 * With no case evidence for how a shared activity splits, `shared` is sized at full and says
 * so. Guessing the split would be inventing a number, and guessing it downwards is the
 * expensive direction.
 */
export const OWNERS = ['us', 'shared', 'client'];

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** The estimator's ownership decisions, by activity. Only an accepted or edited one counts. */
export function ownerDecisions(plan) {
  const rows = Array.isArray(plan.owners) ? plan.owners : [];
  return new Map(rows
    .filter((row) => isObject(row) && typeof row.activity === 'string'
      && isObject(row.review) && ['accepted', 'edited'].indexOf(row.review.status) !== -1)
    .map((row) => [row.activity, row]));
}

/** What a client-owned activity is worth asking about, with the volume it was going to be sized at. */
function clientQuestionFor(name, wholeHours, volume, unit) {
  const sized = unit && unit !== 'fixed' ? `${volume} ${unit}${volume === 1 ? '' : 's'}, ` : '';
  return `${name}: the client is doing this, so the estimate carries none of it. It would have been ${sized}${wholeHours} hours. Is that still their plan, and is the scope the same?`;
}

function exclusionFor(name, note) {
  return `${name} is not in this estimate: the client is doing it. ${note}`;
}

/**
 * How one activity's ownership lands on its hours.
 *
 * @param {{id: string, name: string, unit: string}} activity
 * @param {string} catalogOwner the catalog default, `us` or `shared`
 * @param {object|undefined} decision the plan's ownership decision for this activity, if any
 * @param {number} wholeHours the activity sized as if we did all of it
 * @param {number} volume what it was sized over, for the question
 * @returns {{owner: string, ourPortion: number, ownerNote?: string, exclusion?: string,
 *   ownerQuestion?: string}} `ourPortion` multiplies the whole hours
 */
export function ownershipOf(activity, catalogOwner, decision, wholeHours, volume) {
  const owner = decision ? decision.owner : catalogOwner;
  const note = decision ? decision.note : undefined;
  if (owner === 'client') {
    return {
      owner,
      ourPortion: 0,
      ownerNote: note,
      exclusion: exclusionFor(activity.name, note),
      ownerQuestion: clientQuestionFor(activity.name, wholeHours, volume, activity.unit)
    };
  }
  if (owner === 'shared') {
    return {
      owner,
      // No case records how a shared activity splits, so it is sized at full and says so.
      // Halving it would be a number nobody measured, in the direction that loses money.
      ourPortion: 1,
      ...(note ? { ownerNote: note } : {}),
      ownerQuestion: `${activity.name}: this is shared with the client, but no past project records how the work splits, so the estimate carries all ${wholeHours} hours of it. How much of it are they doing?`
    };
  }
  return { owner, ourPortion: 1, ...(note ? { ownerNote: note } : {}) };
}
