#!/usr/bin/env node
/**
 * Assemble a Start+extract-shaped Blueprint JSON from model extract output + blocks.
 * Derives capabilities from the estimating catalog; never trusts model capability ids.
 *
 * Two modes (SAPP-014):
 *   first-run   writes `{Project}_Blueprint.json`, every requirement `pending`. Refuses to overwrite a
 *               Blueprint that has review state, or one it cannot read (exit 3), so a re-run can never
 *               discard a decision.
 *   proposals   reads the existing Blueprint with `--existing`, never changes it, and writes
 *               `{Project}_Proposals.json`: adds, updates and conflicts against the current rows, each
 *               with its citation and cause. The app accepts or rejects them (docs/spfx/agent-contract.md).
 *
 * Exit codes: 0 written; 1 invalid input or output (nothing written); 2 usage; 3 refused to overwrite
 * (review state, unreadable file, or the file changed while the tool ran); 4 the extraction produced no
 * requirements (nothing written).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { citationLabel } from './citation-label.mjs';
import {
  allCatalogCapabilityIds,
  capabilitiesFor,
  filterKnownCapabilities,
  parseEstimatingCatalog
} from './derive-capabilities.mjs';
import { MODES, updateRunRecord } from './run-record.mjs';
import { PROPOSALS_SCHEMA_VERSION, validateProposalsValue } from './validate-proposals.mjs';
import { COVERAGES, validateWorkingFileValue } from './validate-working-file.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';

/**
 * @typedef {{
 *   id: string,
 *   fileName: string,
 *   itemId: string,
 *   label?: string,
 *   text: string,
 *   location: object
 * }} Block
 */

export const REVIEW_STATE_MESSAGE = 'The Blueprint already has review state (accepted, edited or dismissed rows, a revision, an estimate, notes, questions, proposals or other estimator edits). ' +
  'It is not rewritten. Run again with --mode proposals --existing <that Blueprint> to write a proposals file instead.';

const PLATFORM_NAMES = { aem: 'Adobe Experience Manager', 'aem-eds': 'AEM Edge Delivery Services' };
const STAT_KEY = { add: 'added', update: 'updated', conflict: 'conflicts' };

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function newStats() {
  return {
    requirementsIn: 0,
    requirementsKept: 0,
    droppedEmptyStatement: 0,
    droppedNoSource: 0,
    unknownWorkPackage: 0,
    // Every requirement that ends up unmapped, whether the model said so or named an id the
    // catalog does not have. unknownWorkPackage counts only the second, so it cannot answer
    // whether a catalog change made the mapping better or worse.
    unmapped: 0,
    conflictDowngraded: 0,
    coverageCoerced: 0,
    droppedCapabilities: 0,
    droppedBlockIds: 0,
    droppedEmptyBlocks: 0
  };
}

/** What a run tells the caller beyond its counts: one line per problem worth a person's attention. */
function describeProblems(stats) {
  const warnings = [];
  const note = (count, text) => {
    if (count > 0) {
      warnings.push(`${count} ${text}`);
    }
  };
  note(stats.droppedEmptyStatement, 'requirement(s) dropped for an empty statement');
  note(stats.droppedNoSource, 'requirement(s) dropped because none of their blockIds is a usable block');
  note(stats.droppedBlockIds, 'blockId(s) are not in the blocks file and were ignored');
  note(stats.droppedEmptyBlocks, 'cited block(s) have no text and were ignored');
  note(stats.coverageCoerced, 'requirement(s) had an unknown or missing coverage and took their work package default');
  note(stats.unknownWorkPackage, 'requirement(s) named an activity that is not in the catalog and are unmapped');
  note(stats.duplicateTargetMissing || 0, 'requirement(s) name a duplicateOf row that is not in the Blueprint');
  note(stats.conflictQuestionGenerated || 0, 'conflict(s) had no question, so one was written from the two statements');
  const dropped = stats.droppedEmptyStatement + stats.droppedNoSource;
  if (stats.requirementsIn > 0 && dropped * 2 > stats.requirementsIn) {
    warnings.push(`more than half of the extracted requirements were dropped (${dropped} of ${stats.requirementsIn}): check the blockIds against the blocks file`);
  }
  return warnings;
}

/** The coverage a work package takes when the model's value is unusable. */
function packageDefaultCoverage(parsed, workPackage) {
  return parsed.defaults.get(workPackage) || 'human-led';
}

/** A conflict needs two citations; a row with one is an ordinary row at its package default. */
function downgradeLoneConflict(row, parsed, stats) {
  if (row.coverage === 'conflict' && row.sources.length < 2) {
    row.coverage = packageDefaultCoverage(parsed, row.workPackage);
    stats.conflictDowngraded += 1;
  }
}

/**
 * Turn the model's requirements into working-file rows without ids or review state.
 * Shared by the first run and the proposals run so both apply the same rules. A `conflict` row with one
 * citation is left as it is: whether it has a second citation depends on the existing row it names, which
 * only the caller can resolve.
 *
 * @returns {{ rows: { row: object, question: string|null, duplicateOf: string|null }[], platformId: string|null }}
 */
function convertRequirements(extract, blockMap, parsed, knownCaps, stats) {
  const platformId = extract.platform?.id || null;
  const rows = [];
  const requirements = Array.isArray(extract.requirements) ? extract.requirements : [];
  stats.requirementsIn += requirements.length;

  for (const req of requirements) {
    const statement = isObject(req) && typeof req.statement === 'string' ? req.statement.trim() : '';
    if (!statement) {
      stats.droppedEmptyStatement += 1;
      continue;
    }

    const sources = [];
    for (const id of Array.isArray(req.blockIds) ? req.blockIds : []) {
      const block = blockMap.get(id);
      if (!block) {
        stats.droppedBlockIds += 1;
        continue;
      }
      if (typeof block.text !== 'string' || !block.text.trim()) {
        stats.droppedEmptyBlocks += 1;
        continue;
      }
      sources.push({
        itemId: block.itemId,
        fileName: block.fileName,
        blockId: block.id,
        label: block.label || citationLabel(block.fileName, block.location),
        location: block.location,
        passage: block.text
      });
    }

    if (sources.length === 0) {
      stats.droppedNoSource += 1;
      continue;
    }

    let workPackage = typeof req.workPackage === 'string' ? req.workPackage.trim() : 'unmapped';
    if (workPackage !== 'unmapped' && !parsed.workPackages.has(workPackage)) {
      workPackage = 'unmapped';
      stats.unknownWorkPackage += 1;
    }
    if (workPackage === 'unmapped') {
      stats.unmapped += 1;
    }

    let coverage = req.coverage;
    if (!COVERAGES.includes(coverage)) {
      coverage = packageDefaultCoverage(parsed, workPackage);
      stats.coverageCoerced += 1;
    }
    const duplicateOf = typeof req.duplicateOf === 'string' && req.duplicateOf.trim() ? req.duplicateOf.trim() : null;

    // Model must not invent capability ids: ignore any it sent and derive from catalog.
    if (Array.isArray(req.capabilities) && req.capabilities.length) {
      stats.droppedCapabilities += req.capabilities.filter((id) => typeof id === 'string').length;
    }
    let capabilities = capabilitiesFor(parsed.capabilities, workPackage, platformId);
    const filteredFinal = filterKnownCapabilities(capabilities, knownCaps);
    if (filteredFinal.dropped.length) {
      stats.droppedCapabilities += filteredFinal.dropped.length;
    }
    capabilities = filteredFinal.kept;

    rows.push({
      row: { statement, sources, workPackage, capabilities, coverage },
      question: typeof req.question === 'string' && req.question.trim() ? req.question.trim() : null,
      duplicateOf
    });
  }
  stats.requirementsKept = rows.length;
  return { rows, platformId };
}

function catalogPinsOf(parsed, catalogPins) {
  const catalog = {
    cmkCommit: catalogPins.cmkCommit || parsed.cmkCommit,
    toolkitCommit: catalogPins.toolkitCommit || parsed.toolkitCommit,
    estimatingVersion: String(catalogPins.estimatingVersion || parsed.estimatingVersion || '').replace(/^v/i, '')
  };
  for (const key of Object.keys(catalog)) {
    if (!catalog[key]) {
      delete catalog[key];
    }
  }
  return catalog;
}

function platformOf(platformId, extract, blockMap) {
  if (!platformId) {
    return undefined;
  }
  const name = Object.prototype.hasOwnProperty.call(PLATFORM_NAMES, platformId) ? PLATFORM_NAMES[platformId] : platformId;
  const citeBlock = extract.platform?.blockId ? blockMap.get(extract.platform.blockId) : null;
  return {
    id: platformId,
    name,
    ...(citeBlock
      ? { citation: `${citeBlock.fileName} · ${citationLabel(citeBlock.fileName, citeBlock.location)}` }
      : {})
  };
}

/**
 * First run: a complete working file with every requirement pending.
 *
 * @param {object} opts
 * @param {object} opts.extract
 * @param {Block[]|Record<string, Block>} opts.blocks
 * @param {string} opts.catalogMd
 * @param {{ projectId: string, projectName: string, runId?: string, sources?: object[] }} opts.meta
 * @param {{ cmkCommit?: string, toolkitCommit?: string, estimatingVersion?: string }} [opts.catalogPins]
 * @returns {{ working: object, stats: object, warnings: string[] }}
 */
export function assembleWorkingFile(opts) {
  const { extract, blocks, catalogMd, meta, catalogPins = {} } = opts;
  const parsed = parseEstimatingCatalog(catalogMd);
  const knownCaps = allCatalogCapabilityIds(parsed.capabilities);
  const blockMap = indexBlocks(blocks);
  const stats = newStats();
  const converted = convertRequirements(extract, blockMap, parsed, knownCaps, stats);

  const questions = [];
  const requirements = [];
  for (const item of converted.rows) {
    downgradeLoneConflict(item.row, parsed, stats);
    const id = `R-${String(requirements.length + 1).padStart(3, '0')}`;
    const row = { id, ...item.row, review: { status: 'pending' } };
    if (item.question) {
      const qid = `Q${questions.length + 1}`;
      questions.push({ id: qid, requirementId: id, text: item.question });
      row.questionId = qid;
    }
    requirements.push(row);
  }

  const working = {
    projectId: meta.projectId,
    projectName: meta.projectName,
    revision: 0,
    runId: meta.runId || `offline-${Date.now()}`,
    sources: meta.sources || buildSourcesFromBlocks(blockMap),
    requirements,
    questions,
    notes: [],
    proposals: [],
    history: [],
    catalog: catalogPinsOf(parsed, catalogPins),
    estimate: null,
    handoff: null
  };

  const platform = platformOf(converted.platformId, extract, blockMap);
  if (platform) {
    working.platform = platform;
  }

  return { working, stats, warnings: describeProblems(stats) };
}

/** A question the agent wrote for a row: the row points at it and it points back. */
function isAgentQuestion(question, rows) {
  if (!isObject(question)) {
    return false;
  }
  const row = rows.find((candidate) => candidate.id === question.requirementId);
  return Boolean(row) && row.questionId === question.id;
}

/**
 * True when the Blueprint holds anything a person decided or built: a reviewed row, an edited row, a
 * revision, an estimate, a published workbook, a handoff, history, notes, proposals, a question the agent
 * did not write, or an edited skill set, phase plan or lever choice. Such a file is never rewritten by the
 * agent.
 * @param {object} working
 */
export function hasReviewState(working) {
  if (!isObject(working)) {
    return false;
  }
  const rows = Array.isArray(working.requirements) ? working.requirements.filter(isObject) : [];
  const reviewed = rows.some((row) => isObject(row.review) && row.review.status && row.review.status !== 'pending');
  const edited = rows.some((row) => row.original !== undefined);
  const humanQuestion = Array.isArray(working.questions) && working.questions.some((q) => !isAgentQuestion(q, rows));
  const nonEmpty = (value) => Array.isArray(value) && value.length > 0;
  return reviewed ||
    edited ||
    humanQuestion ||
    (typeof working.revision === 'number' && working.revision > 0) ||
    (working.estimate !== null && working.estimate !== undefined) ||
    (working.handoff !== null && working.handoff !== undefined) ||
    working.published !== undefined ||
    nonEmpty(working.history) ||
    nonEmpty(working.notes) ||
    nonEmpty(working.proposals) ||
    nonEmpty(working.skillSet) ||
    nonEmpty(working.phasePlan) ||
    (working.levers !== null && working.levers !== undefined);
}

/** Lower case, one space between words, no trailing full stop: how two statements are compared. */
export function normalizeStatement(text) {
  return String(text || '').toLowerCase().replace(/\s+/g, ' ').replace(/[.\s]+$/g, '').trim();
}

function proposalKey(kind, requirementId, statement) {
  return `${kind}|${requirementId || ''}|${normalizeStatement(statement)}`;
}

/** The parts of the current proposals file this run builds on, whatever shape the file turned out to have. */
function priorFileParts(proposals) {
  const file = isObject(proposals) ? proposals : {};
  return {
    previous: Array.isArray(file.proposals) ? file.proposals : [],
    sources: Array.isArray(file.sources) ? file.sources : [],
    runs: Array.isArray(file.runs) ? file.runs : []
  };
}

function highestProposalNumber(previous) {
  return previous.reduce((max, p) => {
    const match = /^P-(\d+)$/.exec(p && p.id || '');
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);
}

/**
 * What a converted row means against the existing rows: `add` (no such row), `update` or `conflict`
 * (changes, or disagrees with, an existing row), `unchanged`, or `dismissed` (the estimator already
 * dismissed that row). `targetMissing` is set when the model named a duplicateOf row that is not there.
 *
 * @param {{ row: object, duplicateOf: string|null }} item
 * @param {Map<string, object>} byStatement the existing rows by normalised statement
 * @returns {{ action: 'add'|'update'|'conflict'|'unchanged'|'dismissed', target?: object, targetMissing: boolean }}
 */
function classify(item, byStatement) {
  const named = item.duplicateOf ? byStatement.get(normalizeStatement(item.duplicateOf)) : undefined;
  const targetMissing = Boolean(item.duplicateOf) && !named;
  const target = named || byStatement.get(normalizeStatement(item.row.statement));
  if (!target) {
    return { action: 'add', targetMissing };
  }
  if (target.review.status === 'dismissed') {
    return { action: 'dismissed', target, targetMissing };
  }
  if (item.row.coverage === 'conflict') {
    return { action: 'conflict', target, targetMissing };
  }
  const differs = normalizeStatement(item.row.statement) !== normalizeStatement(target.statement) ||
    item.row.workPackage !== target.workPackage ||
    item.row.coverage !== target.coverage;
  // The same requirement again, from the same or another document, is nothing for the estimator to decide.
  return { action: differs ? 'update' : 'unchanged', target, targetMissing };
}

/** The question a conflict carries when the model sent none: the two statements, side by side. */
function conflictQuestion(target, item) {
  return `Which is correct: "${target.statement}" or "${item.row.statement}"?`;
}

function buildProposal({ number, kind, target, item, question, cause, runId, now, questionText }) {
  const firstSource = item.row.sources[0];
  return {
    id: `P-${String(number).padStart(3, '0')}`,
    kind,
    ...(target ? { requirementId: target.id } : {}),
    statement: item.row.statement,
    sources: item.row.sources,
    workPackage: item.row.workPackage,
    capabilities: item.row.capabilities,
    coverage: kind === 'conflict' ? 'conflict' : item.row.coverage,
    question,
    cause: cause || { kind: 'file', itemId: firstSource.itemId, fileName: firstSource.fileName },
    ...(target ? {
      existing: {
        statement: target.statement,
        workPackage: target.workPackage,
        coverage: target.coverage,
        reviewStatus: target.review.status,
        ...(questionText.has(target.id) ? { question: questionText.get(target.id) } : {})
      }
    } : {}),
    review: { status: 'pending' },
    runId,
    proposedAt: now
  };
}

/**
 * Re-run: compare the model's rows with the existing Blueprint and write proposals. The Blueprint is
 * read, never changed.
 *
 * @param {object} opts
 * @param {object} opts.extract
 * @param {Block[]|Record<string, Block>} opts.blocks
 * @param {string} opts.catalogMd
 * @param {object} opts.existing the current `{Project}_Blueprint.json`
 * @param {object} [opts.proposals] the current `{Project}_Proposals.json`, when there is one
 * @param {object[]} [opts.sources] the parse stage's `sources[]`; entries not yet in the Blueprint are carried
 * @param {{ runId?: string, packVersion?: string, now?: string, cause?: object }} [opts.meta]
 * @returns {{ proposals: object, stats: object, warnings: string[] }}
 */
export function proposeChanges(opts) {
  const { extract, blocks, catalogMd, existing, proposals, sources, meta = {} } = opts;
  const errors = validateWorkingFileValue(existing);
  if (errors.length) {
    throw new Error(`existing Blueprint is not valid: ${errors[0]}`);
  }
  const parsed = parseEstimatingCatalog(catalogMd);
  const knownCaps = allCatalogCapabilityIds(parsed.capabilities);
  const blockMap = indexBlocks(blocks);
  const stats = {
    ...newStats(),
    added: 0,
    updated: 0,
    conflicts: 0,
    unchanged: 0,
    alreadyProposed: 0,
    dismissedTarget: 0,
    duplicateTargetMissing: 0,
    conflictQuestionGenerated: 0
  };
  const converted = convertRequirements(extract, blockMap, parsed, knownCaps, stats);
  const now = meta.now || new Date().toISOString();
  const runId = meta.runId || `offline-${Date.now()}`;

  const byStatement = new Map(existing.requirements.map((row) => [normalizeStatement(row.statement), row]));
  const questionText = new Map((existing.questions || []).map((q) => [q.requirementId, q.text]));
  const prior = priorFileParts(proposals);
  const seenKeys = new Set(prior.previous.map((p) => proposalKey(p.kind, p.requirementId, p.statement)));
  let number = highestProposalNumber(prior.previous);

  const fresh = [];
  const push = (kind, target, item) => {
    const key = proposalKey(kind, target?.id, item.row.statement);
    if (seenKeys.has(key)) {
      stats.alreadyProposed += 1;
      return;
    }
    seenKeys.add(key);
    number += 1;
    let question = item.question;
    if (kind === 'conflict' && !question) {
      question = conflictQuestion(target, item);
      stats.conflictQuestionGenerated += 1;
    }
    fresh.push(buildProposal({ number, kind, target, item, question, cause: meta.cause, runId, now, questionText }));
    stats[STAT_KEY[kind]] += 1;
  };

  for (const item of converted.rows) {
    const decision = classify(item, byStatement);
    if (decision.targetMissing) {
      stats.duplicateTargetMissing += 1;
    }
    switch (decision.action) {
      case 'dismissed':
        stats.dismissedTarget += 1;
        break;
      case 'unchanged':
        stats.unchanged += 1;
        break;
      case 'add':
        // A conflict with no existing row to disagree with has only its own citations.
        downgradeLoneConflict(item.row, parsed, stats);
        push('add', undefined, item);
        break;
      default:
        push(decision.action, decision.target, item);
    }
  }

  const knownItemIds = new Set([
    ...existing.sources.map((source) => source.itemId),
    ...prior.sources.map((source) => source.itemId)
  ]);
  const newSources = (sources || buildSourcesFromBlocks(blockMap)).filter((source) => !knownItemIds.has(source.itemId));

  const file = {
    schemaVersion: PROPOSALS_SCHEMA_VERSION,
    projectId: existing.projectId,
    projectName: existing.projectName,
    blueprintRevision: existing.revision,
    sources: [...prior.sources, ...newSources],
    runs: [
      ...prior.runs,
      { runId, at: now, ...(meta.packVersion ? { packVersion: meta.packVersion } : {}), added: fresh.length }
    ],
    proposals: [...prior.previous, ...fresh]
  };
  return { proposals: file, stats, warnings: describeProblems(stats) };
}

/**
 * @param {Block[]|Record<string, Block>} blocks
 * @returns {Map<string, Block>}
 */
function indexBlocks(blocks) {
  const map = new Map();
  if (Array.isArray(blocks)) {
    for (const b of blocks) {
      if (b && b.id) {
        map.set(b.id, b);
      }
    }
  } else if (blocks && typeof blocks === 'object') {
    for (const [id, b] of Object.entries(blocks)) {
      const block = b.id ? b : { ...b, id };
      map.set(id, block);
    }
  }
  return map;
}

/**
 * The fallback when the parse stage's `sources.json` is not passed: one entry per file that has a block.
 * Files the parser could not read have no block, so they are missing here.
 * @param {Map<string, Block>} blockMap
 */
function buildSourcesFromBlocks(blockMap) {
  /** @type {Map<string, object>} */
  const byItem = new Map();
  for (const block of blockMap.values()) {
    let src = byItem.get(block.itemId);
    if (!src) {
      src = {
        itemId: block.itemId,
        name: block.fileName,
        webUrl: '',
        bytes: 0,
        modified: new Date().toISOString(),
        read: 'partial',
        blocks: [],
        notRead: []
      };
      byItem.set(block.itemId, src);
    }
    src.blocks.push({
      id: block.id,
      location: block.location,
      text: block.text || ''
    });
  }
  return [...byItem.values()];
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 2; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const next = argv[i + 1];
      if (!next || next.startsWith('--')) {
        out[key] = true;
      } else {
        out[key] = next;
        i += 1;
      }
    } else {
      out._.push(arg);
    }
  }
  return out;
}

const USAGE = [
  'Usage:',
  '  first run:  node tools/blueprint/assemble-working-file.mjs --extract <json> --blocks <json> --estimating <md> --project-id <id> --project-name <name> --out <Project>_Blueprint.json [--sources <json>] [--run-id <id>] [--cmk-commit <sha>] [--toolkit-commit <sha>] [--estimating-version <n>]',
  '  re-run:     node tools/blueprint/assemble-working-file.mjs --mode proposals --existing <Project>_Blueprint.json --extract <json> --blocks <json> --estimating <md> --out <Project>_Proposals.json [--proposals <current proposals json>] [--sources <json>] [--run-id <id>]',
  'A first run never overwrites a Blueprint with review state or one it cannot read (exit 3): use --mode proposals.',
  'Exit codes: 1 invalid input or output, 2 usage, 3 refused to overwrite, 4 the extraction produced no requirements.'
].join('\n');

const NO_SOURCES_WARNING = '--sources was not given, so sources[] is built from the blocks alone: files the parser could not read are not listed and read states are approximate. Pass the parse stage\'s sources.json.';

function fail(code, message) {
  console.error(message);
  process.exit(code);
}

function readJson(file) {
  const resolved = path.resolve(file);
  try {
    return JSON.parse(fs.readFileSync(resolved, 'utf8'));
  } catch (error) {
    throw new Error(`${resolved}: ${error.message}`);
  }
}

function samePath(a, b) {
  return process.platform === 'win32' ? a.toLowerCase() === b.toLowerCase() : a === b;
}

function readBytes(file) {
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
}

function value(args, key) {
  return args[key] !== undefined && args[key] !== true ? args[key] : undefined;
}

function recordRun(outPath, patch) {
  try {
    const folder = path.dirname(path.resolve(outPath));
    if (fs.existsSync(path.join(folder, '.blueprint'))) {
      updateRunRecord(folder, patch);
    }
  } catch (error) {
    console.error(`warning: run record not updated: ${error.message}`);
  }
}

function printWarnings(warnings) {
  warnings.forEach((message) => console.error(`warning: ${message}`));
}

/** Exit 4 when nothing survived; the message says why so the model can fix its extract. */
function requireRequirements(stats) {
  if (stats.requirementsKept > 0) {
    return;
  }
  const why = stats.requirementsIn === 0
    ? 'the extract file lists no requirements'
    : `none of the ${stats.requirementsIn} requirements is usable (${stats.droppedEmptyStatement} with an empty statement, ${stats.droppedNoSource} with no usable block; ${stats.droppedBlockIds} blockId(s) are not in the blocks file)`;
  fail(4, `Nothing was written: ${why}.`);
}

/** Refuse when the target changed since it was read: the app or a sync client wrote it meanwhile. */
function requireUnchanged(outPath, snapshot) {
  if (readBytes(outPath) !== snapshot) {
    fail(3, `${outPath} changed while this tool ran, so it was not overwritten. Run the tool again.`);
  }
}

/** Exit 1 with the field-path errors when the file about to be written is not valid. */
function requireValid(errors, label) {
  if (errors.length) {
    errors.forEach((message) => console.error(message));
    fail(1, `Nothing was written: the ${label} this run produced is not valid.`);
  }
}

async function runProposalsMode(args, inputs) {
  const { extract, blocks, catalogMd, sources, outPath, runId } = inputs;
  const existingPath = path.resolve(args.existing);
  if (samePath(outPath, existingPath)) {
    fail(2, `--out is the Blueprint itself (${existingPath}). Proposals mode never changes the Blueprint: write to ${path.basename(existingPath).replace(/_Blueprint\.json$/, '')}_Proposals.json instead.`);
  }
  const existing = readJson(existingPath);
  if (!isObject(existing)) {
    fail(1, `${existingPath}: expected a Blueprint object.`);
  }
  const proposalsPath = value(args, 'proposals') ? path.resolve(args.proposals) : (fs.existsSync(outPath) ? outPath : undefined);
  if (proposalsPath !== undefined && samePath(proposalsPath, existingPath)) {
    fail(2, '--proposals is the Blueprint, not a proposals file.');
  }
  const outBefore = readBytes(outPath);
  const previous = proposalsPath && fs.existsSync(proposalsPath) ? readJson(proposalsPath) : undefined;
  if (previous !== undefined) {
    const problems = validateProposalsValue(previous);
    if (problems.length) {
      problems.forEach((message) => console.error(message));
      fail(1, `${proposalsPath} is not a valid proposals file. It was left as it is; fix or move it, then run again.`);
    }
    if (typeof existing.projectId === 'string' && previous.projectId !== existing.projectId) {
      fail(1, `${proposalsPath} belongs to project "${previous.projectId}", not "${existing.projectId}". It was left as it is.`);
    }
  }

  let result;
  try {
    result = proposeChanges({ extract, blocks, catalogMd, existing, proposals: previous, sources, meta: { runId } });
  } catch (error) {
    fail(1, error.message);
  }
  if (!sources) {
    result.warnings.push(NO_SOURCES_WARNING);
  }
  printWarnings(result.warnings);
  requireRequirements(result.stats);
  requireValid(validateProposalsValue(result.proposals), 'proposals file');
  requireUnchanged(outPath, outBefore);

  writeFileAtomic(outPath, `${JSON.stringify(result.proposals, null, 2)}\n`);
  console.log(`wrote ${outPath}`);
  console.log(`proposals ${result.proposals.proposals.length} (new ${result.stats.added + result.stats.updated + result.stats.conflicts}: add ${result.stats.added}, update ${result.stats.updated}, conflict ${result.stats.conflicts})`);
  console.log(`stats ${JSON.stringify(result.stats)}`);
  console.log('the existing Blueprint was not changed');
  recordRun(outPath, {
    stage: 'extract',
    mode: 'proposals',
    files: { proposals: { path: path.basename(outPath), schemaVersion: PROPOSALS_SCHEMA_VERSION, proposals: result.proposals.proposals.length } },
    note: `proposals: ${result.stats.added} add, ${result.stats.updated} update, ${result.stats.conflicts} conflict`
  });
}

async function runFirstMode(args, inputs) {
  const { extract, blocks, catalogMd, sources, outPath, runId } = inputs;
  const outBefore = readBytes(outPath);
  if (outBefore !== null) {
    let current;
    try {
      current = JSON.parse(outBefore);
    } catch (error) {
      fail(3, `${outPath} exists but is not valid JSON (${error.message}). It was not overwritten: it may hold decisions. Restore it or move it aside, then run again.`);
    }
    if (!isObject(current)) {
      fail(3, `${outPath} exists but is not a Blueprint object. It was not overwritten: move it aside, then run again.`);
    }
    if (hasReviewState(current)) {
      fail(3, REVIEW_STATE_MESSAGE);
    }
  }

  const { working, stats, warnings } = assembleWorkingFile({
    extract,
    blocks,
    catalogMd,
    meta: {
      projectId: args['project-id'],
      projectName: args['project-name'],
      runId,
      sources
    },
    catalogPins: {
      cmkCommit: value(args, 'cmk-commit'),
      toolkitCommit: value(args, 'toolkit-commit'),
      estimatingVersion: value(args, 'estimating-version')
    }
  });
  if (!sources) {
    warnings.push(NO_SOURCES_WARNING);
  }
  printWarnings(warnings);
  requireRequirements(stats);
  requireValid(validateWorkingFileValue(working), 'Blueprint');
  requireUnchanged(outPath, outBefore);

  writeFileAtomic(outPath, `${JSON.stringify(working, null, 2)}\n`);
  console.log(`wrote ${outPath}`);
  console.log(`requirements ${working.requirements.length} questions ${working.questions.length}`);
  console.log(`stats ${JSON.stringify(stats)}`);
  recordRun(outPath, {
    stage: 'extract',
    mode: 'first-run',
    catalog: working.catalog,
    files: { blueprint: { path: path.basename(outPath), schemaVersion: '1', requirements: working.requirements.length } },
    note: `first run: ${working.requirements.length} requirements, ${working.questions.length} questions`
  });
}

async function main(argv) {
  const args = parseArgs(argv);
  const mode = value(args, 'mode') || (value(args, 'existing') ? 'proposals' : 'first-run');
  if (!MODES.includes(mode)) {
    console.error(`Unknown --mode ${mode}`);
    fail(2, USAGE);
  }
  const required = mode === 'proposals'
    ? ['extract', 'blocks', 'estimating', 'existing', 'out']
    : ['extract', 'blocks', 'estimating', 'project-id', 'project-name', 'out'];
  for (const key of required) {
    if (!value(args, key)) {
      console.error(`Missing --${key}`);
      fail(2, USAGE);
    }
  }

  const extract = readJson(args.extract);
  if (!isObject(extract) || !Array.isArray(extract.requirements)) {
    fail(1, `${path.resolve(args.extract)}: expected an object with a requirements array.`);
  }
  const inputs = {
    extract,
    blocks: readJson(args.blocks),
    catalogMd: fs.readFileSync(path.resolve(args.estimating), 'utf8'),
    sources: value(args, 'sources') ? readJson(args.sources) : undefined,
    outPath: path.resolve(args.out),
    runId: value(args, 'run-id')
  };

  if (mode === 'proposals') {
    await runProposalsMode(args, inputs);
  } else {
    await runFirstMode(args, inputs);
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv).catch((error) => {
    console.error(`assemble-working-file: ${error.message}`);
    process.exit(1);
  });
}
