/**
 * The quantity the estimate takes from a requirement: the first number in the statement. This was the rule of
 * the Blueprint web part's Build (cms-estimator, buildEstimate.ts, extractDriverQuantity); the lean fork has
 * no web part, so this file is now the only copy. The ranking of questions, the design sketch comparison and
 * the back-test all read a statement the way the estimate does. Since stage 3 the estimate sizes a package from
 * its workstream volume (estimate-model.mjs), and the ranking and the back-test read the workstreams when a
 * plan has them. This rule is what is left for a file with no workstreams, and for the design sketch
 * comparison, which runs before the estimate exists.
 *
 * This is deliberately NOT the number reader of assemble-drivers.mjs (`numbersIn`). That one checks that a
 * quote backs a figure, so it also reads number words and rejects labels such as "Q4"; this one copies what
 * Build does, even where Build is naive ("Q4" gives 4, and a number word gives nothing).
 * Do not make one follow the other: the gap between them is what the design sketch comparison shows.
 */

export const NUMBER_IN_TEXT = /(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?/;

/** The first number in the text, as a positive number, or undefined. Words ("four") do not count. */
export function statedQuantity(statement) {
  const match = NUMBER_IN_TEXT.exec(String(statement || ''));
  if (!match) {
    return undefined;
  }
  const parsed = Number(match[0].replace(/,/g, ''));
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Quantity per work package as Build would size it from the requirement text alone: the first number of
 * each live requirement, summed per package. A requirement the estimator dismissed is not read.
 * @param {unknown[]} requirements
 * @returns {Record<string, number>}
 */
export function extractedQuantities(requirements) {
  const byPackage = {};
  for (const row of Array.isArray(requirements) ? requirements : []) {
    if (!isObject(row) || typeof row.statement !== 'string' || (isObject(row.review) && row.review.status === 'dismissed')) {
      continue;
    }
    const quantity = statedQuantity(row.statement);
    if (quantity !== undefined && typeof row.workPackage === 'string' && row.workPackage !== 'unmapped' && /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(row.workPackage)) {
      byPackage[row.workPackage] = (byPackage[row.workPackage] || 0) + quantity;
    }
  }
  return byPackage;
}
