/**
 * Capability derivation from the estimating catalog Capabilities table.
 * Ported from .cdk/SPMVP-008/to-working-file.mjs.
 */

const CAP_ROW = /^\| `([a-z][a-z0-9-]*)` \| (all|aem|aem-eds) \| ([^|]+) \|/;
/** Activities table only — anchored on phase and shape, which no other table has. */
const WP_ROW =
  /^\| `([a-z][a-z0-9-]*)` \| [^|]+ \| (?:Discover|Design|Build|Assure|Launch|Run) \| (?:per-unit|tiered|proportional) \| [^|]+ \| [^|]+ \| (?:us|shared) \| (accelerated|partly|human-led) \|/;

/**
 * The `key: value` lines of a markdown file's front matter, trimmed. The one parser the estimating
 * catalog's pins go through: prepare-folder, the pack build and the assembler all read them from here.
 * @param {string} markdown
 * @returns {Record<string, string>}
 */
export function frontMatterPairs(markdown) {
  const pairs = {};
  const match = /^---\r?\n([\s\S]*?)\r?\n---/.exec(markdown);
  if (!match) {
    return pairs;
  }
  for (const line of match[1].split(/\r?\n/)) {
    const pair = /^(\w+):\s*(.+)$/.exec(line.trim());
    if (pair) {
      pairs[pair[1]] = pair[2].trim();
    }
  }
  return pairs;
}

/**
 * The pins the estimating catalog carries: its version (a leading `v` is dropped) and the CMK and toolkit
 * commits it was written against. Keys are absent when the front matter has no such line.
 * @param {string} markdown
 * @returns {{ estimatingVersion?: string, cmkCommit?: string, toolkitCommit?: string }}
 */
export function catalogPins(markdown) {
  const pairs = frontMatterPairs(markdown);
  const pins = {};
  if (pairs.version) {
    pins.estimatingVersion = pairs.version.replace(/^v/i, '');
  }
  if (pairs.cmkCommit) {
    pins.cmkCommit = pairs.cmkCommit;
  }
  if (pairs.toolkitCommit) {
    pins.toolkitCommit = pairs.toolkitCommit;
  }
  return pins;
}

/**
 * @param {string} catalogMd
 * @returns {{
 *   capabilities: Map<string, { all: string[], aem: string[], 'aem-eds': string[] }>,
 *   workPackages: Set<string>,
 *   defaults: Map<string, string>,
 *   estimatingVersion: string|undefined,
 *   cmkCommit: string|undefined,
 *   toolkitCommit: string|undefined
 * }}
 */
export function parseEstimatingCatalog(catalogMd) {
  const capabilities = new Map();
  const workPackages = new Set();
  const defaults = new Map();
  const { estimatingVersion, cmkCommit, toolkitCommit } = catalogPins(catalogMd);

  for (const line of catalogMd.split(/\r?\n/)) {
    const wp = WP_ROW.exec(line);
    if (wp) {
      workPackages.add(wp[1]);
      defaults.set(wp[1], wp[2]);
    }
    const m = CAP_ROW.exec(line);
    if (!m) {
      continue;
    }
    const [, id, platform, cell] = m;
    workPackages.add(id);
    if (!capabilities.has(id)) {
      capabilities.set(id, { all: [], aem: [], 'aem-eds': [] });
    }
    if (cell.trim() === '—') {
      continue;
    }
    const ids = [...cell.matchAll(/`([^`]+)`/g)].map((x) => x[1].replace(/\s*\(opt-in\)$/, ''));
    capabilities.get(id)[platform].push(...ids);
  }

  return { capabilities, workPackages, defaults, estimatingVersion, cmkCommit, toolkitCommit };
}

/**
 * @param {Map<string, { all: string[], aem: string[], 'aem-eds': string[] }>} caps
 * @param {string} wp
 * @param {string|undefined|null} platform
 * @returns {string[]}
 */
export function capabilitiesFor(caps, wp, platform) {
  const row = caps.get(wp);
  if (!row) {
    return [];
  }
  const platformKey = platform === 'aem' || platform === 'aem-eds' ? platform : null;
  const seen = new Set();
  const out = [];
  for (const id of [...row.all, ...(platformKey ? row[platformKey] : [])]) {
    if (!seen.has(id)) {
      seen.add(id);
      out.push(id);
    }
  }
  return out;
}

/**
 * @param {string[]} ids
 * @param {Set<string>} known
 * @returns {{ kept: string[], dropped: string[] }}
 */
export function filterKnownCapabilities(ids, known) {
  const kept = [];
  const dropped = [];
  for (const id of ids) {
    if (known.has(id)) {
      kept.push(id);
    } else {
      dropped.push(id);
    }
  }
  return { kept, dropped };
}

/**
 * Collect every capability id that appears in the Capabilities table.
 * @param {Map<string, { all: string[], aem: string[], 'aem-eds': string[] }>} caps
 * @returns {Set<string>}
 */
export function allCatalogCapabilityIds(caps) {
  const known = new Set();
  for (const row of caps.values()) {
    for (const id of [...row.all, ...row.aem, ...row['aem-eds']]) {
      known.add(id);
    }
  }
  return known;
}
