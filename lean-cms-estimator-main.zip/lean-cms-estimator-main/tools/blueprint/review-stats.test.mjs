import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { findProjectFolders, formatMarkdown, groupOf, reviewStats, suppressionFile } from './review-stats.mjs';
import { validateSuppress } from './suppression.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'review-stats.mjs');
const matchScript = path.join(root, 'tools', 'blueprint', 'match-library.mjs');
const gapScript = path.join(root, 'tools', 'blueprint', 'gap-sweep.mjs');

function item(id, status, extra = {}) {
  return { id, statement: `Statement ${id}`, review: { status }, ...extra };
}

function project(id, context, proposals) {
  return { id, context: { schemaVersion: '2', ...context }, ...(proposals ? { proposals: { proposals } } : {}) };
}

test('an item is grouped by library id, else by a tool marker, else not at all', () => {
  assert.deepEqual(groupOf({ libraryId: ' AS-LIB-1 ', source: 'Gap sweep checklist content-model' }), { family: 'library', key: 'AS-LIB-1' });
  assert.deepEqual(groupOf({ source: 'Gap sweep checklist content-model' }), { family: 'gap-sweep', key: 'Gap sweep checklist content-model' });
  assert.deepEqual(groupOf({ source: 'Lever advice aem-eds-page-import' }), { family: 'lever-advice', key: 'Lever advice aem-eds-page-import' });
  assert.deepEqual(groupOf({ source: 'Second opinion integrations' }), { family: 'second-opinion', key: 'Second opinion integrations' });
  assert.equal(groupOf({ source: 'RFP section 4' }), undefined);
  assert.equal(groupOf({}), undefined);
});

test('rates count accepted and edited as kept, dismissed as rejected, and leave pending out', () => {
  const report = reviewStats([
    project('a', { assumptions: [item('AS-001', 'accepted', { libraryId: 'L1' })], dependencies: [item('DP-001', 'pending', { libraryId: 'L2' })] }),
    project('b', { assumptions: [item('AS-001', 'edited', { libraryId: 'L1' })] }),
    project('c', { assumptions: [item('AS-001', 'dismissed', { libraryId: 'L1' })] })
  ]);
  const l1 = report.items.find((row) => row.key === 'L1');
  assert.deepEqual(
    { projects: l1.projects, decided: l1.decided, kept: l1.kept, edited: l1.edited, rejected: l1.rejected, keptRate: l1.keptRate, rejectRate: l1.rejectRate },
    { projects: 3, decided: 3, kept: 1, edited: 1, rejected: 1, keptRate: 0.67, rejectRate: 0.33 }
  );
  const l2 = report.items.find((row) => row.key === 'L2');
  assert.equal(l2.pending, 1);
  assert.equal(l2.decided, 0);
  assert.equal(l2.rejectRate, null);
});

test('proposal kinds report applied and rejected', () => {
  const report = reviewStats([
    project('a', {}, [
      { kind: 'add', review: { status: 'applied' } },
      { kind: 'add', review: { status: 'rejected' } },
      { kind: 'update', review: { status: 'pending' } }
    ]),
    project('b', {}, [{ kind: 'add', review: { status: 'rejected' } }])
  ]);
  const add = report.proposalKinds.find((row) => row.kind === 'add');
  assert.deepEqual({ projects: add.projects, kept: add.kept, rejected: add.rejected, rejectRate: add.rejectRate }, { projects: 2, kept: 1, rejected: 2, rejectRate: 0.67 });
  assert.equal(report.proposalKinds.find((row) => row.kind === 'update').pending, 1);
});

function rejectedIn(count, key, decided = 1) {
  return Array.from({ length: count }, (_, index) => project(`p${key}${index}`, {
    assumptions: Array.from({ length: decided }, (_, n) => item(`AS-00${n + 1}`, 'dismissed', { libraryId: key }))
  }));
}

test('an item is suppressed only with enough decisions, enough projects and a high enough rejection rate', () => {
  const keep = reviewStats([
    ...rejectedIn(3, 'REJECTED'),
    project('x', { assumptions: [item('AS-001', 'accepted', { libraryId: 'MIXED' })] }),
    project('y', { assumptions: [item('AS-001', 'dismissed', { libraryId: 'MIXED' })] }),
    project('z', { assumptions: [item('AS-001', 'accepted', { libraryId: 'MIXED' })] })
  ]);
  assert.deepEqual(keep.suppress.map((entry) => entry.key), ['REJECTED']);

  const oneProject = reviewStats([project('only', { assumptions: [1, 2, 3, 4].map((n) => item(`AS-00${n}`, 'dismissed', { libraryId: 'ONE' })) })]);
  assert.deepEqual(oneProject.suppress, [], 'rejections in a single project are not a pattern');

  const twoDecisions = reviewStats(rejectedIn(2, 'FEW'));
  assert.deepEqual(twoDecisions.suppress, [], 'two decisions are below the default bar of three');
  assert.equal(reviewStats(rejectedIn(2, 'FEW'), { minDecisions: 2 }).suppress.length, 1);
});

test('only a library item, a gap or a lever advice can be suppressed; a second-opinion marker is only reported', () => {
  const projects = ['a', 'b', 'c'].map((id) => project(id, {
    deliveryUnknowns: [
      item('DU-001', 'dismissed', { source: 'Gap sweep checklist uat-support' }),
      item('DU-002', 'dismissed', { source: 'Second opinion integrations' })
    ],
    assumptions: [item('AS-001', 'dismissed', { source: 'Lever advice aem-cloud-rde' })]
  }));
  const report = reviewStats(projects);
  assert.deepEqual(
    report.suppress.map((entry) => `${entry.family}:${entry.key}`).sort(),
    ['gap-sweep:Gap sweep checklist uat-support', 'lever-advice:Lever advice aem-cloud-rde']
  );
  assert.ok(report.items.some((row) => row.family === 'second-opinion'));
});

test('an accepted unchanged statement in several projects is a library candidate; the suppression file never holds it', () => {
  const same = (id) => project(id, { assumptions: [{ id: 'AS-001', statement: 'The client supplies the Figma  designs.', review: { status: 'accepted' } }] });
  const report = reviewStats([same('a'), { ...same('b'), context: { schemaVersion: '2', assumptions: [{ id: 'AS-004', statement: 'the client supplies the figma designs', review: { status: 'accepted' } }] } }, project('c', { assumptions: [item('AS-001', 'accepted')] })]);
  assert.equal(report.libraryCandidates.length, 1);
  assert.equal(report.libraryCandidates[0].projects, 2);
  const file = suppressionFile(report);
  assert.doesNotMatch(JSON.stringify(file), /Figma/i);
  assert.deepEqual(validateSuppress(file), []);
});

test('validateSuppress names the field that is wrong', () => {
  const errors = validateSuppress({ schemaVersion: '2', items: [{ key: '', family: 'second-opinion' }] });
  assert.ok(errors.some((message) => message.startsWith('schemaVersion')));
  assert.ok(errors.some((message) => message.startsWith('items[0].key')));
  assert.ok(errors.some((message) => message.startsWith('items[0].family')));
});

test('the markdown report lists items, kinds, what to stop proposing and the library candidates', () => {
  const text = formatMarkdown(reviewStats(rejectedIn(3, 'REJECTED')));
  assert.match(text, /## Review decisions across 3 projects/);
  assert.match(text, /Stop proposing/);
  assert.match(text, /`REJECTED` \(library\): rejected 3 of 3 in 3 projects/);
});

function writeProject(dir, name, context, proposals) {
  const folder = path.join(dir, name);
  fs.mkdirSync(folder, { recursive: true });
  fs.writeFileSync(path.join(folder, `${name}_Context.json`), JSON.stringify({ meta: { schemaVersion: '2' }, ...context }));
  if (proposals) {
    fs.writeFileSync(path.join(folder, `${name}_Proposals.json`), JSON.stringify({ proposals }));
  }
  return folder;
}

test('the command reads a folder of project folders, skips an unusable file with a warning, and writes the suppression file', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'review-stats-'));
  try {
    for (const name of ['One', 'Two', 'Three']) {
      writeProject(dir, name, { assumptions: [{ id: 'AS-001', statement: 'S', libraryId: 'LIB-X', review: { status: 'dismissed' } }] }, [{ kind: 'add', review: { status: 'rejected' } }]);
    }
    const broken = path.join(dir, 'Broken');
    fs.mkdirSync(broken);
    fs.writeFileSync(path.join(broken, 'Broken_Context.json'), '{ nope');
    assert.deepEqual(findProjectFolders(dir).map((folder) => path.basename(folder)).sort(), ['Broken', 'One', 'Three', 'Two']);

    const out = path.join(dir, 'team', 'suppress.json');
    const run = spawnSync(process.execPath, [script, dir, '--suppress-out', out], { encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.match(run.stderr, /warning: .*Broken_Context\.json is not valid JSON/);
    const report = JSON.parse(run.stdout);
    assert.equal(report.projects, 3);
    assert.equal(report.proposalKinds.find((row) => row.kind === 'add').rejected, 3);
    const file = JSON.parse(fs.readFileSync(out, 'utf8'));
    assert.deepEqual(file.items.map((entry) => `${entry.family}:${entry.key}`), ['library:LIB-X']);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('the command exits 2 on bad usage and 1 when no project is found', () => {
  assert.equal(spawnSync(process.execPath, [script], { encoding: 'utf8' }).status, 2);
  assert.equal(spawnSync(process.execPath, [script, '.', '--reject-rate', '2'], { encoding: 'utf8' }).status, 2);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'review-stats-empty-'));
  try {
    assert.equal(spawnSync(process.execPath, [script, dir], { encoding: 'utf8' }).status, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('match-library and gap-sweep leave out what a suppression file lists', () => {
  const blueprint = path.join(root, 'samples', 'offline', 'Synthetic_AEM_Blueprint.json');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'suppress-'));
  try {
    const before = JSON.parse(spawnSync(process.execPath, [matchScript, blueprint], { encoding: 'utf8' }).stdout);
    const target = before.assumptions.entries[0];
    assert.ok(target, 'the sample matches at least one assumption');
    const file = path.join(dir, 'suppress.json');
    fs.writeFileSync(file, JSON.stringify({
      schemaVersion: '1',
      items: [{ key: target.libraryId, family: 'library' }, { key: 'Gap sweep checklist content-model', family: 'gap-sweep' }]
    }));
    const after = JSON.parse(spawnSync(process.execPath, [matchScript, blueprint, '--suppress', file], { encoding: 'utf8' }).stdout);
    assert.equal(after.assumptions.entries.some((entry) => entry.libraryId === target.libraryId), false);
    assert.ok(after.assumptions.suppressed > before.assumptions.suppressed);
    assert.equal(after.assumptions.skipped, before.assumptions.skipped);
    assert.deepEqual(after.existingUnmatched, []);

    const gapBefore = JSON.parse(spawnSync(process.execPath, [gapScript, blueprint], { encoding: 'utf8' }).stdout);
    const gapAfter = JSON.parse(spawnSync(process.execPath, [gapScript, blueprint, '--suppress', file], { encoding: 'utf8' }).stdout);
    const wasGap = gapBefore.gaps.some((gap) => gap.workPackageId === 'content-model');
    assert.equal(gapAfter.gaps.some((gap) => gap.workPackageId === 'content-model'), false);
    if (wasGap) {
      assert.ok(gapAfter.suppressed.includes('content-model'));
      assert.deepEqual(gapAfter.alreadyProposed, gapBefore.alreadyProposed);
    }

    fs.writeFileSync(file, JSON.stringify({ schemaVersion: '9', items: [] }));
    assert.equal(spawnSync(process.execPath, [matchScript, blueprint, '--suppress', file], { encoding: 'utf8' }).status, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('a project is one vote for a key, however many of its items carry the key', () => {
  const both = (status) => project('p', {
    deliveryUnknowns: [item('DU-001', status, { source: 'Gap sweep checklist content-model' })],
    assumptions: [item('AS-001', status, { source: 'Gap sweep checklist content-model' })]
  });
  const one = reviewStats([both('dismissed')]);
  assert.equal(one.suppress.length, 0, 'one project is not a pattern, even with two items');
  const report = reviewStats([
    { ...both('dismissed'), id: 'a' },
    { ...both('dismissed'), id: 'b' },
    { ...both('dismissed'), id: 'c' }
  ], { minDecisions: 3 });
  assert.deepEqual(report.suppress.map((entry) => [entry.key, entry.decided, entry.rejected, entry.projects]), [['Gap sweep checklist content-model', 3, 3, 3]]);
  const twoProjects = reviewStats([{ ...both('dismissed'), id: 'a' }, { ...both('dismissed'), id: 'b' }], { minDecisions: 3 });
  assert.deepEqual(twoProjects.suppress, [], 'two projects with two items each are two decisions, not four');
});

test('a rejected item in a project outweighs a kept one with the same key', () => {
  const report = reviewStats([
    project('a', { deliveryUnknowns: [item('DU-001', 'accepted', { source: 'Lever advice x' })], assumptions: [item('AS-001', 'dismissed', { source: 'Lever advice x' })] }),
    project('b', { assumptions: [item('AS-001', 'dismissed', { source: 'Lever advice x' })] })
  ], { minDecisions: 2, minProjects: 2 });
  assert.equal(report.suppress[0].rejected, 2);
});

test('the suppression file keeps keys written earlier and copies no other field', () => {
  const report = reviewStats(rejectedIn(3, 'NEW'));
  const previous = {
    schemaVersion: '1',
    items: [
      { key: 'OLD', family: 'library', decided: 4, rejected: 4, projects: 3, statement: 'client text' },
      { key: 'NEW', family: 'library', decided: 1, rejected: 1, projects: 1 }
    ]
  };
  const file = suppressionFile(report, previous);
  assert.deepEqual(file.items.map((entry) => entry.key), ['NEW', 'OLD']);
  assert.equal(file.items.find((entry) => entry.key === 'NEW').decided, 3, 'the fresh figures win');
  assert.equal(JSON.stringify(file).includes('client text'), false);
});

test('the command extends an existing suppression file, reports skipped projects and refuses a broken file', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'stats-'));
  try {
    for (const name of ['a', 'b', 'c']) {
      fs.mkdirSync(path.join(dir, name));
      fs.writeFileSync(path.join(dir, name, `${name}_Context.json`), JSON.stringify({
        schemaVersion: '2', assumptions: [item('AS-001', 'dismissed', { libraryId: 'LIB-X' })]
      }));
    }
    fs.mkdirSync(path.join(dir, 'broken'));
    fs.writeFileSync(path.join(dir, 'broken', 'broken_Context.json'), '{ nope');
    const out = path.join(dir, 'suppress.json');
    fs.writeFileSync(out, JSON.stringify({ schemaVersion: '1', items: [{ key: 'EARLIER', family: 'library' }] }));
    const run = spawnSync(process.execPath, [script, dir, '--suppress-out', out], { encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.equal(JSON.parse(run.stdout).skippedProjects, 1);
    assert.deepEqual(JSON.parse(fs.readFileSync(out, 'utf8')).items.map((entry) => entry.key).sort(), ['EARLIER', 'LIB-X']);
    fs.writeFileSync(out, '{ nope');
    const refused = spawnSync(process.execPath, [script, dir, '--suppress-out', out], { encoding: 'utf8' });
    assert.equal(refused.status, 1);
    assert.equal(fs.readFileSync(out, 'utf8'), '{ nope');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
