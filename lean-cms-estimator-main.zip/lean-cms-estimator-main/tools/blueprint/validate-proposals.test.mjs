import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { collectProposalWarnings, validateProposalsValue } from './validate-proposals.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'validate-proposals.mjs');
const scratch = mkdtempSync(join(tmpdir(), 'proposals-val-'));
const fixture = JSON.parse(readFileSync(join(root, 'tools/blueprint/fixtures/proposals-validator-cases.json'), 'utf8'));

after(() => rmSync(scratch, { recursive: true, force: true }));

function run(args) {
  return spawnSync(process.execPath, [script, ...args], { cwd: root, encoding: 'utf8' });
}

describe('validate-proposals shared cases', () => {
  it('has unique case names', () => {
    const names = fixture.cases.map((c) => c.name);
    assert.deepEqual(names.filter((n, i) => names.indexOf(n) !== i), []);
  });

  for (const c of fixture.cases) {
    it(c.name, () => {
      assert.deepEqual(validateProposalsValue(c.value), c.errors);
    });
  }

  it('prefixes a base path', () => {
    assert.deepEqual(validateProposalsValue({ proposals: 1 }, 'x.'), [
      'x.schemaVersion: expected "1"',
      'x.projectId: expected string',
      'x.projectName: expected string',
      'x.blueprintRevision: expected non-negative integer',
      'x.proposals: expected array'
    ]);
  });
});

describe('validate-proposals warnings', () => {
  const valid = fixture.cases.find((c) => c.name === 'update and conflict proposals are valid with a target and a snapshot').value;

  it('names a target that is not in the Blueprint and a source that is in neither file', () => {
    const warnings = collectProposalWarnings(valid, {
      requirements: [{ id: 'R-003' }],
      sources: [{ itemId: 'src-addendum' }]
    });
    assert.deepEqual(warnings, [
      'proposals[1].requirementId: R-004 is not in the Blueprint',
      'proposals[1].sources[0].itemId: src-deck is in neither the Blueprint nor this file\'s sources'
    ]);
  });

  it('accepts a source listed in the proposals file itself', () => {
    const warnings = collectProposalWarnings({ ...valid, sources: [{ itemId: 'src-deck', name: 'Deck.pptx' }] }, {
      requirements: [{ id: 'R-003' }, { id: 'R-004' }],
      sources: [{ itemId: 'src-addendum' }]
    });
    assert.deepEqual(warnings, []);
  });

  it('does not throw on a Blueprint that is null, an array or a string', () => {
    for (const blueprint of [null, [], 'x', 3]) {
      const warnings = collectProposalWarnings(valid, blueprint);
      assert.equal(warnings.length, 1);
      assert.match(warnings[0], /^blueprint: expected a Blueprint object/);
    }
    // Fields of the wrong type count as empty: both targets and both cited files are then unknown.
    assert.equal(collectProposalWarnings(valid, { requirements: 'x', sources: null, questions: 5 }).length, 4);
  });

  it('names a different project, a different revision and a pending snapshot that has gone stale', () => {
    const pending = {
      ...valid,
      proposals: [{ ...valid.proposals[0], review: { status: 'pending' } }]
    };
    const live = {
      projectId: 'p1',
      revision: 1,
      sources: [{ itemId: 'src-addendum' }],
      requirements: [{ id: 'R-003', statement: 'Migrate 6,400 pages.', workPackage: 'content-migration', coverage: 'accelerated', review: { status: 'accepted' } }],
      questions: []
    };
    assert.deepEqual(collectProposalWarnings(pending, live), []);
    const moved = collectProposalWarnings(pending, {
      ...live,
      projectId: 'other',
      revision: 4,
      requirements: [{ ...live.requirements[0], statement: 'Migrate 6,000 pages.', review: { status: 'edited' } }]
    });
    assert.deepEqual(moved, [
      'projectId: "p1" does not match the Blueprint\'s "other"',
      'blueprintRevision: 1 but the Blueprint is at revision 4',
      'proposals[0].existing: R-003 has changed since the agent read it (statement, reviewStatus)'
    ]);
    // A decided proposal is history: the row is expected to differ from the old snapshot.
    assert.deepEqual(collectProposalWarnings(valid, { ...live, requirements: [{ ...live.requirements[0], statement: 'changed' }, { id: 'R-004' }], sources: [{ itemId: 'src-addendum' }, { itemId: 'src-deck' }] }), []);
  });

  it('does not change or drop unknown fields while validating', () => {
    const kept = fixture.cases.find((c) => c.preserved);
    assert.ok(kept, 'the fixture has a case that names the fields to keep');
    const value = JSON.parse(JSON.stringify(kept.value));
    assert.deepEqual(validateProposalsValue(value), kept.errors);
    assert.deepEqual(value, kept.value, 'validation does not touch the value');
    for (const key of kept.preserved.root) {
      assert.notEqual(value[key], undefined, key);
    }
    for (const key of kept.preserved.proposal) {
      assert.notEqual(value.proposals[0][key], undefined, key);
    }
  });
});

describe('validate-proposals staleness shared cases', () => {
  const staleness = JSON.parse(readFileSync(join(root, 'tools/blueprint/fixtures/proposals-staleness-cases.json'), 'utf8'));

  it('has unique case names', () => {
    const names = staleness.cases.map((c) => c.name);
    assert.deepEqual(names.filter((n, i) => names.indexOf(n) !== i), []);
    assert.ok(names.length >= 8);
  });

  for (const c of staleness.cases) {
    it(c.name, () => {
      const proposals = {
        proposals: [{ kind: 'update', requirementId: c.row.id, existing: c.existing, sources: [], review: { status: 'pending' } }]
      };
      const warnings = collectProposalWarnings(proposals, { requirements: [c.row], questions: c.questions, sources: [] });
      if (c.changed.length === 0) {
        assert.deepEqual(warnings, []);
      } else {
        assert.deepEqual(warnings, [`proposals[0].existing: ${c.row.id} has changed since the agent read it (${c.changed.join(', ')})`]);
      }
    });
  }
});

describe('validate-proposals CLI', () => {
  it('accepts the committed sample with its Blueprint', () => {
    const result = run(['samples/agent-run/Fabrikam Outdoor_Proposals.json', '--blueprint', 'samples/agent-run/Fabrikam Outdoor_Blueprint.json']);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /^OK: Fabrikam Outdoor_Proposals\.json \(\d+ proposals, \d+ pending\)/);
    assert.equal(result.stderr, '');
  });

  it('exits 1 with field paths for a malformed file', () => {
    const file = join(scratch, 'bad.json');
    writeFileSync(file, JSON.stringify({ schemaVersion: '1', projectId: 'p', projectName: 'n', blueprintRevision: 0, proposals: [{}] }));
    const result = run([file]);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /proposals\[0\]\.id: expected P-###/);
  });

  it('exits 2 on usage errors', () => {
    assert.equal(run([]).status, 2);
    assert.equal(run([join(scratch, 'missing.json')]).status, 2);
    const sample = 'samples/agent-run/Fabrikam Outdoor_Proposals.json';
    assert.equal(run([sample, '--nope']).status, 2, 'unknown flag');
    assert.equal(run([sample, '--blueprint']).status, 2, 'flag without a value');
    assert.equal(run([sample, '--strict']).status, 2, '--strict needs --blueprint');
  });

  it('prints cross-file problems as warnings, and as errors with --strict', () => {
    const blueprint = JSON.parse(readFileSync(join(root, 'samples/agent-run/Fabrikam Outdoor_Blueprint.json'), 'utf8'));
    blueprint.projectId = 'someone-else';
    const blueprintPath = join(scratch, 'other_Blueprint.json');
    writeFileSync(blueprintPath, JSON.stringify(blueprint));
    const sample = 'samples/agent-run/Fabrikam Outdoor_Proposals.json';

    const loose = run([sample, '--blueprint', blueprintPath]);
    assert.equal(loose.status, 0, loose.stderr);
    assert.match(loose.stderr, /^warning: projectId: /m);

    const strict = run([sample, '--blueprint', blueprintPath, '--strict']);
    assert.equal(strict.status, 1);
    assert.match(strict.stderr, /^error: projectId: /m);
    assert.equal(strict.stdout, '');

    const clean = run([sample, '--blueprint', 'samples/agent-run/Fabrikam Outdoor_Blueprint.json', '--strict']);
    assert.equal(clean.status, 0, clean.stderr);
  });

  it('survives a Blueprint that is not an object', () => {
    const blueprintPath = join(scratch, 'null_Blueprint.json');
    writeFileSync(blueprintPath, 'null');
    const result = run(['samples/agent-run/Fabrikam Outdoor_Proposals.json', '--blueprint', blueprintPath]);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stderr, /warning: blueprint: expected a Blueprint object/);
  });
});
