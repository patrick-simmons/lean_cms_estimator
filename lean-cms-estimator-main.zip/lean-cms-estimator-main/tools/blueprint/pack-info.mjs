/**
 * Where this copy of the tools lives and what version it carries.
 *
 * Two layouts exist. In the repository, `tools/blueprint/` sits beside `tools/release/pack.config.json`,
 * `docs/catalogs/` and `samples/factors/seed/`. In a built skill pack (tools/release/build-skill-pack.mjs)
 * the same relative layout is kept under the pack root, and `pack.json` at that root records the
 * version, commit and catalog pins the pack was built with.
 */
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

/** The folder that holds `tools/`, `docs/` and `samples/`: the repo root or the pack root. */
export const PACK_ROOT = join(here, '../..');

/**
 * @returns {{ layout: 'pack'|'repo', root: string, name: string, version: string, commit?: string,
 *   builtAt?: string, parseToolVersion: string, schemas: Record<string, string>, catalogs?: object }}
 */
export function packInfo() {
  const packJson = join(PACK_ROOT, 'pack.json');
  if (existsSync(packJson)) {
    const pack = readJsonFile(packJson);
    // A pack.json written by the pack build names the pack and its version; any other file of that name is not one.
    if (typeof pack.name === 'string' && typeof pack.version === 'string') {
      return { ...pack, layout: 'pack', root: PACK_ROOT };
    }
  }
  const config = readJsonFile(join(PACK_ROOT, 'tools/release/pack.config.json'));
  return { ...config, layout: 'repo', root: PACK_ROOT };
}

function readJsonFile(file) {
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Error(`${file} could not be read as JSON: ${error.message}`);
  }
}

/** Repo or pack path of a resource the skills cite, for example `docs/catalogs/estimating-catalog.md`. */
export function resource(relativePath) {
  return join(PACK_ROOT, relativePath);
}
