import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { checkObjection, compareReads, formatMarkdown, objectionSource, OBJECTION_CATEGORIES, packageSource } from './second-opinion.mjs';
import { DEFAULT_CATALOG, parseActivities, rankQuestions } from './rank-questions.mjs';
import { validateContextValue } from './validate-context.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'second-opinion.mjs');
const workPackages = parseActivities(fs.readFileSync(DEFAULT_CATALOG, 'utf8'));
const evalFile = (name) => path.join(root, 'samples', 'eval', name);
const sampleBlueprint = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json');
const sampleBlocks = path.join(root, 'samples', 'agent-run', '.blueprint', 'parsed', 'blocks.json');

const blocks = [
  { id: 'b1', text: 'Product data from the PIM through a nightly feed. The redirect map needs approval from marketing.' },
  { id: 'b2', text: 'Four locales at launch.' }
];
const blueprint = {
  requirements: [
    { id: 'R-1', workPackage: 'integrations', coverage: 'accelerated', statement: 'Integrate the PIM' },
    { id: 'R-2', workPackage: 'integrations', coverage: 'human-led', statement: 'Integrate the CRM' },
    { id: 'R-3', workPackage: 'localization', coverage: 'accelerated', statement: 'Four locales', review: { status: 'dismissed' } },
    { id: 'R-4', workPackage: 'multisite', coverage: 'accelerated', statement: 'Sites' }
  ]
};

function sketch(...drivers) {
  return { drivers: drivers.map(([workPackageId, quantity]) => ({ workPackageId, quantity })) };
}

function objection(extra = {}) {
  return { requirementId: 'R-1', category: 'custom-integration', reason: 'The feed is built for this client.', blockIds: ['b1'], quote: 'a nightly feed', ...extra };
}

function compare(first, second, extra = {}) {
  return compareReads({ blueprint, first, second, blocks, workPackages, ...extra });
}

test('the categories are named, and no category text states a duration', () => {
  assert.ok(Object.keys(OBJECTION_CATEGORIES).length >= 5);
  for (const text of Object.values(OBJECTION_CATEGORIES)) {
    assert.doesNotMatch(text, /\d|\b(hours?|weeks?|days?)\b/i);
  }
});

test('equal counts agree, different counts disagree, and a count in one read only is one-sided', () => {
  const result = compare(sketch(['integrations', 4], ['content-migration', 100], ['multisite', 3]), sketch(['integrations', 3], ['content-migration', 100], ['localization', 4]));
  assert.deepEqual(result.agree, [{ workPackageId: 'content-migration', quantity: 100 }]);
  assert.deepEqual(result.disagree.map((item) => [item.workPackageId, item.first, item.second]), [['integrations', 4, 3]]);
  assert.deepEqual(result.oneSided.map((item) => [item.workPackageId, item.side, item.quantity]), [['localization', 'second', 4], ['multisite', 'first', 3]]);
});

test('each disagreement comes with a pending unknown that names the counts, cites the package and links the live rows', () => {
  const result = compare(sketch(['integrations', 4]), sketch(['integrations', 3]));
  const { unknown } = result.disagree[0];
  assert.match(unknown.statement, /count 4 and 3 integrations for Integrations \(integrations\)/);
  assert.equal(unknown.source, packageSource('integrations'));
  assert.deepEqual(unknown.refs, ['R-1', 'R-2']);
  assert.deepEqual(unknown.review, { status: 'pending' });
  const dismissed = compare(sketch(['localization', 4]), sketch(['localization', 5]));
  assert.equal(dismissed.disagree[0].unknown.refs, undefined, 'a dismissed row is not linked');
});

test('a gap already in the sidecar is not proposed again, whatever its review status', () => {
  const result = compare(sketch(['integrations', 4]), sketch(['integrations', 3]), { existingSources: [packageSource('integrations').toUpperCase()] });
  assert.deepEqual(result.disagree, []);
  assert.deepEqual(result.alreadyProposed, ['integrations']);
});

test('an objection is kept for a live accelerated requirement with a quote that is in the cited block', () => {
  const result = compare(sketch(), sketch(), { objections: { objections: [objection()] } });
  assert.equal(result.objections.kept.length, 1);
  const [kept] = result.objections.kept;
  assert.equal(kept.workPackageId, 'integrations');
  assert.equal(kept.unknown.source, objectionSource('R-1'));
  assert.deepEqual(kept.unknown.refs, ['R-1']);
  assert.match(kept.unknown.statement, /accelerated coverage of R-1 \(integrations\) is challenged because a custom integration/);
});

test('an objection is rejected with the reason when it does not hold together', () => {
  const requirements = new Map(blueprint.requirements.map((row) => [row.id, row]));
  const texts = new Map(blocks.map((block) => [block.id, block.text.toLowerCase()]));
  const check = (extra) => checkObjection(objection(extra), { requirements, blocks: texts }).join('\n');
  assert.equal(check({}), '');
  assert.match(check({ requirementId: 'R-9' }), /not a requirement in the Blueprint/);
  assert.match(check({ requirementId: 'R-2' }), /not claimed as accelerated \(it is human-led\)/);
  assert.match(check({ requirementId: 'R-3' }), /dismissed by the estimator/);
  assert.match(check({ category: 'vibes' }), /category: expected one of/);
  assert.match(check({ reason: '' }), /reason: expected text/);
  assert.match(check({ reason: 'It will take three weeks.' }), /do not state hours, days, weeks or months/);
  assert.match(check({ blockIds: [] }), /blockIds: expected at least one/);
  assert.match(check({ blockIds: ['zz'] }), /"zz" is not in the blocks file/);
  assert.match(check({ quote: 'made up words' }), /quote: this text is not in the cited blocks/);
  assert.match(check({ blockIds: ['b2'] }), /quote: this text is not in the cited blocks/);
  assert.match(check({ quote: '' }), /quote: expected the words copied/);
  assert.deepEqual(checkObjection('x', { requirements, blocks: texts }), ['expected an object']);
});

test('a second objection for the same requirement, and one already in the sidecar, add nothing', () => {
  const twice = compare(sketch(), sketch(), { objections: { objections: [objection(), objection({ category: 'novel-work' })] } });
  assert.equal(twice.objections.kept.length, 1);
  assert.match(twice.objections.rejected[0].errors.join('\n'), /already has an objection/);
  const known = compare(sketch(), sketch(), { objections: { objections: [objection()] }, existingSources: [objectionSource('R-1')] });
  assert.equal(known.objections.kept.length, 0);
  assert.deepEqual(known.alreadyProposed, ['R-1']);
});

test('every unknown it proposes is valid Context content, and the ranking reads them', () => {
  const result = compare(sketch(['integrations', 4], ['multisite', 3]), sketch(['integrations', 3]), { objections: { objections: [objection()] } });
  const unknowns = [...result.disagree, ...result.oneSided, ...result.objections.kept].map((item, index) => ({ id: `DU-${String(index + 1).padStart(3, '0')}`, ...item.unknown }));
  assert.equal(unknowns.length, 3);
  assert.deepEqual(validateContextValue({ meta: { schemaVersion: '2', producedBy: 'skill' }, deliveryUnknowns: unknowns }), []);
  const ranked = rankQuestions(blueprint, { deliveryUnknowns: unknowns }, workPackages).ranked;
  const byId = Object.fromEntries(ranked.map((item) => [item.id, item]));
  assert.equal(byId['DU-001'].workPackageId, 'integrations');
  assert.ok(byId['DU-001'].reasons.includes('two independent reads of the documents disagree'));
  assert.ok(byId['DU-003'].reasons.includes('the accelerated coverage was challenged with a quote from the documents'));
  assert.equal(byId['DU-002'].workPackageId, 'multisite');
});

test('the report names what differs and which objections were rejected', () => {
  const result = compare(sketch(['integrations', 4]), sketch(['integrations', 3]), { objections: { objections: [objection(), objection({ requirementId: 'R-2' })] } });
  const text = formatMarkdown(result);
  assert.match(text, /integrations Integrations: 4 against 3 integrations/);
  assert.match(text, /R-1 \(integrations, custom-integration\)/);
  assert.match(text, /Objections rejected/);
  assert.match(text, /R-2: requirementId: R-2 is not claimed as accelerated/);
});

function runCli(args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

function sampleArgs(extra = []) {
  return [
    '--blueprint', sampleBlueprint,
    '--first', evalFile('synthetic-aem-design-sketch.json'),
    '--second', evalFile('synthetic-aem-second-sketch.json'),
    '--blocks', sampleBlocks,
    '--objections', evalFile('synthetic-aem-objections.json'),
    ...extra
  ];
}

test('the CLI compares the two synthetic reads', () => {
  const run = runCli(sampleArgs());
  assert.equal(run.status, 0, run.stderr);
  const result = JSON.parse(run.stdout);
  assert.deepEqual(result.agree.map((item) => item.workPackageId), ['content-migration']);
  assert.deepEqual(result.disagree.map((item) => item.workPackageId), ['integrations']);
  assert.deepEqual(result.oneSided.map((item) => item.workPackageId), ['multisite']);
  assert.deepEqual(result.objections.kept.map((item) => item.requirementId), ['R-003', 'R-004']);
  assert.deepEqual(result.objections.rejected, []);
  const markdown = runCli(sampleArgs(['--markdown']));
  assert.match(markdown.stdout, /## Second opinion/);
});

test('the CLI output is accepted by the Context validator against the Blueprint, and is not proposed twice', () => {
  const result = JSON.parse(runCli(sampleArgs()).stdout);
  const unknowns = [...result.disagree, ...result.oneSided, ...result.objections.kept].map((item, index) => ({ id: `DU-${String(index + 1).padStart(3, '0')}`, ...item.unknown }));
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'second-'));
  const context = path.join(folder, 'context.json');
  fs.writeFileSync(context, JSON.stringify({ meta: { schemaVersion: '2', producedBy: 'skill' }, deliveryUnknowns: unknowns }));
  const validate = spawnSync(process.execPath, [path.join(root, 'tools', 'blueprint', 'validate-context.mjs'), context, '--blueprint', sampleBlueprint], { encoding: 'utf8' });
  assert.equal(validate.status, 0, validate.stdout + validate.stderr);
  assert.equal(validate.stderr, '');
  const again = JSON.parse(runCli(sampleArgs(['--existing', context])).stdout);
  assert.deepEqual([again.disagree, again.oneSided, again.objections.kept], [[], [], []]);
  assert.deepEqual(again.alreadyProposed.sort(), ['R-003', 'R-004', 'integrations', 'multisite']);
});

test('the CLI exits 1 when a sketch no longer matches the blocks, and 2 for bad usage', () => {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'second-'));
  const changed = path.join(folder, 'blocks.json');
  const original = JSON.parse(fs.readFileSync(sampleBlocks, 'utf8'));
  fs.writeFileSync(changed, JSON.stringify(original.map((block) => (block.id.endsWith('x1.r1.1') ? { ...block, text: 'nothing here' } : block))));
  const run = runCli(sampleArgs().map((arg) => (arg === sampleBlocks ? changed : arg)));
  assert.equal(run.status, 1);
  assert.match(run.stderr, /\(first sketch\) drivers\[0\]/);
  assert.equal(runCli([]).status, 2);
  assert.equal(runCli(['--blueprint', sampleBlueprint]).status, 2);
  assert.equal(runCli([...sampleArgs(), '--bogus']).status, 2);
  const objections = path.join(folder, 'objections.json');
  fs.writeFileSync(objections, JSON.stringify({ nope: [] }));
  assert.equal(runCli(sampleArgs().map((arg) => (arg === evalFile('synthetic-aem-objections.json') ? objections : arg))).status, 1);
  const context = path.join(folder, 'context.json');
  fs.writeFileSync(context, JSON.stringify({ deliveryUnknowns: 'no' }));
  const bad = runCli(sampleArgs(['--existing', context]));
  assert.equal(bad.status, 1);
  assert.match(bad.stderr, /\(existing\)/);
});

test('an objection quote must be whole words from the block and at least three of them', () => {
  assert.match(checkObjection(objection({ quote: 'e' }), { requirements: new Map(blueprint.requirements.map((row) => [row.id, row])), blocks: new Map(blocks.map((block) => [block.id, block.text.toLowerCase()])) }).join('\n'), /at least 3 words/);
  const result = compare(sketch(), sketch(), { objections: { objections: [objection({ quote: 'a nightly fee' }), objection({ quote: 'a nightly feed' })] } });
  assert.equal(result.objections.rejected.length, 1);
  assert.match(result.objections.rejected[0].errors.join('\n'), /not in the cited blocks/);
  assert.equal(result.objections.kept.length, 1);
});

test('a driver the estimator dismissed in the first read does not count as a read', () => {
  const first = { drivers: [{ workPackageId: 'integrations', quantity: 4, review: { status: 'dismissed' } }] };
  const result = compare(first, sketch(['integrations', 3]));
  assert.deepEqual(result.disagree, []);
  assert.deepEqual(result.oneSided.map((item) => [item.workPackageId, item.side]), [['integrations', 'second']]);
});

test('a single unit is not pluralised in the report', () => {
  const result = compare(sketch(['multisite', 1]), sketch());
  assert.match(formatMarkdown(result), /1 site, found by the first read/);
});

test('the CLI refuses the same file as both reads', () => {
  const same = evalFile('synthetic-aem-design-sketch.json');
  const run = runCli(['--blueprint', sampleBlueprint, '--first', same, '--second', same, '--blocks', sampleBlocks]);
  assert.equal(run.status, 1);
  assert.match(run.stderr, /same file/);
});