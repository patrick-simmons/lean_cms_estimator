import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { acceptRequirements, assemblePlan, formatSummary, planFileName, summarizePlan, validatePlan } from './plan.mjs';
import { assembleDrivers } from './assemble-drivers.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'plan.mjs');
const catalogMd = fs.readFileSync(DEFAULT_CATALOG, 'utf8');
const workPackages = parseActivities(catalogMd);
const NOW = '2026-11-13T12:00:00.000Z';

const blocks = [
  {
    id: 'src-rfp#p1.1',
    itemId: 'src-rfp',
    fileName: 'RFP.docx',
    label: 'RFP p.1',
    location: { kind: 'page', page: 1 },
    text: 'The vendor shall migrate approximately 6,400 pages of content and implement 301 redirects.'
  },
  {
    id: 'src-rfp#p1.2',
    itemId: 'src-rfp',
    fileName: 'RFP.docx',
    label: 'RFP p.1',
    location: { kind: 'page', page: 1 },
    text: 'The site launches in four locales: English, German, French and Dutch.'
  },
  {
    id: 'src-deck#s2',
    itemId: 'src-deck',
    fileName: 'Deck.pptx',
    label: 'Deck slide 2',
    location: { kind: 'slide', slide: 2 },
    text: 'Launch scope: two locales at launch.'
  }
];

function requirement(statement, blockIds, workPackage, extra = {}) {
  return { statement, blockIds, workPackage, coverage: 'accelerated', question: null, duplicateOf: null, ...extra };
}

const extract = {
  requirements: [
    requirement('Migrate approximately 6,400 pages of content with 301 redirects.', ['src-rfp#p1.1'], 'content-migration', { question: 'How many pages remain in scope after clean-up?' }),
    requirement('The site launches in four locales.', ['src-rfp#p1.2'], 'localization'),
    requirement('The site launches in two locales; the RFP says four.', ['src-deck#s2', 'src-rfp#p1.2'], 'localization', { coverage: 'conflict', question: 'Two locales or four at launch?' })
  ],
  platform: { id: 'aem', blockId: 'src-rfp#p1.1' },
  notes: null
};

function sketchOf(quantity = 6400) {
  return assembleDrivers({
    drivers: [{
      workPackageId: 'content-migration',
      quantity,
      basis: 'stated',
      quote: 'migrate approximately 6,400 pages of content',
      blockIds: ['src-rfp#p1.1'],
      confidence: 'high'
    }]
  }, blocks, workPackages).sketch;
}

function build(overrides = {}) {
  return assemblePlan({ extract, blocks, catalogMd, projectName: 'Fabrikam', now: NOW, ...overrides });
}

test('a first run writes a valid plan with every requirement pending, plus questions and volumes', () => {
  const { plan, stats } = build({ sketch: sketchOf() });
  assert.deepEqual(validatePlan(plan, { blocks, workPackages }), []);
  assert.equal(plan.requirements.length, 3);
  assert.deepEqual(plan.requirements.map((row) => row.id), ['R-001', 'R-002', 'R-003']);
  assert.ok(plan.requirements.every((row) => row.review.status === 'pending'));
  assert.equal(plan.questions.length, 2);
  assert.equal(plan.volumes.length, 1);
  assert.equal(plan.volumes[0].id, 'D-001');
  assert.equal(plan.volumes[0].review.status, 'pending');
  assert.equal(plan.platform.id, 'aem');
  assert.deepEqual(plan.sources.map((source) => source.itemId).sort(), ['src-deck', 'src-rfp']);
  assert.deepEqual([plan.skills, plan.workstreams, plan.aiPlan], [[], [], null]);
  assert.equal(stats.addedRequirements, 3);
});

test('requirements and questions keep the names the carried-over tools read', () => {
  const { plan } = build();
  const row = plan.requirements[0];
  assert.equal(row.questionId, 'Q1');
  assert.deepEqual(plan.questions[0], { id: 'Q1', requirementId: 'R-001', text: 'How many pages remain in scope after clean-up?' });
  assert.ok(Array.isArray(row.capabilities) && row.capabilities.length > 0, 'capabilities come from the catalog');
});

test('a re-run only adds: existing rows, decisions and volumes stay as they were', () => {
  const first = build({ sketch: sketchOf() }).plan;
  acceptRequirements(first, { ids: ['R-001'], dismiss: ['R-002'], via: 'walk', now: NOW });
  const before = JSON.parse(JSON.stringify(first));

  const more = {
    ...extract,
    requirements: [
      ...extract.requirements,
      requirement('Preserve inbound links with a redirect map.', ['src-rfp#p1.1'], 'seo', { question: 'Who approves the redirect map?' })
    ]
  };
  const other = sketchOf();
  other.drivers[0].quantity = 6500;
  const { plan, stats, warnings } = assemblePlan({
    extract: more, blocks, catalogMd, projectName: 'Fabrikam', existing: first, sketch: other, now: '2026-11-14T00:00:00.000Z'
  });
  assert.equal(stats.addedRequirements, 1);
  assert.equal(stats.unchangedRequirements, 3);
  assert.equal(stats.addedQuestions, 1);
  assert.equal(plan.requirements.length, 4);
  assert.equal(plan.requirements[3].id, 'R-004');
  assert.equal(plan.requirements[3].questionId, 'Q3');
  assert.equal(plan.requirements[3].review.status, 'pending');
  assert.deepEqual(plan.requirements.slice(0, 3), before.requirements, 'earlier rows are untouched, decisions included');
  assert.deepEqual(plan.volumes, before.volumes, 'a different figure does not replace the volume');
  assert.equal(stats.volumeDisagreements, 1);
  assert.ok(warnings.some((message) => /content-migration: this run found 6500/.test(message)));
  assert.equal(plan.updatedAt, '2026-11-14T00:00:00.000Z');
  assert.deepEqual(validatePlan(plan), []);
});

test('a dismissed requirement that the model finds again stays dismissed and is not added again', () => {
  const first = build().plan;
  acceptRequirements(first, { dismiss: ['R-002'], via: 'walk', now: NOW });
  const { plan, stats } = assemblePlan({ extract, blocks, catalogMd, projectName: 'Fabrikam', existing: first, now: NOW });
  assert.equal(stats.addedRequirements, 0);
  assert.equal(plan.requirements.find((row) => row.id === 'R-002').review.status, 'dismissed');
});

test('validate names the field of each problem', () => {
  const { plan } = build({ sketch: sketchOf() });
  const bad = JSON.parse(JSON.stringify(plan));
  bad.requirements[1].id = 'R-001';
  bad.requirements[0].review = { status: 'accepted', via: 'magic' };
  bad.requirements[2].workPackage = 'WP-99';
  bad.requirements[2].coverage = 'maybe';
  bad.questions[0].requirementId = 'R-404';
  bad.volumes[0].quote = 'x';
  const errors = validatePlan(bad, { blocks, workPackages });
  assert.ok(errors.includes('requirements[1].id: R-001 is used twice'));
  assert.ok(errors.some((message) => message.startsWith('requirements[0].review.via: expected one of')));
  assert.ok(errors.some((message) => message.startsWith('requirements[0].review.at: expected an ISO time')));
  assert.ok(errors.some((message) => message.startsWith('requirements[2].workPackage: "WP-99" is not an activity')));
  assert.ok(errors.some((message) => message.startsWith('requirements[2].coverage: expected one of')));
  assert.ok(errors.some((message) => message.startsWith('questions[0].requirementId: "R-404"')));
  assert.ok(errors.some((message) => message.startsWith('volumes[0].')), 'a volume whose quote is not in the blocks is named');
  assert.deepEqual(validatePlan(null), ['(root): expected an object']);
});

test('a volume is checked against the blocks only when the blocks are given', () => {
  const { plan } = build({ sketch: sketchOf() });
  const forged = JSON.parse(JSON.stringify(plan));
  forged.volumes[0].quote = 'migrate approximately 9,999 pages of content';
  forged.volumes[0].quantity = 9999;
  assert.deepEqual(validatePlan(forged), []);
  assert.ok(validatePlan(forged, { blocks, workPackages }).length > 0);
});

test('accept all marks pending rows and volumes, and leaves a person\'s decisions alone', () => {
  const { plan } = build({ sketch: sketchOf() });
  acceptRequirements(plan, { dismiss: ['R-003'], via: 'walk', now: NOW });
  const result = acceptRequirements(plan, { all: true, via: 'bulk', now: '2026-11-13T13:00:00.000Z' });
  assert.deepEqual(result, { accepted: 2, dismissed: 0, volumesAccepted: 1, unknownIds: [] });
  assert.deepEqual(plan.requirements.map((row) => row.review.status), ['accepted', 'accepted', 'dismissed']);
  assert.deepEqual(plan.requirements[0].review, { status: 'accepted', via: 'bulk', at: '2026-11-13T13:00:00.000Z' });
  assert.equal(plan.requirements[2].review.via, 'walk');
  assert.equal(plan.volumes[0].review.status, 'accepted');
  assert.deepEqual(validatePlan(plan), []);
  assert.deepEqual(acceptRequirements(plan, { all: true, now: NOW }), { accepted: 0, dismissed: 0, volumesAccepted: 0, unknownIds: [] });
});

test('accepting one workstream takes its requirements and its volume and nothing else', () => {
  const { plan } = build({ sketch: sketchOf() });
  const result = acceptRequirements(plan, { workstream: 'content-migration', via: 'walk', now: NOW });
  assert.equal(result.accepted, 1);
  assert.equal(result.volumesAccepted, 1);
  assert.deepEqual(plan.requirements.map((row) => row.review.status), ['accepted', 'pending', 'pending']);
});

test('accept reports an id that is not in the plan', () => {
  const { plan } = build();
  const result = acceptRequirements(plan, { ids: ['R-001', 'R-777'], via: 'walk', now: NOW });
  assert.deepEqual(result.unknownIds, ['R-777']);
});

test('the summary counts what was found and names the workstreams with no requirement', () => {
  const { plan } = build({ sketch: sketchOf() });
  acceptRequirements(plan, { dismiss: ['R-002'], via: 'walk', now: NOW });
  const summary = summarizePlan(plan, workPackages);
  assert.equal(summary.requirements, 2);
  assert.equal(summary.workstreams, 2);
  assert.equal(summary.volumes, 1);
  assert.equal(summary.conflicts, 1);
  assert.equal(summary.questions, 2);
  assert.deepEqual(summary.review, { pending: 2, accepted: 0, edited: 0, dismissed: 1 });
  assert.deepEqual(summary.byWorkstream.map((item) => [item.id, item.requirements, item.volume]), [['content-migration', 1, true], ['localization', 1, false]]);
  assert.ok(summary.noRequirement.some((item) => item.id === 'discovery-audit'));
  assert.ok(!summary.noRequirement.some((item) => item.id === 'content-migration'));
  const markdown = formatSummary(summary);
  assert.match(markdown, /2 requirements in 2 workstreams, 1 volume found, 2 questions \(1 conflict\)\. Platform: Adobe Experience Manager\./);
  assert.match(markdown, /workstreams with no requirement/);
});

test('the plan file name drops characters a file name cannot hold', () => {
  assert.equal(planFileName('Fabrikam Outdoor'), 'Fabrikam Outdoor_Plan.json');
  assert.equal(planFileName('A/B: "C"'), 'AB C_Plan.json');
  assert.equal(planFileName('***'), 'Project_Plan.json');
});

// --- command line ---

function folderWith(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'plan-'));
  fs.mkdirSync(path.join(dir, '.blueprint', 'parsed'), { recursive: true });
  fs.writeFileSync(path.join(dir, '.blueprint', 'sources.json'), JSON.stringify({ schemaVersion: '1', projectName: 'Fabrikam', sources: [] }));
  fs.writeFileSync(path.join(dir, '.blueprint', 'parsed', 'blocks.json'), JSON.stringify(blocks));
  for (const [name, value] of Object.entries(files)) {
    fs.writeFileSync(path.join(dir, '.blueprint', name), JSON.stringify(value));
  }
  return dir;
}

function run(...args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

test('assemble writes the plan, then adds on a second run, and accept and validate work on it', () => {
  const dir = folderWith({ 'extract.json': extract, 'design-sketch.json': sketchOf() });
  try {
    const first = run('assemble', dir);
    assert.equal(first.status, 0, first.stderr);
    const file = path.join(dir, 'Fabrikam_Plan.json');
    assert.ok(fs.existsSync(file));
    assert.match(first.stdout, /new: 3 requirements, 2 questions, 1 volumes/);

    const validate = run('validate', file, '--blocks', path.join(dir, '.blueprint', 'parsed', 'blocks.json'));
    assert.equal(validate.status, 0, validate.stderr);
    assert.match(validate.stdout, /^ok: 3 requirements, 2 questions, 1 volumes, volumes checked against the blocks/);

    const accept = run('accept', file, '--all');
    assert.equal(accept.status, 0, accept.stderr);
    assert.match(accept.stdout, /accepted 3 requirements and 1 volumes, dismissed 0/);
    assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).requirements[0].review.via, 'bulk');

    const second = run('assemble', dir);
    assert.equal(second.status, 0, second.stderr);
    assert.match(second.stdout, /added: 0 requirements, 0 questions, 0 volumes; 3 requirements were already in the plan/);
    assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).requirements[0].review.status, 'accepted');

    const summary = run('summary', file, '--markdown');
    assert.equal(summary.status, 0, summary.stderr);
    assert.match(summary.stdout, /3 requirements in 2 workstreams/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('rate records a decision, re-records it as an edit, and refuses an activity or figure it cannot use', () => {
  const dir = folderWith({ 'extract.json': extract, 'design-sketch.json': sketchOf() });
  try {
    const file = path.join(dir, 'Fabrikam_Plan.json');
    assert.equal(run('assemble', dir).status, 0);

    const first = run('rate', file, '--activity', 'component-build', '--hours', '7', '--note', 'Matches the last two pursuits.');
    assert.equal(first.status, 0, first.stderr);
    assert.match(first.stdout, /component-build: rate accepted at 7 h per unit/);
    const recorded = JSON.parse(fs.readFileSync(file, 'utf8')).rates;
    assert.equal(recorded.length, 1);
    assert.deepEqual([recorded[0].activity, recorded[0].hoursPerUnit, recorded[0].review.status, recorded[0].review.via], ['component-build', 7, 'accepted', 'rate']);

    const again = run('rate', file, '--activity', 'component-build', '--hours', '9', '--note', 'Revised after the workshop.');
    assert.equal(again.status, 0, again.stderr);
    const edited = JSON.parse(fs.readFileSync(file, 'utf8')).rates;
    assert.equal(edited.length, 1, 'a second decision replaces the first rather than stacking');
    assert.deepEqual([edited[0].hoursPerUnit, edited[0].review.status], [9, 'edited']);
    assert.equal(run('validate', file).status, 0);

    const before = fs.readFileSync(file, 'utf8');
    assert.equal(run('rate', file, '--activity', 'no-such-activity', '--hours', '9', '--note', 'n').status, 1);
    // A rate of zero hours is not a decision, it is a missing one.
    assert.equal(run('rate', file, '--activity', 'component-build', '--hours', '0', '--note', 'n').status, 2);
    assert.equal(run('rate', file, '--activity', 'component-build', '--hours', '9').status, 2);
    assert.equal(fs.readFileSync(file, 'utf8'), before, 'a refused rate changes nothing');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('assemble exits 4 and writes nothing when no requirement survives', () => {
  const dir = folderWith({ 'extract.json': { requirements: [requirement('Nothing real.', ['no-such-block'], 'content-migration')], platform: { id: null, blockId: null }, notes: null } });
  try {
    const result = run('assemble', dir);
    assert.equal(result.status, 4);
    assert.match(result.stderr, /Nothing was written: none of the 1 requirements is usable/);
    assert.equal(fs.existsSync(path.join(dir, 'Fabrikam_Plan.json')), false);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('assemble refuses a plan file it cannot read and leaves it as it is', () => {
  const dir = folderWith({ 'extract.json': extract });
  try {
    fs.writeFileSync(path.join(dir, 'Fabrikam_Plan.json'), '{"schemaVersion":"1"}');
    const result = run('assemble', dir);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /is not a valid plan file\. It was left as it is/);
    assert.equal(fs.readFileSync(path.join(dir, 'Fabrikam_Plan.json'), 'utf8'), '{"schemaVersion":"1"}');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('assemble refuses a design sketch that the blocks do not back', () => {
  const sketch = sketchOf();
  sketch.drivers[0].quote = 'migrate approximately 9,999 pages of content';
  sketch.drivers[0].quantity = 9999;
  const dir = folderWith({ 'extract.json': extract, 'design-sketch.json': sketch });
  try {
    const result = run('assemble', dir);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /\(design sketch\)/);
    assert.equal(fs.existsSync(path.join(dir, 'Fabrikam_Plan.json')), false);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('the command line exits 2 on bad usage and 1 on an unknown id', () => {
  assert.equal(run().status, 2);
  assert.equal(run('accept', 'x.json').status, 2);
  assert.equal(run('accept', 'x.json', '--all', '--ids', 'R-001').status, 2);
  const dir = folderWith({ 'extract.json': extract });
  try {
    assert.equal(run('assemble', dir).status, 0);
    const file = path.join(dir, 'Fabrikam_Plan.json');
    const result = run('accept', file, '--ids', 'R-999');
    assert.equal(result.status, 1);
    assert.match(result.stderr, /Not requirements in this plan: R-999\. Nothing was changed\./);
    assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).requirements[0].review.status, 'pending');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
