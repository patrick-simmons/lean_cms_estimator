/**
 * Local PDF text reader for tools/blueprint/parse-local.mjs (SAPP-013).
 *
 * The Azure function reads PDFs with Document Intelligence. On a machine with only Node that service is
 * not available, so this module reads the PDF's own text layer with pdf.js and turns it into the same
 * block shape through the function's passage grouper. A PDF with no text layer (a scan) yields no text,
 * and the caller reports it as not read; nothing is guessed and no OCR is attempted. A page with only a
 * few characters (a stamp, a footer) is treated the same way as a page with none.
 *
 * Page numbers are exact (the page the text sits on). Headings are a heuristic: a short line that starts
 * with a section number such as `3.6.1`, or a line set in a clearly larger font than the page's body text.
 * The label and `section` follow the same rules as the function (citation.ts).
 */
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import * as pdfjsWorker from 'pdfjs-dist/legacy/build/pdf.worker.mjs';

// The worker runs on the main thread. Setting the global stops pdf.js from importing the worker file
// by path, which would not work from a bundled copy of this tool.
globalThis.pdfjsWorker = pdfjsWorker;

const HEADING_NUMBER = /^(\d+(?:\.\d+)*)\.?\s+(\S.*)$/;
const MAX_HEADING_CHARS = 120;
const MAX_NUMBERED_HEADING_CHARS = 80;
const LARGE_FONT_RATIO = 1.25;
const LINE_TOLERANCE = 2;
const PARAGRAPH_GAP_RATIO = 1.6;
const WORD_GAP_RATIO = 0.2;

/**
 * A page counts as having a text layer only when it carries at least this many non-whitespace characters.
 * A scan with a Bates stamp, a "CONFIDENTIAL" footer or a scanner header has some text on every page but
 * none of the document's content; below this the page is reported as unread rather than as read.
 */
export const MIN_PAGE_CHARS = 40;

/** `[3, 4, 5, 7]` becomes `3-5,7`. */
export function formatPageRanges(pages) {
  const sorted = [...new Set(pages)].sort((a, b) => a - b);
  const parts = [];
  for (let index = 0; index < sorted.length; index += 1) {
    const start = sorted[index];
    let end = start;
    while (sorted[index + 1] === end + 1) {
      end += 1;
      index += 1;
    }
    parts.push(end === start ? `${start}` : `${start}-${end}`);
  }
  return parts.join(',');
}

function characterCount(lines) {
  return lines.reduce((total, line) => total + line.text.replace(/\s+/g, '').length, 0);
}

/**
 * @typedef {{ page: number, text: string, height: number, y: number }} Line
 */

/**
 * Group pdf.js text items into lines by their baseline, left to right, top to bottom.
 * @param {Array<{ str: string, transform: number[], width: number, height: number, hasEOL?: boolean }>} items
 * @param {number} page
 * @returns {Line[]}
 */
export function itemsToLines(items, page) {
  const positioned = items
    .filter((item) => typeof item.str === 'string' && Array.isArray(item.transform))
    .map((item) => ({
      text: item.str,
      x: item.transform[4],
      y: item.transform[5],
      width: item.width || 0,
      height: Math.abs(item.transform[3]) || item.height || 0
    }))
    .filter((item) => item.text.trim().length > 0 || item.text === ' ');
  positioned.sort((a, b) => (Math.abs(b.y - a.y) > LINE_TOLERANCE ? b.y - a.y : a.x - b.x));

  /** @type {Line[]} */
  const lines = [];
  let current;
  for (const item of positioned) {
    if (current && Math.abs(current.y - item.y) <= LINE_TOLERANCE) {
      const gap = item.x - current.right;
      const space = gap > current.height * WORD_GAP_RATIO && !current.text.endsWith(' ') && !item.text.startsWith(' ');
      current.text += (space ? ' ' : '') + item.text;
      current.right = item.x + item.width;
      current.height = Math.max(current.height, item.height);
    } else {
      current = { page, text: item.text, height: item.height, y: item.y, right: item.x + item.width };
      lines.push(current);
    }
  }
  return lines
    .map((line) => ({ page: line.page, text: line.text.replace(/\s+/g, ' ').trim(), height: line.height, y: line.y }))
    .filter((line) => line.text.length > 0);
}

function median(values) {
  if (values.length === 0) {
    return 0;
  }
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * Join lines into paragraphs. A new paragraph starts after a vertical gap larger than the usual line
 * spacing, or at a heading. Returns paragraphs in reading order with a heading flag.
 * @param {Line[]} lines
 * @returns {{ text: string, heading: boolean }[]}
 */
export function linesToParagraphs(lines) {
  const bodyHeight = median(lines.map((line) => line.height).filter((height) => height > 0));
  const isHeading = (line, next) => {
    if (line.text.length > MAX_HEADING_CHARS) {
      return false;
    }
    if (bodyHeight > 0 && line.height >= bodyHeight * LARGE_FONT_RATIO) {
      return true;
    }
    // A numbered line is a heading only when it stands alone: short, no sentence punctuation at the
    // end, and followed by a paragraph gap or another numbered line. A numbered body paragraph that
    // wraps onto a second line fails that test.
    const match = HEADING_NUMBER.exec(line.text);
    if (match === null || /[.:;,]$/.test(line.text) || line.text.length > MAX_NUMBERED_HEADING_CHARS) {
      return false;
    }
    if (!next) {
      return true;
    }
    const spacing = Math.max(line.height, next.height) || 1;
    return line.y - next.y > spacing * PARAGRAPH_GAP_RATIO || HEADING_NUMBER.test(next.text);
  };

  const paragraphs = [];
  let open;
  let previous;
  lines.forEach((line, index) => {
    const heading = isHeading(line, lines[index + 1]);
    const gap = previous ? previous.y - line.y : 0;
    const spacing = Math.max(previous?.height || 0, line.height || 0) || 1;
    const breakBefore = !open || heading || open.heading || gap > spacing * PARAGRAPH_GAP_RATIO;
    if (breakBefore) {
      open = { text: line.text, heading };
      paragraphs.push(open);
    } else {
      open.text = `${open.text} ${line.text}`;
    }
    previous = line;
  });
  return paragraphs;
}

/**
 * Read a PDF's text layer into blocks.
 *
 * @param {Uint8Array} bytes
 * @param {string} fileName
 * @param {string} itemId
 * @param {{ createPassages: Function, splitHeading: Function }} readers from function/dist localParse
 * @param {() => void} [checkBudget]
 * @returns {Promise<{ blocks: object[], capped: boolean, totalPages: number, textPages: number, noTextPages: number[] }>}
 *   `noTextPages` lists the pages with fewer than MIN_PAGE_CHARS characters; their text is not turned into blocks.
 */
export async function readPdfText(bytes, fileName, itemId, readers, checkBudget = () => undefined) {
  const task = pdfjs.getDocument({
    data: bytes.slice(),
    useSystemFonts: false,
    disableFontFace: true,
    isEvalSupported: false,
    verbosity: 0
  });
  const document = await task.promise;
  try {
    const passages = readers.createPassages(fileName, itemId);
    let heading;
    let section;
    let textPages = 0;
    const noTextPages = [];
    const totalPages = document.numPages;
    for (let pageNumber = 1; pageNumber <= totalPages; pageNumber += 1) {
      checkBudget();
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent({ includeMarkedContent: false, disableNormalization: false });
      const lines = itemsToLines(content.items, pageNumber);
      page.cleanup();
      if (characterCount(lines) < MIN_PAGE_CHARS) {
        noTextPages.push(pageNumber);
        continue;
      }
      textPages += 1;
      for (const paragraph of linesToParagraphs(lines)) {
        if (paragraph.heading) {
          const split = readers.splitHeading(paragraph.text);
          heading = split.heading;
          if (split.section !== undefined) {
            section = split.section;
          }
        }
        const location = { kind: 'page', page: pageNumber };
        if (section !== undefined) {
          location.section = section;
        }
        if (heading !== undefined) {
          location.heading = heading;
        }
        passages.add(location, `p${pageNumber}.`, paragraph.text);
      }
    }
    return { blocks: passages.blocks(), capped: passages.capped, totalPages, textPages, noTextPages };
  } finally {
    await task.destroy();
  }
}
