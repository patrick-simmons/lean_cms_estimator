import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { packInfo } from './pack-info.mjs';
import { MODES, readRunRecord, runRecordPath, STAGES, updateRunRecord } from './run-record.mjs';

const script = fileURLToPath(new URL('./run-record.mjs', import.meta.url));
const scratch = mkdtempSync(join(tmpdir(), 'run-record-'));
let counter = 0;

after(() => rmSync(scratch, { recursive: true, force: true }));

function folder() {
  counter += 1;
  const dir = join(scratch, `f${counter}`);
  mkdirSync(dir, { recursive: true });
  return dir;
}

function cli(args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

function writeRecord(dir, value) {
  mkdirSync(join(dir, '.blueprint'), { recursive: true });
  writeFileSync(runRecordPath(dir), typeof value === 'string' ? value : JSON.stringify(value));
}

const T1 = new Date('2026-11-09T10:00:00Z');
const T2 = new Date('2026-11-09T11:00:00Z');

describe('run record writer', () => {
  it('creates a record at the prepared stage with the running pack and schemas', () => {
    const dir = folder();
    const record = updateRunRecord(dir, {}, T1);
    const info = packInfo();
    assert.equal(record.stage, 'prepared');
    assert.equal(record.mode, 'first-run');
    assert.equal(record.pack.version, info.version);
    assert.deepEqual(record.schemas, info.schemas);
    assert.equal(record.startedAt, T1.toISOString());
    assert.match(record.runId, /^run-20261109T100000/);
    assert.deepEqual(readRunRecord(dir), record);
  });

  it('keeps runId and startedAt, merges files, notes and stage history', () => {
    const dir = folder();
    const first = updateRunRecord(dir, { stage: 'parse', note: 'first', files: { parsed: { path: 'a' } } }, T1);
    const second = updateRunRecord(dir, { stage: 'extract', note: 'second', files: { blueprint: { path: 'b' } }, parseTool: { name: 'p', version: '1' } }, T2);
    assert.equal(second.runId, first.runId);
    assert.equal(second.startedAt, T1.toISOString());
    assert.equal(second.updatedAt, T2.toISOString());
    assert.deepEqual(Object.keys(second.files).sort(), ['blueprint', 'parsed']);
    assert.deepEqual(Object.keys(second.stages), ['parse', 'extract']);
    assert.equal(second.stages.parse.note, 'first');
    assert.deepEqual(second.notes, [`${T1.toISOString()} parse: first`, `${T2.toISOString()} extract: second`]);
    assert.deepEqual(second.parseTool, { name: 'p', version: '1' });
  });

  it('uses the given runId only when there is none yet', () => {
    const dir = folder();
    assert.equal(updateRunRecord(dir, { runId: 'run-a' }, T1).runId, 'run-a');
    assert.equal(updateRunRecord(dir, { stage: 'parse' }, T2).runId, 'run-a');
    assert.equal(updateRunRecord(dir, { runId: 'run-b' }, T2).runId, 'run-b', 'an explicit run id replaces the old one');
  });

  it('describes the pack that wrote last: a record from an older pack is brought up to date', () => {
    const dir = folder();
    writeRecord(dir, {
      schemaVersion: '1', runId: 'run-old', startedAt: T1.toISOString(), updatedAt: T1.toISOString(), stage: 'extract', mode: 'first-run',
      pack: { name: 'blueprint-skill-pack', version: '0.0.9', commit: 'old', builtAt: '2026-01-01T00:00:00.000Z', layout: 'pack' },
      schemas: { blueprint: '0', context: '1', proposals: '0', runRecord: '1', legacy: '7' },
      stages: { extract: { at: T1.toISOString() } }, files: {}, notes: []
    });
    const record = updateRunRecord(dir, { stage: 'enrich' }, T2);
    const info = packInfo();
    assert.equal(record.pack.version, info.version);
    assert.notEqual(record.pack.commit, 'old');
    assert.deepEqual(record.schemas, info.schemas, 'the schemas of the tool that wrote last, nothing carried over');
    assert.equal(record.runId, 'run-old', 'the run itself persists');
    assert.equal(record.startedAt, T1.toISOString());
    assert.equal(record.stage, 'enrich');
  });

  it('never moves the stage backwards, except from done or when asked', () => {
    const dir = folder();
    updateRunRecord(dir, { stage: 'validate' }, T1);
    const back = updateRunRecord(dir, { stage: 'parse', note: 'reparse' }, T2);
    assert.equal(back.stage, 'validate', 'the furthest stage stays');
    assert.ok(back.stages.parse && back.stages.validate, 'the history still records the stage that ran');
    assert.equal(updateRunRecord(dir, { stage: 'parse', allowRegress: true }, T2).stage, 'parse');
    updateRunRecord(dir, { stage: 'done' }, T2);
    assert.equal(updateRunRecord(dir, { stage: 'parse' }, T2).stage, 'parse', 'a finished record starts a new pass');
    assert.equal(updateRunRecord(dir, { stage: 'extract' }, T2).stage, 'extract', 'and moves forward again');
  });

  it('rejects an unknown stage or mode and writes nothing', () => {
    const dir = folder();
    assert.throws(() => updateRunRecord(dir, { stage: 'nope' }), /stage must be one of/);
    assert.throws(() => updateRunRecord(dir, { mode: 'nope' }), /mode must be one of/);
    assert.ok(!existsSync(runRecordPath(dir)));
    assert.deepEqual(STAGES.slice(0, 2), ['prepared', 'parse']);
    assert.deepEqual(MODES, ['first-run', 'proposals']);
  });

  it('writes through a temporary file that is gone afterwards', () => {
    const dir = folder();
    updateRunRecord(dir, { stage: 'parse' });
    assert.deepEqual(readdirSync(join(dir, '.blueprint')), ['run.json']);
  });

  it('--reset (the reset option) starts a new record even over a damaged one', () => {
    const dir = folder();
    writeRecord(dir, '{ broken');
    assert.throws(() => updateRunRecord(dir, { stage: 'parse' }), /run\.json is not valid JSON/);
    const fresh = updateRunRecord(dir, { stage: 'parse', reset: true, runId: 'run-new' }, T2);
    assert.equal(fresh.runId, 'run-new');
    assert.equal(fresh.startedAt, T2.toISOString());
    assert.deepEqual(Object.keys(fresh.stages), ['parse']);
  });
});

describe('reading a record', () => {
  it('returns undefined when there is none', () => {
    assert.equal(readRunRecord(folder()), undefined);
  });

  it('names the file and the way out when the record is damaged or not an object', () => {
    const dir = folder();
    writeRecord(dir, '{"schemaVersion":');
    assert.throws(() => readRunRecord(dir), (error) => error.message.includes(runRecordPath(dir)) && /not valid JSON/.test(error.message) && /--reset/.test(error.message));
    writeRecord(dir, '[1,2]');
    assert.throws(() => readRunRecord(dir), (error) => error.message.includes(runRecordPath(dir)) && /expected a JSON object/.test(error.message) && /--reset/.test(error.message));
    writeRecord(dir, 'null');
    assert.throws(() => readRunRecord(dir), /expected a JSON object/);
  });
});

describe('run-record command line', () => {
  it('writes the record and reports the stage', () => {
    const dir = folder();
    const result = cli([dir, '--stage', 'parse', '--mode', 'proposals', '--note', 'hello world']);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /wrote .*run\.json \(stage parse, pack /);
    const record = readRunRecord(dir);
    assert.equal(record.mode, 'proposals');
    assert.match(record.notes[0], /parse: hello world$/);
  });

  it('accumulates notes across calls', () => {
    const dir = folder();
    cli([dir, '--stage', 'parse', '--note', 'one']);
    cli([dir, '--note', 'two']);
    cli([dir, '--stage', 'extract', '--note', 'three']);
    const record = readRunRecord(dir);
    assert.equal(record.notes.length, 3);
    assert.match(record.notes[1], / two$/);
    assert.doesNotMatch(record.notes[1], /parse: two/, 'a note without a stage carries no stage prefix');
  });

  it('--show prints the record, or says there is none', () => {
    const dir = folder();
    assert.match(cli([dir, '--show']).stdout, /no run record/);
    cli([dir, '--stage', 'parse']);
    const shown = cli([dir, '--show']);
    assert.equal(shown.status, 0);
    assert.equal(JSON.parse(shown.stdout).stage, 'parse');
    assert.equal(readdirSync(join(dir, '.blueprint')).length, 1, '--show writes nothing');
  });

  it('--reset starts a new record, and --allow-regress moves the stage back', () => {
    const dir = folder();
    cli([dir, '--stage', 'validate', '--note', 'old']);
    const oldId = readRunRecord(dir).runId;
    assert.equal(cli([dir, '--stage', 'parse']).status, 0);
    assert.equal(readRunRecord(dir).stage, 'validate');
    assert.equal(cli([dir, '--stage', 'parse', '--allow-regress']).status, 0);
    assert.equal(readRunRecord(dir).stage, 'parse');
    const reset = cli([dir, '--reset', '--stage', 'prepared']);
    assert.equal(reset.status, 0, reset.stderr);
    const record = readRunRecord(dir);
    assert.deepEqual(record.notes, []);
    assert.deepEqual(Object.keys(record.stages), ['prepared']);
    assert.ok(oldId);
  });

  it('exits 2 with usage for a missing folder, extra arguments, unknown flags and flags without a value', () => {
    const dir = folder();
    for (const args of [[], [dir, 'extra'], [dir, '--bogus'], [dir, '--stages', 'done'], [dir, '--stage'], [dir, '--mode'], [dir, '--note'], [dir, '--stage', '--reset']]) {
      const result = cli(args);
      assert.equal(result.status, 2, `${args.join(' ')}: ${result.stdout}`);
      assert.match(result.stderr, /Usage/);
    }
    assert.ok(!existsSync(runRecordPath(dir)), 'a bad command line writes nothing');
  });

  it('exits 2 for an unknown stage or mode', () => {
    const dir = folder();
    for (const args of [[dir, '--stage', 'nope'], [dir, '--mode', 'nope']]) {
      const result = cli(args);
      assert.equal(result.status, 2);
      assert.match(result.stderr, /must be one of/);
    }
  });

  it('exits 2 and names the file when the record is damaged, for update and --show alike', () => {
    const dir = folder();
    writeRecord(dir, '{ broken');
    for (const args of [[dir, '--stage', 'parse'], [dir, '--show']]) {
      const result = cli(args);
      assert.equal(result.status, 2);
      assert.match(result.stderr, /run\.json is not valid JSON/);
    }
    assert.equal(readFileSync(runRecordPath(dir), 'utf8'), '{ broken', 'the damaged file is left for a person to look at');
    assert.equal(cli([dir, '--stage', 'parse', '--reset']).status, 0);
    assert.equal(readRunRecord(dir).stage, 'parse');
  });
});
