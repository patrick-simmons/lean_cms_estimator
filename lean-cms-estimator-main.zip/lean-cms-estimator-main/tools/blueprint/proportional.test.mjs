import assert from 'node:assert/strict';
import fs from 'node:fs';
import { test } from 'node:test';
import { EVERYTHING_ELSE, loadShareFallbacks, proportionalPasses, ProportionalError, referenceSetOf, validateShareFallbacks } from './proportional.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';

function catalog(rows) {
  return new Map(rows.map(([id, shape, shareOf = []]) => [id, { name: id, shape, shareOf }]));
}

test('a named share set is the set; everything else is everything that is not itself a share of everything else', () => {
  const activities = catalog([
    ['component-build', 'per-unit'],
    ['search', 'tiered'],
    ['qa-automation', 'proportional', ['component-build', 'search']],
    ['project-management', 'proportional', [EVERYTHING_ELSE]],
    ['delivery-governance', 'proportional', [EVERYTHING_ELSE]]
  ]);
  assert.deepEqual(referenceSetOf('qa-automation', activities), ['component-build', 'search']);
  // The two reporting activities cover the delivery work and the QA sized over it, but not
  // each other and not themselves, which is what stops the two of them sizing in circles.
  assert.deepEqual(referenceSetOf('project-management', activities), ['component-build', 'search', 'qa-automation']);
  assert.deepEqual(referenceSetOf('delivery-governance', activities), ['component-build', 'search', 'qa-automation']);
  assert.deepEqual(referenceSetOf('component-build', activities), [], 'only a proportional activity has a share set');
  assert.deepEqual(referenceSetOf('no-such-activity', activities), []);
});

test('the passes put an activity after everything it is a share of', () => {
  const activities = catalog([
    ['component-build', 'per-unit'],
    ['qa-automation', 'proportional', ['component-build']],
    ['uat-support', 'proportional', ['component-build']],
    ['project-management', 'proportional', [EVERYTHING_ELSE]],
    ['delivery-governance', 'proportional', [EVERYTHING_ELSE]]
  ]);
  assert.deepEqual(proportionalPasses(activities), [
    ['qa-automation', 'uat-support'],
    ['project-management', 'delivery-governance']
  ]);
});

test('a share of nothing proportional resolves in the first pass', () => {
  const activities = catalog([['component-build', 'per-unit'], ['qa-automation', 'proportional', ['component-build']]]);
  assert.deepEqual(proportionalPasses(activities), [['qa-automation']]);
  assert.deepEqual(proportionalPasses(catalog([['component-build', 'per-unit']])), []);
});

test('activities that are shares of each other stop the estimate rather than looping', () => {
  const activities = catalog([
    ['a', 'proportional', ['b']],
    ['b', 'proportional', ['a']]
  ]);
  assert.throws(() => proportionalPasses(activities), (error) => error instanceof ProportionalError && /shares of each other/.test(error.message));
});

test('the shipped catalog resolves in the order the plan says it should', () => {
  const activities = parseActivities(fs.readFileSync(DEFAULT_CATALOG, 'utf8'));
  assert.deepEqual(proportionalPasses(activities), [
    ['qa-automation', 'uat-support'],
    ['project-management', 'delivery-governance']
  ]);
});

test('every proportional activity in the catalog has a fallback share until cases cover it', () => {
  const activities = parseActivities(fs.readFileSync(DEFAULT_CATALOG, 'utf8'));
  const fallbacks = loadShareFallbacks();
  for (const [id, entry] of activities) {
    assert.equal(fallbacks.has(id), entry.shape === 'proportional', id);
  }
});

test('a fallback that is not a share is rejected, because a share of 1 or more is not a share', () => {
  assert.deepEqual(validateShareFallbacks({ schemaVersion: '1', shares: { 'qa-automation': 0.18 } }), []);
  assert.deepEqual(validateShareFallbacks({}), ['expected { schemaVersion: "1", shares: {} }']);
  for (const bad of [0, 1, 1.5, -0.1, '0.2']) {
    assert.equal(validateShareFallbacks({ schemaVersion: '1', shares: { x: bad } }).length, 1, String(bad));
  }
});

test('an unreadable fallbacks file stops the estimate rather than sizing everything at zero', () => {
  assert.throws(() => loadShareFallbacks('no-such-file.json'), ProportionalError);
});
