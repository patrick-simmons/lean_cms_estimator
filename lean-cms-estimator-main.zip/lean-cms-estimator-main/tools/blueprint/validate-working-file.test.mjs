import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';
import { validateWorkingFileValue } from './validate-working-file.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'validate-working-file.mjs');
const pending = 'samples/review/03-all-pending/Northwind Health replatform_Blueprint.json';
const startOnly = 'samples/review/05-start-only/Northwind Health replatform_Blueprint.json';
const malformed = 'samples/review/07-malformed/Northwind Health replatform_Blueprint.json';

function run(file) {
  return spawnSync(process.execPath, [script, file], { cwd: root, encoding: 'utf8' });
}

describe('validate-working-file', () => {
  it('passes 03-all-pending', () => {
    const result = run(pending);
    assert.equal(result.status, 0, result.stderr);
  });

  it('passes 05-start-only', () => {
    const result = run(startOnly);
    assert.equal(result.status, 0, result.stderr);
  });

  it('fails 07-malformed with statement path', () => {
    const result = run(malformed);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /requirements\[0\]\.statement/);
  });

  it('accepts conflict rows with two sources', () => {
    const errors = validateWorkingFileValue({
      revision: 0,
      sources: [],
      requirements: [{
        id: 'R-001',
        statement: 'RFP says four locales; deck says two.',
        sources: [
          {
            itemId: 'a',
            fileName: 'a.pdf',
            blockId: 'a#1',
            label: 'a p.1',
            location: { kind: 'page', page: 1 },
            passage: 'four'
          },
          {
            itemId: 'b',
            fileName: 'b.pptx',
            blockId: 'b#2',
            label: 'b slide 2',
            location: { kind: 'slide', slide: 2 },
            passage: 'two'
          }
        ],
        workPackage: 'localization',
        capabilities: [],
        coverage: 'conflict',
        review: { status: 'pending' }
      }],
      questions: [],
      estimate: null,
      handoff: null,
      history: []
    });
    assert.deepEqual(errors, []);
  });
});

describe('validate-working-file AI levers (SPMVP-034)', () => {
  function estimate(overrides = {}) {
    return {
      totalHours: 100,
      deliveryMix: 'Balanced',
      blendedRate: 150,
      price: 15000,
      mixCountry: 'USA',
      deliveryMixes: ['Balanced'],
      packages: [{
        workPackageId: 'content-migration',
        name: 'Content migration',
        unit: 'page',
        quantity: 100,
        hoursPerUnit: 1,
        hours: 100,
        confidence: 'low',
        sized: true,
        baseHoursPerUnit: 2,
        baseHours: 200,
        accelerationPct: 50,
        appliedLevers: ['aem-eds-page-import']
      }],
      staffing: [],
      challengerNotes: ['AI levers: Saved levers were ignored.'],
      quantityOverrides: {},
      assumedOptIn: false,
      assumedMethods: true,
      traditionalHours: 200,
      savingsHours: 100,
      levers: { optIn: ['aem-eds-page-import'], methods: [] },
      stale: false,
      challengerReviewed: false,
      builtAt: '2026-10-19T12:00:00Z',
      ...overrides
    };
  }

  function file(overrides = {}, rootOverrides = {}) {
    return {
      revision: 0,
      sources: [],
      requirements: [],
      questions: [],
      estimate: estimate(overrides),
      handoff: null,
      history: [],
      ...rootOverrides
    };
  }

  it('accepts a lever build with assumedOptIn false and a root levers selection', () => {
    const errors = validateWorkingFileValue(file({}, { levers: { optIn: ['aem-eds-page-import'], methods: ['cdk-loop'] } }));
    assert.deepEqual(errors, []);
  });

  it('still accepts a legacy estimate that assumed every lever', () => {
    const legacy = file({
      assumedOptIn: true,
      assumedMethods: true,
      levers: undefined,
      traditionalHours: undefined,
      savingsHours: undefined
    });
    assert.deepEqual(validateWorkingFileValue(legacy), []);
  });

  it('rejects assumed flags that are not booleans', () => {
    const errors = validateWorkingFileValue(file({ assumedOptIn: 'no' }));
    assert.ok(errors.some((error) => /estimate\.assumedOptIn: expected boolean/.test(error)), errors.join('\n'));
    const methods = validateWorkingFileValue(file({ assumedMethods: 'no' }));
    assert.ok(methods.some((error) => /estimate\.assumedMethods: expected boolean/.test(error)), methods.join('\n'));
  });

  it('accepts the traced fields and rejects them out of range', () => {
    assert.deepEqual(validateWorkingFileValue(file({ tracedHours: 40, tracedShare: 0.4 })), []);
    assert.deepEqual(validateWorkingFileValue(file({ tracedHours: 0, tracedShare: 0 })), []);
    const hours = validateWorkingFileValue(file({ tracedHours: -1 }));
    assert.ok(hours.some((error) => /estimate\.tracedHours: expected non-negative number/.test(error)), hours.join('\n'));
    const high = validateWorkingFileValue(file({ tracedShare: 1.5 }));
    assert.ok(high.some((error) => /estimate\.tracedShare: expected a number from 0 to 1/.test(error)), high.join('\n'));
    const low = validateWorkingFileValue(file({ tracedShare: -0.1 }));
    assert.ok(low.some((error) => /estimate\.tracedShare: expected a number from 0 to 1/.test(error)), low.join('\n'));
  });

  it('rejects negative or non-numeric hours totals and an out-of-range acceleration', () => {
    const traditional = validateWorkingFileValue(file({ traditionalHours: -1 }));
    assert.ok(traditional.some((error) => /estimate\.traditionalHours: expected non-negative number/.test(error)), traditional.join('\n'));
    const negative = validateWorkingFileValue(file({ savingsHours: -5 }));
    assert.ok(negative.some((error) => /estimate\.savingsHours: expected non-negative number/.test(error)), negative.join('\n'));
    const text = validateWorkingFileValue(file({ savingsHours: 'x' }));
    assert.ok(text.some((error) => /estimate\.savingsHours/.test(error)), text.join('\n'));
    const pkg = estimate().packages[0];
    const over = validateWorkingFileValue(file({ packages: [{ ...pkg, accelerationPct: 150 }] }));
    assert.ok(over.some((error) => /accelerationPct: expected a number from 0 to 100/.test(error)), over.join('\n'));
  });

  it('rejects a malformed root levers field with its path', () => {
    const errors = validateWorkingFileValue(file({}, { levers: { optIn: [], methods: 'cdk-loop' } }));
    assert.ok(errors.some((error) => /levers\.methods: expected string\[\]/.test(error)), errors.join('\n'));
  });

  it('rejects malformed lever fields on the estimate and its packages', () => {
    const bad = estimate();
    bad.packages[0].appliedLevers = 'aem-eds-page-import';
    bad.packages[0].baseHours = -1;
    bad.levers = ['cdk-loop'];
    const errors = validateWorkingFileValue(file(bad));
    assert.ok(errors.some((error) => /packages\[0\]\.appliedLevers: expected string\[\]/.test(error)), errors.join('\n'));
    assert.ok(errors.some((error) => /packages\[0\]\.baseHours: expected non-negative number/.test(error)), errors.join('\n'));
    assert.ok(errors.some((error) => /estimate\.levers: expected object/.test(error)), errors.join('\n'));
  });

  it('accepts a package with coverage shares and one without', () => {
    const pkg = estimate().packages[0];
    [
      { accelerated: 0.333, partly: 0.333, humanLed: 0.333, unresolved: 0 },
      { accelerated: 0.429, partly: 0.286, humanLed: 0.286, unresolved: 0 },
      { accelerated: 1, partly: 0, humanLed: 0, unresolved: 0 },
      { accelerated: 0, partly: 0, humanLed: 0, unresolved: 1 }
    ].forEach((shares) => {
      assert.deepEqual(validateWorkingFileValue(file({ packages: [{ ...pkg, coverageShares: shares }] })), []);
    });
    assert.deepEqual(validateWorkingFileValue(file({ packages: [{ ...pkg, coverageShares: undefined }] })), []);
  });

  it('rejects malformed coverage shares with the package path', () => {
    const pkg = estimate().packages[0];
    const good = { accelerated: 0.5, partly: 0, humanLed: 0.5, unresolved: 0 };
    const bad = [
      { accelerated: 0.5, partly: 0, humanLed: 0.5 },
      { ...good, accelerated: 1.5 },
      { ...good, partly: -0.1 },
      { ...good, humanLed: '0.5' },
      { ...good, humanLed: 0.2 },
      { accelerated: 0.5, partly: 0, humanLed: 0.49, unresolved: 0 },
      { accelerated: 0.5, partly: 0, humanLed: 0.51, unresolved: 0 },
      { accelerated: 0.6, partly: 0, humanLed: 0.6, unresolved: 0 },
      { accelerated: 0, partly: 0, humanLed: 0, unresolved: 0 },
      'accelerated',
      ['accelerated'],
      null
    ];
    bad.forEach((coverageShares) => {
      const errors = validateWorkingFileValue(file({ packages: [{ ...pkg, coverageShares }] }));
      assert.ok(
        errors.some((error) => /packages\[0\]\.coverageShares: expected/.test(error)),
        `${JSON.stringify(coverageShares)}: ${errors.join('\n')}`
      );
    });
  });
});

describe('validate-working-file phase lagWeeks (SPMVP-041)', () => {
  const planPhase = (overrides = {}) => ({
    phaseId: 'build',
    name: 'Build',
    durationWeeks: 4,
    afterPhaseId: 'discovery',
    coversWorkPackages: [],
    allocations: [],
    ramps: [],
    ...overrides
  });

  const base = (overrides = {}) => ({
    revision: 0,
    sources: [],
    requirements: [],
    questions: [],
    estimate: null,
    handoff: null,
    history: [],
    ...overrides
  });

  const estimateWith = (phases) => ({
    totalHours: 100,
    deliveryMix: 'Balanced',
    blendedRate: 150,
    price: 15000,
    mixCountry: 'USA',
    deliveryMixes: ['Balanced'],
    packages: [],
    staffing: [],
    challengerNotes: [],
    quantityOverrides: {},
    assumedOptIn: true,
    assumedMethods: true,
    stale: false,
    challengerReviewed: false,
    builtAt: '2026-10-19T12:00:00Z',
    phases
  });

  it('accepts negative, zero, positive and absent lags in phasePlan and estimate.phases', () => {
    const phases = [planPhase({ lagWeeks: -2 }), planPhase({ phaseId: 'b', lagWeeks: 0 }), planPhase({ phaseId: 'c', lagWeeks: 3 }), planPhase({ phaseId: 'd' })];
    assert.deepEqual(validateWorkingFileValue(base({ phasePlan: phases })), []);
    assert.deepEqual(
      validateWorkingFileValue(base({ estimate: estimateWith(phases.map((p) => ({ ...p, hours: 0 }))) })),
      []
    );
  });

  it('rejects a fraction, text, null, non-finite and out-of-range lag in phasePlan with the field path', () => {
    for (const lagWeeks of [1.5, '2', null, NaN, 521, -521, 1e9]) {
      const errors = validateWorkingFileValue(base({
        phasePlan: [planPhase({ phaseId: 'discovery', afterPhaseId: undefined }), planPhase({ lagWeeks })]
      }));
      assert.ok(
        errors.includes('phasePlan[1].lagWeeks: expected integer from -520 to 520'),
        `${String(lagWeeks)}: ${errors.join('\n')}`
      );
    }
  });

  it('rejects a bad lag on an estimate phase with the field path', () => {
    const errors = validateWorkingFileValue(base({
      estimate: estimateWith([planPhase({ phaseId: 'a', hours: 0 }), planPhase({ lagWeeks: 1.5, hours: 0 })])
    }));
    assert.ok(
      errors.includes('estimate.phases[1].lagWeeks: expected integer from -520 to 520'),
      errors.join('\n')
    );
  });

  it('accepts the largest lag either way', () => {
    const phases = [planPhase({ phaseId: 'a', lagWeeks: 520 }), planPhase({ lagWeeks: -520 })];
    assert.deepEqual(validateWorkingFileValue(base({ phasePlan: phases })), []);
  });

  it('ignores estimate phases that are not objects', () => {
    assert.deepEqual(
      validateWorkingFileValue(base({ estimate: estimateWith([null, 'x', { phaseId: 'legacy' }]) })),
      []
    );
  });

  it('ignores a phasePlan that is not an array and entries that are not objects', () => {
    assert.deepEqual(validateWorkingFileValue(base({ phasePlan: 'later' })), []);
    assert.deepEqual(validateWorkingFileValue(base({ phasePlan: [null, 'x'] })), []);
  });
});
