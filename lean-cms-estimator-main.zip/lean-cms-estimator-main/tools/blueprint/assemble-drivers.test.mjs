import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { assembleDrivers, checkDriver, checkSketch, compareWithRequirements, DESIGN_SKILLS, numbersIn } from './assemble-drivers.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'assemble-drivers.mjs');
const workPackages = parseActivities(fs.readFileSync(DEFAULT_CATALOG, 'utf8'));
const sampleBlocks = path.join(root, 'samples', 'agent-run', '.blueprint', 'parsed', 'blocks.json');
const sampleInput = path.join(root, 'samples', 'eval', 'synthetic-aem-design-input.json');

const blocks = [
  { id: 'b1', fileName: 'RFP.pdf', label: 'RFP p.3', text: 'The platform launches in four locales: English, German, French and Dutch.' },
  { id: 'b2', fileName: 'Inventory.xlsx', label: 'Inventory', text: '1: Section | Pages\n2: Products | 2,100\n3: Stories | 3400' },
  { id: 'b3', text: 'We migrate approximately 6,400 pages.' }
];
const context = { blocks: new Map(blocks.map((block) => [block.id, block.text.toLowerCase().replace(/\s+/g, ' ')])), workPackages };

function stated(extra = {}) {
  return { workPackageId: 'content-migration', quantity: 6400, basis: 'stated', quote: 'approximately 6,400 pages', blockIds: ['b3'], confidence: 'high', ...extra };
}

test('design skills are CMK capabilities in the catalog', () => {
  const catalog = fs.readFileSync(path.join(root, 'docs', 'catalogs', 'cmk-capability-catalog.md'), 'utf8');
  for (const id of DESIGN_SKILLS) {
    assert.ok(catalog.includes(`\`${id}\``), id);
  }
});

test('numbers are read from digits, commas and words up to twenty', () => {
  assert.deepEqual([...numbersIn('about 6,400 pages, two days and 3.5 hours')].sort((a, b) => a - b), [2, 3.5, 6400]);
  assert.equal(numbersIn('no figure').size, 0);
});

test('a comma is a thousands separator only in the usual grouping, and a label or a compound is not a count', () => {
  assert.deepEqual([...numbersIn('1,2,3')].sort((a, b) => a - b), [1, 2, 3]);
  assert.deepEqual([...numbersIn('12,500 and 1,200,000')].sort((a, b) => a - b), [12500, 1200000]);
  assert.equal(numbersIn('the Q4 launch and the H2 plan').size, 0);
  assert.equal(numbersIn('a one-time fee').size, 0);
  assert.ok(numbersIn('one locale').has(1));
});

test('a quote is matched as whole words and has to be more than the bare number', () => {
  assert.deepEqual(checkDriver(stated({ quote: '6,400' }), context).length > 0, true);
  assert.match(checkDriver(stated({ quote: '6,400' }), context).join('\n'), /at least 2 words, not the number alone/);
  // "12" is inside "2012" but is not the word 12.
  const year = { id: 'b4', text: 'The site was rebuilt in 2012 and again in 2019.' };
  const yearContext = { blocks: new Map([[year.id, year.text.toLowerCase()]]), workPackages };
  assert.match(
    checkDriver({ workPackageId: 'content-migration', quantity: 12, basis: 'stated', quote: 'rebuilt in 12', blockIds: ['b4'], confidence: 'low' }, yearContext).join('\n'),
    /not in the cited blocks/
  );
  const long = 'approximately 6,400 pages '.repeat(20);
  assert.match(checkDriver(stated({ quote: long }), context).join('\n'), /up to 300 characters/);
});

test('a counted item is matched as a whole word, not inside another word', () => {
  const counted = { workPackageId: 'localization', quantity: 3, basis: 'counted', items: ['en', 'de', 'fr'], blockIds: ['b1'], confidence: 'low' };
  const errors = checkDriver(counted, context).join('\n');
  assert.match(errors, /"en" is not in the cited blocks/);
  assert.match(errors, /"de" is not in the cited blocks/);
});

test('a stated driver is valid when the quote is in a cited block and holds the number', () => {
  assert.deepEqual(checkDriver(stated(), context), []);
  assert.deepEqual(checkDriver(stated({ quote: 'Approximately   6,400 PAGES' }), context), []);
});

test('a stated driver is rejected for a quote that is not in the block, one without the number, or a wrong block', () => {
  assert.match(checkDriver(stated({ quote: 'about 7,000 pages' }), context).join('\n'), /quote: this text is not in the cited blocks/);
  assert.match(checkDriver(stated({ quantity: 5000 }), context).join('\n'), /does not contain 5000/);
  assert.match(checkDriver(stated({ blockIds: ['b1'] }), context).join('\n'), /not in the cited blocks/);
  assert.match(checkDriver(stated({ blockIds: ['nope'] }), context).join('\n'), /"nope" is not in the blocks file/);
  assert.match(checkDriver(stated({ blockIds: [] }), context).join('\n'), /blockIds: expected at least one/);
  assert.match(checkDriver(stated({ quote: '' }), context).join('\n'), /quote: expected the words copied/);
});

test('a stated figure may be a number word', () => {
  const driver = { workPackageId: 'localization', quantity: 4, basis: 'stated', quote: 'launches in four locales', blockIds: ['b1'], confidence: 'high' };
  assert.deepEqual(checkDriver(driver, context), []);
});

test('a counted driver needs every item in a cited block and as many items as the quantity', () => {
  const counted = { workPackageId: 'localization', quantity: 4, basis: 'counted', items: ['English', 'German', 'French', 'Dutch'], blockIds: ['b1'], confidence: 'low' };
  assert.deepEqual(checkDriver(counted, context), []);
  assert.match(checkDriver({ ...counted, quantity: 5 }, context).join('\n'), /5 does not match the 4 items/);
  assert.match(checkDriver({ ...counted, items: ['English', 'German', 'French', 'Spanish'] }, context).join('\n'), /"Spanish" is not in the cited blocks/);
  assert.match(checkDriver({ ...counted, items: ['English', 'english', 'French', 'Dutch'] }, context).join('\n'), /listed twice/);
  assert.match(checkDriver({ ...counted, items: [] }, context).join('\n'), /items: expected the names/);
});

test('a summed driver needs each part quoted with its own number and a quantity equal to their sum', () => {
  const summed = {
    workPackageId: 'content-migration',
    quantity: 5500,
    basis: 'summed',
    parts: [
      { label: 'Products', quantity: 2100, quote: 'Products | 2,100' },
      { label: 'Stories', quantity: 3400, quote: 'Stories | 3400' }
    ],
    blockIds: ['b2'],
    confidence: 'medium'
  };
  assert.deepEqual(checkDriver(summed, context), []);
  assert.match(checkDriver({ ...summed, quantity: 5600 }, context).join('\n'), /not the sum of the parts \(5500\)/);
  assert.match(checkDriver({ ...summed, parts: [summed.parts[0]] }, context).join('\n'), /at least two parts/);
  const wrong = { ...summed, parts: [summed.parts[0], { label: 'Stories', quantity: 3000, quote: 'Stories | 3400' }] };
  assert.match(checkDriver(wrong, context).join('\n'), /parts\[1\]\.quote: the quote does not contain 3000/);
});

test('the work package, unit, confidence, design skill and note are checked', () => {
  assert.match(checkDriver(stated({ workPackageId: 'WP-99' }), context).join('\n'), /not an activity/);
  assert.match(checkDriver(stated({ unit: 'locale' }), context).join('\n'), /sized in pages, not "locale"/);
  assert.match(checkDriver(stated({ confidence: 'certain' }), context).join('\n'), /confidence: expected one of/);
  assert.match(checkDriver(stated({ designSkill: 'cmk-audit' }), context).join('\n'), /designSkill: expected one of/);
  assert.match(checkDriver(stated({ note: 'x'.repeat(401) }), context).join('\n'), /note: expected text/);
  assert.match(checkDriver(stated({ quantity: 6400.5 }), context).join('\n'), /quantity: expected a whole number/);
  assert.match(checkDriver(stated({ quantity: 0 }), context).join('\n'), /quantity: expected a whole number/);
  assert.match(checkDriver(stated({ basis: 'guess' }), context).join('\n'), /basis: expected one of/);
  assert.deepEqual(checkDriver('x', context), ['expected an object']);
});

test('the file holds only valid drivers, each pending, with ids, the catalog unit and the sources', () => {
  const { sketch, rejected } = assembleDrivers({ drivers: [stated({ designSkill: 'cmk-migration-assess', note: 'Addendum differs.' }), stated({ quantity: 1 })] }, blocks, workPackages);
  assert.equal(sketch.drivers.length, 1);
  assert.equal(rejected.length, 1);
  assert.equal(rejected[0].index, 1);
  const [driver] = sketch.drivers;
  assert.equal(driver.id, 'D-001');
  assert.equal(driver.unit, 'page');
  assert.deepEqual(driver.review, { status: 'pending' });
  assert.deepEqual(driver.sources, [{ blockId: 'b3' }]);
  assert.equal(sketch.producedBy, 'skill');
  assert.doesNotMatch(JSON.stringify(sketch), /hours|weeks|price/i);
});

test('a second driver for the same package is rejected and the first keeps its id', () => {
  const { sketch, rejected } = assembleDrivers({ drivers: [stated(), stated({ quantity: 6400 })] }, blocks, workPackages);
  assert.equal(sketch.drivers.length, 1);
  assert.match(rejected[0].errors.join('\n'), /already has a driver/);
});

test('checkSketch accepts what assemble writes, and names a driver that no longer matches the blocks', () => {
  const { sketch } = assembleDrivers({ drivers: [stated()] }, blocks, workPackages);
  assert.deepEqual(checkSketch(sketch, blocks, workPackages), []);
  const changed = blocks.map((block) => (block.id === 'b3' ? { ...block, text: 'We migrate about 5,900 pages.' } : block));
  assert.match(checkSketch(sketch, changed, workPackages).join('\n'), /drivers\[0\]\.quote: this text is not in the cited blocks/);
  const broken = { ...sketch, schemaVersion: '2', drivers: [{ ...sketch.drivers[0], id: 'X' }, { ...sketch.drivers[0], review: { status: 'maybe' } }] };
  const errors = checkSketch(broken, blocks, workPackages).join('\n');
  assert.match(errors, /schemaVersion/);
  assert.match(errors, /drivers\[0\]\.id: expected an id/);
  assert.match(errors, /has two drivers/);
  assert.match(errors, /review\.status/);
});

test('the comparison shows the sketch beside what Build would take from the requirement text', () => {
  const { sketch } = assembleDrivers({ drivers: [stated(), { workPackageId: 'localization', quantity: 4, basis: 'stated', quote: 'four locales', blockIds: ['b1'], confidence: 'high' }] }, blocks, workPackages);
  const rows = compareWithRequirements(sketch, {
    requirements: [{ workPackage: 'content-migration', statement: 'Migrate 5,000 pages' }, { workPackage: 'localization', statement: 'Four locales' }]
  });
  assert.deepEqual(rows.map((row) => [row.workPackageId, row.sketch, row.fromRequirements]), [['content-migration', 6400, 5000], ['localization', 4, null]]);
});

function runCli(args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

function temp() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'drivers-'));
}

test('the committed sample sketch is exactly what the tool writes from the sample input', () => {
  const out = path.join(temp(), 'design-sketch.json');
  const run = runCli(['--input', sampleInput, '--blocks', sampleBlocks, '--out', out]);
  assert.equal(run.status, 0, run.stderr);
  assert.deepEqual(JSON.parse(run.stdout).rejected, []);
  const committed = fs.readFileSync(path.join(root, 'samples', 'eval', 'synthetic-aem-design-sketch.json'), 'utf8');
  assert.equal(fs.readFileSync(out, 'utf8').replace(/\r\n/g, '\n'), committed.replace(/\r\n/g, '\n'));
  assert.equal(runCli(['--check', out, '--blocks', sampleBlocks]).status, 0);
});

test('the sample sketch lowers the back-test quantity error against the synthetic reference', () => {
  const backtest = path.join(root, 'tools', 'eval', 'backtest.mjs');
  const run = (args) => JSON.parse(spawnSync(process.execPath, [backtest, ...args, '--json'], { encoding: 'utf8' }).stdout);
  const suite = run(['--suite', path.join(root, 'samples', 'eval', 'suite.json')]);
  const sketch = run(['--suite', path.join(root, 'samples', 'eval', 'suite-sketch.json')]);
  assert.equal(suite.metrics.quantityError, 0.8);
  assert.equal(sketch.metrics.quantityError, 0.4);
  assert.equal(sketch.metrics.requirementRecall, suite.metrics.requirementRecall);
});

test('the CLI reports each rejected driver with its reason, and exits 4 with nothing written when none is valid', () => {
  const folder = temp();
  const input = path.join(folder, 'input.json');
  const out = path.join(folder, 'out.json');
  fs.writeFileSync(input, JSON.stringify({ drivers: [stated({ quote: 'invented' })] }));
  const run = runCli(['--input', input, '--blocks', sampleBlocks, '--out', out]);
  assert.equal(run.status, 4);
  assert.match(run.stderr, /not in the cited blocks|No valid driver/);
  assert.ok(!fs.existsSync(out));
  const good = JSON.parse(fs.readFileSync(sampleInput, 'utf8'));
  fs.writeFileSync(input, JSON.stringify({ drivers: [...good.drivers, { ...good.drivers[0], quantity: 1 }] }));
  const mixed = runCli(['--input', input, '--blocks', sampleBlocks, '--out', out]);
  assert.equal(mixed.status, 0, mixed.stderr);
  assert.equal(JSON.parse(mixed.stdout).rejected.length, 1);
});

test('the CLI will not overwrite a sketch with review decisions, but replaces an untouched one', () => {
  const folder = temp();
  const out = path.join(folder, 'design-sketch.json');
  assert.equal(runCli(['--input', sampleInput, '--blocks', sampleBlocks, '--out', out]).status, 0);
  assert.equal(runCli(['--input', sampleInput, '--blocks', sampleBlocks, '--out', out]).status, 0);
  const written = JSON.parse(fs.readFileSync(out, 'utf8'));
  written.drivers[0].review = { status: 'accepted' };
  fs.writeFileSync(out, JSON.stringify(written));
  const refused = runCli(['--input', sampleInput, '--blocks', sampleBlocks, '--out', out]);
  assert.equal(refused.status, 3);
  assert.equal(JSON.parse(fs.readFileSync(out, 'utf8')).drivers[0].review.status, 'accepted');
  fs.writeFileSync(out, '{ not json');
  assert.equal(runCli(['--input', sampleInput, '--blocks', sampleBlocks, '--out', out]).status, 3);
});

test('--check exits 1 on a sketch that does not hold, and bad usage exits 2', () => {
  const folder = temp();
  const file = path.join(folder, 'sketch.json');
  fs.writeFileSync(file, JSON.stringify({ schemaVersion: '1', drivers: [{ id: 'D-001', ...stated({ quote: 'made up' }), review: { status: 'pending' } }] }));
  const check = runCli(['--check', file, '--blocks', sampleBlocks]);
  assert.equal(check.status, 1);
  assert.match(check.stderr, /\(design sketch\) drivers\[0\]\.quote/);
  assert.equal(runCli([]).status, 2);
  assert.equal(runCli(['--input', sampleInput, '--blocks', sampleBlocks]).status, 2);
  assert.equal(runCli(['--check', file, '--blocks', sampleBlocks, '--out', file]).status, 2);
  assert.equal(runCli(['--bogus', 'x']).status, 2);
  assert.equal(runCli(['--input', path.join(folder, 'missing.json'), '--blocks', sampleBlocks, '--out', file]).status, 1);
});
