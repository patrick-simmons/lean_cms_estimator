import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import { assembleWorkingFile, hasReviewState, proposeChanges } from './assemble-working-file.mjs';
import { blocks, catalogMd, estimatingPath, reviewedBlueprint, rerunExtract, root } from './fixtures/assemble-fixtures.mjs';
import { validateProposalsValue } from './validate-proposals.mjs';

describe('assemble-working-file proposals mode (SAPP-014)', () => {
  it('never changes the existing Blueprint and lists adds, updates and conflicts', () => {
    const existing = reviewedBlueprint();
    const snapshot = JSON.stringify(existing);
    const { proposals, stats } = proposeChanges({
      extract: rerunExtract,
      blocks,
      catalogMd,
      existing,
      meta: { runId: 'run-2', now: '2026-11-09T10:00:00Z', packVersion: '0.1.0' }
    });
    assert.equal(JSON.stringify(existing), snapshot, 'the Blueprint object is untouched');
    assert.deepEqual(validateProposalsValue(proposals), []);
    assert.equal(stats.unchanged, 1);
    assert.equal(stats.dismissedTarget, 1);
    assert.deepEqual(proposals.proposals.map((p) => [p.id, p.kind, p.requirementId]), [
      ['P-001', 'conflict', 'R-002'],
      ['P-002', 'update', 'R-001'],
      ['P-003', 'add', undefined]
    ]);
    const conflict = proposals.proposals[0];
    assert.equal(conflict.coverage, 'conflict');
    assert.equal(conflict.sources[0].blockId, 'src-deck#s9');
    assert.equal(conflict.existing.statement, 'Launch in four locales, EN first.');
    assert.equal(conflict.existing.reviewStatus, 'edited');
    assert.equal(conflict.question, 'Which is the launch scope?');
    const update = proposals.proposals[1];
    assert.deepEqual(update.cause, { kind: 'file', itemId: 'src-addendum', fileName: 'Addendum.pdf' });
    assert.equal(update.existing.reviewStatus, 'accepted');
    assert.equal(proposals.blueprintRevision, 1);
    assert.deepEqual(proposals.sources.map((s) => s.itemId), ['src-addendum'], 'only the file the Blueprint does not list is carried');
    assert.deepEqual(proposals.runs, [{ runId: 'run-2', at: '2026-11-09T10:00:00Z', packVersion: '0.1.0', added: 3 }]);
  });

  it('appends to an existing proposals file and does not propose the same thing twice', () => {
    const existing = reviewedBlueprint();
    const first = proposeChanges({ extract: rerunExtract, blocks, catalogMd, existing, meta: { runId: 'run-2', now: '2026-11-09T10:00:00Z' } });
    first.proposals.proposals[2].review = { status: 'rejected', by: 'e@example.com', at: '2026-11-09T11:00:00Z' };
    const second = proposeChanges({
      extract: {
        ...rerunExtract,
        requirements: [
          ...rerunExtract.requirements,
          { statement: 'All public pages meet WCAG 2.2 AA.', blockIds: ['src-addendum#p1.2'], workPackage: 'search', coverage: 'human-led', question: null, duplicateOf: null }
        ]
      },
      blocks,
      catalogMd,
      existing,
      proposals: first.proposals,
      meta: { runId: 'run-3', now: '2026-11-10T10:00:00Z' }
    });
    assert.equal(second.stats.alreadyProposed, 3, 'the rejected add stays rejected and is not re-proposed');
    assert.deepEqual(second.proposals.proposals.map((p) => [p.id, p.kind, p.review.status]), [
      ['P-001', 'conflict', 'pending'],
      ['P-002', 'update', 'pending'],
      ['P-003', 'add', 'rejected'],
      ['P-004', 'add', 'pending']
    ]);
    assert.equal(second.proposals.runs.length, 2);
    assert.deepEqual(second.proposals.sources.map((s) => s.itemId), ['src-addendum']);
    assert.deepEqual(validateProposalsValue(second.proposals), []);
  });

  it('does not propose a rejected update again, so the app can say a rejected proposal is final', () => {
    const existing = reviewedBlueprint();
    const first = proposeChanges({ extract: rerunExtract, blocks, catalogMd, existing, meta: { runId: 'run-2', now: '2026-11-09T10:00:00Z' } });
    const update = first.proposals.proposals.find((p) => p.kind === 'update');
    update.review = { status: 'rejected', by: 'e@example.com', at: '2026-11-09T11:00:00Z' };
    const second = proposeChanges({ extract: rerunExtract, blocks, catalogMd, existing, proposals: first.proposals, meta: { runId: 'run-3', now: '2026-11-10T10:00:00Z' } });
    assert.equal(second.proposals.proposals.length, first.proposals.proposals.length, 'nothing new is written');
    assert.equal(second.proposals.proposals.find((p) => p.id === update.id).review.status, 'rejected');
    assert.equal(second.stats.alreadyProposed, first.proposals.proposals.length);
  });

  it('refuses an existing Blueprint that is not valid', () => {
    assert.throws(
      () => proposeChanges({ extract: rerunExtract, blocks, catalogMd, existing: { requirements: [{}] } }),
      /existing Blueprint is not valid/
    );
  });

  it('knows which files hold review state', () => {
    const { working } = assembleWorkingFile({
      extract: { requirements: [{ statement: 'A', blockIds: ['src-rfp#p1'], workPackage: 'content-migration', coverage: 'accelerated' }], platform: { id: null, blockId: null } },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(hasReviewState(working), false);
    assert.equal(hasReviewState({ ...working, revision: 1 }), true);
    assert.equal(hasReviewState({ ...working, skillSet: [{ skillId: 'aem-core' }] }), true);
    assert.equal(hasReviewState({ ...working, estimate: { totalHours: 1 } }), true);
    assert.equal(hasReviewState(reviewedBlueprint()), true);
    assert.equal(hasReviewState(undefined), false);
  });

  it('the CLI refuses to overwrite a reviewed Blueprint and writes proposals instead', () => {
    const scratch = mkdtempSync(join(tmpdir(), 'assemble-'));
    try {
      const blueprintPath = join(scratch, 'Pilot_Blueprint.json');
      writeFileSync(blueprintPath, JSON.stringify(reviewedBlueprint()));
      const before = readFileSync(blueprintPath, 'utf8');
      writeFileSync(join(scratch, 'extract.json'), JSON.stringify(rerunExtract));
      writeFileSync(join(scratch, 'blocks.json'), JSON.stringify(blocks));
      const estimating = estimatingPath;
      const script = join(root, 'tools', 'blueprint', 'assemble-working-file.mjs');
      const common = ['--extract', join(scratch, 'extract.json'), '--blocks', join(scratch, 'blocks.json'), '--estimating', estimating];

      const refused = spawnSync(process.execPath, [script, ...common, '--project-id', 'p1', '--project-name', 'Pilot', '--out', blueprintPath], { encoding: 'utf8' });
      assert.equal(refused.status, 3, refused.stderr);
      assert.match(refused.stderr, /--mode proposals/);
      assert.equal(readFileSync(blueprintPath, 'utf8'), before);

      const proposalsPath = join(scratch, 'Pilot_Proposals.json');
      const run = spawnSync(process.execPath, [script, '--mode', 'proposals', ...common, '--existing', blueprintPath, '--out', proposalsPath, '--run-id', 'run-2'], { encoding: 'utf8' });
      assert.equal(run.status, 0, run.stderr);
      assert.match(run.stdout, /the existing Blueprint was not changed/);
      assert.equal(readFileSync(blueprintPath, 'utf8'), before);
      const written = JSON.parse(readFileSync(proposalsPath, 'utf8'));
      assert.equal(written.proposals.length, 3);
      assert.deepEqual(validateProposalsValue(written), []);

      const again = spawnSync(process.execPath, [script, '--mode', 'proposals', ...common, '--existing', blueprintPath, '--out', proposalsPath, '--run-id', 'run-3'], { encoding: 'utf8' });
      assert.equal(again.status, 0, again.stderr);
      assert.equal(JSON.parse(readFileSync(proposalsPath, 'utf8')).proposals.length, 3, 'a repeat run adds nothing new');
    } finally {
      rmSync(scratch, { recursive: true, force: true });
    }
  });
});
