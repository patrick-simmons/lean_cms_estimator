import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { estimatePlan, formatSummary, summarizePlan, validatePlan } from './plan.mjs';
import { buildSyntheticPlan } from '../eval/synthetic-plan.mjs';
import { loadModelInputs, round2 } from './estimate-model.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';
import {
  AiPlanError,
  buildAiPlan,
  buildInventory,
  eligibilityOf,
  formatAiReport,
  OPT_OUT_REASONS,
  parseCmk,
  parseEstimating,
  parseToolkit,
  readCatalogs,
  staleAiPlan,
  validateAiPlan,
  withOptOut,
  withoutOptOut
} from './ai-plan.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'plan.mjs');
const catalogs = readCatalogs();
const workPackages = parseActivities(catalogs.estimatingMd);
const inputs = loadModelInputs();
const NOW = '2026-11-13T12:00:00.000Z';

/** The synthetic plan (platform aem) with its AI plan built, as `ai-plan` would write it. */
function withAiPlan(platform = 'aem', optOuts = [], modelInputs = inputs) {
  const plan = buildSyntheticPlan();
  if (platform !== 'aem') {
    estimatePlan(plan, modelInputs, { platform, workPackages, now: NOW });
  }
  plan.aiPlan = buildAiPlan(plan, catalogs, { platform, now: NOW, optOuts }).aiPlan;
  estimatePlan(plan, modelInputs, { workPackages, now: NOW });
  return plan;
}

const byId = (list, id) => list.find((item) => item.id === id);

test('the catalogs parse: the estimating tables, CMK for all platforms and by platform, and the toolkit', () => {
  const estimating = parseEstimating(catalogs.estimatingMd);
  assert.deepEqual(Array.from(estimating.methods.keys()).sort(), ['adr', 'cdk-loop', 'ld-bug', 'ld-quality', 'pdk-product']);
  assert.ok(estimating.rows.some((row) => row.workPackage === 'component-build' && row.platform === 'aem-eds' && row.capabilities.some((item) => item.id === 'aem-eds-figma-to-content' && item.optIn)));
  const cmk = parseCmk(catalogs.cmkMd);
  assert.equal(cmk.common.get('cmk-a11y').kind, 'skill');
  assert.equal(cmk.common.get('cmk-content-architect').kind, 'agent');
  assert.equal(cmk.vendor.get('aem').get('aem-cloud-rde').mode, 'opt_in');
  assert.equal(cmk.assets.get('adobe-aem-cloud-rde').name, 'AEM Cloud Service Rapid Development Environments');
  const toolkit = parseToolkit(catalogs.toolkitMd);
  assert.equal(toolkit.get('cdk:cdk-plan').plugin, 'cdk');
  assert.equal(toolkit.get('adr:adr-adversarial-challenger').kind, 'agent');
});

test('the inventory is every tool the catalogs offer for the platform, and nothing from another platform', () => {
  const cmk = parseCmk(catalogs.cmkMd);
  const toolkit = parseToolkit(catalogs.toolkitMd);
  const aem = buildInventory({ cmk, toolkit, platform: 'aem' });
  const eds = buildInventory({ cmk, toolkit, platform: 'aem-eds' });
  const acquia = buildInventory({ cmk, toolkit, platform: 'acquia' });
  assert.ok(aem.has('aem-cloud-dispatcher') && !aem.has('aem-eds-cli'));
  assert.ok(eds.has('aem-eds-cli') && !eds.has('aem-cloud-dispatcher'));
  assert.ok(aem.has('cmk-a11y') && aem.has('cdk:cdk-plan') && aem.has('launch-delivery:setup-project'));
  assert.equal(aem.get('aem-cloud-rde').optIn, true);
  assert.equal(aem.get('aem-cloud-rde').assetId, 'adobe-aem-cloud-rde');
  assert.equal(acquia.get('acquia-acli-application-management').localOnly, true);
  assert.ok(eds.size > aem.size, 'Edge Delivery has the larger vendor set');
});

test('every tool the estimating catalog lists is in the inventory, on both pilot platforms', () => {
  for (const platform of ['aem', 'aem-eds']) {
    assert.doesNotThrow(() => buildAiPlan(buildSyntheticPlan(), catalogs, { platform }), platform);
  }
});

test('a catalog id the CMK and toolkit catalogs do not offer on the platform is an error', () => {
  const broken = { ...catalogs, estimatingMd: catalogs.estimatingMd.replace('`cmk-audit`, `pdk:pdk-document-project`', '`cmk-audit`, `pdk:not-a-skill`') };
  assert.throws(() => buildAiPlan(buildSyntheticPlan(), broken, { platform: 'aem' }), (error) => error instanceof AiPlanError && /pdk:not-a-skill/.test(error.message));
});

test('every tool a workstream uses is ON by default, every opt-in tool and method included', () => {
  const { aiPlan } = buildAiPlan(buildSyntheticPlan(), catalogs, { platform: 'aem', now: NOW });
  assert.ok(aiPlan.tools.length > 0 && aiPlan.tools.every((tool) => tool.status === 'on'));
  assert.ok(aiPlan.methods.every((method) => method.status === 'on'), 'pdk-product, ld-bug and adr are not default methods, and are ON');
  assert.equal(byId(aiPlan.tools, 'aem-cloud-rde').optIn, true);
  assert.equal(byId(aiPlan.tools, 'aem-cloud-rde').status, 'on');
  assert.deepEqual(byId(aiPlan.tools, 'cdk:cdk-plan').methods, ['cdk-loop']);
  assert.deepEqual(byId(aiPlan.tools, 'cdk:cdk-plan').workstreams,
    ['accessibility-audit', 'component-build', 'component-review', 'frontend-delivery', 'integrations', 'search']);
  assert.deepEqual(aiPlan.optOuts, []);
  assert.equal(aiPlan.inventory.on, aiPlan.inventory.used);
  assert.equal(aiPlan.inventory.used + aiPlan.inventory.unused, aiPlan.inventory.total);
});

test('mapped local-only tools are ON and readiness requires local sync before default or opt-in obligations', () => {
  const original = '| `component-build` | aem | `aem-cloud-create-component` | — | — |';
  const replacement = '| `component-build` | acquia | `acquia-acli-application-management`, `acquia-playbooks-drupal-update-deploy` (opt-in) | — | — |';
  assert.ok(catalogs.estimatingMd.includes(original));
  const localCatalogs = { ...catalogs, estimatingMd: catalogs.estimatingMd.replace(original, replacement) };
  const { aiPlan } = buildAiPlan(buildSyntheticPlan(), localCatalogs, { platform: 'acquia', now: NOW });
  const defaultTool = byId(aiPlan.tools, 'acquia-acli-application-management');
  const optInTool = byId(aiPlan.tools, 'acquia-playbooks-drupal-update-deploy');
  assert.deepEqual([defaultTool.status, defaultTool.localOnly, defaultTool.optIn], ['on', true, false]);
  assert.deepEqual([optInTool.status, optInTool.localOnly, optInTool.optIn], ['on', true, true]);

  const defaultAsset = aiPlan.readiness.find((item) => item.item.includes('(acquia-cloud-ace)'));
  const optInAsset = aiPlan.readiness.find((item) => item.item.includes('(acquia-drupal-update-deploy)'));
  assert.match(defaultAsset.needs, /must be synced locally/);
  assert.doesNotMatch(defaultAsset.needs, /Opt-in vendor asset/);
  assert.match(optInAsset.needs, /must be synced locally/);
  assert.match(optInAsset.needs, /Opt-in vendor asset: enable it explicitly/);
});

test('with everything ON the hours are the stage 3 hours', () => {
  const plan = buildSyntheticPlan();
  const before = plan.workstreams.map((row) => [row.id, row.aiAssistedHours]);
  const after = withAiPlan().workstreams.map((row) => [row.id, row.aiAssistedHours]);
  assert.deepEqual(after, before);
  const eds = withAiPlan('aem-eds');
  const edsPlain = buildSyntheticPlan();
  estimatePlan(edsPlain, inputs, { platform: 'aem-eds', workPackages, now: NOW });
  assert.deepEqual(eds.workstreams.map((row) => row.aiAssistedHours), edsPlain.workstreams.map((row) => row.aiAssistedHours));
});

test('a requirement has a tool, or a reason, and the reason is the catalog fact, not an invention', () => {
  const plan = withAiPlan();
  const entries = plan.aiPlan.requirements;
  assert.equal(entries.length, plan.requirements.length);
  for (const entry of entries) {
    assert.ok(entry.tools.length > 0 || entry.methods.length > 0 || entry.reason, entry.requirementId);
  }
  const unmapped = entries.find((entry) => entry.workstream === 'unmapped');
  assert.match(unmapped.reason, /No work package fits/);
  assert.equal(unmapped.reasonSource, 'catalog');
  const integrations = entries.find((entry) => entry.workstream === 'integrations');
  assert.deepEqual(integrations.tools, [], 'integrations lists no tool, only a method');
  assert.deepEqual(integrations.methods, ['cdk-loop']);
  assert.equal(integrations.reason, undefined);
  const migration = entries.find((entry) => entry.workstream === 'content-migration');
  assert.ok(migration.tools.includes('cmk-migration-script'));
});

test('the validator rejects a requirement with neither a tool nor a reason, and an unknown tool', () => {
  const plan = withAiPlan();
  assert.deepEqual(validatePlan(plan, { workPackages }), []);
  const entry = plan.aiPlan.requirements.find((item) => item.workstream === 'content-migration');
  const clone = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy.aiPlan.requirements.find((item) => item.workstream === 'content-migration'));
    return validateAiPlan(copy);
  };
  assert.ok(clone((row) => { row.tools = []; row.methods = []; }).some((m) => /has neither a tool nor a reason/.test(m)));
  assert.deepEqual(clone((row) => { row.tools = []; row.methods = []; row.reason = 'The client does its own migration.'; }), []);
  assert.ok(clone((row) => { row.tools = ['not-a-tool']; }).some((m) => /not ON in this AI plan/.test(m)));
  assert.ok(entry.tools.length > 0);
});

test('an opt-out needs a reason from the list and a typed note', () => {
  assert.deepEqual(OPT_OUT_REASONS, ['not-licensed', 'not-installed', 'client-restriction', 'not-suitable']);
  assert.throws(() => withOptOut([], { id: 'cdk-loop', reason: 'because', note: 'x' }), /needs a reason: one of not-licensed/);
  assert.throws(() => withOptOut([], { id: 'cdk-loop', reason: 'not-licensed', note: '  ' }), /typed note/);
  assert.throws(() => withOptOut([], { reason: 'not-licensed', note: 'x' }), /Name the tool/);
  const list = withOptOut([], { id: 'cdk-loop', reason: 'not-licensed', note: ' No licence for cdk. ', now: NOW });
  assert.deepEqual(list, [{ id: 'cdk-loop', reason: 'not-licensed', note: 'No licence for cdk.', at: NOW }]);
  assert.equal(withOptOut(list, { id: 'cdk-loop', reason: 'not-installed', note: 'Not rolled out yet', now: NOW }).length, 1, 'the same id is replaced, not repeated');
  assert.deepEqual(withoutOptOut(list, 'cdk-loop'), []);
  assert.throws(() => withoutOptOut([], 'cdk-loop'), /is not opted out/);
});

test('opting out of a delivery method turns off its tools and sends the hours it supported back to traditional', () => {
  const on = withAiPlan('aem-eds');
  const off = withAiPlan('aem-eds', [{ id: 'cdk-loop', kind: 'method', reason: 'client-restriction', note: 'No code leaves the client network.', at: NOW }]);
  assert.equal(byId(off.aiPlan.methods, 'cdk-loop').status, 'off');
  assert.equal(byId(off.aiPlan.tools, 'cdk:cdk-implement').status, 'off');
  assert.equal(byId(off.aiPlan.tools, 'cmk-enrich-spec').status, 'off');
  assert.equal(byId(off.aiPlan.tools, 'cmk-a11y').status, 'on', 'tools outside the method stay ON');
  // integrations has only the method behind it: no tool ON for it, so no saving.
  const saved = (plan, id) => byId(plan.workstreams, id).aiAssistedHours < byId(plan.workstreams, id).traditionalHours;
  assert.equal(saved(off, 'integrations'), false);
  assert.equal(saved(on, 'integrations'), true);
  // search has a tool outside the method (cmk-search-design), so it keeps the saving.
  assert.equal(saved(off, 'search'), true);
  // component-build keeps it too: the tools outside the method are still ON.
  assert.equal(saved(off, 'component-build'), true);
  // The catalog's 30% saving, still taken off whatever the rate is. Naming the rate here would
  // tie a test about opt-outs to the case library, which moves every time a case lands.
  const build = byId(off.workstreams, 'component-build').hoursPerUnit;
  assert.equal(build.aiAssisted, round2(build.traditional * 0.7));
  assert.ok(off.workstreams.reduce((sum, row) => sum + row.aiAssistedHours, 0) > on.workstreams.reduce((sum, row) => sum + row.aiAssistedHours, 0));
  assert.deepEqual(validatePlan(off, { workPackages }), []);
  const entry = off.aiPlan.requirements.find((item) => item.workstream === 'integrations');
  assert.deepEqual(entry.methods, []);
  assert.match(entry.reason, /Every tool and delivery method the catalog lists for integrations on aem-eds is opted out/);
});

test('a workstream keeps its saving while any tool for it is ON, and loses it when every one is opted out', () => {
  const someOut = withAiPlan('aem-eds', [
    { id: 'aem-eds-page-import', kind: 'tool', reason: 'not-installed', note: 'Import skills not installed.', at: NOW },
    { id: 'aem-eds-generate-import-html', kind: 'tool', reason: 'not-installed', note: 'Import skills not installed.', at: NOW },
    { id: 'aem-eds-preview-import', kind: 'tool', reason: 'not-installed', note: 'Import skills not installed.', at: NOW }
  ]);
  // Three of content-migration's tools are off, but others are not, so the saving stands.
  assert.equal(byId(someOut.workstreams, 'content-migration').hoursPerUnit.aiAssisted, 1.4);
  assert.deepEqual(eligibilityOf(someOut.aiPlan, ['content-migration']).get('content-migration'), { tools: true });

  const allOut = withAiPlan('aem-eds', someOut.aiPlan.tools
    .filter((tool) => tool.workstreams.indexOf('content-migration') !== -1)
    .map((tool) => ({ id: tool.id, kind: 'tool', reason: 'not-installed', note: 'Nothing installed.', at: NOW })));
  const migration = byId(allOut.workstreams, 'content-migration');
  assert.equal(migration.hoursPerUnit.aiAssisted, migration.hoursPerUnit.traditional, 'no tool ON, no saving');
  assert.deepEqual(eligibilityOf(allOut.aiPlan, ['content-migration']).get('content-migration'), { tools: false });
});

test('an opt-out is kept when the plan is built again, and dropped with a warning when nothing uses the tool', () => {
  const plan = withAiPlan('aem', [{ id: 'cdk-loop', kind: 'method', reason: 'not-licensed', note: 'No licence.', at: NOW }]);
  const again = buildAiPlan(plan, catalogs, { platform: 'aem', now: NOW, optOuts: plan.aiPlan.optOuts });
  assert.deepEqual(again.aiPlan.optOuts, plan.aiPlan.optOuts);
  const gone = buildAiPlan(plan, catalogs, { platform: 'aem', now: NOW, optOuts: [{ id: 'aem-eds-cli', kind: 'tool', reason: 'not-licensed', note: 'x', at: NOW }] });
  assert.deepEqual(gone.aiPlan.optOuts, []);
  assert.match(gone.warnings.join(), /opt-out of aem-eds-cli was dropped/);
});

test('the validator catches an opt-out with no note, a status that disagrees, and hours that claim a saving from an OFF tool', () => {
  const plan = withAiPlan('aem', [{ id: 'cdk-loop', kind: 'method', reason: 'not-licensed', note: 'No licence.', at: NOW }]);
  assert.deepEqual(validatePlan(plan, { workPackages }), []);
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validatePlan(copy, { workPackages });
  };
  assert.ok(broken((p) => { p.aiPlan.optOuts[0].note = ''; }).some((m) => /note: an opt-out carries the typed reason/.test(m)));
  assert.ok(broken((p) => { p.aiPlan.optOuts[0].reason = 'whim'; }).some((m) => /optOuts\[0\]\.reason/.test(m)));
  assert.ok(broken((p) => { byId(p.aiPlan.methods, 'cdk-loop').status = 'on'; }).some((m) => /cdk-loop is on but is opted out/.test(m)));
  assert.ok(broken((p) => { byId(p.aiPlan.tools, 'cdk:cdk-plan').status = 'on'; }).some((m) => /cdk:cdk-plan is on but should be off/.test(m)));
  // The opt-out is made by hand and the estimate is not run again: the hours still claim the saving.
  const handEdited = withAiPlan('aem');
  handEdited.aiPlan = buildAiPlan(handEdited, catalogs, { platform: 'aem', now: NOW, optOuts: plan.aiPlan.optOuts }).aiPlan;
  const claims = validatePlan(handEdited, { workPackages });
  assert.ok(claims.some((m) => /integrations claims an AI saving, but no tool for it is ON in this AI plan; run estimate again/.test(m)), claims.join('\n'));
  assert.ok(broken((p) => { p.aiPlan.platform = 'aem-eds'; }).some((m) => /not the platform of the estimate/.test(m)));
});

test('an AI plan for another platform stops the estimate; with the catalogs it is rebuilt and the opt-outs stay', () => {
  const plan = withAiPlan('aem', [{ id: 'cdk-loop', kind: 'method', reason: 'not-licensed', note: 'No licence.', at: NOW }]);
  assert.throws(() => estimatePlan(JSON.parse(JSON.stringify(plan)), inputs, { platform: 'aem-eds', workPackages }), /AI plan was built for aem, not aem-eds/);
  const copy = JSON.parse(JSON.stringify(plan));
  estimatePlan(copy, inputs, { platform: 'aem-eds', workPackages, catalogs, now: NOW });
  assert.equal(copy.aiPlan.platform, 'aem-eds');
  assert.deepEqual(copy.aiPlan.optOuts.map((item) => item.id), ['cdk-loop']);
  assert.deepEqual(validatePlan(copy, { workPackages }), []);
});

test('a requirement added after the AI plan is a warning, not an error', () => {
  const plan = withAiPlan();
  plan.requirements.push({ ...plan.requirements[0], id: 'R-099', statement: 'A new requirement', review: { status: 'pending' } });
  assert.deepEqual(validatePlan(plan, { workPackages }), []);
  assert.deepEqual(staleAiPlan(plan), ['R-099 has no tool or reason in the AI plan yet.']);
  assert.match(formatSummary(summarizePlan(plan, workPackages)), /Out of date: R-099 has no tool or reason in the AI plan yet\. Run ai-plan again\./);
});

test('the readiness list names the plugins, vendor assets and method prerequisites that the ON tools need', () => {
  const { aiPlan } = buildAiPlan(buildSyntheticPlan(), catalogs, { platform: 'aem-eds', now: NOW });
  const items = aiPlan.readiness.map((item) => item.item);
  assert.ok(items.includes('CMK plugin'));
  assert.ok(items.includes('ai-dev-toolkit plugin cdk'));
  assert.ok(items.includes('Delivery method cdk-loop'));
  const figma = aiPlan.readiness.find((item) => /adobe-aem-eds-figma/.test(item.item));
  assert.match(figma.needs, /Opt-in vendor asset/);
  assert.ok(figma.workstreams.includes('component-build'));
  assert.match(aiPlan.readiness.find((item) => item.item === 'Delivery method cdk-loop').needs, /Jira or Azure DevOps ticket/);

  const off = buildAiPlan(buildSyntheticPlan(), catalogs, { platform: 'aem-eds', now: NOW, optOuts: [{ id: 'cdk-loop', kind: 'method', reason: 'not-licensed', note: 'No licence.', at: NOW }] }).aiPlan;
  assert.ok(!off.readiness.some((item) => item.item === 'Delivery method cdk-loop'));
  assert.ok(!off.readiness.some((item) => item.item === 'ai-dev-toolkit plugin cdk'), 'the cdk tools are all in the method');
});

test('the unused-tool report lists what the catalogs offer and the estimating catalog maps to no workstream', () => {
  const plan = withAiPlan('aem-eds');
  assert.ok(plan.aiPlan.unusedTools.includes('aem-eds-bulk-metadata'));
  assert.ok(plan.aiPlan.unusedTools.includes('pdk:pdk-dev-story'));
  assert.ok(!plan.aiPlan.unusedTools.includes('aem-eds-cli'));
  const report = formatAiReport(plan);
  assert.match(report, /## Tools no workstream uses \(\d+\)/);
  assert.match(report, /- aem-eds \(\d+\): .*aem-eds-bulk-metadata/);
  assert.match(report, /## What must be ready/);
  assert.match(report, /## Requirements with no tool/);
});

test('the summary shows the AI plan', () => {
  const summary = summarizePlan(withAiPlan(), workPackages);
  assert.equal(summary.ai.platform, 'aem');
  const markdown = formatSummary(summary);
  assert.match(markdown, /## AI plan/);
  assert.match(markdown, /Every available tool is assumed in use on aem: \d+ of \d+ tools/);
  assert.equal(summarizePlan(buildSyntheticPlan(), workPackages).ai, undefined);
});

test('CLI: ai-plan, ai-opt-out, ai-restore and ai-report change the file and size the estimate again', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ai-plan-cli-'));
  try {
    const file = path.join(dir, 'Fabrikam_Plan.json');
    const run = (...args) => spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
    const read = () => JSON.parse(fs.readFileSync(file, 'utf8'));
    const plan = buildSyntheticPlan();
    fs.writeFileSync(file, `${JSON.stringify(plan, null, 2)}\n`);

    const built = run('ai-plan', file);
    assert.equal(built.status, 0, built.stderr);
    assert.match(built.stdout, /AI plan for aem: \d+ of \d+ tools used by a workstream are ON/);
    assert.equal(read().aiPlan.optOuts.length, 0);
    const base = read().workstreams.reduce((sum, row) => sum + row.aiAssistedHours, 0);

    const noNote = run('ai-opt-out', file, '--id', 'cdk-loop', '--reason', 'not-licensed');
    assert.equal(noNote.status, 1);
    assert.match(noNote.stderr, /typed note/);
    assert.equal(run('ai-opt-out', file, '--id', 'cdk-loop', '--reason', 'whim', '--note', 'x').status, 1);
    const unknown = run('ai-opt-out', file, '--id', 'aem-eds-cli', '--reason', 'not-licensed', '--note', 'x');
    assert.equal(unknown.status, 1);
    assert.match(unknown.stderr, /not a tool a workstream uses on aem/);
    assert.equal(run('ai-opt-out', file).status, 2);
    assert.equal(read().aiPlan.optOuts.length, 0, 'nothing written by a refused opt-out');

    const out = run('ai-opt-out', file, '--id', 'cdk-loop', '--reason', 'client-restriction', '--note', 'No code leaves the client network.');
    assert.equal(out.status, 0, out.stderr);
    assert.deepEqual(read().aiPlan.optOuts.map((item) => [item.id, item.reason, item.note]), [['cdk-loop', 'client-restriction', 'No code leaves the client network.']]);
    assert.ok(read().workstreams.reduce((sum, row) => sum + row.aiAssistedHours, 0) > base);
    assert.equal(run('validate', file).status, 0);

    const report = run('ai-report', file, '--markdown');
    assert.match(report.stdout, /client-restriction\. No code leaves the client network\./);

    const again = run('estimate', file);
    assert.equal(again.status, 0, again.stderr);
    assert.equal(read().aiPlan.optOuts.length, 1, 'a new estimate keeps the opt-outs');

    assert.equal(run('ai-restore', file, '--id', 'cdk-loop').status, 0);
    assert.equal(read().workstreams.reduce((sum, row) => sum + row.aiAssistedHours, 0), base);
    assert.equal(run('ai-restore', file, '--id', 'cdk-loop').status, 1, 'restoring what is not opted out is refused');

    const fresh = path.join(dir, 'Unestimated_Plan.json');
    const unestimated = JSON.parse(JSON.stringify(plan));
    unestimated.workstreams = [];
    unestimated.skills = [];
    delete unestimated.estimateBasis;
    unestimated.aiPlan = null;
    fs.writeFileSync(fresh, `${JSON.stringify(unestimated, null, 2)}\n`);
    const refused = run('ai-plan', fresh);
    assert.equal(refused.status, 1);
    assert.match(refused.stderr, /Run estimate first/);
    assert.equal(run('ai-report', fresh).status, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
