/**
 * What each retired `WP-nn` and `OH-nn` id became, so a plan file written against the old
 * breakdown fails with the replacement named rather than being silently migrated. A plan
 * carries estimator decisions, and guessing which activity a decision meant would put words
 * in their mouth.
 *
 * Two of the old ids split, and two overheads folded into delivery activities, so this is a
 * map to one or more activities rather than a rename.
 */
export const RETIRED_IDS = new Map([
  ['WP-01', ['discovery-audit']],
  ['WP-02', ['content-model']],
  ['WP-03', ['component-build']],
  ['WP-04', ['component-review', 'accessibility-audit']],
  ['WP-05', ['integrations']],
  ['WP-06', ['content-migration']],
  ['WP-07', ['seo']],
  ['WP-08', ['search']],
  ['WP-09', ['localization']],
  ['WP-10', ['multisite']],
  ['WP-11', ['qa-automation']],
  ['WP-12', ['environments-devops']],
  ['WP-13', ['uat-support', 'training-enablement']],
  ['WP-15', ['frontend-delivery']],
  ['OH-01', ['project-management']],
  ['OH-02', ['delivery-governance']],
  ['OH-03', ['qa-automation']],
  ['OH-04', ['environments-devops']]
]);

/**
 * The sentence to add to a validation error when the id is one we retired, or '' when it is
 * simply unknown.
 */
export function replacementFor(id) {
  const activities = RETIRED_IDS.get(String(id));
  if (!activities) {
    return '';
  }
  const named = activities.map((activity) => `"${activity}"`).join(' and ');
  return activities.length === 1
    ? `${id} is retired; it is now ${named}`
    : `${id} is retired; it split into ${named}, so choose the one this row meant`;
}
