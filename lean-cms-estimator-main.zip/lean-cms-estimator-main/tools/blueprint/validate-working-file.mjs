#!/usr/bin/env node
/**
 * Offline Blueprint working-file validator with field-path errors.
 * Mirrors parseWorkingFileContent / working-file.md (not silent undefined).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const COVERAGES = ['accelerated', 'partly', 'human-led', 'question', 'conflict'];
export const REVIEW_STATUSES = ['pending', 'accepted', 'edited', 'dismissed'];
const KINDS = new Set(['page', 'section', 'slide', 'sheet']);
const REQUIREMENT_ID = /^R-\d{3,}$/;
const SERVICE_START = /^\d{4}-(0[1-9]|1[0-2])$/;
const CATALOG_FIELDS = ['cmkCommit', 'toolkitCommit', 'estimatingVersion'];

function isObject(value) {
  return typeof value === 'object' && !!value && !Array.isArray(value);
}

function isString(value) {
  return typeof value === 'string';
}

function isText(value) {
  return isString(value) && value.trim().length > 0;
}

function isCount(value) {
  return typeof value === 'number' && Number.isFinite(value) && Math.floor(value) === value && value >= 0;
}

function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function isNonNegative(value) {
  return isFiniteNumber(value) && value >= 0;
}

const COVERAGE_SHARE_KEYS = ['accelerated', 'partly', 'humanLed', 'unresolved'];

/** Each of the four shares is rounded to three decimals, so their sum is off by 0.002 at most. */
const COVERAGE_SUM_TOLERANCE = 0.0025;

/** Four shares between 0 and 1 that sum to 1 within the rounding the build applies. */
function isCoverageShares(value) {
  if (!isObject(value)) {
    return false;
  }
  if (!COVERAGE_SHARE_KEYS.every((key) => isNonNegative(value[key]) && value[key] <= 1)) {
    return false;
  }
  const sum = COVERAGE_SHARE_KEYS.reduce((total, key) => total + value[key], 0);
  return Math.abs(sum - 1) <= COVERAGE_SUM_TOLERANCE;
}

function isPositiveInteger(value) {
  return typeof value === 'number' && Number.isFinite(value) && Math.floor(value) === value && value > 0;
}

/**
 * @param {unknown} value
 * @param {string} path
 * @param {string[]} errors
 */
export function checkLocation(value, locPath, errors) {
  if (!isObject(value) || !isString(value.kind) || !KINDS.has(value.kind)) {
    errors.push(`${locPath}: expected location with kind page|section|slide|sheet`);
    return;
  }
  if (value.kind === 'slide') {
    if (!isPositiveInteger(value.slide)) {
      errors.push(`${locPath}.slide: expected positive integer`);
    }
    if (value.slideTitle !== undefined && !isString(value.slideTitle)) {
      errors.push(`${locPath}.slideTitle: expected string`);
    }
    if (value.notes !== undefined && typeof value.notes !== 'boolean') {
      errors.push(`${locPath}.notes: expected boolean`);
    }
    return;
  }
  if (value.kind === 'sheet') {
    if (!isString(value.sheet)) {
      errors.push(`${locPath}.sheet: expected string`);
    }
    if (!isPositiveInteger(value.rowStart)) {
      errors.push(`${locPath}.rowStart: expected positive integer`);
    }
    if (!isPositiveInteger(value.rowEnd)) {
      errors.push(`${locPath}.rowEnd: expected positive integer`);
    } else if (isPositiveInteger(value.rowStart) && value.rowEnd < value.rowStart) {
      errors.push(`${locPath}.rowEnd: must be >= rowStart`);
    }
    return;
  }
  if (value.page !== undefined && !isPositiveInteger(value.page)) {
    errors.push(`${locPath}.page: expected positive integer`);
  }
  if (value.pageEnd !== undefined) {
    if (!isPositiveInteger(value.pageEnd)) {
      errors.push(`${locPath}.pageEnd: expected positive integer`);
    } else if (!isPositiveInteger(value.page) || value.pageEnd <= value.page) {
      errors.push(`${locPath}.pageEnd: must be > page`);
    }
  }
  if (value.pageApprox !== undefined && typeof value.pageApprox !== 'boolean') {
    errors.push(`${locPath}.pageApprox: expected boolean`);
  }
  if (value.heading !== undefined && !isString(value.heading)) {
    errors.push(`${locPath}.heading: expected string`);
  }
  if (value.section !== undefined && !isString(value.section)) {
    errors.push(`${locPath}.section: expected string`);
  }
}

/**
 * @param {unknown} value
 * @param {string} [base]
 * @returns {string[]}
 */
export function validateWorkingFileValue(value, base = '') {
  const errors = [];
  if (!isObject(value)) {
    return [`${base || '(root)'}: expected object`];
  }
  if (!isCount(value.revision)) {
    errors.push(`${base}revision: expected non-negative integer`);
  }
  if (!Array.isArray(value.sources)) {
    errors.push(`${base}sources: expected array`);
  }
  if (!Array.isArray(value.requirements)) {
    errors.push(`${base}requirements: expected array`);
    return errors;
  }
  if (!Array.isArray(value.questions)) {
    errors.push(`${base}questions: expected array`);
  }

  const seenIds = new Set();
  value.requirements.forEach((req, i) => {
    const p = `${base}requirements[${i}]`;
    if (!isObject(req)) {
      errors.push(`${p}: expected object`);
      return;
    }
    if (!isString(req.id) || !REQUIREMENT_ID.test(req.id)) {
      errors.push(`${p}.id: expected R-### (at least three digits)`);
    } else if (seenIds.has(req.id)) {
      errors.push(`${p}.id: duplicate id ${req.id}`);
    } else {
      seenIds.add(req.id);
    }
    if (!isText(req.statement)) {
      errors.push(`${p}.statement: required non-empty string`);
    }
    if (!Array.isArray(req.sources) || req.sources.length === 0) {
      errors.push(`${p}.sources: expected non-empty array`);
    } else {
      req.sources.forEach((src, j) => {
        const sp = `${p}.sources[${j}]`;
        if (!isObject(src)) {
          errors.push(`${sp}: expected object`);
          return;
        }
        for (const key of ['itemId', 'fileName', 'blockId', 'label', 'passage']) {
          if (!isString(src[key])) {
            errors.push(`${sp}.${key}: expected string`);
          }
        }
        checkLocation(src.location, `${sp}.location`, errors);
      });
    }
    if (!isText(req.workPackage)) {
      errors.push(`${p}.workPackage: required non-empty string`);
    }
    if (!Array.isArray(req.capabilities) || !req.capabilities.every(isString)) {
      errors.push(`${p}.capabilities: expected string[]`);
    }
    if (!isString(req.coverage) || !COVERAGES.includes(req.coverage)) {
      errors.push(`${p}.coverage: expected accelerated|partly|human-led|question|conflict`);
    }
    if (req.questionId !== undefined && !isString(req.questionId)) {
      errors.push(`${p}.questionId: expected string`);
    }
    if (!isObject(req.review) || !isString(req.review.status) || !REVIEW_STATUSES.includes(req.review.status)) {
      errors.push(`${p}.review.status: expected pending|accepted|edited|dismissed`);
    } else if (req.review.status !== 'pending') {
      if (!isString(req.review.by)) {
        errors.push(`${p}.review.by: required for non-pending`);
      }
      if (!isString(req.review.at)) {
        errors.push(`${p}.review.at: required for non-pending`);
      }
    }
    if (req.review && req.review.byName !== undefined && !isString(req.review.byName)) {
      errors.push(`${p}.review.byName: expected string`);
    }
    if (req.original !== undefined) {
      if (!isObject(req.original)) {
        errors.push(`${p}.original: expected object`);
      } else {
        if (!isText(req.original.statement)) {
          errors.push(`${p}.original.statement: required non-empty string`);
        }
        if (!isString(req.original.workPackage)) {
          errors.push(`${p}.original.workPackage: expected string`);
        }
        if (!isString(req.original.coverage) || !COVERAGES.includes(req.original.coverage)) {
          errors.push(`${p}.original.coverage: expected coverage enum`);
        }
      }
    }
  });

  if (Array.isArray(value.questions)) {
    value.questions.forEach((q, i) => {
      const p = `${base}questions[${i}]`;
      if (!isObject(q)) {
        errors.push(`${p}: expected object`);
        return;
      }
      if (!isString(q.id)) {
        errors.push(`${p}.id: expected string`);
      }
      if (!isString(q.requirementId)) {
        errors.push(`${p}.requirementId: expected string`);
      }
      if (!isString(q.text)) {
        errors.push(`${p}.text: expected string`);
      }
    });
  }

  if (value.platform !== undefined) {
    if (!isObject(value.platform)) {
      errors.push(`${base}platform: expected object`);
    } else {
      if (!isString(value.platform.id)) {
        errors.push(`${base}platform.id: expected string`);
      }
      if (!isString(value.platform.name)) {
        errors.push(`${base}platform.name: expected string`);
      }
      if (value.platform.citation !== undefined && !isString(value.platform.citation)) {
        errors.push(`${base}platform.citation: expected string`);
      }
    }
  }

  if (value.catalog !== undefined && isObject(value.catalog)) {
    for (const field of CATALOG_FIELDS) {
      if (value.catalog[field] !== undefined && !isString(value.catalog[field]) && value.catalog[field] !== null) {
        // Legacy nulls are ignored by the web part; only non-string non-null is wrong for pins we care about.
        // Non-catalog keys (legacy cmk/estimating null) are allowed.
      }
    }
  }

  if (value.levers !== undefined && value.levers !== null) {
    checkLevers(value.levers, `${base}levers`, errors);
  }

  checkPhaseLag(value.phasePlan, `${base}phasePlan`, errors);

  if (value.estimate !== undefined && value.estimate !== null) {
    checkEstimate(value.estimate, `${base}estimate`, errors);
  }

  if (value.handoff !== undefined && value.handoff !== null) {
    checkHandoff(value.handoff, `${base}handoff`, errors);
    if (value.estimate === undefined || value.estimate === null) {
      errors.push(`${base}handoff: requires estimate to be present`);
    }
  }

  if (value.history !== undefined) {
    if (!Array.isArray(value.history)) {
      errors.push(`${base}history: expected array`);
    } else {
      value.history.forEach((entry, i) => {
        const p = `${base}history[${i}]`;
        if (!isObject(entry)) {
          errors.push(`${p}: expected object`);
          return;
        }
        if (!isString(entry.at)) {
          errors.push(`${p}.at: expected string`);
        }
        if (entry.kind !== 'estimate') {
          errors.push(`${p}.kind: expected "estimate"`);
        }
        if (!isNonNegative(entry.totalHours)) {
          errors.push(`${p}.totalHours: expected non-negative number`);
        }
        if (!isNonNegative(entry.price)) {
          errors.push(`${p}.price: expected non-negative number`);
        }
        if (!isString(entry.deliveryMix)) {
          errors.push(`${p}.deliveryMix: expected string`);
        }
      });
    }
  }

  if (value.published !== undefined) {
    checkPublished(value.published, `${base}published`, errors);
  }

  return errors;
}

function isStringArray(value) {
  return Array.isArray(value) && value.every(isString);
}

/** `{ optIn: string[], methods: string[] }`, the project's AI lever selection (SPMVP-034). */
function checkLevers(value, p, errors) {
  if (!isObject(value)) {
    errors.push(`${p}: expected object`);
    return;
  }
  for (const key of ['optIn', 'methods']) {
    if (!isStringArray(value[key])) {
      errors.push(`${p}.${key}: expected string[]`);
    }
  }
}

// Keep in step with MAX_LAG_WEEKS in src/webparts/blueprint/projects/workingFile.ts.
const MAX_LAG_WEEKS = 520;

/**
 * Phase `lagWeeks` (SPMVP-041): optional whole number, negative allowed, within ±MAX_LAG_WEEKS.
 * This tool does not validate other phase fields; it only reports a bad lag with its field path.
 */
function checkPhaseLag(phases, p, errors) {
  if (!Array.isArray(phases)) {
    return;
  }
  phases.forEach((phase, i) => {
    if (isObject(phase) && phase.lagWeeks !== undefined &&
      !(typeof phase.lagWeeks === 'number' && Number.isInteger(phase.lagWeeks) && Math.abs(phase.lagWeeks) <= MAX_LAG_WEEKS)) {
      errors.push(`${p}[${i}].lagWeeks: expected integer from -${MAX_LAG_WEEKS} to ${MAX_LAG_WEEKS}`);
    }
  });
}

function checkEstimate(value, p, errors) {
  if (!isObject(value)) {
    errors.push(`${p}: expected object`);
    return;
  }
  checkPhaseLag(value.phases, `${p}.phases`, errors);
  for (const key of ['totalHours', 'blendedRate', 'price']) {
    if (!isNonNegative(value[key])) {
      errors.push(`${p}.${key}: expected non-negative number`);
    }
  }
  if (!isText(value.deliveryMix)) {
    errors.push(`${p}.deliveryMix: required non-empty string`);
  }
  if (!isString(value.mixCountry)) {
    errors.push(`${p}.mixCountry: expected string`);
  }
  if (value.monthlyHours !== undefined && !(isFiniteNumber(value.monthlyHours) && value.monthlyHours >= 0)) {
    errors.push(`${p}.monthlyHours: expected non-negative number`);
  }
  if (!Array.isArray(value.deliveryMixes) || !value.deliveryMixes.every(isString)) {
    errors.push(`${p}.deliveryMixes: expected string[]`);
  }
  if (!Array.isArray(value.packages)) {
    errors.push(`${p}.packages: expected array`);
  } else {
    value.packages.forEach((pkg, i) => {
      const pp = `${p}.packages[${i}]`;
      if (!isObject(pkg)) {
        errors.push(`${pp}: expected object`);
        return;
      }
      for (const key of ['workPackageId', 'name', 'unit', 'confidence']) {
        if (!isString(pkg[key])) {
          errors.push(`${pp}.${key}: expected string`);
        }
      }
      for (const key of ['quantity', 'hoursPerUnit', 'hours']) {
        if (!isNonNegative(pkg[key])) {
          errors.push(`${pp}.${key}: expected non-negative number`);
        }
      }
      if (typeof pkg.sized !== 'boolean') {
        errors.push(`${pp}.sized: expected boolean`);
      }
      for (const key of ['baseHoursPerUnit', 'baseHours', 'accelerationPct']) {
        if (pkg[key] !== undefined && !isNonNegative(pkg[key])) {
          errors.push(`${pp}.${key}: expected non-negative number`);
        }
      }
      if (pkg.accelerationPct !== undefined && isNonNegative(pkg.accelerationPct) && pkg.accelerationPct > 100) {
        errors.push(`${pp}.accelerationPct: expected a number from 0 to 100`);
      }
      if (pkg.appliedLevers !== undefined && !isStringArray(pkg.appliedLevers)) {
        errors.push(`${pp}.appliedLevers: expected string[]`);
      }
      if (pkg.coverageShares !== undefined && !isCoverageShares(pkg.coverageShares)) {
        errors.push(`${pp}.coverageShares: expected {accelerated, partly, humanLed, unresolved} numbers from 0 to 1 that sum to 1 (within 0.0025)`);
      }
    });
  }
  if (!Array.isArray(value.staffing)) {
    errors.push(`${p}.staffing: expected array`);
  }
  if (!Array.isArray(value.challengerNotes) || !value.challengerNotes.every(isString)) {
    errors.push(`${p}.challengerNotes: expected string[]`);
  }
  if (!isObject(value.quantityOverrides)) {
    errors.push(`${p}.quantityOverrides: expected object`);
  }
  if (typeof value.assumedOptIn !== 'boolean') {
    errors.push(`${p}.assumedOptIn: expected boolean`);
  }
  if (typeof value.assumedMethods !== 'boolean') {
    errors.push(`${p}.assumedMethods: expected boolean`);
  }
  for (const key of ['traditionalHours', 'savingsHours', 'tracedHours']) {
    if (value[key] !== undefined && !isNonNegative(value[key])) {
      errors.push(`${p}.${key}: expected non-negative number`);
    }
  }
  if (value.tracedShare !== undefined && !(isNonNegative(value.tracedShare) && value.tracedShare <= 1)) {
    errors.push(`${p}.tracedShare: expected a number from 0 to 1`);
  }
  if (value.levers !== undefined) {
    checkLevers(value.levers, `${p}.levers`, errors);
  }
  if (typeof value.stale !== 'boolean') {
    errors.push(`${p}.stale: expected boolean`);
  }
  if (typeof value.challengerReviewed !== 'boolean') {
    errors.push(`${p}.challengerReviewed: expected boolean`);
  }
  if (!isString(value.builtAt)) {
    errors.push(`${p}.builtAt: expected string`);
  }
}

function checkHandoff(value, p, errors) {
  if (!isObject(value)) {
    errors.push(`${p}: expected object`);
    return;
  }
  if (!isString(value.serviceStart) || !SERVICE_START.test(value.serviceStart)) {
    errors.push(`${p}.serviceStart: expected YYYY-MM`);
  }
  if (!Number.isInteger(value.durationMonths) || value.durationMonths <= 0) {
    errors.push(`${p}.durationMonths: expected positive integer`);
  }
  if (!isString(value.savedAt)) {
    errors.push(`${p}.savedAt: expected string`);
  }
}

function checkPublished(value, p, errors) {
  if (!isObject(value)) {
    errors.push(`${p}: expected object`);
    return;
  }
  const required = ['publishedAt', 'publishedBy', 'fileId', 'fileName', 'webUrl', 'versionHistoryUrl', 'fileEtag', 'modified'];
  for (const field of required) {
    if (!isString(value[field])) {
      errors.push(`${p}.${field}: expected string`);
    }
  }
}

function main(argv) {
  const filePath = argv[2];
  if (!filePath) {
    console.error('Usage: node tools/blueprint/validate-working-file.mjs <path-to-blueprint.json>');
    process.exit(2);
  }
  const abs = path.resolve(filePath);
  let raw;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch (err) {
    console.error(`Cannot read ${abs}: ${err.message}`);
    process.exit(1);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    console.error(`(root): invalid JSON (${err.message})`);
    process.exit(1);
  }
  const errors = validateWorkingFileValue(parsed);
  if (errors.length) {
    for (const e of errors) {
      console.error(e);
    }
    process.exit(1);
  }
  console.log(`OK: ${path.basename(abs)}`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main(process.argv);
}
