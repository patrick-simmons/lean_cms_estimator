import assert from 'node:assert/strict';
import { test } from 'node:test';
import { bandAll, bandFor, BandError, BANDS, loadTierSignals, NO_SIGNAL_BAND, validateTierSignals } from './band.mjs';

const signals = new Map([
  ['search', [
    { band: 'large', words: ['federated search', 'relevance tuning'], reason: 'Search spans systems.' },
    { band: 'medium', words: ['facets'], reason: 'Faceting to configure.' },
    { band: 'medium', volume: 'integrations', atLeast: 3, reason: 'Three or more systems to search across.' },
    { band: 'small', words: ['native search'], reason: 'The platform\'s own search.' }
  ]]
]);

function planWith({ statement = 'Nothing much.', passage, volumes = [] } = {}) {
  return {
    requirements: [{
      id: 'R-001',
      statement,
      sources: passage ? [{ blockId: 'b#1', passage }] : [],
      review: { status: 'accepted' }
    }],
    volumes
  };
}

function band(plan) {
  return bandFor(plan, 'search', signals, 'Search');
}

test('a phrase quoted in the documents sets the band and says what it read', () => {
  const result = band(planWith({ passage: 'The platform must support federated search across the intranet.' }));
  assert.equal(result.band, 'large');
  assert.equal(result.bandConfidence, 'high');
  assert.equal(result.bandReason, 'Search spans systems.');
  assert.deepEqual(result.bandSignals.map((signal) => [signal.band, signal.matched, signal.blockId]), [['large', 'federated search', 'b#1']]);
  assert.equal(result.bandQuestion, undefined);
});

test('a phrase only in the statement bands it, but at lower confidence: a paraphrase is not a quote', () => {
  const result = band(planWith({ statement: 'They want federated search.' }));
  assert.equal(result.band, 'large');
  assert.equal(result.bandConfidence, 'medium');
  assert.equal(result.bandSignals[0].quoted, false);
});

test('quoted evidence replaces inferred evidence rather than outvoting it', () => {
  // The paraphrase says large, the document says medium. The document wins, even though it is
  // the lower band, because a summary cannot argue with the passage it was made from.
  const result = band(planWith({
    statement: 'They want relevance tuning.',
    passage: 'Search results are filtered by up to four facets.'
  }));
  assert.equal(result.band, 'medium');
  assert.deepEqual(result.bandSignals.map((signal) => signal.matched), ['facets']);
  assert.equal(result.bandChallenge, undefined, 'the inferred signal was never in the running, so there is nothing to challenge');
});

test('signals that disagree take the higher band and raise a challenge, not a question', () => {
  const result = band(planWith({ passage: 'Native search is enough today, but relevance tuning is expected later.' }));
  assert.equal(result.band, 'large');
  assert.match(result.bandChallenge, /banded large on "relevance tuning", but "native search" reads small/);
  assert.equal(result.bandQuestion, undefined, 'the documents did say something, so this is an argument to have, not a question to ask');
});

test('no signal means medium, low confidence and a question', () => {
  const result = band(planWith({ passage: 'The site has a home page.' }));
  assert.equal(result.band, NO_SIGNAL_BAND);
  assert.equal(result.bandConfidence, 'low');
  assert.deepEqual(result.bandSignals, []);
  assert.match(result.bandQuestion, /nothing in the documents says how complicated this is/);
});

test('an accepted volume of another activity bands this one, and counts as quoted', () => {
  const volume = { id: 'D-001', workPackageId: 'integrations', quantity: 4, unit: 'system', blockIds: ['b#9'], review: { status: 'accepted' } };
  const result = band(planWith({ volumes: [volume] }));
  assert.equal(result.band, 'medium');
  assert.equal(result.bandConfidence, 'high');
  assert.deepEqual(result.bandSignals, [{ band: 'medium', quoted: true, reason: 'Three or more systems to search across.', matched: '4 systems', blockId: 'b#9', volumeId: 'D-001' }]);
});

test('a volume nobody accepted does not set a band, any more than it sizes a workstream', () => {
  const volume = { id: 'D-001', workPackageId: 'integrations', quantity: 4, unit: 'system', blockIds: ['b#9'], review: { status: 'pending' } };
  assert.equal(band(planWith({ volumes: [volume] })).bandSignals.length, 0);
});

test('a dismissed requirement is not evidence', () => {
  const plan = planWith({ passage: 'The platform must support federated search.' });
  plan.requirements[0].review.status = 'dismissed';
  assert.equal(band(plan).band, NO_SIGNAL_BAND);
});

test('the same plan bands the same way every time, whatever order the signals matched in', () => {
  const plan = planWith({ passage: 'Native search is enough today, but relevance tuning is expected later.' });
  const once = band(plan);
  for (let run = 0; run < 5; run += 1) {
    assert.deepEqual(band(plan), once);
  }
});

test('the shipped signals file is usable, and covers every tiered activity in the catalog', async () => {
  const shipped = loadTierSignals();
  const { DEFAULT_CATALOG, parseActivities } = await import('./rank-questions.mjs');
  const { readFileSync } = await import('node:fs');
  const tiered = Array.from(parseActivities(readFileSync(DEFAULT_CATALOG, 'utf8')).entries())
    .filter(([, entry]) => entry.shape === 'tiered')
    .map(([id]) => id);
  assert.ok(tiered.length > 0);
  for (const id of tiered) {
    assert.ok(shipped.has(id), `${id} is tiered in the catalog but has no signals`);
  }
  for (const id of shipped.keys()) {
    assert.ok(tiered.includes(id), `${id} has signals but is not tiered in the catalog`);
  }
});

test('bandAll bands the tiered activities and leaves the rest alone', () => {
  const workPackages = new Map([
    ['search', { name: 'Search', shape: 'tiered' }],
    ['component-build', { name: 'Component build', shape: 'per-unit' }]
  ]);
  const bands = bandAll(planWith({ passage: 'Up to four facets.' }), workPackages, signals);
  assert.deepEqual([...bands.keys()], ['search']);
  assert.equal(bands.get('search').band, 'medium');
});

test('a signals file is rejected when a signal could not be acted on', () => {
  const ok = { schemaVersion: '1', activities: [{ activity: 'search', signals: [{ band: 'large', words: ['federated search'], reason: 'why' }] }] };
  assert.deepEqual(validateTierSignals(ok), []);

  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(ok));
    change(copy);
    return validateTierSignals(copy);
  };
  assert.deepEqual(validateTierSignals({}), ['expected { schemaVersion: "1", activities: [] }']);
  assert.ok(broken((doc) => { doc.activities[0].signals[0].band = 'huge'; })[0].includes(`expected one of ${BANDS.join(', ')}`));
  assert.ok(broken((doc) => { delete doc.activities[0].signals[0].reason; })[0].includes('reason'));
  assert.ok(broken((doc) => { doc.activities[0].signals[0].volume = 'integrations'; })[0].includes('not both and not neither'));
  assert.ok(broken((doc) => { delete doc.activities[0].signals[0].words; })[0].includes('not both and not neither'));
  assert.ok(broken((doc) => { doc.activities[0].signals[0].words = ['...']; })[0].includes('phrases with words in them'));
  assert.ok(broken((doc) => {
    doc.activities[0].signals[0] = { band: 'large', volume: 'integrations', atLeast: 3, atMost: 9, reason: 'why' };
  })[0].includes('one of atLeast or atMost'));
  assert.ok(broken((doc) => { doc.activities.push(doc.activities[0]); })[0].includes('listed twice'));
});

test('an unreadable signals file stops the estimate rather than banding everything medium', () => {
  assert.throws(() => loadTierSignals('no-such-file.json'), BandError);
});
