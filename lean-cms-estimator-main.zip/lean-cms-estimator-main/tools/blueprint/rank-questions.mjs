#!/usr/bin/env node
/**
 * Orders the open questions of a bid by how much the answer would move the estimate, and prints a client
 * clarification list (question text only, safe to send) with a team-only part that says why they rank so.
 *
 * What is ranked: the Blueprint's questions (a question about a dismissed requirement is left out) and the
 * Context sidecar's delivery unknowns that no question covers (`--context`), including the gap sweep's.
 *
 * How it ranks: a fixed score from what the question touches. It never reads the answer and never makes up
 * hours. The score adds up
 *   1  every item
 *   3  the requirement it belongs to is a conflict between sources
 *   2  that requirement is flagged as a question
 *   2  the wording asks for a quantity or a scope (how many, number of, in scope)
 *   2  the answer changes what sizes the package: its workstream volume (an assumed one, or one from the
 *      documents) in an estimated plan file; the first figure in the statement in a file with no workstreams
 *   1  for each other live requirement in the same package, up to 3 (more rows ride on the answer)
 *   3  an unknown from the gap sweep: no requirement sizes that package at all
 *   2  an unknown from the second opinion: two independent reads disagree, or an objection to accelerated
 *      coverage came with a quote from the documents
 *   3, 2 or 1  only when the Blueprint holds an estimate: the package carries 25% or more, 10% or more,
 *              or some of the estimated hours. The share is the app's own figure, not a new one.
 * A score of 6 or more is `high`, 4 or more `medium`, otherwise `low`. Ties keep the Blueprint's order.
 * The reasons that add up to the score are listed on each item so the estimator can disagree with them.
 *
 * Usage: node tools/blueprint/rank-questions.mjs <Project>_Blueprint.json [--context <Project>_Context.json]
 *        [--estimating <estimating-catalog.md>] [--markdown]
 * Exit 0 on success. Exit 1 when a file cannot be read, is not JSON, has the wrong shape, or the catalog has
 * no work package table. Exit 2 on bad usage.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { statedQuantity } from './driver-quantity.mjs';
import { validateContextValue } from './validate-context.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_CATALOG = path.join(HERE, '..', '..', 'docs', 'catalogs', 'estimating-catalog.md');

export const HIGH_AT = 6;
export const MEDIUM_AT = 4;

/** An Activities row. Anchored on phase and shape so capability and method rows cannot match. */
const ACTIVITY_TABLE_ROW =
  /^\| `([a-z][a-z0-9-]*)` \| ([^|]+) \| (Discover|Design|Build|Assure|Launch|Run) \| (per-unit|tiered|proportional) \| ([^|]+) \| [^|]+ \| (us|shared) \| (accelerated|partly|human-led) \| ([^|]+) \|/;
/**
 * A Starting figures row. Anchored on the two number-or-dash cells and the percentage, so the
 * Capabilities table — also an id and four cells — cannot match it.
 */
const FIGURE_TABLE_ROW = /^\| `([a-z][a-z0-9-]*)` \| (\d+(?:\.\d+)?|—) \| (\d+(?:\.\d+)?|—) \| (\d+) \| ([^|]+) \|\s*$/;
const GAP_SOURCE = /^Gap sweep checklist ([a-z][a-z0-9-]*)$/;
const SECOND_READ_SOURCE = /^Second opinion ([a-z][a-z0-9-]*)$/;
const OBJECTION_SOURCE = /^Second opinion objection /;
const QUANTITY_CUE = /\b(how many|how much|number of|count|approximate|approximately|roughly|volume|in scope|scope)\b/i;
const USAGE =
  'Usage: node tools/blueprint/rank-questions.mjs <Project>_Blueprint.json [--context <Project>_Context.json] [--estimating <file>] [--markdown]';

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** A dash in a table cell means "none here", and reads back as nothing rather than as a value. */
function cellOf(text) {
  const cell = text.trim();
  return cell === '—' ? '' : cell;
}

/** `a`, `b`, `c` in a table cell, back to a list of ids. */
function idsOf(text) {
  const cell = cellOf(text);
  return cell === '' ? [] : cell.split(',').map((entry) => entry.trim().replace(/^`|`$/g, ''));
}

/**
 * Activity id to `{ name, unit, phase, shape, owner, shareOf }`, from the catalog's Activities
 * table. A tiered or proportional activity has no unit, and only a proportional one has a
 * share set; their dashes read back as an empty string and an empty list.
 *
 * `owner` is the catalog's default, `us` or `shared`. `client` is a decision made on an
 * estimate (`plan.mjs owner`), never a default here.
 *
 * An activity with a Starting figures row also carries `hoursPerUnit`, `volume`,
 * `aiSavingPercent` and `skillIds`: what the estimate falls back on before it has evidence.
 * One without a row is not sized, and `estimate` says so rather than inventing a figure.
 */
export function parseActivities(catalogMd, warnings = []) {
  const activities = new Map();
  const figures = new Map();
  for (const line of catalogMd.split(/\r?\n/)) {
    const match = ACTIVITY_TABLE_ROW.exec(line);
    if (match) {
      const [, id, name, phase, shape, unit, owner, , shareOf] = match;
      if (activities.has(id)) {
        warnings.push(`the catalog lists ${id} more than once; the first row is used`);
      } else {
        activities.set(id, {
          name: name.trim(),
          unit: cellOf(unit),
          phase: phase.toLowerCase(),
          shape,
          owner,
          shareOf: idsOf(shareOf)
        });
      }
      continue;
    }
    const figure = FIGURE_TABLE_ROW.exec(line);
    if (!figure) {
      continue;
    }
    const [, id, hours, volume, saving, skills] = figure;
    if (figures.has(id)) {
      warnings.push(`the catalog gives ${id} starting figures more than once; the first row is used`);
      continue;
    }
    figures.set(id, {
      // A proportional activity takes its hours from its share, so it has neither of these.
      hoursPerUnit: hours === '—' ? null : Number(hours),
      volume: volume === '—' ? null : Number(volume),
      aiSavingPercent: Number(saving),
      skillIds: idsOf(skills)
    });
  }
  for (const [id, figure] of figures) {
    if (activities.has(id)) {
      Object.assign(activities.get(id), figure);
    } else {
      warnings.push(`the catalog gives ${id} starting figures but does not list it as an activity`);
    }
  }
  return activities;
}

function status(item) {
  return isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
}

function tierOf(score) {
  if (score >= HIGH_AT) {
    return 'high';
  }
  return score >= MEDIUM_AT ? 'medium' : 'low';
}

function hoursShares(blueprint) {
  const estimate = blueprint.estimate;
  let packages = isObject(estimate) && Array.isArray(estimate.packages) ? estimate.packages.filter(isObject) : [];
  if (packages.length === 0 && Array.isArray(blueprint.workstreams)) {
    // A plan file (stage 3): the share of each workstream in the traditional hours, overhead included in the total.
    packages = blueprint.workstreams.filter(isObject).map((row) => ({ workPackageId: row.id, hours: row.traditionalHours }));
  }
  const total = packages.reduce((sum, entry) => sum + (Number(entry.hours) || 0), 0);
  const shares = new Map();
  if (total > 0) {
    for (const entry of packages) {
      shares.set(entry.workPackageId, (Number(entry.hours) || 0) / total);
    }
  }
  return shares;
}

/**
 * @param {object} blueprint requirements, questions and (optionally) estimate
 * @param {object | undefined} context a Context sidecar
 * @param {Map<string, { name: string, unit: string }>} workPackages from parseActivities
 */
export function rankQuestions(blueprint, context, workPackages) {
  const requirements = (Array.isArray(blueprint.requirements) ? blueprint.requirements : []).filter(isObject);
  const questions = (Array.isArray(blueprint.questions) ? blueprint.questions : []).filter(isObject);
  const byId = new Map(requirements.map((row) => [row.id, row]));
  const live = requirements.filter((row) => status(row) !== 'dismissed');
  const ridingByPackage = new Map();
  for (const row of live) {
    ridingByPackage.set(row.workPackage, (ridingByPackage.get(row.workPackage) || 0) + 1);
  }
  const shares = hoursShares(blueprint);
  const workstreams = new Map((Array.isArray(blueprint.workstreams) ? blueprint.workstreams : [])
    .filter((entry) => isObject(entry) && entry.kind === 'delivery')
    .map((entry) => [entry.id, entry]));

  const skipped = { questionsOnDismissed: 0, questionsWithoutText: 0, unknownsDismissed: 0, unknownsCoveredByQuestion: 0 };
  const items = [];

  const describe = (item, workPackageId, row) => {
    const reasons = [];
    let score = 1;
    const pack = workPackageId ? workPackages.get(workPackageId) : undefined;
    if (row && row.coverage === 'conflict') {
      score += 3;
      reasons.push('the sources disagree');
    } else if (row && row.coverage === 'question') {
      score += 2;
      reasons.push('the requirement is open');
    }
    if (QUANTITY_CUE.test(item.text) && pack) {
      score += 2;
      reasons.push(`the answer settles how many ${pack.unit}s, or what is in scope, for ${workPackageId}`);
    }
    // With workstreams (a plan file that was estimated) the workstream's volume is what sizes the package; the
    // first number in a statement is only the rule for a file that has no workstreams.
    const workstream = row && pack ? workstreams.get(workPackageId) : undefined;
    if (workstream) {
      const units = `${workstream.volume} ${pack.unit}${workstream.volume === 1 ? '' : 's'}`;
      score += 2;
      reasons.push(workstream.volumeBasis === 'placeholder'
        ? `${workPackageId} is sized on an assumed ${units}; the answer replaces it`
        : `the volume for ${workPackageId} (${units}) comes from the documents; the answer can change it`);
    }
    const stated = row && pack && !workstream && workstreams.size === 0 ? statedQuantity(row.statement) : undefined;
    if (stated !== undefined) {
      score += 2;
      reasons.push(`the figure stated for ${workPackageId} (${stated} ${pack.unit}${stated === 1 ? '' : 's'}) is what sizes it today`);
    }
    if (workPackageId) {
      const riding = Math.min(Math.max((ridingByPackage.get(workPackageId) || 0) - (row ? 1 : 0), 0), 3);
      if (riding > 0) {
        score += riding;
        reasons.push(`${riding} other requirement${riding === 1 ? '' : 's'} in ${workPackageId} depend on it`);
      }
      const share = shares.get(workPackageId);
      if (share !== undefined && share > 0) {
        const points = share >= 0.25 ? 3 : share >= 0.1 ? 2 : 1;
        score += points;
        reasons.push(`${workPackageId} carries ${Math.round(share * 100)}% of the estimated hours`);
      }
    }
    return { score, reasons, pack };
  };

  for (const question of questions) {
    if (typeof question.text !== 'string' || question.text.trim() === '') {
      skipped.questionsWithoutText += 1;
      continue;
    }
    const row = byId.get(question.requirementId);
    if (row && status(row) === 'dismissed') {
      skipped.questionsOnDismissed += 1;
      continue;
    }
    const { score, reasons, pack } = describe(question, row ? row.workPackage : undefined, row);
    items.push({
      kind: 'question',
      audience: 'client',
      id: question.id,
      text: question.text,
      requirementId: row ? row.id : undefined,
      workPackageId: row && workPackages.has(row.workPackage) ? row.workPackage : undefined,
      workPackageName: pack ? pack.name : undefined,
      score,
      reasons
    });
  }

  const questionIds = new Set(questions.map((question) => question.id));
  const unknowns = context && Array.isArray(context.deliveryUnknowns) ? context.deliveryUnknowns.filter(isObject) : [];
  for (const unknown of unknowns) {
    if (typeof unknown.statement !== 'string') {
      continue;
    }
    if (status(unknown) === 'dismissed') {
      skipped.unknownsDismissed += 1;
      continue;
    }
    const refs = Array.isArray(unknown.refs) ? unknown.refs : [];
    if (refs.some((ref) => questionIds.has(ref))) {
      skipped.unknownsCoveredByQuestion += 1;
      continue;
    }
    const gap = typeof unknown.source === 'string' ? GAP_SOURCE.exec(unknown.source.trim()) : null;
    const refRow = refs.map((ref) => byId.get(ref)).find(Boolean);
    const source = typeof unknown.source === 'string' ? unknown.source.trim() : '';
    const reads = SECOND_READ_SOURCE.exec(source);
    const workPackageId = gap ? gap[1] : reads ? reads[1] : refRow ? refRow.workPackage : undefined;
    const { score, reasons, pack } = describe({ text: unknown.statement }, workPackageId, refRow);
    let total = score;
    // Only while the gap is still a gap: once a live requirement sits in the package, nothing is missing.
    if (gap && !(ridingByPackage.get(gap[1]) > 0)) {
      total += 3;
      reasons.push(`nothing sizes ${gap[1]} yet`);
    }
    if (reads) {
      total += 2;
      reasons.push('two independent reads of the documents disagree');
    }
    if (OBJECTION_SOURCE.test(source)) {
      total += 2;
      reasons.push('the accelerated coverage was challenged with a quote from the documents');
    }
    items.push({
      kind: 'unknown',
      // The second opinion's unknowns name two internal reads and counts. They are for the team, not the client.
      audience: reads || OBJECTION_SOURCE.test(source) ? 'team' : 'client',
      id: unknown.id,
      text: unknown.statement,
      requirementId: refRow ? refRow.id : undefined,
      workPackageId: workPackageId && workPackages.has(workPackageId) ? workPackageId : undefined,
      workPackageName: pack ? pack.name : undefined,
      score: total,
      reasons
    });
  }

  const ranked = items
    .map((item, order) => ({ ...item, order }))
    .sort((a, b) => b.score - a.score || a.order - b.order)
    .map(({ order, ...item }, index) => ({ rank: index + 1, tier: tierOf(item.score), ...item }));
  return { input: { questions: questions.length, unknowns: unknowns.length, estimate: shares.size > 0 }, skipped, ranked };
}

const TIER_HEADINGS = { high: 'Ask first', medium: 'Ask next', low: 'Ask if there is time' };

/**
 * Two parts. The client clarification list holds only the question text, in the order to ask: nothing in it
 * says how the team sized or ranked anything, so it can be sent as it is. The second part is for the team:
 * why each item ranks where it does (which can mention the estimate), and the items that are not for the client.
 */
export function formatMarkdown(result) {
  const lines = ['## Client clarification list', ''];
  const forClient = result.ranked.filter((item) => item.audience !== 'team');
  const forTeam = result.ranked.filter((item) => item.audience === 'team');
  if (forClient.length === 0) {
    lines.push('No open questions.', '');
  }
  let number = 0;
  for (const tier of ['high', 'medium', 'low']) {
    const group = forClient.filter((item) => item.tier === tier);
    if (group.length === 0) {
      continue;
    }
    lines.push(`### ${TIER_HEADINGS[tier]}`, '');
    for (const item of group) {
      number += 1;
      lines.push(`${number}. ${item.text}`);
    }
    lines.push('');
  }
  if (result.ranked.length > 0) {
    lines.push('## Why this order (team only, do not send)', '');
    for (const item of result.ranked) {
      const where = item.workPackageId ? `${item.workPackageId} ${item.workPackageName}` : 'no work package';
      const label = item.kind === 'question' ? item.id : `${item.id} (unknown${item.audience === 'team' ? ', not for the client' : ''})`;
      const why = item.reasons.length > 0 ? `; ${item.reasons.join('; ')}` : '';
      lines.push(`- ${item.rank}. ${label} [${item.tier}]: ${where}${why}`);
      if (item.audience === 'team') {
        lines.push(`  - ${item.text}`);
      }
    }
    lines.push('');
  }
  return `${lines.join('\n')}`;
}

function readText(file) {
  const abs = path.resolve(file);
  try {
    return fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`Cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
}

function readJson(file, label) {
  try {
    return JSON.parse(readText(file));
  } catch (error) {
    console.error(`(${label}): invalid JSON (${error.message})`);
    process.exit(1);
  }
}

function parseArgs(args) {
  const parsed = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === '--context' || arg === '--estimating') {
      const next = args[index + 1];
      const name = arg.slice(2);
      if (next === undefined || next === '' || next.startsWith('-') || parsed[name] !== undefined) {
        return undefined;
      }
      parsed[name] = next;
      index += 1;
    } else if (arg === '--markdown') {
      parsed.markdown = true;
    } else if (arg.startsWith('-') || parsed.blueprintPath !== undefined) {
      return undefined;
    } else {
      parsed.blueprintPath = arg;
    }
  }
  return parsed.blueprintPath ? parsed : undefined;
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  const blueprint = readJson(parsed.blueprintPath, 'blueprint');
  if (!isObject(blueprint) || !Array.isArray(blueprint.requirements) || !Array.isArray(blueprint.questions)) {
    console.error('(blueprint): expected an object with requirements and questions arrays');
    process.exit(1);
  }
  const catalogWarnings = [];
  const workPackages = parseActivities(readText(parsed.estimating || DEFAULT_CATALOG), catalogWarnings);
  if (workPackages.size === 0) {
    console.error('The estimating catalog has no Activities table');
    process.exit(1);
  }
  catalogWarnings.forEach((message) => console.error(`warning: ${message}`));
  const unlisted = Array.from(new Set(blueprint.requirements.filter(isObject).map((row) => row.workPackage)
    .filter((id) => typeof id === 'string' && id !== 'unmapped' && !workPackages.has(id)))).sort();
  if (unlisted.length > 0) {
    console.error(`warning: requirements use package ids the catalog does not list: ${unlisted.join(', ')}`);
  }
  let context;
  if (parsed.context !== undefined) {
    context = readJson(parsed.context, 'context');
    const errors = validateContextValue(context);
    if (errors.length) {
      errors.forEach((message) => console.error(`(context) ${message}`));
      process.exit(1);
    }
  }
  const result = rankQuestions(blueprint, context, workPackages);
  process.stdout.write(parsed.markdown ? formatMarkdown(result) : `${JSON.stringify(result, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
