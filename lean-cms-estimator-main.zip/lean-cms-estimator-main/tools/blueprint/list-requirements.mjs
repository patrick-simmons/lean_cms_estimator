#!/usr/bin/env node
/**
 * Print the requirements of a Blueprint compactly, for the "Already extracted" part of the extract
 * stage on a re-run (SAPP-014). Per row the model gets the id, review status, statement, work package,
 * coverage, the block ids the row cites and its open question, if any: no passages, no estimate, no
 * sidecar. A row without review state counts as pending.
 *
 * Usage: node tools/blueprint/list-requirements.mjs <Project>_Blueprint.json [--json] [--pending]
 * Exit codes: 2 for an unknown flag or no file, 1 when the file cannot be read as JSON.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export function compactRequirements(working, options = {}) {
  const questions = new Map((working.questions || []).map((q) => [q.requirementId, q.text]));
  return (working.requirements || [])
    .filter((row) => row && typeof row === 'object')
    .map((row) => ({ row, status: (row.review && row.review.status) || 'pending' }))
    .filter(({ status }) => !options.pendingOnly || status === 'pending')
    .map(({ row, status }) => ({
      id: row.id,
      status,
      statement: row.statement,
      workPackage: row.workPackage,
      coverage: row.coverage,
      blockIds: (Array.isArray(row.sources) ? row.sources : []).map((source) => source.blockId),
      ...(questions.has(row.id) ? { question: questions.get(row.id) } : {})
    }));
}

export function formatRequirements(rows) {
  return rows.map((row) => {
    const head = `${row.id} [${row.status}] ${row.workPackage} ${row.coverage}`;
    const cites = row.blockIds.join(', ');
    const question = row.question ? `\n    question: ${row.question}` : '';
    return `${head}\n    ${row.statement}\n    cites: ${cites}${question}`;
  }).join('\n');
}

const USAGE = 'Usage: node tools/blueprint/list-requirements.mjs <Project>_Blueprint.json [--json] [--pending]';

function main(argv) {
  const args = argv.slice(2);
  const flags = args.filter((arg) => arg.startsWith('--'));
  const files = args.filter((arg) => !arg.startsWith('--'));
  const unknown = flags.filter((flag) => flag !== '--json' && flag !== '--pending');
  if (unknown.length || files.length !== 1) {
    if (unknown.length) {
      console.error(`Unknown option ${unknown.join(', ')}`);
    }
    console.error(USAGE);
    process.exit(2);
  }
  let working;
  try {
    working = JSON.parse(fs.readFileSync(path.resolve(files[0]), 'utf8'));
  } catch (error) {
    console.error(`${path.resolve(files[0])}: ${error.message}`);
    process.exit(1);
  }
  if (!working || typeof working !== 'object' || Array.isArray(working)) {
    console.error(`${path.resolve(files[0])}: expected a Blueprint object`);
    process.exit(1);
  }
  const rows = compactRequirements(working, { pendingOnly: flags.includes('--pending') });
  const text = flags.includes('--json') ? JSON.stringify(rows, null, 2) : formatRequirements(rows);
  process.stdout.write(`${text}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
