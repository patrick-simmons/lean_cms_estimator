import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { after, before, describe, it } from 'node:test';
import { docxFixture, HEADING_STYLES, pptxFixture, shape, sheetRow, wPara, xlsxFixture } from './fixtures/ooxml-fixture.mjs';
import { assignItemIds, IMAGE_NOT_READ, isSourceCandidate, parseLocalFile, SCANNED_PDF } from './parse-local-core.mjs';
import { itemsToLines, linesToParagraphs } from './pdf-text.mjs';
import { LEGACY_OFFICE, UNSUPPORTED } from '../../function/dist/src/blocks.js';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'parse-local.mjs');
const sources = join(root, 'samples', 'sources', 'synthetic-aem');
const scratch = mkdtempSync(join(tmpdir(), 'parse-local-'));

after(() => rmSync(scratch, { recursive: true, force: true }));

/** The function's parse with a layout service that must never be reached. */
function functionDeps(calls) {
  return {
    getToken: async () => {
      calls.push('token');
      throw new Error('no token offline');
    },
    fetchImpl: async (url) => {
      calls.push(`fetch ${url}`);
      throw new Error('no network offline');
    },
    sleep: async () => undefined,
    now: () => 0,
    log: () => undefined,
    logFailure: () => undefined
  };
}

const docx = docxFixture({
  styles: HEADING_STYLES,
  body: wPara('3.6 Content migration', 'Heading2') +
    wPara('3.6.1 The vendor shall migrate approximately 18,240 pages and implement 301 redirects.') +
    wPara('3.6.2 Preserve inbound links with a redirect map approved by marketing.')
});
const pptx = pptxFixture({
  order: [1, 2],
  slides: [
    { file: 1, shapes: shape('Launch scope', 'title') + shape('Two locales at launch\nEnglish and Spanish'), notes: 'Confirm with the client' },
    { file: 2, shapes: shape('Integrations', 'title') + shape('PIM feed nightly') }
  ]
});
const xlsx = xlsxFixture({
  sheets: [{ name: 'Inventory', rows: sheetRow(1, ['Section', 'Pages']) + sheetRow(2, ['News', 1200]) + sheetRow(3, ['Products', 400]) }]
});

describe('parse-local reads Office files with the function readers', () => {
  for (const [name, bytes] of [['RFP.docx', docx], ['Deck.pptx', pptx], ['Inventory.xlsx', xlsx]]) {
    it(`produces the function's blocks for ${name}`, async () => {
      const calls = [];
      const actual = await parseLocalFile(bytes, name, 'item-1');
      assert.ok(actual.blocks.length > 0, 'fixture yields blocks');
      assert.deepEqual(actual.notRead, []);
      assert.ok(actual.blocks.every((b) => b.id.startsWith('item-1#') && b.label && b.text));
      assert.deepEqual(calls, [], 'nothing reached the network');
    });
  }

  it('reports legacy and unsupported files as not read like the function does', async () => {
    const ole = new Uint8Array([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0, 0]);
    assert.deepEqual((await parseLocalFile(ole, 'Old.doc', 'i')).notRead, [{ reason: LEGACY_OFFICE }]);
    const text = new TextEncoder().encode('plain notes');
    assert.deepEqual((await parseLocalFile(text, 'notes.txt', 'i')).notRead, [{ reason: UNSUPPORTED }]);
    const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]);
    const image = await parseLocalFile(png, 'scan.png', 'i');
    assert.equal(image.format, 'image');
    assert.deepEqual(image.notRead, [{ reason: IMAGE_NOT_READ }]);
  });
});

describe('parse-local reads PDF text layers', () => {
  const rfp = () => new Uint8Array(readFileSync(join(sources, 'Fabrikam_RFP_2027.pdf')));
  const scan = () => new Uint8Array(readFileSync(join(sources, 'Signed_NDA_scan.pdf')));

  it('gives every block its page, section and label', async () => {
    const result = await parseLocalFile(rfp(), 'Fabrikam_RFP_2027.pdf', 'src-rfp');
    assert.equal(result.format, 'pdf');
    assert.equal(result.totalPages, 4);
    assert.equal(result.pagesRead, '1-4');
    assert.deepEqual(result.notRead, []);
    assert.deepEqual(result.blocks.map((b) => b.location.page), [1, 2, 3, 4]);
    const migration = result.blocks.find((b) => b.location.page === 2);
    assert.equal(migration.location.section, '2');
    assert.equal(migration.location.heading, 'Content migration');
    assert.equal(migration.label, 'Fabrikam_RFP_2027 p.2 §2');
    assert.equal(migration.id, 'src-rfp#p2.1');
    assert.match(migration.text, /approximately 6,400 pages/);
    assert.match(result.blocks[2].text, /four locales: English, German, French and Dutch/);
  });

  it('reports a PDF with no text layer as not read and invents nothing', async () => {
    const result = await parseLocalFile(scan(), 'Signed_NDA_scan.pdf', 'src-scan');
    assert.deepEqual(result.blocks, []);
    assert.equal(result.totalPages, 2);
    assert.equal(result.pagesRead, undefined);
    assert.deepEqual(result.notRead, [{ reason: SCANNED_PDF, pages: '1-2' }]);
  });

  it('groups text items into lines and paragraphs', () => {
    const item = (str, x, y, size) => ({ str, transform: [size, 0, 0, size, x, y], width: str.length * size * 0.5, height: size });
    const lines = itemsToLines([
      item('2 Hosting', 50, 740, 16),
      item('2.1 The platform', 50, 700, 11),
      item('runs in the EU.', 142, 700, 11),
      item('Next paragraph.', 50, 660, 11)
    ], 1);
    assert.deepEqual(lines.map((l) => l.text), ['2 Hosting', '2.1 The platform runs in the EU.', 'Next paragraph.']);
    const paragraphs = linesToParagraphs(lines);
    assert.deepEqual(paragraphs, [
      { text: '2 Hosting', heading: true },
      { text: '2.1 The platform runs in the EU.', heading: false },
      { text: 'Next paragraph.', heading: false }
    ]);
  });
});

describe('parse-local folder run', () => {
  const folder = join(scratch, 'project');
  let first;
  let offlineEnv;

  before(() => {
    cpSync(sources, folder, { recursive: true });
    writeFileSync(join(folder, 'Fabrikam_Blueprint.json'), '{}');
    writeFileSync(join(folder, 'AGENTS.md'), '# not a source');
    // The parser runs in a child process, so the offline guarantee has to be enforced there: this module
    // makes any network call throw before the tool loads.
    const noNetwork = join(scratch, 'no-network.mjs');
    writeFileSync(noNetwork, [
      "import http from 'node:http';",
      "import https from 'node:https';",
      "import net from 'node:net';",
      "const fail = () => { throw new Error('network call from parse-local'); };",
      'globalThis.fetch = fail;',
      'http.request = http.get = https.request = https.get = fail;',
      'net.Socket.prototype.connect = fail;',
      ''
    ].join('\n'));
    offlineEnv = { ...process.env, NODE_OPTIONS: `--import ${pathToFileURL(noNetwork).href}` };
    first = spawnSync(process.execPath, [script, folder, '--quiet'], { cwd: root, encoding: 'utf8', env: offlineEnv });
    assert.equal(first.status, 0, first.stderr);
  });

  it('writes the manifest, sources, blocks and one file per source', () => {
    const out = join(folder, '.blueprint', 'parsed');
    const manifest = JSON.parse(readFileSync(join(out, 'manifest.json'), 'utf8'));
    assert.equal(manifest.tool, 'parse-local');
    assert.deepEqual(manifest.files.map((f) => f.name), [
      'Content_Inventory.xlsx', 'Fabrikam_Kickoff_Deck.pptx', 'Fabrikam_RFP_2027.pdf', 'Legacy_Brief.doc', 'Signed_NDA_scan.pdf', 'Workshop_Notes.docx'
    ]);
    const byName = Object.fromEntries(manifest.files.map((f) => [f.name, f]));
    assert.equal(byName['Legacy_Brief.doc'].read, 'not read');
    assert.equal(byName['Legacy_Brief.doc'].notRead[0].reason, LEGACY_OFFICE);
    assert.equal(byName['Signed_NDA_scan.pdf'].read, 'not read');
    assert.equal(byName['Signed_NDA_scan.pdf'].notRead[0].reason, SCANNED_PDF);
    assert.equal(byName['Fabrikam_RFP_2027.pdf'].read, 'read');
    const sourcesOut = JSON.parse(readFileSync(join(out, 'sources.json'), 'utf8'));
    assert.equal(sourcesOut.length, 6);
    for (const source of sourcesOut) {
      for (const key of ['itemId', 'name', 'webUrl', 'bytes', 'modified', 'read', 'blocks', 'notRead']) {
        assert.ok(key in source, `${source.name} has ${key}`);
      }
      assert.ok(existsSync(join(out, `${source.itemId}.json`)));
    }
    const blocks = JSON.parse(readFileSync(join(out, 'blocks.json'), 'utf8'));
    assert.equal(blocks.length, sourcesOut.reduce((n, s) => n + s.blocks.length, 0));
    assert.equal(new Set(blocks.map((b) => b.id)).size, blocks.length, 'block ids are unique');
  });

  it('records the parse stage in the run record', () => {
    const record = JSON.parse(readFileSync(join(folder, '.blueprint', 'run.json'), 'utf8'));
    assert.equal(record.stage, 'parse');
    assert.equal(record.parseTool.name, 'parse-local');
    assert.equal(record.files.parsed.sources, 6);
    assert.equal(record.files.parsed.notRead, 2);
    assert.equal(record.pack.name, 'blueprint-skill-pack');
  });

  it('is deterministic apart from timestamps, and the manifest carries no local path', () => {
    const files = ['blocks.json', 'sources.json', 'manifest.json'];
    const stable = (name) => readFileSync(join(folder, '.blueprint', 'parsed', name), 'utf8').replace(/\d{4}-\d\d-\d\dT[\d:.]+Z/g, '<time>');
    const before = files.map(stable);
    const again = spawnSync(process.execPath, [script, folder, '--quiet'], { cwd: root, encoding: 'utf8', env: offlineEnv });
    assert.equal(again.status, 0, again.stderr);
    assert.deepEqual(files.map(stable), before);
    const manifest = JSON.parse(readFileSync(join(folder, '.blueprint', 'parsed', 'manifest.json'), 'utf8'));
    assert.equal(manifest.folder, '.');
    assert.equal(manifest.selection, 'folder');
    assert.deepEqual(manifest.skipped, []);
    assert.ok(!before[2].includes('Temp') && !before[2].includes('parse-local-'), 'no local path in the manifest');
  });

  it('parses only the selected files when told to', () => {
    const out = join(scratch, 'selected');
    const result = spawnSync(process.execPath, [script, folder, '--out', out, '--select', 'Workshop_Notes.docx', '--quiet'], { cwd: root, encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    const manifest = JSON.parse(readFileSync(join(out, 'manifest.json'), 'utf8'));
    assert.deepEqual(manifest.files.map((f) => f.name), ['Workshop_Notes.docx']);
    assert.equal(manifest.selection, 'selected');
  });

  it('reads the selection prepared for the agent when no files are listed', () => {
    const prepared = join(scratch, 'prepared');
    cpSync(sources, prepared, { recursive: true });
    mkdirSync(join(prepared, '.blueprint'), { recursive: true });
    writeFileSync(join(prepared, '.blueprint', 'sources.json'), JSON.stringify({ sources: [{ name: 'Content_Inventory.xlsx' }] }));
    const result = spawnSync(process.execPath, [script, prepared, '--quiet'], { cwd: root, encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    const manifest = JSON.parse(readFileSync(join(prepared, '.blueprint', 'parsed', 'manifest.json'), 'utf8'));
    assert.deepEqual(manifest.files.map((f) => f.name), ['Content_Inventory.xlsx']);
  });

  it('skips Blueprint outputs and bootstrap files and keeps ids unique', () => {
    assert.equal(isSourceCandidate('Fabrikam_Blueprint.json'), false);
    assert.equal(isSourceCandidate('Fabrikam_Blueprint.xlsx'), false);
    assert.equal(isSourceCandidate('AGENTS.md'), false);
    assert.equal(isSourceCandidate('.hidden.pdf'), false);
    assert.equal(isSourceCandidate('~$lock.docx'), false);
    assert.equal(isSourceCandidate('Brief.PDF'), true);
    const ids = assignItemIds(['RFP.pdf', 'RFP.docx', 'Kick off (v2).pptx']);
    assert.deepEqual([...ids.values()], ['src-rfp', 'src-rfp-2', 'src-kick-off-v2']);
  });

  it('exits with the documented codes from the command line', () => {
    const guarded = join(scratch, 'guarded');
    cpSync(sources, guarded, { recursive: true });
    const refused = spawnSync(process.execPath, [script, guarded, '--out', guarded, '--quiet'], { cwd: root, encoding: 'utf8' });
    assert.equal(refused.status, 2);
    assert.ok(existsSync(join(guarded, 'Workshop_Notes.docx')), '--out <folder> deleted nothing');
    mkdirSync(join(guarded, '.blueprint'), { recursive: true });
    writeFileSync(join(guarded, '.blueprint', 'sources.json'), JSON.stringify({ sources: [] }));
    const none = spawnSync(process.execPath, [script, guarded, '--quiet'], { cwd: root, encoding: 'utf8' });
    assert.equal(none.status, 3);
    assert.match(none.stderr, /no sources were selected/);
  });

  it('exits with usage when no folder is given', () => {
    const result = spawnSync(process.execPath, [script], { cwd: root, encoding: 'utf8' });
    assert.equal(result.status, 2);
    assert.match(result.stderr, /Usage/);
  });
});
