#!/usr/bin/env node
/**
 * Reads the review decisions across several project folders and reports how often the team keeps or
 * rejects what the agent proposed.
 *
 * What it reads, in each project folder (a folder holds one project: `<Project>_Context.json` and, when
 * there is one, `<Project>_Proposals.json`). A folder with no Context file is searched one and two levels
 * down, so a folder of project folders works too.
 *   Context items  deliveryUnknowns, assumptions, dependencies and deliveryRisks, with `review.status`.
 *                  pending is not a decision. accepted and edited count as kept, dismissed as rejected.
 *   Proposals      `kind` (add, update, conflict) with `review.status`: applied is kept, rejected is rejected.
 *
 * What it reports
 *   items           per library id, and per `source` marker of the gap sweep, lever advice and second opinion:
 *                   projects, kept, edited, rejected, pending and the rates. An item is grouped under its
 *                   library id when it has one, otherwise under its marker; an item with neither is not grouped.
 *   proposalKinds   the same per proposal kind.
 *   suppress        items the team keeps rejecting: at least --min-decisions decisions in at least
 *                   --min-projects projects with a rejection rate of --reject-rate or more. Only a library
 *                   item, a gap or a lever advice can be suppressed, because those are the proposers that read
 *                   a suppression file (`--suppress` on match-library, gap-sweep and lever-advice).
 *   libraryCandidates  agent-written items without a library id that the team accepted unchanged, with the
 *                   same statement, in at least --min-projects projects: worth considering for the libraries.
 *                   They hold project text, so they are printed and never written to the suppression file.
 *
 * `--suppress-out <file>` writes the suppression file (keys only, no client text). A file already there is
 * kept and extended, never narrowed; delete it to start over. A project counts once per key, whatever number
 * of its items carry the key. Nothing here edits a project folder or a library.
 *
 * Usage: node tools/blueprint/review-stats.mjs <folder> [<folder> ...] [--min-decisions <n>] [--min-projects <n>]
 *        [--reject-rate <0-1>] [--suppress-out <file>] [--markdown]
 * Exit 0 on success. Exit 1 when a folder cannot be read or no project is found. Exit 2 on bad usage.
 * A Context or Proposals file that cannot be used is skipped with a warning on stderr.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SUPPRESS_SCHEMA_VERSION, validateSuppress } from './suppression.mjs';
import { validateContextValue } from './validate-context.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';

export const CONTEXT_LISTS = ['deliveryUnknowns', 'assumptions', 'dependencies', 'deliveryRisks'];
export const DEFAULTS = { minDecisions: 3, minProjects: 2, rejectRate: 0.75 };

const MARKERS = [
  { family: 'gap-sweep', pattern: /^Gap sweep checklist [a-z][a-z0-9-]*$/i },
  { family: 'lever-advice', pattern: /^Lever advice \S+$/i },
  { family: 'second-opinion', pattern: /^Second opinion /i }
];
const SUPPRESSIBLE = ['library', 'gap-sweep', 'lever-advice'];
const SKIP_DIRS = new Set(['node_modules', '.git', '.blueprint']);
const USAGE =
  'Usage: node tools/blueprint/review-stats.mjs <folder> [<folder> ...] [--min-decisions <n>] [--min-projects <n>] [--reject-rate <0-1>] [--suppress-out <file>] [--markdown]';

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function normalize(text) {
  return String(text ?? '').toLowerCase().replace(/\s+/g, ' ').replace(/[.\s]+$/g, '').trim();
}

/** How an item is grouped: its library id, else the marker in its `source`, else not at all. */
export function groupOf(item) {
  if (typeof item.libraryId === 'string' && item.libraryId.trim() !== '') {
    return { family: 'library', key: item.libraryId.trim() };
  }
  const source = typeof item.source === 'string' ? item.source.trim() : '';
  const marker = MARKERS.find((entry) => entry.pattern.test(source));
  return marker ? { family: marker.family, key: source } : undefined;
}

/** `kept`, `edited`, `rejected`, `pending` for a Context item's review status. */
function contextOutcome(item) {
  const value = isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
  return value === 'accepted' ? 'kept' : value === 'edited' ? 'edited' : value === 'dismissed' ? 'rejected' : 'pending';
}

function proposalOutcome(proposal) {
  const value = isObject(proposal.review) && typeof proposal.review.status === 'string' ? proposal.review.status : 'pending';
  return value === 'applied' ? 'kept' : value === 'rejected' ? 'rejected' : 'pending';
}

function tally() {
  return { kept: 0, edited: 0, rejected: 0, pending: 0, projects: new Set() };
}

function finish(entry) {
  const decided = entry.kept + entry.edited + entry.rejected;
  return {
    projects: entry.projects.size,
    decided,
    kept: entry.kept,
    edited: entry.edited,
    rejected: entry.rejected,
    pending: entry.pending,
    keptRate: decided === 0 ? null : Math.round(((entry.kept + entry.edited) / decided) * 100) / 100,
    rejectRate: decided === 0 ? null : Math.round((entry.rejected / decided) * 100) / 100
  };
}

function bump(map, key, outcome, projectId) {
  const entry = map.get(key) || tally();
  entry[outcome] += 1;
  if (outcome !== 'pending') {
    entry.projects.add(projectId);
  }
  map.set(key, entry);
}

/**
 * @param {Array<{ id: string, context?: object, proposals?: object }>} projects
 * @param {{ minDecisions?: number, minProjects?: number, rejectRate?: number }} [options]
 */
export function reviewStats(projects, options = {}) {
  const given = Object.fromEntries(Object.entries(options).filter(([, value]) => value !== undefined));
  const { minDecisions, minProjects, rejectRate } = { ...DEFAULTS, ...given };
  const items = new Map();
  const votes = new Map();
  const kinds = new Map();
  const statements = new Map();

  for (const project of projects) {
    for (const list of CONTEXT_LISTS) {
      const rows = project.context && Array.isArray(project.context[list]) ? project.context[list] : [];
      for (const item of rows.filter(isObject)) {
        const outcome = contextOutcome(item);
        const group = groupOf(item);
        if (group) {
          const key = `${group.family}\u0000${group.key}\u0000${list}`;
          const entry = items.get(key) || { family: group.family, key: group.key, list, tally: tally() };
          entry.tally[outcome] += 1;
          if (outcome !== 'pending') {
            entry.tally.projects.add(project.id);
          }
          items.set(key, entry);
          const voteKey = `${group.family}\u0000${group.key}`;
          const vote = votes.get(voteKey) || { family: group.family, key: group.key, byProject: new Map() };
          const seen = vote.byProject.get(project.id) || new Set();
          seen.add(outcome);
          vote.byProject.set(project.id, seen);
          votes.set(voteKey, vote);
        } else if (outcome === 'kept' && typeof item.statement === 'string') {
          const id = `${list}\u0000${normalize(item.statement)}`;
          const entry = statements.get(id) || { list, statement: item.statement.trim(), projects: new Set(), count: 0 };
          entry.projects.add(project.id);
          entry.count += 1;
          statements.set(id, entry);
        }
      }
    }
    const proposals = project.proposals && Array.isArray(project.proposals.proposals) ? project.proposals.proposals : [];
    for (const proposal of proposals.filter(isObject)) {
      bump(kinds, typeof proposal.kind === 'string' ? proposal.kind : 'unknown', proposalOutcome(proposal), project.id);
    }
  }

  const itemRows = Array.from(items.values())
    .map((entry) => ({ family: entry.family, key: entry.key, list: entry.list, ...finish(entry.tally) }))
    .sort((a, b) => b.decided - a.decided || a.family.localeCompare(b.family) || a.key.localeCompare(b.key) || a.list.localeCompare(b.list));
  const kindRows = Array.from(kinds.entries())
    .map(([kind, entry]) => ({ kind, ...finish(entry) }))
    .sort((a, b) => a.kind.localeCompare(b.kind));

  // A gap or a lever advice puts its marker on two items (an unknown and an assumption) and a library id
  // can sit in more than one list. A project is one vote for a key: rejected when any of its items was
  // rejected, kept when one was kept or edited and none rejected, and no vote while all are pending.
  const suppressByKey = new Map();
  for (const entry of votes.values()) {
    if (SUPPRESSIBLE.indexOf(entry.family) === -1) {
      continue;
    }
    const row = { family: entry.family, key: entry.key, decided: 0, rejected: 0, projects: 0 };
    for (const outcomes of entry.byProject.values()) {
      if (outcomes.has('rejected')) {
        row.rejected += 1;
      } else if (!outcomes.has('kept') && !outcomes.has('edited')) {
        continue;
      }
      row.decided += 1;
      row.projects += 1;
    }
    suppressByKey.set(`${entry.family}\u0000${entry.key}`, row);
  }
  const suppress = Array.from(suppressByKey.values())
    .filter((entry) => entry.decided >= minDecisions && entry.projects >= minProjects && entry.rejected / entry.decided >= rejectRate)
    .map((entry) => ({ ...entry, rejectRate: Math.round((entry.rejected / entry.decided) * 100) / 100 }))
    .sort((a, b) => b.rejected - a.rejected || a.key.localeCompare(b.key));

  const libraryCandidates = Array.from(statements.values())
    .filter((entry) => entry.projects.size >= minProjects)
    .map((entry) => ({ list: entry.list, statement: entry.statement, projects: entry.projects.size, accepted: entry.count }))
    .sort((a, b) => b.projects - a.projects || a.statement.localeCompare(b.statement));

  return {
    projects: projects.length,
    thresholds: { minDecisions, minProjects, rejectRate },
    items: itemRows,
    proposalKinds: kindRows,
    suppress,
    libraryCandidates
  };
}

/**
 * The suppression file for a report: keys only. With the file already on disk (`previous`) it is the union:
 * a key suppressed earlier stays, because once it is not proposed any more the projects stop adding decisions
 * for it and a later run over newer folders would drop it. Delete the file to bring everything back.
 */
export function suppressionFile(report, previous) {
  const items = report.suppress.map((entry) => ({ key: entry.key, family: entry.family, decided: entry.decided, rejected: entry.rejected, projects: entry.projects }));
  const have = new Set(items.map((item) => `${item.family}\u0000${item.key}`));
  for (const item of previous && Array.isArray(previous.items) ? previous.items : []) {
    if (!have.has(`${item.family}\u0000${item.key}`)) {
      items.push({ key: item.key, family: item.family, decided: item.decided, rejected: item.rejected, projects: item.projects });
    }
  }
  return {
    schemaVersion: SUPPRESS_SCHEMA_VERSION,
    note: 'Written by tools/blueprint/review-stats.mjs. Keys only: a library id, or the source marker a proposing tool puts on its items. Pass it with --suppress to match-library, gap-sweep or lever-advice. Delete it to bring everything back.',
    items
  };
}

function percent(rate) {
  return rate === null ? 'n/a' : `${Math.round(rate * 100)}%`;
}

export function formatMarkdown(report) {
  const lines = [`## Review decisions across ${report.projects} project${report.projects === 1 ? '' : 's'}`, ''];
  if (report.skippedProjects > 0) {
    lines.push(`${report.skippedProjects} project folder${report.skippedProjects === 1 ? ' was' : 's were'} skipped because the Context file could not be used (see the warnings).`, '');
  }
  lines.push('| Item | Family | List | Projects | Kept | Edited | Rejected | Pending | Reject rate |', '| --- | --- | --- | --- | --- | --- | --- | --- | --- |');
  if (report.items.length === 0) {
    lines.push('| (none) | | | | | | | | |');
  }
  for (const row of report.items) {
    lines.push(`| \`${row.key}\` | ${row.family} | ${row.list} | ${row.projects} | ${row.kept} | ${row.edited} | ${row.rejected} | ${row.pending} | ${percent(row.rejectRate)} |`);
  }
  lines.push('', '### Proposals by kind', '', '| Kind | Projects | Applied | Rejected | Pending | Reject rate |', '| --- | --- | --- | --- | --- | --- |');
  if (report.proposalKinds.length === 0) {
    lines.push('| (none) | | | | | |');
  }
  for (const row of report.proposalKinds) {
    lines.push(`| ${row.kind} | ${row.projects} | ${row.kept} | ${row.rejected} | ${row.pending} | ${percent(row.rejectRate)} |`);
  }
  const { minDecisions, minProjects, rejectRate } = report.thresholds;
  lines.push('', `### Stop proposing (${minDecisions}+ decisions in ${minProjects}+ projects, ${percent(rejectRate)}+ rejected)`, '');
  if (report.suppress.length === 0) {
    lines.push('Nothing meets the bar.');
  }
  for (const entry of report.suppress) {
    lines.push(`- \`${entry.key}\` (${entry.family}): rejected ${entry.rejected} of ${entry.decided} in ${entry.projects} projects`);
  }
  lines.push('', `### Worth adding to the libraries (accepted unchanged in ${minProjects}+ projects)`, '');
  if (report.libraryCandidates.length === 0) {
    lines.push('Nothing meets the bar.');
  }
  for (const entry of report.libraryCandidates) {
    lines.push(`- ${entry.list}: ${entry.statement} (${entry.projects} projects)`);
  }
  lines.push('');
  return lines.join('\n');
}

function readJsonIfPresent(file, label, warnings) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (error) {
    warnings.push(`${label}: cannot read ${file}: ${error.message}`);
    return undefined;
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    warnings.push(`${label}: ${file} is not valid JSON (${error.message})`);
    return undefined;
  }
}

/** Project folders under `root`: itself when it holds a Context file, else the folders one and two levels down that do. */
export function findProjectFolders(root, depth = 2) {
  const entries = fs.readdirSync(root, { withFileTypes: true });
  if (entries.some((entry) => entry.isFile() && /_Context\.json$/.test(entry.name))) {
    return [root];
  }
  if (depth === 0) {
    return [];
  }
  return entries
    .filter((entry) => entry.isDirectory() && !SKIP_DIRS.has(entry.name) && !entry.name.startsWith('.'))
    .flatMap((entry) => findProjectFolders(path.join(root, entry.name), depth - 1));
}

/** Loads one project folder; undefined when no usable Context file is there. */
export function loadProject(folder, warnings) {
  const names = fs.readdirSync(folder);
  const contextName = names.find((name) => /_Context\.json$/.test(name));
  if (!contextName) {
    return undefined;
  }
  const context = readJsonIfPresent(path.join(folder, contextName), 'context', warnings);
  if (context === undefined) {
    return undefined;
  }
  const errors = validateContextValue(context);
  if (errors.length) {
    warnings.push(`context: ${path.join(folder, contextName)} skipped (${errors[0]})`);
    return undefined;
  }
  const proposalsName = names.find((name) => /_Proposals\.json$/.test(name));
  let proposals;
  if (proposalsName) {
    proposals = readJsonIfPresent(path.join(folder, proposalsName), 'proposals', warnings);
    if (proposals !== undefined && !(isObject(proposals) && Array.isArray(proposals.proposals))) {
      warnings.push(`proposals: ${path.join(folder, proposalsName)} has no proposals array and is ignored`);
      proposals = undefined;
    }
  }
  return { id: path.resolve(folder), context, proposals };
}

function parseArgs(args) {
  const parsed = { folders: [] };
  const valueFlags = { '--min-decisions': 'minDecisions', '--min-projects': 'minProjects', '--reject-rate': 'rejectRate', '--suppress-out': 'suppressOut' };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === '--markdown') {
      parsed.markdown = true;
    } else if (Object.prototype.hasOwnProperty.call(valueFlags, arg)) {
      const next = args[index + 1];
      const name = valueFlags[arg];
      if (next === undefined || next === '' || next.startsWith('--') || parsed[name] !== undefined) {
        return undefined;
      }
      if (name === 'minDecisions' || name === 'minProjects') {
        if (!/^[1-9][0-9]*$/.test(next)) {
          return undefined;
        }
        parsed[name] = Number(next);
      } else if (name === 'rejectRate') {
        const rate = Number(next);
        if (!Number.isFinite(rate) || rate <= 0 || rate > 1) {
          return undefined;
        }
        parsed[name] = rate;
      } else {
        parsed[name] = next;
      }
      index += 1;
    } else if (arg.startsWith('--')) {
      return undefined;
    } else {
      parsed.folders.push(arg);
    }
  }
  return parsed.folders.length > 0 ? parsed : undefined;
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  const warnings = [];
  const folders = [];
  for (const root of parsed.folders) {
    try {
      findProjectFolders(path.resolve(root)).forEach((folder) => {
        if (folders.indexOf(folder) === -1) {
          folders.push(folder);
        }
      });
    } catch (error) {
      console.error(`Cannot read ${path.resolve(root)}: ${error.message}`);
      process.exit(1);
    }
  }
  const projects = folders.map((folder) => loadProject(folder, warnings)).filter((project) => project !== undefined);
  warnings.forEach((message) => console.error(`warning: ${message}`));
  if (projects.length === 0) {
    console.error('No project with a usable Context file was found in the folders given.');
    process.exit(1);
  }
  const report = reviewStats(projects, {
    minDecisions: parsed.minDecisions,
    minProjects: parsed.minProjects,
    rejectRate: parsed.rejectRate
  });
  report.skippedProjects = folders.length - projects.length;
  if (parsed.suppressOut) {
    const out = path.resolve(parsed.suppressOut);
    let previous;
    if (fs.existsSync(out)) {
      try {
        previous = JSON.parse(fs.readFileSync(out, 'utf8'));
      } catch (error) {
        console.error(`Cannot update ${out}: ${error.message}. Fix or delete it.`);
        process.exit(1);
      }
      const errors = validateSuppress(previous);
      if (errors.length) {
        console.error(`Cannot update ${out}: ${errors[0]}. Fix or delete it.`);
        process.exit(1);
      }
    }
    writeFileAtomic(out, `${JSON.stringify(suppressionFile(report, previous), null, 2)}\n`);
  }
  process.stdout.write(parsed.markdown ? formatMarkdown(report) : `${JSON.stringify(report, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
