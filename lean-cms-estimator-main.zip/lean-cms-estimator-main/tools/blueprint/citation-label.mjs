/**
 * Citation label helpers ported from function/src/citation.ts.
 */
const EN_DASH = '\u2013';
const ELLIPSIS = '\u2026';
const MAX_HEADING_IN_LABEL = 60;
const HEADING_NUMBER = /^(\d+(?:\.\d+)*)\.?\s+(.+)$/;

/**
 * @param {string} fileName
 * @returns {string}
 */
export function baseName(fileName) {
  const name = String(fileName).trim();
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(0, dot) : name;
}

/**
 * @param {string} text
 * @returns {{ section?: string, heading: string }}
 */
export function splitHeading(text) {
  const trimmed = String(text).trim();
  const match = HEADING_NUMBER.exec(trimmed);
  if (match) {
    return { section: match[1], heading: match[2].trim() };
  }
  return { heading: trimmed };
}

/**
 * @param {{ page?: number, pageEnd?: number, pageApprox?: boolean }} location
 * @returns {string|undefined}
 */
function pagePart(location) {
  if (location.page === undefined) {
    return undefined;
  }
  const approx = location.pageApprox ? '~' : '';
  if (location.pageEnd !== undefined && location.pageEnd > location.page) {
    return `p.${approx}${location.page}${EN_DASH}${location.pageEnd}`;
  }
  return `p.${approx}${location.page}`;
}

/**
 * @param {string} text
 * @param {number} max
 */
function truncate(text, max) {
  return text.length > max ? `${text.slice(0, max).trimEnd()}${ELLIPSIS}` : text;
}

/**
 * @param {string} fileName
 * @param {{ kind: string, page?: number, pageEnd?: number, pageApprox?: boolean, section?: string, heading?: string, slide?: number, notes?: boolean, sheet?: string, rowStart?: number, rowEnd?: number }} location
 * @returns {string}
 */
export function citationLabel(fileName, location) {
  const parts = [baseName(fileName)];
  if (location.kind === 'slide') {
    parts.push(`slide ${location.slide}`);
    if (location.notes) {
      parts.push('notes');
    }
    return parts.join(' ');
  }
  if (location.kind === 'sheet') {
    const start = location.rowStart;
    const end = location.rowEnd;
    parts.push(location.sheet);
    parts.push(end > start ? `rows ${start}${EN_DASH}${end}` : `row ${start}`);
    return parts.filter((part) => part.length > 0).join(' ');
  }

  const page = pagePart(location);
  if (page) {
    parts.push(page);
  }
  if (location.section) {
    parts.push(`\u00A7${location.section}`);
  }
  if (location.kind === 'section') {
    if (location.heading) {
      parts.push(truncate(location.heading, MAX_HEADING_IN_LABEL));
    } else if (!page && !location.section) {
      parts.push('opening text');
    }
  }
  return parts.join(' ');
}

/**
 * @param {string} itemId
 * @param {string} anchor
 * @returns {string}
 */
export function blockId(itemId, anchor) {
  return `${itemId}#${anchor}`;
}
