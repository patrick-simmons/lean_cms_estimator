# Blueprint project: {{projectName}}

This folder is a Launch CMS Blueprint project. An estimator prepared it for the Blueprint skill pack. Follow this file before anything else in the folder.

## What to do

Run the **estimate** skill on this folder. It parses the sources, extracts the requirements, counts what the documents let it count, and writes the plan file into this folder, asking the estimator a few questions in chat at set points (accept all or walk through, only what is unclear, the client questions). Nothing is pasted anywhere. A person starts each run; nothing here starts on its own. The stage skills it uses are in the same pack; `blueprint-offline` is the older, longer route and is not needed.

If the skill pack is not installed, stop and say so. The install guide is `README.md` in the pack and `docs/standalone/agent-skill-pack.md` in the Blueprint repository. Do not improvise the pipeline without the skills and their tools.

## Read only these files

{{sourcesList}}

Do not read any other file in this folder as a source. The same list is in `.blueprint/sources.json`, and the parse tool reads it when it is run without a file list.

## Write

- **First run** (no `{{projectName}}_Plan.json` in the folder yet): write `{{projectName}}_Plan.json` (through `plan.mjs assemble`) and `{{projectName}}_Context.json`.
- **Later runs:** `plan.mjs assemble` only adds to the plan file; it never changes a row that is already there, decisions included. Add to `{{projectName}}_Context.json` only; never edit or remove an item that is already there.
- **Always:** the parse tool writes `.blueprint/parsed/`. You write `.blueprint/extract.json`, the extraction result the plan tool reads. The optional steps add working files, each written through its tool: `.blueprint/design-sketch.json` and `.blueprint/second-opinion-sketch.json` (sizing drivers, from `assemble-drivers.mjs`, always pending) and the inputs those tools read (the drivers, objections and a team suppression file, if there is one). Their results reach the estimator as pending items in the plan file and `{{projectName}}_Context.json`. Do not write anything else into this folder.

## Contract and versions

- Expected pack version: {{packVersion}}. Schemas: {{schemas}}.
- Catalogs: {{catalogs}}.
- The file contract is `docs/agent-contract.md` in the pack (`docs/spfx/agent-contract.md` in the Blueprint repository). When the pack you have is older than the version above, say so before running.

## Guardrails

- Do not invent driver quantities, hours, dates or weeks. Leave a number blank when the documents do not give it. A sizing driver in the design sketch is the one exception to "no quantity", and only with the words, names or parts in the parsed blocks that back it.
- Do not resolve a conflict. Two sources that disagree become one requirement with coverage `conflict`, both citations and a question. No winner.
- Do not write commercial or work-environment fields: account history, new logo, commercial risks, client difficulty, difficulty multipliers, staffing profiles.
- Cite only block ids the parse tool produced. Do not invent passages, block ids or files.
- Capability ids come from the Node post-process only. Do not write them yourself.
- Propose, never decide: every row and register item you write is `pending`.
