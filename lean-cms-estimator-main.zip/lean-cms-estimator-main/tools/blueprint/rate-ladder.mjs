/**
 * Which rung an activity's rate stands on (story B-07).
 *
 * The ladder has three rungs and they are ordered by how much the number is worth:
 *
 *   cases           enough cases on this platform. Evidence. No question owed.
 *   cases-adjusted  cases, but too few or from another platform. A question is owed.
 *   derived         no case covers it, so the figure is the seed's. A question is owed, and
 *                   the estimator has to accept the number before it counts as theirs.
 *
 * The field is `rateBasis` rather than `basis` because a workstream already carries
 * `volumeBasis`, and a plan that says `basis` twice about two different things is a plan
 * nobody can read.
 *
 * The rung also decides the range (story B-08): cases bring their own spread, a derived rate
 * has none.
 */
import { deriveRate } from '../cases/derive.mjs';

export const RATE_BASES = ['cases', 'cases-adjusted', 'derived'];

/** Rung 1 is the only rung that does not owe the client a question about where the rate came from. */
export function questionOwed(rateBasis) {
  return rateBasis !== 'cases';
}

function thinCasesQuestion(name, rate) {
  const from = rate.platformMatch === 'same'
    ? `${rate.n} past project${rate.n === 1 ? '' : 's'}`
    : `${rate.n} past project${rate.n === 1 ? '' : 's'} on another platform`;
  return `${name}: the rate comes from ${from} (${rate.caseIds.join(', ')}), which is thin. Is this work comparable to those?`;
}

function derivedQuestion(name, accepted) {
  return accepted
    ? `${name}: no past project covers this, so the rate is one we set rather than measured. Does it match your experience?`
    : `${name}: no past project covers this and nobody has accepted a rate yet, so the estimate uses the catalog's starting figure. It needs a decision before this number is ours.`;
}

/**
 * The rate for one activity, and the evidence behind it.
 *
 * Cases win when the library covers the activity. Otherwise the seed figure is used as a
 * working number and marked as not accepted: the tool never records an estimator's decision
 * on their behalf, but it also will not refuse to produce an estimate before they have made
 * one. `plan.mjs rate` is how the decision gets recorded.
 *
 * @param {object[]} cases the validated case library
 * @param {{id: string, name: string, shape: string, unit: string}} activity
 * @param {string} platform
 * @param {number} seedRate the catalog's starting hours per unit
 * @param {object|undefined} acceptedRate the plan's accepted rate for this activity, if any
 */
export function rateFor(cases, activity, platform, seedRate, acceptedRate) {
  const fromCases = deriveRate(cases, activity, platform);
  if (fromCases) {
    return {
      rate: fromCases.likely,
      rateLow: fromCases.low,
      rateHigh: fromCases.high,
      rateSpread: fromCases.spread,
      rateBasis: fromCases.basis,
      caseIds: fromCases.caseIds,
      caseCount: fromCases.n,
      ...(questionOwed(fromCases.basis) ? { rateQuestion: thinCasesQuestion(activity.name, fromCases) } : {})
    };
  }
  const accepted = Boolean(acceptedRate);
  const rate = accepted ? acceptedRate.hoursPerUnit : seedRate;
  return {
    rate,
    // A single figure has no spread, and a range invented on top of one would read as evidence
    // of a width nobody measured. The rung says what the uncertainty is; the range stays silent.
    rateLow: rate,
    rateHigh: rate,
    rateSpread: 'none',
    rateBasis: 'derived',
    caseIds: [],
    caseCount: 0,
    rateAccepted: accepted,
    rateQuestion: derivedQuestion(activity.name, accepted)
  };
}

/** The plan's accepted rates, by activity. Only an accepted or edited decision counts. */
export function acceptedRates(plan) {
  const rows = Array.isArray(plan.rates) ? plan.rates : [];
  return new Map(rows
    .filter((row) => row && typeof row.activity === 'string'
      && row.review && ['accepted', 'edited'].indexOf(row.review.status) !== -1)
    .map((row) => [row.activity, row]));
}
