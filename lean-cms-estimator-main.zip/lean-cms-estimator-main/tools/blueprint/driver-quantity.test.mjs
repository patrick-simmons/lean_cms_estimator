import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractedQuantities, NUMBER_IN_TEXT, statedQuantity } from './driver-quantity.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

test('a number with a thousands separator counts as one number', () => {
  assert.ok(NUMBER_IN_TEXT instanceof RegExp);
  assert.equal(statedQuantity('Migrate approximately 6,400 pages and 12 templates'), 6400);
});

test('the quantity is the first number, and words and zero do not count', () => {
  assert.equal(statedQuantity('Four launch locales'), undefined);
  assert.equal(statedQuantity('Build 3 integrations over 12 weeks'), 3);
  assert.equal(statedQuantity('0 items'), undefined);
  assert.equal(statedQuantity(undefined), undefined);
});

test('quantities are summed per package, and dismissed or unmapped rows are left out', () => {
  assert.deepEqual(
    extractedQuantities([
      { workPackage: 'integrations', statement: 'Two systems, 3 feeds' },
      { workPackage: 'integrations', statement: '4 APIs' },
      { workPackage: 'integrations', statement: '9 more', review: { status: 'dismissed' } },
      { workPackage: 'unmapped', statement: '9 things' },
      { statement: '9 things' },
      null
    ]),
    { 'integrations': 7 }
  );
  assert.deepEqual(extractedQuantities(undefined), {});
});
