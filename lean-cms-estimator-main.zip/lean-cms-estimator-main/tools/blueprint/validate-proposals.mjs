#!/usr/bin/env node
/**
 * Validator for `{Project}_Proposals.json`, the file the agent writes on a re-run instead of touching a
 * Blueprint that has review state (SAPP-014). Field-path errors, same style as validate-working-file.mjs.
 * The TypeScript mirror is src/webparts/blueprint/projects/proposalsFile.ts; both run the shared cases in
 * fixtures/proposals-validator-cases.json. The contract is docs/spfx/agent-contract.md.
 *
 * Usage: node tools/blueprint/validate-proposals.mjs <path-to-proposals.json> [--blueprint <path-to-blueprint.json> [--strict]]
 *
 * With --blueprint, cross-file problems print a `warning:` line on stderr and do not change the exit
 * code: a requirementId or cited itemId that is not in the Blueprint, a different projectId or
 * blueprintRevision, and a pending proposal whose `existing` snapshot no longer matches the live row.
 * With --strict the same problems are errors (exit 1).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkLocation, COVERAGES, REVIEW_STATUSES } from './validate-working-file.mjs';

export const PROPOSALS_SCHEMA_VERSION = '1';
export const PROPOSAL_KINDS = ['add', 'update', 'conflict'];
export const PROPOSAL_STATUSES = ['pending', 'applied', 'rejected'];
const CAUSE_KINDS = ['file', 'note'];
/** The citation fields that identify and quote the evidence: never empty. */
const CITATION_TEXT_KEYS = ['itemId', 'blockId', 'passage'];
const PROPOSAL_ID = /^P-\d{3,}$/;
const REQUIREMENT_ID = /^R-\d{3,}$/;

function isObject(value) {
  return typeof value === 'object' && !!value && !Array.isArray(value);
}

function isString(value) {
  return typeof value === 'string';
}

function isText(value) {
  return isString(value) && value.trim().length > 0;
}

function isCount(value) {
  return typeof value === 'number' && Number.isFinite(value) && Math.floor(value) === value && value >= 0;
}

function isDate(value) {
  return isString(value) && !Number.isNaN(Date.parse(value));
}

/** A required timestamp: a string that parses as a date. */
function checkTimestamp(value, field, errors) {
  if (!isString(value)) {
    errors.push(`${field}: expected string`);
  } else if (!isDate(value)) {
    errors.push(`${field}: expected an ISO 8601 date`);
  }
}

function checkSources(sources, p, errors) {
  if (!Array.isArray(sources) || sources.length === 0) {
    errors.push(`${p}.sources: expected non-empty array`);
    return;
  }
  sources.forEach((src, j) => {
    const sp = `${p}.sources[${j}]`;
    if (!isObject(src)) {
      errors.push(`${sp}: expected object`);
      return;
    }
    for (const key of ['itemId', 'fileName', 'blockId', 'label', 'passage']) {
      if (CITATION_TEXT_KEYS.includes(key)) {
        if (!isText(src[key])) {
          errors.push(`${sp}.${key}: required non-empty string`);
        }
      } else if (!isString(src[key])) {
        errors.push(`${sp}.${key}: expected string`);
      }
    }
    checkLocation(src.location, `${sp}.location`, errors);
  });
}

function checkCause(cause, p, errors) {
  if (!isObject(cause) || !isString(cause.kind) || !CAUSE_KINDS.includes(cause.kind)) {
    errors.push(`${p}.cause.kind: expected file|note`);
    return;
  }
  if (cause.kind === 'file') {
    for (const key of ['itemId', 'fileName']) {
      if (!isText(cause[key])) {
        errors.push(`${p}.cause.${key}: required non-empty string`);
      }
    }
  } else {
    checkTimestamp(cause.at, `${p}.cause.at`, errors);
    if (!isText(cause.text)) {
      errors.push(`${p}.cause.text: required non-empty string`);
    }
  }
}

function checkExisting(existing, p, errors) {
  if (!isObject(existing)) {
    errors.push(`${p}.existing: expected object`);
    return;
  }
  if (!isText(existing.statement)) {
    errors.push(`${p}.existing.statement: required non-empty string`);
  }
  if (!isString(existing.workPackage)) {
    errors.push(`${p}.existing.workPackage: expected string`);
  }
  if (!isString(existing.coverage) || !COVERAGES.includes(existing.coverage)) {
    errors.push(`${p}.existing.coverage: expected coverage enum`);
  }
  if (!isString(existing.reviewStatus) || !REVIEW_STATUSES.includes(existing.reviewStatus)) {
    errors.push(`${p}.existing.reviewStatus: expected pending|accepted|edited|dismissed`);
  }
  if (existing.question !== undefined && !isString(existing.question)) {
    errors.push(`${p}.existing.question: expected string`);
  }
}

function checkProposal(item, p, seen, errors) {
  if (!isObject(item)) {
    errors.push(`${p}: expected object`);
    return;
  }
  if (!isString(item.id) || !PROPOSAL_ID.test(item.id)) {
    errors.push(`${p}.id: expected P-### (at least three digits)`);
  } else if (seen.has(item.id)) {
    errors.push(`${p}.id: duplicate id ${item.id}`);
  } else {
    seen.add(item.id);
  }
  const kind = isString(item.kind) && PROPOSAL_KINDS.includes(item.kind) ? item.kind : undefined;
  if (kind === undefined) {
    errors.push(`${p}.kind: expected add|update|conflict`);
  }
  if (kind === 'add') {
    if (item.requirementId !== undefined && item.requirementId !== null) {
      errors.push(`${p}.requirementId: must be absent on an add`);
    }
    if (item.existing !== undefined) {
      errors.push(`${p}.existing: must be absent on an add`);
    }
  } else if (kind !== undefined) {
    if (!isString(item.requirementId) || !REQUIREMENT_ID.test(item.requirementId)) {
      errors.push(`${p}.requirementId: expected R-### (at least three digits)`);
    }
    checkExisting(item.existing, p, errors);
  }
  if (!isText(item.statement)) {
    errors.push(`${p}.statement: required non-empty string`);
  }
  checkSources(item.sources, p, errors);
  if (!isText(item.workPackage)) {
    errors.push(`${p}.workPackage: required non-empty string`);
  }
  if (!Array.isArray(item.capabilities) || !item.capabilities.every(isString)) {
    errors.push(`${p}.capabilities: expected string[]`);
  }
  if (!isString(item.coverage) || !COVERAGES.includes(item.coverage)) {
    errors.push(`${p}.coverage: expected accelerated|partly|human-led|question|conflict`);
  } else if (kind === 'conflict' && item.coverage !== 'conflict') {
    errors.push(`${p}.coverage: a conflict proposal has coverage conflict`);
  }
  if (item.question !== undefined && item.question !== null && !isString(item.question)) {
    errors.push(`${p}.question: expected string or null`);
  } else if (kind === 'conflict' && !isText(item.question)) {
    errors.push(`${p}.question: a conflict proposal needs a question for the client`);
  }
  checkCause(item.cause, p, errors);
  if (!isObject(item.review) || !isString(item.review.status) || !PROPOSAL_STATUSES.includes(item.review.status)) {
    errors.push(`${p}.review.status: expected pending|applied|rejected`);
  } else {
    if (item.review.status !== 'pending') {
      if (!isText(item.review.by)) {
        errors.push(`${p}.review.by: required for non-pending`);
      }
      if (!isText(item.review.at)) {
        errors.push(`${p}.review.at: required for non-pending`);
      } else if (!isDate(item.review.at)) {
        errors.push(`${p}.review.at: expected an ISO 8601 date`);
      }
    }
    if (item.review.byName !== undefined && !isString(item.review.byName)) {
      errors.push(`${p}.review.byName: expected string`);
    }
    if (item.review.requirementId !== undefined) {
      if (item.review.status !== 'applied') {
        errors.push(`${p}.review.requirementId: only allowed when the proposal is applied`);
      } else if (!isString(item.review.requirementId)) {
        errors.push(`${p}.review.requirementId: expected string`);
      }
    }
  }
  if (item.runId !== undefined && !isString(item.runId)) {
    errors.push(`${p}.runId: expected string`);
  }
  checkTimestamp(item.proposedAt, `${p}.proposedAt`, errors);
}

/**
 * @param {unknown} value
 * @param {string} [base]
 * @returns {string[]} field-path errors; empty when valid
 */
export function validateProposalsValue(value, base = '') {
  const errors = [];
  if (!isObject(value)) {
    return [`${base || '(root)'}: expected object`];
  }
  if (value.schemaVersion !== PROPOSALS_SCHEMA_VERSION) {
    errors.push(`${base}schemaVersion: expected "${PROPOSALS_SCHEMA_VERSION}"`);
  }
  for (const key of ['projectId', 'projectName']) {
    if (!isString(value[key])) {
      errors.push(`${base}${key}: expected string`);
    }
  }
  if (!isCount(value.blueprintRevision)) {
    errors.push(`${base}blueprintRevision: expected non-negative integer`);
  }
  if (value.sources !== undefined) {
    if (!Array.isArray(value.sources)) {
      errors.push(`${base}sources: expected array`);
    } else {
      value.sources.forEach((source, i) => {
        const p = `${base}sources[${i}]`;
        if (!isObject(source)) {
          errors.push(`${p}: expected object`);
          return;
        }
        for (const key of ['itemId', 'name']) {
          if (!isText(source[key])) {
            errors.push(`${p}.${key}: required non-empty string`);
          }
        }
      });
    }
  }
  if (value.runs !== undefined) {
    if (!Array.isArray(value.runs)) {
      errors.push(`${base}runs: expected array`);
    } else {
      value.runs.forEach((run, i) => {
        const p = `${base}runs[${i}]`;
        if (!isObject(run)) {
          errors.push(`${p}: expected object`);
          return;
        }
        if (!isString(run.runId)) {
          errors.push(`${p}.runId: expected string`);
        }
        checkTimestamp(run.at, `${p}.at`, errors);
        if (run.packVersion !== undefined && !isString(run.packVersion)) {
          errors.push(`${p}.packVersion: expected string`);
        }
        if (run.added !== undefined && !isCount(run.added)) {
          errors.push(`${p}.added: expected non-negative integer`);
        }
      });
    }
  }
  if (!Array.isArray(value.proposals)) {
    errors.push(`${base}proposals: expected array`);
    return errors;
  }
  const seen = new Set();
  value.proposals.forEach((item, i) => checkProposal(item, `${base}proposals[${i}]`, seen, errors));
  return errors;
}

/** The fields of a row a proposal's `existing` snapshot records, as the live Blueprint holds them. */
function liveSnapshot(row, questions) {
  const link = questions.find((q) => isObject(q) && q.requirementId === row.id);
  return {
    statement: row.statement,
    workPackage: row.workPackage,
    coverage: row.coverage,
    reviewStatus: isObject(row.review) ? row.review.status : undefined,
    question: link && isString(link.text) ? link.text : undefined
  };
}

/**
 * Cross-file checks against the Blueprint, each a message: a different projectId or blueprintRevision, a
 * requirementId that matches no row, a cited itemId that is neither in the Blueprint's sources nor in the
 * proposals file's own `sources`, and a pending proposal whose `existing` snapshot no longer matches the
 * live row (the estimator edited it after the agent ran). Safe on a value that is not a Blueprint.
 * @param {object} proposals
 * @param {object} blueprint
 * @returns {string[]}
 */
export function collectProposalWarnings(proposals, blueprint) {
  if (!isObject(proposals)) {
    return ['proposals: expected object'];
  }
  if (!isObject(blueprint)) {
    return ['blueprint: expected a Blueprint object, so the cross-file checks were skipped'];
  }
  const warnings = [];
  if (isString(blueprint.projectId) && proposals.projectId !== blueprint.projectId) {
    warnings.push(`projectId: "${proposals.projectId}" does not match the Blueprint's "${blueprint.projectId}"`);
  }
  if (isCount(blueprint.revision) && proposals.blueprintRevision !== blueprint.revision) {
    warnings.push(`blueprintRevision: ${proposals.blueprintRevision} but the Blueprint is at revision ${blueprint.revision}`);
  }
  const rows = (Array.isArray(blueprint.requirements) ? blueprint.requirements : []).filter(isObject);
  const questions = Array.isArray(blueprint.questions) ? blueprint.questions : [];
  const rowsById = new Map(rows.map((row) => [row.id, row]));
  const itemIds = new Set([
    ...(Array.isArray(blueprint.sources) ? blueprint.sources : []).map((s) => isObject(s) ? s.itemId : undefined),
    ...(Array.isArray(proposals.sources) ? proposals.sources : []).map((s) => isObject(s) ? s.itemId : undefined)
  ]);
  (Array.isArray(proposals.proposals) ? proposals.proposals : []).forEach((item, i) => {
    if (!isObject(item)) {
      return;
    }
    if (item.kind !== 'add') {
      const row = rowsById.get(item.requirementId);
      if (!row) {
        warnings.push(`proposals[${i}].requirementId: ${item.requirementId} is not in the Blueprint`);
      } else if (isObject(item.review) && item.review.status === 'pending' && isObject(item.existing)) {
        const live = liveSnapshot(row, questions);
        const changed = ['statement', 'workPackage', 'coverage', 'reviewStatus', 'question']
          .filter((field) => item.existing[field] !== live[field]);
        if (changed.length) {
          warnings.push(`proposals[${i}].existing: ${row.id} has changed since the agent read it (${changed.join(', ')})`);
        }
      }
    }
    (Array.isArray(item.sources) ? item.sources : []).forEach((src, j) => {
      if (isObject(src) && !itemIds.has(src.itemId)) {
        warnings.push(`proposals[${i}].sources[${j}].itemId: ${src.itemId} is in neither the Blueprint nor this file's sources`);
      }
    });
  });
  return warnings;
}

const USAGE = 'Usage: node tools/blueprint/validate-proposals.mjs <path-to-proposals.json> [--blueprint <path-to-blueprint.json> [--strict]]';

function readJson(file, label) {
  const abs = path.resolve(file);
  if (!fs.existsSync(abs)) {
    console.error(`${label} not found: ${abs}`);
    process.exit(2);
  }
  let text;
  try {
    text = fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`${label}: cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    console.error(`${label}: invalid JSON: ${error.message}`);
    process.exit(1);
  }
}

/** @returns {{ file: string, blueprint?: string, strict: boolean } | undefined} undefined on a usage error */
function parseCli(args) {
  const out = { strict: false };
  const positional = [];
  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];
    if (arg === '--strict') {
      out.strict = true;
    } else if (arg === '--blueprint') {
      i += 1;
      if (!args[i] || args[i].startsWith('--')) {
        return undefined;
      }
      out.blueprint = args[i];
    } else if (arg.startsWith('--')) {
      return undefined;
    } else {
      positional.push(arg);
    }
  }
  if (positional.length !== 1 || (out.strict && !out.blueprint)) {
    return undefined;
  }
  out.file = positional[0];
  return out;
}

function main(argv) {
  const cli = parseCli(argv.slice(2));
  if (!cli) {
    console.error(USAGE);
    process.exit(2);
  }
  const value = readJson(cli.file, 'proposals');
  const errors = validateProposalsValue(value);
  if (errors.length) {
    errors.forEach((message) => console.error(message));
    process.exit(1);
  }
  if (cli.blueprint) {
    const blueprint = readJson(cli.blueprint, 'blueprint');
    const problems = collectProposalWarnings(value, blueprint);
    if (cli.strict && problems.length) {
      problems.forEach((message) => console.error(`error: ${message}`));
      process.exit(1);
    }
    problems.forEach((message) => console.error(`warning: ${message}`));
  }
  const pending = value.proposals.filter((item) => item.review.status === 'pending').length;
  console.log(`OK: ${path.basename(path.resolve(cli.file))} (${value.proposals.length} proposals, ${pending} pending)`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
