import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { DEFAULT_CATALOG, formatMarkdown, parseActivities, rankQuestions } from './rank-questions.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'rank-questions.mjs');
const catalogMd = fs.readFileSync(DEFAULT_CATALOG, 'utf8');
const workPackages = parseActivities(catalogMd);

function req(id, workPackage, statement, coverage = 'accelerated', status) {
  return { id, workPackage, statement, coverage, ...(status ? { review: { status } } : {}) };
}

test('the Activities table gives each activity its name, unit, phase, shape, owner and share set', () => {
  assert.equal(workPackages.size, 25);
  // A tiered or proportional activity has no unit, and only a proportional one has a share
  // set; their dashes read back as an empty string and an empty list.
  const shape = ({ name, unit, phase, shape: how, owner, shareOf }) => ({ name, unit, phase, shape: how, owner, shareOf });
  assert.deepEqual(shape(workPackages.get('content-migration')), { name: 'Content migration', unit: 'page', phase: 'build', shape: 'per-unit', owner: 'us', shareOf: [] });
  assert.deepEqual(shape(workPackages.get('localization')), { name: 'Localization', unit: 'locale', phase: 'build', shape: 'per-unit', owner: 'shared', shareOf: [] });
  assert.deepEqual(shape(workPackages.get('qa-automation')), {
    name: 'QA and test automation',
    unit: '',
    phase: 'assure',
    shape: 'proportional',
    owner: 'us',
    shareOf: ['component-build', 'frontend-delivery', 'integrations', 'search', 'seo', 'localization', 'multisite', 'workflow-governance']
  });
  assert.deepEqual(workPackages.get('project-management').shareOf, ['everything-else']);
  assert.deepEqual(shape(workPackages.get('design-system')), { name: 'Design system', unit: '', phase: 'design', shape: 'tiered', owner: 'us', shareOf: [] });
  // The catalog says who usually does the work, and it never says the client: handing an
  // activity over is a decision on one estimate, not a default.
  for (const [id, entry] of workPackages) {
    assert.ok(entry.owner === 'us' || entry.owner === 'shared', `${id} has owner "${entry.owner}"`);
  }
  // The Capabilities table has rows that look like activity rows; they must not replace the real ones.
  assert.deepEqual(shape(workPackages.get('integrations')), { name: 'Integrations', unit: 'integration', phase: 'build', shape: 'per-unit', owner: 'us', shareOf: [] });
});

test('the Starting figures table lands on the activity it names, and the Capabilities table does not', () => {
  assert.deepEqual(workPackages.get('content-migration').skillIds, ['aem-core', 'content-strategy', 'seo']);
  assert.equal(workPackages.get('content-migration').hoursPerUnit, 2);
  assert.equal(workPackages.get('content-migration').volume, 100);
  // A proportional activity is sized by its share, so it has the skills and the saving but
  // neither of the two numbers.
  assert.equal(workPackages.get('project-management').hoursPerUnit, null);
  assert.equal(workPackages.get('project-management').volume, null);
  assert.equal(workPackages.get('uat-support').aiSavingPercent, 0);
  // An activity with no row is not sized at all, which is different from being sized at zero.
  assert.equal(workPackages.get('hypercare').skillIds, undefined);

  const warnings = [];
  parseActivities(`${catalogMd}\n| \`not-an-activity\` | 4 | 2 | 30 | \`qa\` |\n`, warnings);
  assert.deepEqual(warnings, ['the catalog gives not-an-activity starting figures but does not list it as an activity']);
});

test('a conflict outranks an open question, which outranks a plain one', () => {
  const blueprint = {
    requirements: [req('R-1', 'localization', 'Locales', 'conflict'), req('R-2', 'integrations', 'Feeds', 'question'), req('R-3', 'qa-automation', 'Testing')],
    questions: [
      { id: 'Q1', requirementId: 'R-3', text: 'Who tests?' },
      { id: 'Q2', requirementId: 'R-2', text: 'Which feeds?' },
      { id: 'Q3', requirementId: 'R-1', text: 'Which locales?' }
    ]
  };
  const { ranked } = rankQuestions(blueprint, undefined, workPackages);
  assert.deepEqual(ranked.map((item) => item.id), ['Q3', 'Q2', 'Q1']);
  assert.deepEqual(ranked.map((item) => item.rank), [1, 2, 3]);
  assert.ok(ranked[0].reasons.includes('the sources disagree'));
});

test('a question that asks for a quantity, or about a requirement with a stated figure, scores higher', () => {
  const blueprint = {
    requirements: [req('R-1', 'content-migration', 'Migrate 6,400 pages'), req('R-2', 'content-model', 'Model the content')],
    questions: [
      { id: 'Q1', requirementId: 'R-2', text: 'Who owns the models?' },
      { id: 'Q2', requirementId: 'R-1', text: 'How many pages remain after clean-up?' }
    ]
  };
  const { ranked } = rankQuestions(blueprint, undefined, workPackages);
  assert.equal(ranked[0].id, 'Q2');
  assert.equal(ranked[0].score, 5);
  assert.ok(ranked[0].reasons.some((text) => text.includes('6400 pages')));
  assert.equal(ranked[1].score, 1);
});

test('other live requirements in the package count up to 3, and dismissed ones do not', () => {
  const blueprint = {
    requirements: [
      req('R-1', 'integrations', 'A'),
      req('R-2', 'integrations', 'B'),
      req('R-3', 'integrations', 'C'),
      req('R-4', 'integrations', 'D'),
      req('R-5', 'integrations', 'E'),
      req('R-6', 'integrations', 'F', 'accelerated', 'dismissed')
    ],
    questions: [{ id: 'Q1', requirementId: 'R-1', text: 'Which systems?' }]
  };
  assert.equal(rankQuestions(blueprint, undefined, workPackages).ranked[0].score, 4);
});

test('a question about a dismissed requirement is left out and counted', () => {
  const blueprint = {
    requirements: [req('R-1', 'integrations', 'A', 'question', 'dismissed')],
    questions: [{ id: 'Q1', requirementId: 'R-1', text: 'Which?' }, { id: 'Q2', requirementId: 'R-9', text: 'Unlinked?' }, { id: 'Q3', requirementId: 'R-1' }]
  };
  const result = rankQuestions(blueprint, undefined, workPackages);
  assert.deepEqual(result.ranked.map((item) => item.id), ['Q2']);
  assert.equal(result.skipped.questionsOnDismissed, 1);
  assert.equal(result.skipped.questionsWithoutText, 1);
  assert.equal(result.ranked[0].workPackageId, undefined);
});

test('an estimate adds points by the share of hours its package carries, and no hours are written', () => {
  const blueprint = {
    requirements: [req('R-1', 'content-migration', 'Migrate pages'), req('R-2', 'content-model', 'Model content'), req('R-3', 'component-build', 'Build components')],
    questions: [
      { id: 'Q1', requirementId: 'R-1', text: 'Which pages?' },
      { id: 'Q2', requirementId: 'R-2', text: 'Which types?' },
      { id: 'Q3', requirementId: 'R-3', text: 'Which blocks?' }
    ],
    estimate: {
      packages: [
        { workPackageId: 'content-migration', hours: 700 },
        { workPackageId: 'content-model', hours: 200 },
        { workPackageId: 'component-build', hours: 100 }
      ]
    }
  };
  const result = rankQuestions(blueprint, undefined, workPackages);
  assert.deepEqual(result.ranked.map((item) => [item.id, item.score]), [['Q1', 4], ['Q2', 3], ['Q3', 3]]);
  assert.ok(result.ranked[0].reasons.includes('content-migration carries 70% of the estimated hours'));
  assert.equal(result.input.estimate, true);
  assert.doesNotMatch(JSON.stringify(result.ranked), /"hours"/);
});

test('an unknown that no question covers is ranked, and a gap-sweep unknown is medium at least', () => {
  const blueprint = { requirements: [req('R-1', 'integrations', 'Feeds')], questions: [{ id: 'Q1', requirementId: 'R-1', text: 'Which feeds?' }] };
  const context = {
    meta: { schemaVersion: '2', producedBy: 'skill' },
    deliveryUnknowns: [
      { id: 'DU-001', statement: 'Covered by a question.', refs: ['Q1'], review: { status: 'pending' } },
      { id: 'DU-002', statement: 'No requirement covers QA.', source: 'Gap sweep checklist qa-automation', review: { status: 'pending' } },
      { id: 'DU-003', statement: 'Dismissed one.', review: { status: 'dismissed' } },
      { id: 'DU-004', statement: 'Hosting region unclear.', refs: ['R-1'], review: { status: 'pending' } }
    ]
  };
  const result = rankQuestions(blueprint, context, workPackages);
  assert.deepEqual(result.ranked.map((item) => item.id), ['DU-002', 'Q1', 'DU-004']);
  assert.equal(result.ranked[0].tier, 'medium');
  assert.equal(result.ranked[0].workPackageId, 'qa-automation');
  assert.equal(result.ranked[2].workPackageId, 'integrations');
  assert.equal(result.skipped.unknownsDismissed, 1);
  assert.equal(result.skipped.unknownsCoveredByQuestion, 1);
});

test('ties keep the Blueprint order', () => {
  const blueprint = {
    requirements: [req('R-1', 'qa-automation', 'A'), req('R-2', 'environments-devops', 'B')],
    questions: [{ id: 'Q2', requirementId: 'R-2', text: 'Second?' }, { id: 'Q1', requirementId: 'R-1', text: 'First?' }]
  };
  assert.deepEqual(rankQuestions(blueprint, undefined, workPackages).ranked.map((item) => item.id), ['Q2', 'Q1']);
});

test('the markdown groups by tier, keeps the question as written, and says where it bites', () => {
  const blueprint = {
    requirements: [req('R-1', 'localization', 'Locales', 'conflict')],
    questions: [{ id: 'Q1', requirementId: 'R-1', text: 'Which is the launch scope?' }]
  };
  const text = formatMarkdown(rankQuestions(blueprint, undefined, workPackages));
  assert.match(text, /### Ask first/);
  assert.match(text, /1\. Which is the launch scope\?/);
  assert.match(text, /Q1 \[high\]: localization Localization; the sources disagree/);
  // Nothing about how the team ranked it sits in the part that goes to the client.
  const clientPart = text.split('## Why this order')[0];
  assert.doesNotMatch(clientPart, /disagree|WP-\d|Q1|%|hours/);
  assert.equal(formatMarkdown({ ranked: [] }).trim().endsWith('No open questions.'), true);
});

function runCli(args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

test('the CLI ranks the synthetic sample and prints the list as markdown', () => {
  const blueprint = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json');
  const context = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Context.json');
  const json = runCli([blueprint, '--context', context]);
  assert.equal(json.status, 0, json.stderr);
  const result = JSON.parse(json.stdout);
  assert.deepEqual(result.ranked.map((item) => item.id).slice(0, 3), ['Q2', 'Q1', 'Q3']);
  const markdown = runCli([blueprint, '--context', context, '--markdown']);
  assert.equal(markdown.status, 0, markdown.stderr);
  assert.match(markdown.stdout, /## Client clarification list/);
});

test('the CLI exits 1 for an invalid context or a catalog with no table, and 2 for bad usage', () => {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'rank-'));
  const blueprint = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json');
  const context = path.join(folder, 'context.json');
  fs.writeFileSync(context, JSON.stringify({ deliveryUnknowns: 'no' }));
  const bad = runCli([blueprint, '--context', context]);
  assert.equal(bad.status, 1);
  assert.match(bad.stderr, /\(context\)/);
  const catalog = path.join(folder, 'catalog.md');
  fs.writeFileSync(catalog, '# nothing here');
  const empty = runCli([blueprint, '--estimating', catalog]);
  assert.equal(empty.status, 1);
  assert.match(empty.stderr, /no Activities table/);
  assert.equal(runCli([]).status, 2);
  assert.equal(runCli([blueprint, '--bogus']).status, 2);
  assert.equal(runCli([blueprint, '--context']).status, 2);
  const notBlueprint = path.join(folder, 'b.json');
  fs.writeFileSync(notBlueprint, '{}');
  assert.equal(runCli([notBlueprint]).status, 1);
});

test('a gap bonus is dropped once a live requirement sits in the package', () => {
  const unknown = { id: 'DU-001', statement: 'Is search in scope?', source: 'Gap sweep checklist localization', review: { status: 'pending' } };
  const withGap = rankQuestions({ requirements: [], questions: [] }, { deliveryUnknowns: [unknown] }, workPackages);
  assert.ok(withGap.ranked[0].reasons.some((reason) => /nothing sizes localization/.test(reason)));
  const filled = rankQuestions({ requirements: [req('R-1', 'localization', 'Four locales')], questions: [] }, { deliveryUnknowns: [unknown] }, workPackages);
  assert.equal(filled.ranked[0].reasons.some((reason) => /nothing sizes/.test(reason)), false);
});

test('second opinion unknowns stay out of the client list and show in the team part', () => {
  const context = {
    deliveryUnknowns: [
      { id: 'DU-001', statement: 'The two reads differ on integrations: 4 against 3.', source: 'Second opinion integrations', review: { status: 'pending' } },
      { id: 'DU-002', statement: 'Which systems are in scope?', source: 'Gap sweep checklist integrations', review: { status: 'pending' } }
    ]
  };
  const result = rankQuestions({ requirements: [], questions: [] }, context, workPackages);
  assert.deepEqual(result.ranked.map((item) => [item.id, item.audience]).sort(), [['DU-001', 'team'], ['DU-002', 'client']]);
  const [client, team] = formatMarkdown(result).split('## Why this order');
  assert.match(client, /Which systems are in scope\?/);
  assert.doesNotMatch(client, /two reads/);
  assert.match(team, /two reads/);
});

test('parseActivities warns about an activity listed twice and keeps the first row', () => {
  const warnings = [];
  const row = (name, unit) => `| \`discovery-audit\` | ${name} | Discover | per-unit | ${unit} | Driver | us | accelerated | — |`;
  const catalog = `${row('One', 'template')}\n${row('Again', 'page')}\n`;
  const parsed = parseActivities(catalog, warnings);
  assert.equal(parsed.get('discovery-audit').name, 'One');
  assert.equal(warnings.length, 1);
});

test('in an estimated plan the workstream volume, not the first number of the statement, says what the answer changes', () => {
  const workstream = (id, volume, volumeBasis) => ({ id, kind: 'delivery', volume, volumeBasis, traditionalHours: 100 });
  const blueprint = {
    requirements: [req('R-1', 'content-migration', 'Migrate 6,400 pages'), req('R-2', 'localization', 'Launch in the EU'), req('R-3', 'content-model', 'Model the content')],
    questions: [
      { id: 'Q1', requirementId: 'R-1', text: 'Who signs off the clean-up?' },
      { id: 'Q2', requirementId: 'R-2', text: 'Who owns translation?' },
      { id: 'Q3', requirementId: 'R-3', text: 'Who owns the models?' }
    ],
    workstreams: [workstream('content-migration', 6400, 'document'), workstream('localization', 1, 'placeholder'), { id: 'project-management', kind: 'overhead', volume: 1, volumeBasis: 'placeholder', traditionalHours: 100 }]
  };
  const byId = Object.fromEntries(rankQuestions(blueprint, undefined, workPackages).ranked.map((item) => [item.id, item]));
  assert.ok(byId.Q1.reasons.includes('the volume for content-migration (6400 pages) comes from the documents; the answer can change it'));
  assert.ok(byId.Q2.reasons.includes('localization is sized on an assumed 1 locale; the answer replaces it'));
  assert.ok(!byId.Q1.reasons.some((reason) => /sizes it today/.test(reason)));
  assert.ok(!byId.Q3.reasons.some((reason) => /volume|assumed/.test(reason)), 'a package with no workstream row gets neither reason');
  assert.ok(byId.Q1.reasons.some((reason) => /carries 33% of the estimated hours/.test(reason)), 'the share comes from the workstream hours');
});
