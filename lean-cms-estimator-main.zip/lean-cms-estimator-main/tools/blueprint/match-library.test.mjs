import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { loadSeed, SEED_DIR, SHEETS } from '../factors/seed.mjs';
import {
  collectWarnings,
  containsSequence,
  DEFAULT_MAX,
  LIST_COLUMNS,
  matchLibrary,
  resolvePlatform,
  tokenize
} from './match-library.mjs';
import { validateContextValue } from './validate-context.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'match-library.mjs');
const scratch = mkdtempSync(join(tmpdir(), 'match-lib-'));
const USAGE =
  'Usage: node tools/blueprint/match-library.mjs <path-to-blueprint.json> [--platform <id>] [--max <n>] ' +
  '[--existing <path-to-context.json>] [--suppress <path-to-suppress.json>] [--seed-dir <dir>]';
const SAMPLE_BLUEPRINT = 'samples/offline/Synthetic_AEM_Blueprint.json';
const SAMPLE_CONTEXT = 'samples/offline/Synthetic_AEM_Context.json';

after(() => rmSync(scratch, { recursive: true, force: true }));

function run(args) {
  return spawnSync(process.execPath, [script, ...args], { cwd: root, encoding: 'utf8' });
}

function runJson(args) {
  const result = run(args);
  assert.equal(result.status, 0, result.stderr);
  return JSON.parse(result.stdout);
}

function writeJson(name, value) {
  const file = join(scratch, name);
  writeFileSync(file, JSON.stringify(value));
  return file;
}

function readJson(file) {
  return JSON.parse(readFileSync(join(root, file), 'utf8'));
}

// In-memory loadSeed-shaped sheets, built from the real sheet definitions so a header rename shows up here.
function sheetFor(name, rows) {
  const definition = SHEETS.find((sheet) => sheet.name === name);
  return { name, headers: definition.headers, file: definition.file, rows };
}

const ASSUMPTION = 'Assumption library';
const DEPENDENCY = 'Dependency library';
const RISK = 'Risk library';

// [id, platform, hints, statement, category, confidence, if it fails]
function asm(id, platform, hints, confidence = 'medium') {
  return [id, platform, hints, `Statement ${id}`, 'delivery', confidence, `Fails ${id}`];
}

// [id, platform, hints, statement, owner, needed, impact if missing, priority, required week]
function dep(id, platform, hints, priority = 'medium', week = '') {
  return [id, platform, hints, `Statement ${id}`, 'Owner', 'Needed', 'Impact', priority, week];
}

// [id, platform, hints, statement, impact, likelihood, severity, mitigation]
function risk(id, platform, hints, likelihood = 'medium', severity = 'medium') {
  return [id, platform, hints, `Statement ${id}`, 'Impact', likelihood, severity, 'Mitigation'];
}

function sheetsOf({ assumptions = [], dependencies = [], risks = [] }) {
  return [sheetFor(ASSUMPTION, assumptions), sheetFor(DEPENDENCY, dependencies), sheetFor(RISK, risks)];
}

function blueprintOf(statements, extra = {}) {
  return {
    platform: { id: 'aem' },
    requirements: statements.map((statement, index) => ({
      id: `R-${String(index + 1).padStart(3, '0')}`,
      statement,
      review: { status: 'pending' }
    })),
    questions: [],
    ...extra
  };
}

function idsOf(list) {
  return list.entries.map((entry) => entry.libraryId);
}

const LIBRARY_LISTS = ['assumptions', 'dependencies', 'deliveryRisks'];

const INPUT_ZERO = {
  requirements: 0,
  requirementsSkippedDismissed: 0,
  requirementsSkippedMalformed: 0,
  questions: 0,
  questionsSkippedDismissed: 0,
  questionsSkippedMalformed: 0,
  questionsUnlinked: 0,
  unitsWithoutId: 0
};

function allEntries(result) {
  return [].concat(...LIBRARY_LISTS.map((key) => result[key].entries));
}

describe('tokenize and containsSequence', () => {
  it('lowercases, splits on punctuation and keeps short and stop-list words', () => {
    assert.deepEqual(tokenize('The AEM cloud, SSO & DAM'), ['the', 'aem', 'cloud', 'sso', 'dam']);
  });

  it('applies the light stemming', () => {
    assert.deepEqual(tokenize('Environments'), ['environment']);
    assert.deepEqual(tokenize('policies'), ['policy']);
    assert.deepEqual(tokenize('listing'), ['list']);
    assert.deepEqual(tokenize('migrated'), ['migrat']);
    assert.deepEqual(tokenize('access'), ['access']);
  });

  it('returns no tokens for blank or non-text input', () => {
    assert.deepEqual(tokenize('  -- '), []);
    assert.deepEqual(tokenize(undefined), []);
  });

  it('finds a contiguous run in order and nothing else', () => {
    const tokens = tokenize('use cloud manager for the pipeline');
    assert.equal(containsSequence(tokens, tokenize('cloud manager')), true);
    assert.equal(containsSequence(tokens, tokenize('manager cloud')), false);
    assert.equal(containsSequence(tokens, tokenize('cloud pipeline')), false);
    assert.equal(containsSequence(tokens, []), false);
    assert.equal(containsSequence(tokenize('cloud'), tokenize('cloud manager')), false);
  });
});

describe('resolvePlatform', () => {
  it('uses a Blueprint platform id that is a library platform, trimmed and lowercased', () => {
    assert.deepEqual(resolvePlatform({ platform: { id: ' AEM ' } }), {
      used: 'aem',
      source: 'blueprint',
      requested: 'AEM'
    });
  });

  it('falls back to all for an id the libraries do not know', () => {
    assert.deepEqual(resolvePlatform({ platform: { id: 'sitecore-xm-cloud' } }), {
      used: 'all',
      source: 'default',
      requested: 'sitecore-xm-cloud'
    });
  });

  it('falls back to all and reports no request when the platform is absent or blank', () => {
    for (const blueprint of [{}, { platform: {} }, { platform: { id: '  ' } }, { platform: { id: 7 } }, null]) {
      assert.deepEqual(resolvePlatform(blueprint), { used: 'all', source: 'default', requested: null });
    }
  });

  it('lets the override win over the Blueprint', () => {
    assert.deepEqual(resolvePlatform({ platform: { id: 'aem' } }, 'aem-eds'), {
      used: 'aem-eds',
      source: 'flag',
      requested: 'aem'
    });
  });

  it('rejects an override that is not a library platform', () => {
    assert.throws(() => resolvePlatform({}, 'aemm'), /Unknown platform "aemm"/);
  });
});

describe('matchLibrary candidates', () => {
  it('lists entries for all and the platform, and drops other platforms', () => {
    const sheets = sheetsOf({
      assumptions: [
        asm('asm-all', 'all', 'alpha'),
        asm('asm-aem', 'aem', 'alpha'),
        asm('asm-eds', 'aem-eds', 'alpha'),
        asm('asm-aep', 'aep', 'alpha')
      ]
    });
    const result = matchLibrary({ blueprint: blueprintOf(['Alpha work']), sheets });
    assert.deepEqual(idsOf(result.assumptions), ['asm-aem', 'asm-all']);
    assert.equal(result.assumptions.excludedByPlatform, 2);
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Alpha work']), sheets, platform: 'aem-eds' }).assumptions), [
      'asm-all',
      'asm-eds'
    ]);
  });

  it('lists only all entries when the Blueprint platform is not a library platform, even if text matches', () => {
    const sheets = sheetsOf({
      assumptions: [asm('asm-all', 'all', 'alpha'), asm('asm-aem', 'aem', 'alpha'), asm('asm-aep', 'aep', 'alpha')]
    });
    const blueprint = blueprintOf(['Alpha work'], { platform: { id: 'sitecore-xm-cloud' } });
    const result = matchLibrary({ blueprint, sheets });
    assert.deepEqual(result.platform, { used: 'all', source: 'default', requested: 'sitecore-xm-cloud' });
    assert.deepEqual(idsOf(result.assumptions), ['asm-all']);
    assert.equal(result.assumptions.excludedByPlatform, 2);
  });

  it('keeps an entry with no matching hint out, unless it is always-propose', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-hit', 'all', 'alpha'), asm('asm-miss', 'all', 'beta'), asm('asm-always', 'all', '')] });
    const result = matchLibrary({ blueprint: blueprintOf(['Alpha work']), sheets });
    assert.deepEqual(idsOf(result.assumptions), ['asm-hit', 'asm-always']);
    const always = result.assumptions.entries.find((entry) => entry.libraryId === 'asm-always');
    assert.equal(always.alwaysPropose, true);
    assert.deepEqual(always.matchedHints, []);
  });

  it('lists only always-propose entries for empty requirements and questions', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-hit', 'all', 'alpha'), asm('asm-always', 'all', '')] });
    const result = matchLibrary({ blueprint: { requirements: [], questions: [] }, sheets });
    assert.deepEqual(idsOf(result.assumptions), ['asm-always']);
    assert.deepEqual(result.input, INPUT_ZERO);
  });

  it('shows the matching hints as authored and the requirement and question ids in Blueprint order', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-idp', 'all', 'SSO; Identity Provider; nothing here')] });
    const blueprint = blueprintOf(['Sign in with SSO', 'Nothing relevant', 'The identity provider stays'], {
      questions: [
        { id: 'Q1', requirementId: 'R-003', text: 'Does the identity provider change?' },
        { id: 'Q2', requirementId: 'R-001', text: 'Is SSO needed for authors?' }
      ]
    });
    const [entry] = matchLibrary({ blueprint, sheets }).assumptions.entries;
    assert.deepEqual(entry.matchedHints, ['SSO', 'Identity Provider']);
    assert.deepEqual(entry.requirementIds, ['R-001', 'R-003']);
    assert.deepEqual(entry.questionIds, ['Q1', 'Q2']);
  });

  it('matches whole tokens only', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-dam', 'all', 'dam'), asm('asm-api', 'all', 'api')] });
    const result = matchLibrary({ blueprint: blueprintOf(['Fix the damage', 'Raise capital']), sheets });
    assert.deepEqual(idsOf(result.assumptions), []);
  });

  it('needs the tokens adjacent and in order, but ignores punctuation and case', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-cm', 'all', 'cloud manager')] });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Use the Cloud, Manager.']), sheets }).assumptions), ['asm-cm']);
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Manager of the cloud']), sheets }).assumptions), []);
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Cloud and manager']), sheets }).assumptions), []);
  });

  it('matches a plural hint against a singular text', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-env', 'all', 'environments')] });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['One environment per stage']), sheets }).assumptions), ['asm-env']);
  });

  it('ignores a hint with no tokens', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-odd', 'all', '--; alpha')] });
    const [entry] = matchLibrary({ blueprint: blueprintOf(['Alpha']), sheets }).assumptions.entries;
    assert.deepEqual(entry.matchedHints, ['alpha']);
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Beta']), sheets }).assumptions), []);
  });

  it('does not treat a platform-specific entry with blank hints as always-propose', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-odd', 'aem', '')] });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Alpha']), sheets }).assumptions), []);
  });
});

describe('matchLibrary text rules', () => {
  const sheets = sheetsOf({ assumptions: [asm('asm-alpha', 'all', 'alpha')] });

  it('skips a dismissed requirement and a question linked to one', () => {
    const blueprint = {
      requirements: [
        { id: 'R-001', statement: 'Alpha work', review: { status: 'dismissed' } },
        { id: 'R-002', statement: 'Beta work', review: { status: 'pending' } }
      ],
      questions: [
        { id: 'Q1', requirementId: 'R-001', text: 'Is alpha needed?' },
        { id: 'Q2', requirementId: 'R-002', text: 'Is gamma needed?' }
      ]
    };
    const result = matchLibrary({ blueprint, sheets });
    assert.deepEqual(idsOf(result.assumptions), []);
    assert.deepEqual(result.input, {
      ...INPUT_ZERO,
      requirements: 1,
      requirementsSkippedDismissed: 1,
      questions: 1,
      questionsSkippedDismissed: 1
    });
  });

  it('keeps a question whose requirement is not dismissed', () => {
    const blueprint = {
      requirements: [{ id: 'R-001', statement: 'Beta work', review: { status: 'accepted' } }],
      questions: [{ id: 'Q1', requirementId: 'R-001', text: 'Is alpha needed?' }]
    };
    const [entry] = matchLibrary({ blueprint, sheets }).assumptions.entries;
    assert.deepEqual(entry.questionIds, ['Q1']);
  });

  it('never reads source passages', () => {
    const blueprint = blueprintOf(['Beta work']);
    blueprint.requirements[0].sources = [{ passage: 'Alpha appears only here' }];
    assert.deepEqual(idsOf(matchLibrary({ blueprint, sheets }).assumptions), []);
  });

  it('does not let a match span two text units', () => {
    const multiword = sheetsOf({ assumptions: [asm('asm-cm', 'all', 'cloud manager')] });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: blueprintOf(['Use the cloud', 'manager approves']), sheets: multiword }).assumptions), []);
  });

  it('counts requirements and questions that are not objects or have no text, and does not match them', () => {
    const blueprint = {
      requirements: ['text', null, { id: 'R-001' }, { id: 'R-002', statement: 'Alpha' }],
      questions: [7, { id: 'Q1', requirementId: 'R-002' }]
    };
    const result = matchLibrary({ blueprint, sheets });
    assert.deepEqual(idsOf(result.assumptions), ['asm-alpha']);
    assert.equal(result.input.requirements, 1);
    assert.equal(result.input.requirementsSkippedMalformed, 3);
    assert.equal(result.input.questions, 0);
    assert.equal(result.input.questionsSkippedMalformed, 2);
  });

  it('keeps a question with no requirement link but counts it as unlinked', () => {
    const blueprint = {
      requirements: [{ id: 'R-001', statement: 'Beta' }],
      questions: [
        { id: 'Q1', requirementId: 'R-001', text: 'Linked?' },
        { id: 'Q2', requirementId: 'R-404', text: 'Alpha, but linked to nothing?' },
        { id: 'Q3', text: 'No link at all?' }
      ]
    };
    const result = matchLibrary({ blueprint, sheets });
    assert.deepEqual(result.assumptions.entries[0].questionIds, ['Q2']);
    assert.equal(result.input.questions, 3);
    assert.equal(result.input.questionsUnlinked, 2);
  });

  it('matches text units that have no id, reports no ids for them, and counts them', () => {
    const blueprint = { requirements: [{ id: 7, statement: 'Alpha work' }], questions: [{ text: 'Alpha?' }] };
    const result = matchLibrary({ blueprint, sheets });
    const [entry] = result.assumptions.entries;
    assert.deepEqual(entry.matchedHints, ['alpha']);
    assert.deepEqual(entry.requirementIds, []);
    assert.deepEqual(entry.questionIds, []);
    assert.equal(result.input.unitsWithoutId, 2);
  });

  it('lists a matching id once and in Blueprint order, whichever hint comes first', () => {
    const multi = sheetsOf({ assumptions: [asm('asm-multi', 'all', 'beta; alpha')] });
    const blueprint = blueprintOf(['Alpha only', 'Alpha and beta together', 'Beta only']);
    const [entry] = matchLibrary({ blueprint, sheets: multi }).assumptions.entries;
    assert.deepEqual(entry.matchedHints, ['beta', 'alpha']);
    assert.deepEqual(entry.requirementIds, ['R-001', 'R-002', 'R-003']);
  });
});

describe('matchLibrary ordering, cap and existing entries', () => {
  const text = blueprintOf(['Alpha and beta work']);

  it('orders dependencies by priority, then matched hints, then library id', () => {
    const sheets = sheetsOf({
      dependencies: [
        dep('dep-d-low', 'all', 'alpha', 'low'),
        dep('dep-b-medium', 'all', 'alpha', 'medium'),
        dep('dep-c-high-two', 'all', 'alpha; beta', 'high'),
        dep('dep-a-high-one', 'all', 'alpha', 'high'),
        dep('dep-e-high-one', 'all', 'beta', 'high')
      ]
    });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: text, sheets }).dependencies), [
      'dep-c-high-two',
      'dep-a-high-one',
      'dep-e-high-one',
      'dep-b-medium',
      'dep-d-low'
    ]);
  });

  it('orders risks by the level band, not the raw score', () => {
    const sheets = sheetsOf({
      risks: [
        risk('risk-1-low', 'all', 'alpha', 'low', 'low'),
        risk('risk-2-low-two', 'all', 'alpha', 'low', 'medium'),
        risk('risk-3-medium', 'all', 'alpha', 'medium', 'medium'),
        risk('risk-4-high-six', 'all', 'alpha', 'medium', 'high'),
        risk('risk-5-high-nine', 'all', 'alpha', 'high', 'high'),
        risk('risk-6-medium-three', 'all', 'alpha', 'low', 'high')
      ]
    });
    // Six and nine share the HIGH band, so the id decides. Three and four share MEDIUM, one and two LOW.
    assert.deepEqual(idsOf(matchLibrary({ blueprint: text, sheets }).deliveryRisks), [
      'risk-4-high-six',
      'risk-5-high-nine',
      'risk-3-medium',
      'risk-6-medium-three',
      'risk-1-low',
      'risk-2-low-two'
    ]);
  });

  it('orders assumptions with the least certain first', () => {
    const sheets = sheetsOf({
      assumptions: [
        asm('asm-a-high', 'all', 'alpha', 'high'),
        asm('asm-b-low', 'all', 'alpha', 'low'),
        asm('asm-c-medium', 'all', 'alpha', 'medium'),
        asm('asm-d-low-two', 'all', 'alpha; beta', 'low')
      ]
    });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: text, sheets }).assumptions), [
      'asm-d-low-two',
      'asm-b-low',
      'asm-c-medium',
      'asm-a-high'
    ]);
  });

  it('lets an always-propose entry compete on the same key', () => {
    const sheets = sheetsOf({
      dependencies: [dep('dep-always', 'all', '', 'high'), dep('dep-hit', 'all', 'alpha', 'high')]
    });
    assert.deepEqual(idsOf(matchLibrary({ blueprint: text, sheets }).dependencies), ['dep-hit', 'dep-always']);
  });

  it('breaks ties by library id, whatever order the rows come in', () => {
    // Every row ties on rank and matched hints, so only the id can order them. Rows are fed in reverse.
    const sheets = sheetsOf({
      assumptions: [asm('asm-c', 'all', 'alpha'), asm('asm-a', 'all', 'alpha'), asm('asm-b', 'all', 'alpha')],
      dependencies: [dep('dep-c', 'all', 'alpha'), dep('dep-a', 'all', 'alpha'), dep('dep-b', 'all', 'alpha')],
      risks: [risk('risk-c', 'all', 'alpha'), risk('risk-a', 'all', 'alpha'), risk('risk-b', 'all', 'alpha')]
    });
    const result = matchLibrary({ blueprint: text, sheets });
    assert.deepEqual(idsOf(result.assumptions), ['asm-a', 'asm-b', 'asm-c']);
    assert.deepEqual(idsOf(result.dependencies), ['dep-a', 'dep-b', 'dep-c']);
    assert.deepEqual(idsOf(result.deliveryRisks), ['risk-a', 'risk-b', 'risk-c']);
  });

  it('gives the same output when the library rows are reversed', () => {
    const seed = loadSeed();
    const reversed = seed.map((sheet) => ({ ...sheet, rows: sheet.rows.slice().reverse() }));
    const blueprint = readJson(SAMPLE_BLUEPRINT);
    assert.equal(
      JSON.stringify(matchLibrary({ blueprint, sheets: reversed })),
      JSON.stringify(matchLibrary({ blueprint, sheets: seed }))
    );
  });

  it('caps each list and reports what was cut', () => {
    const sheets = sheetsOf({
      dependencies: [
        dep('dep-a', 'all', 'alpha', 'high'),
        dep('dep-b', 'all', 'alpha', 'high'),
        dep('dep-c', 'all', 'alpha', 'low')
      ],
      assumptions: [asm('asm-a', 'all', 'alpha')]
    });
    const result = matchLibrary({ blueprint: text, sheets, max: 2 });
    assert.equal(result.max, 2);
    assert.deepEqual(idsOf(result.dependencies), ['dep-a', 'dep-b']);
    assert.equal(result.dependencies.candidates, 3);
    assert.equal(result.dependencies.dropped, 1);
    assert.equal(result.assumptions.dropped, 0);
  });

  it(`defaults the cap to ${DEFAULT_MAX} per list`, () => {
    const rows = [];
    for (let i = 0; i < DEFAULT_MAX + 3; i += 1) {
      rows.push(asm(`asm-${String(i).padStart(2, '0')}`, 'all', 'alpha'));
    }
    const result = matchLibrary({ blueprint: text, sheets: sheetsOf({ assumptions: rows }) });
    assert.equal(result.max, DEFAULT_MAX);
    assert.equal(result.assumptions.entries.length, DEFAULT_MAX);
    assert.equal(result.assumptions.dropped, 3);
  });

  it('skips existing library ids, counts them, and does not spend the cap on them', () => {
    const sheets = sheetsOf({
      assumptions: [asm('asm-a', 'all', 'alpha'), asm('asm-b', 'all', 'alpha'), asm('asm-c', 'all', 'alpha')]
    });
    const result = matchLibrary({ blueprint: text, sheets, max: 2, existingLibraryIds: ['asm-a'] });
    assert.deepEqual(idsOf(result.assumptions), ['asm-b', 'asm-c']);
    assert.equal(result.assumptions.skipped, 1);
    assert.equal(result.assumptions.candidates, 2);
    assert.equal(result.assumptions.dropped, 0);
  });

  it('skips existing ids in every list, whatever their case or padding', () => {
    const sheets = sheetsOf({
      assumptions: [asm('asm-a', 'all', 'alpha'), asm('asm-b', 'all', 'alpha')],
      dependencies: [dep('dep-a', 'all', 'alpha'), dep('dep-b', 'all', 'alpha')],
      risks: [risk('risk-a', 'all', 'alpha'), risk('risk-b', 'all', 'alpha')]
    });
    const result = matchLibrary({ blueprint: text, sheets, existingLibraryIds: [' ASM-A ', 'dep-a', 'Risk-A'] });
    assert.deepEqual(idsOf(result.assumptions), ['asm-b']);
    assert.deepEqual(idsOf(result.dependencies), ['dep-b']);
    assert.deepEqual(idsOf(result.deliveryRisks), ['risk-b']);
    for (const key of LIBRARY_LISTS) {
      assert.equal(result[key].skipped, 1, key);
    }
    assert.deepEqual(result.existingUnmatched, []);
  });

  it('does not count an existing id that is a library entry but not a candidate as skipped', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-hit', 'all', 'alpha'), asm('asm-miss', 'all', 'gamma')] });
    const result = matchLibrary({ blueprint: text, sheets, existingLibraryIds: ['asm-miss'] });
    assert.deepEqual(idsOf(result.assumptions), ['asm-hit']);
    assert.equal(result.assumptions.skipped, 0);
    assert.deepEqual(result.existingUnmatched, []);
  });

  it('lists existing ids that match no library entry', () => {
    const sheets = sheetsOf({ assumptions: [asm('asm-a', 'all', 'alpha')] });
    const result = matchLibrary({ blueprint: text, sheets, existingLibraryIds: ['asm-gone', 'asm-a', 'ASM-Typo'] });
    assert.deepEqual(result.existingUnmatched, ['asm-gone', 'asm-typo']);
  });

  it('is byte-identical across runs', () => {
    const seed = loadSeed();
    const blueprint = readJson(SAMPLE_BLUEPRINT);
    const first = JSON.stringify(matchLibrary({ blueprint, sheets: seed }));
    const second = JSON.stringify(matchLibrary({ blueprint, sheets: seed }));
    assert.equal(first, second);
  });

  it('fails clearly when a library sheet is missing', () => {
    assert.throws(() => matchLibrary({ blueprint: text, sheets: [] }), /missing the "Assumption library" sheet/);
  });
});

describe('matchLibrary items', () => {
  const blueprint = blueprintOf(['Alpha work']);

  it('maps library columns to sidecar field names, with a pending review and nothing else', () => {
    const sheets = sheetsOf({
      assumptions: [asm('asm-a', 'all', 'alpha')],
      dependencies: [dep('dep-a', 'all', 'alpha', 'high', '4')],
      risks: [risk('risk-a', 'all', 'alpha', 'low', 'high')]
    });
    const result = matchLibrary({ blueprint, sheets });
    assert.deepEqual(result.assumptions.entries[0].item, {
      libraryId: 'asm-a',
      statement: 'Statement asm-a',
      category: 'delivery',
      confidence: 'medium',
      ifFails: 'Fails asm-a',
      review: { status: 'pending' }
    });
    assert.deepEqual(result.dependencies.entries[0].item, {
      libraryId: 'dep-a',
      statement: 'Statement dep-a',
      owner: 'Owner',
      needed: 'Needed',
      impactIfMissing: 'Impact',
      priority: 'high',
      requiredWeek: 4,
      review: { status: 'pending' }
    });
    assert.deepEqual(result.deliveryRisks.entries[0].item, {
      libraryId: 'risk-a',
      statement: 'Statement risk-a',
      impact: 'Impact',
      likelihood: 'low',
      severity: 'high',
      mitigation: 'Mitigation',
      review: { status: 'pending' }
    });
  });

  it('omits requiredWeek when the library week is blank, never writing an empty value', () => {
    const sheets = sheetsOf({ dependencies: [dep('dep-a', 'all', 'alpha', 'high', ''), dep('dep-b', 'all', 'alpha', 'low', '  ')] });
    for (const entry of matchLibrary({ blueprint, sheets }).dependencies.entries) {
      assert.equal('requiredWeek' in entry.item, false);
    }
  });

  it('writes item keys in a fixed order', () => {
    const sheets = sheetsOf({
      assumptions: [asm('asm-a', 'all', 'alpha')],
      dependencies: [dep('dep-a', 'all', 'alpha', 'high', '4')],
      risks: [risk('risk-a', 'all', 'alpha')]
    });
    const result = matchLibrary({ blueprint, sheets });
    assert.deepEqual(Object.keys(result.assumptions.entries[0].item), [
      'libraryId', 'statement', 'category', 'confidence', 'ifFails', 'review'
    ]);
    assert.deepEqual(Object.keys(result.dependencies.entries[0].item), [
      'libraryId', 'statement', 'owner', 'needed', 'impactIfMissing', 'priority', 'requiredWeek', 'review'
    ]);
    assert.deepEqual(Object.keys(result.deliveryRisks.entries[0].item), [
      'libraryId', 'statement', 'impact', 'likelihood', 'severity', 'mitigation', 'review'
    ]);
  });

  it('never emits id, source, refs, level or score on an item', () => {
    const entries = allEntries(matchLibrary({ blueprint: readJson(SAMPLE_BLUEPRINT), sheets: loadSeed(), max: 100 }));
    assert.ok(entries.length > 0);
    for (const entry of entries) {
      for (const key of ['id', 'source', 'refs', 'level', 'score']) {
        assert.equal(key in entry.item, false, `${entry.libraryId} has ${key}`);
      }
    }
  });

  it('produces items the context validator accepts once ids are added', () => {
    const result = matchLibrary({ blueprint: readJson(SAMPLE_BLUEPRINT), sheets: loadSeed(), max: 100 });
    const withIds = (list, prefix) =>
      list.entries.map((entry, index) => ({ id: `${prefix}-${String(index + 1).padStart(3, '0')}`, ...entry.item }));
    const context = {
      assumptions: withIds(result.assumptions, 'AS'),
      dependencies: withIds(result.dependencies, 'DP'),
      deliveryRisks: withIds(result.deliveryRisks, 'DR'),
      meta: { schemaVersion: '2', producedBy: 'skill' }
    };
    assert.ok(context.assumptions.length > 0 && context.dependencies.length > 0 && context.deliveryRisks.length > 0);
    assert.deepEqual(validateContextValue(context), []);
  });

  it('reads only columns that exist on the workbook sheets', () => {
    for (const { sheet, headers } of LIST_COLUMNS) {
      const definition = SHEETS.find((candidate) => candidate.name === sheet);
      assert.ok(definition, sheet);
      for (const header of headers) {
        assert.notEqual(definition.headers.indexOf(header), -1, `${sheet}: no "${header}" column`);
      }
    }
  });
});

describe('match-library on the committed seed', () => {
  it('carries the default required week with the library id, as the seed has it', () => {
    const seed = loadSeed();
    const weeks = new Map(
      seed
        .find((sheet) => sheet.name === DEPENDENCY)
        .rows.map((row) => [row[0], row[8].trim()])
    );
    const result = matchLibrary({ blueprint: readJson(SAMPLE_BLUEPRINT), sheets: seed, max: 100 });
    assert.ok(result.dependencies.entries.length > 0);
    for (const entry of result.dependencies.entries) {
      const week = weeks.get(entry.libraryId);
      assert.equal(entry.item.libraryId, entry.libraryId);
      if (week === '') {
        assert.equal('requiredWeek' in entry.item, false);
      } else {
        assert.equal(entry.item.requiredWeek, Number(week));
      }
    }
  });

  it('proposes only the always-propose entries for a platform the libraries do not know', () => {
    const seed = loadSeed();
    const blueprint = { platform: { id: 'sitecore-xm-cloud' }, requirements: [], questions: [] };
    const result = matchLibrary({ blueprint, sheets: seed, max: 100 });
    assert.equal(result.platform.used, 'all');
    for (const key of LIBRARY_LISTS) {
      assert.ok(result[key].entries.length > 0, key);
      assert.ok(result[key].entries.every((entry) => entry.alwaysPropose), key);
      assert.ok(result[key].excludedByPlatform > 0, key);
    }
  });
});

describe('collectWarnings', () => {
  const sheets = sheetsOf({ assumptions: [asm('asm-a', 'all', 'alpha')] });

  it('has nothing to say for a clean run', () => {
    assert.deepEqual(collectWarnings(matchLibrary({ blueprint: blueprintOf(['Alpha work']), sheets })), []);
  });

  it('names a Blueprint platform that fell back to all', () => {
    const blueprint = blueprintOf(['Alpha work'], { platform: { id: 'sitecore-xm-cloud' } });
    const warnings = collectWarnings(matchLibrary({ blueprint, sheets }));
    assert.equal(warnings.length, 1);
    assert.match(warnings[0], /"sitecore-xm-cloud" is not a library platform/);
  });

  it('is quiet when there is no platform at all, or --platform was given', () => {
    assert.deepEqual(collectWarnings(matchLibrary({ blueprint: { requirements: [], questions: [] }, sheets })), []);
    const flagged = blueprintOf(['Alpha work'], { platform: { id: 'sitecore-xm-cloud' } });
    assert.deepEqual(collectWarnings(matchLibrary({ blueprint: flagged, sheets, platform: 'aem' })), []);
  });

  it('reports malformed entries, entries without an id, unlinked questions and unmatched existing ids', () => {
    const blueprint = {
      requirements: [null, { id: 7, statement: 'Alpha' }],
      questions: [{ text: 'Alpha?' }, 3]
    };
    const warnings = collectWarnings(matchLibrary({ blueprint, sheets, existingLibraryIds: ['asm-gone'] }));
    assert.equal(warnings.length, 4);
    assert.match(warnings[0], /skipped 1 requirement\(s\) and 1 question\(s\)/);
    assert.match(warnings[1], /2 requirement\(s\) or question\(s\) have no id/);
    assert.match(warnings[2], /1 question\(s\) are not linked/);
    assert.match(warnings[3], /asm-gone/);
  });
});

describe('match-library CLI', () => {
  it('prints one JSON document for the synthetic project and is deterministic', () => {
    const first = run([SAMPLE_BLUEPRINT]);
    const second = run([SAMPLE_BLUEPRINT]);
    assert.equal(first.status, 0, first.stderr);
    assert.equal(first.stderr, '');
    assert.equal(first.stdout, second.stdout);
    assert.ok(first.stdout.endsWith('\n'));
    const result = JSON.parse(first.stdout);
    assert.deepEqual(result.platform, { used: 'aem', source: 'blueprint', requested: 'aem' });
    assert.equal(result.max, DEFAULT_MAX);
  });

  it('applies --max and --platform', () => {
    const result = runJson([SAMPLE_BLUEPRINT, '--max', '1', '--platform', 'all']);
    assert.equal(result.platform.source, 'flag');
    assert.equal(result.platform.used, 'all');
    assert.equal(result.max, 1);
    for (const key of LIBRARY_LISTS) {
      assert.equal(result[key].entries.length, 1, key);
      assert.equal(result[key].dropped, result[key].candidates - 1, key);
    }
  });

  it('skips the library entries already in a --existing sidecar, in every list', () => {
    const before = runJson([SAMPLE_BLUEPRINT, '--max', '100']);
    const after = runJson([SAMPLE_BLUEPRINT, '--max', '100', '--existing', SAMPLE_CONTEXT]);
    const sidecar = readJson(SAMPLE_CONTEXT);
    for (const key of LIBRARY_LISTS) {
      const used = sidecar[key].map((item) => item.libraryId).filter((id) => id !== undefined);
      assert.ok(used.length > 0, key);
      assert.equal(after[key].skipped, used.length, key);
      assert.equal(after[key].skipped + after[key].candidates, before[key].candidates, key);
      for (const id of used) {
        assert.notEqual(idsOf(before[key]).indexOf(id), -1, id);
        assert.equal(idsOf(after[key]).indexOf(id), -1, id);
      }
    }
  });

  it('skips existing ids whatever the item status, list, case or padding, and notes ids no library entry has', () => {
    const before = runJson([SAMPLE_BLUEPRINT, '--max', '100']);
    const [assumptionId, otherAssumptionId] = idsOf(before.assumptions);
    const [dependencyId] = idsOf(before.dependencies);
    const [riskId] = idsOf(before.deliveryRisks);
    const existing = writeJson('existing-all.json', {
      assumptions: [
        { id: 'AS-001', statement: 'One', libraryId: ` ${assumptionId.toUpperCase()} `, review: { status: 'dismissed' } },
        { id: 'AS-002', statement: 'Two', libraryId: '', review: { status: 'pending' } }
      ],
      deliveryUnknowns: [{ id: 'DU-001', statement: 'Three', libraryId: otherAssumptionId, review: { status: 'pending' } }],
      dependencies: [{ id: 'DP-001', statement: 'Four', libraryId: dependencyId, review: { status: 'accepted' } }],
      deliveryRisks: [{ id: 'DR-001', statement: 'Five', libraryId: riskId, review: { status: 'pending' } }],
      meta: { schemaVersion: '2' }
    });
    const result = run([SAMPLE_BLUEPRINT, '--max', '100', '--existing', existing]);
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stderr, '');
    const after = JSON.parse(result.stdout);
    assert.equal(idsOf(after.assumptions).indexOf(assumptionId), -1);
    assert.equal(idsOf(after.assumptions).indexOf(otherAssumptionId), -1);
    assert.equal(idsOf(after.dependencies).indexOf(dependencyId), -1);
    assert.equal(idsOf(after.deliveryRisks).indexOf(riskId), -1);
    assert.equal(after.assumptions.skipped, 2);
    assert.equal(after.dependencies.skipped, 1);
    assert.equal(after.deliveryRisks.skipped, 1);

    const stale = writeJson('existing-stale.json', {
      assumptions: [{ id: 'AS-001', statement: 'Gone', libraryId: 'asm-removed-from-library', review: { status: 'pending' } }],
      meta: { schemaVersion: '2' }
    });
    const warned = run([SAMPLE_BLUEPRINT, '--existing', stale]);
    assert.equal(warned.status, 0, warned.stderr);
    assert.match(warned.stderr, /^warning: --existing has library ids that match no library entry: asm-removed-from-library$/m);
    assert.deepEqual(JSON.parse(warned.stdout).existingUnmatched, ['asm-removed-from-library']);
  });

  it('warns on stderr, without changing stdout, for a platform the libraries do not know', () => {
    const blueprint = writeJson('sitecore.json', {
      platform: { id: 'sitecore-xm-cloud' },
      requirements: [{ id: 'R-001', statement: 'Build the site' }],
      questions: []
    });
    const result = run([blueprint]);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stderr, /^warning: Blueprint platform "sitecore-xm-cloud" is not a library platform/m);
    assert.equal(JSON.parse(result.stdout).platform.used, 'all');
  });

  it('warns on stderr about requirements and questions it could not use', () => {
    const blueprint = writeJson('rough.json', {
      requirements: [null, { id: 'R-001', statement: 'Hypercare cover' }],
      questions: [{ text: 'Is hypercare needed?' }]
    });
    const result = run([blueprint]);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stderr, /^warning: skipped 1 requirement\(s\) and 0 question\(s\) with no usable text$/m);
    assert.match(result.stderr, /^warning: 1 requirement\(s\) or question\(s\) have no id/m);
    assert.match(result.stderr, /^warning: 1 question\(s\) are not linked to a requirement/m);
  });

  it('exits 2 with the usage line for bad usage', () => {
    const cases = [
      [],
      ['--max', '3'],
      [SAMPLE_BLUEPRINT, '--bogus'],
      [SAMPLE_BLUEPRINT, '--format', 'text'],
      [SAMPLE_BLUEPRINT, 'second.json'],
      [SAMPLE_BLUEPRINT, '--max'],
      [SAMPLE_BLUEPRINT, '--max', '--platform'],
      [SAMPLE_BLUEPRINT, '--max', '3', '--max', '4'],
      [SAMPLE_BLUEPRINT, '--max', '0'],
      [SAMPLE_BLUEPRINT, '--max', '2.5'],
      [SAMPLE_BLUEPRINT, '--max', 'many'],
      [SAMPLE_BLUEPRINT, '--max', '08'],
      [SAMPLE_BLUEPRINT, '--max', '-1'],
      [SAMPLE_BLUEPRINT, '--max', '1e2'],
      [SAMPLE_BLUEPRINT, '--max', ' 3'],
      [SAMPLE_BLUEPRINT, '--max=3'],
      [SAMPLE_BLUEPRINT, '--platform', ''],
      [SAMPLE_BLUEPRINT, '--platform'],
      [SAMPLE_BLUEPRINT, '--platform', 'aem', '--platform', 'all'],
      [SAMPLE_BLUEPRINT, '--existing'],
      [SAMPLE_BLUEPRINT, '--existing', SAMPLE_CONTEXT, '--existing', SAMPLE_CONTEXT],
      [SAMPLE_BLUEPRINT, '--seed-dir'],
      [SAMPLE_BLUEPRINT, '--seed-dir', 'a', '--seed-dir', 'b']
    ];
    for (const args of cases) {
      const result = run(args);
      assert.equal(result.status, 2, args.join(' '));
      assert.equal(result.stdout, '');
      assert.equal(result.stderr.trim(), USAGE, args.join(' '));
    }
  });

  it('exits 2 and lists the valid platforms for an unknown --platform', () => {
    const result = run([SAMPLE_BLUEPRINT, '--platform', 'sitecore']);
    assert.equal(result.status, 2);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, /Unknown platform "sitecore". Valid platforms: all, aem, aem-eds, aep/);
  });

  it('treats --platform as case-sensitive and checks it before reading anything', () => {
    const result = run([join(scratch, 'does-not-exist.json'), '--platform', 'AEM']);
    assert.equal(result.status, 2);
    assert.equal(result.stdout, '');
    assert.match(result.stderr, /Unknown platform "AEM"/);
  });

  it('exits 1 for a missing or non-JSON Blueprint', () => {
    const missing = run([join(scratch, 'missing.json')]);
    assert.equal(missing.status, 1);
    assert.match(missing.stderr, /Cannot read /);
    assert.equal(missing.stdout, '');

    const bad = join(scratch, 'bad.json');
    writeFileSync(bad, '{ nope');
    const invalid = run([bad]);
    assert.equal(invalid.status, 1);
    assert.match(invalid.stderr, /\(blueprint\): invalid JSON/);
    assert.equal(invalid.stdout, '');
  });

  it('exits 1 when the Blueprint is not an object or lacks the arrays', () => {
    const list = run([writeJson('list.json', [])]);
    assert.equal(list.status, 1);
    assert.match(list.stderr, /\(blueprint\): expected object/);

    const empty = run([writeJson('empty.json', {})]);
    assert.equal(empty.status, 1);
    assert.match(empty.stderr, /\(blueprint\)\.requirements: expected array/);
    assert.match(empty.stderr, /\(blueprint\)\.questions: expected array/);
    assert.equal(empty.stdout, '');

    const half = run([writeJson('half.json', { requirements: [] })]);
    assert.equal(half.status, 1);
    assert.match(half.stderr, /\(blueprint\)\.questions: expected array/);
    assert.doesNotMatch(half.stderr, /requirements/);
    assert.equal(half.stdout, '');
  });

  it('exits 1 for an unreadable, non-JSON or invalid --existing file', () => {
    const missing = run([SAMPLE_BLUEPRINT, '--existing', join(scratch, 'nope.json')]);
    assert.equal(missing.status, 1);
    assert.match(missing.stderr, /Cannot read /);
    assert.equal(missing.stdout, '');

    const bad = join(scratch, 'bad-existing.json');
    writeFileSync(bad, 'nope');
    const notJson = run([SAMPLE_BLUEPRINT, '--existing', bad]);
    assert.equal(notJson.status, 1);
    assert.match(notJson.stderr, /\(existing\): invalid JSON/);
    assert.equal(notJson.stdout, '');

    const invalid = run([SAMPLE_BLUEPRINT, '--existing', writeJson('invalid-existing.json', { assumptions: [{ id: 'AS-001' }] })]);
    assert.equal(invalid.status, 1);
    assert.match(invalid.stderr, /\(existing\) assumptions\[0\]\.statement/);
    assert.equal(invalid.stdout, '');
  });

  it('ignores existing items without a library id', () => {
    const existing = writeJson('existing.json', {
      assumptions: [{ id: 'AS-001', statement: 'Own', review: { status: 'pending' } }],
      meta: { schemaVersion: '2' }
    });
    const result = runJson([SAMPLE_BLUEPRINT, '--existing', existing]);
    assert.equal(result.assumptions.skipped, 0);
  });

  describe('with a scratch seed directory', () => {
    const riskRows = loadSeed().find((sheet) => sheet.name === RISK).rows;
    const RISK_FILE = 'risk-library.csv';

    function seedDirWith(rewrites) {
      const dir = mkdtempSync(join(scratch, 'seed-'));
      cpSync(SEED_DIR, dir, { recursive: true });
      for (const [file, rewrite] of Object.entries(rewrites)) {
        const target = join(dir, file);
        const original = readFileSync(target, 'utf8');
        const rewritten = rewrite(original);
        assert.notEqual(rewritten, original, `the rewrite of ${file} changed nothing`);
        writeFileSync(target, rewritten);
      }
      return dir;
    }

    it('reads the libraries from --seed-dir', () => {
      // An always-propose risk is listed for any project, so renaming it must show up in the output.
      const [id] = riskRows.find((row) => row[1].trim() === 'all' && row[2].trim() === '');
      const dir = seedDirWith({ [RISK_FILE]: (text) => text.replace(id, `${id}-renamed`) });
      const result = runJson([SAMPLE_BLUEPRINT, '--seed-dir', dir, '--max', '100']);
      const ids = idsOf(result.deliveryRisks);
      assert.notEqual(ids.indexOf(`${id}-renamed`), -1);
      assert.equal(ids.indexOf(id), -1);
    });

    it('refuses an invalid seed and prints nothing on stdout', () => {
      const [id, platform] = riskRows[0];
      const dir = seedDirWith({ [RISK_FILE]: (text) => text.replace(`${id},${platform},`, `${id},zzz,`) });
      const result = run([SAMPLE_BLUEPRINT, '--seed-dir', dir]);
      assert.equal(result.status, 1);
      assert.equal(result.stdout, '');
      assert.match(result.stderr, /^Cannot load libraries: risk-library\.csv: row \d+:/);
    });

    it('refuses a missing seed directory', () => {
      const result = run([SAMPLE_BLUEPRINT, '--seed-dir', join(scratch, 'no-such-dir')]);
      assert.equal(result.status, 1);
      assert.match(result.stderr, /Cannot load libraries: /);
    });
  });
});

describe('synthetic AEM sample', () => {
  const blueprint = readJson(SAMPLE_BLUEPRINT);
  const context = readJson(SAMPLE_CONTEXT);
  const lists = ['deliveryRisks', 'deliveryUnknowns', 'assumptions', 'dependencies'];

  it('has a Blueprint that passes the working-file validator', () => {
    const result = spawnSync(
      process.execPath,
      [join(root, 'tools', 'blueprint', 'validate-working-file.mjs'), SAMPLE_BLUEPRINT],
      { cwd: root, encoding: 'utf8' }
    );
    assert.equal(result.status, 0, result.stderr);
  });

  it('has a sidecar that validates against the Blueprint with no warnings', () => {
    const result = spawnSync(
      process.execPath,
      [join(root, 'tools', 'blueprint', 'validate-context.mjs'), SAMPLE_CONTEXT, '--blueprint', SAMPLE_BLUEPRINT],
      { cwd: root, encoding: 'utf8' }
    );
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stderr, '');
  });

  it('is a v2 sidecar written by the skill, with every item pending', () => {
    assert.equal(context.meta.schemaVersion, '2');
    assert.equal(context.meta.producedBy, 'skill');
    let count = 0;
    for (const key of lists) {
      for (const item of context[key]) {
        count += 1;
        assert.deepEqual(item.review, { status: 'pending' }, item.id);
      }
    }
    assert.ok(count > 0);
  });

  it('gives every unknown a linked assumption', () => {
    assert.ok(context.deliveryUnknowns.length > 0);
    for (const unknown of context.deliveryUnknowns) {
      const linked = context.assumptions.filter((assumption) => (assumption.refs ?? []).indexOf(unknown.id) !== -1);
      assert.ok(linked.length > 0, `${unknown.id} has no linked assumption`);
    }
  });

  it('uses unique three-digit ids across the four lists', () => {
    const ids = [];
    for (const key of lists) {
      context[key].forEach((item) => ids.push(item.id));
    }
    assert.equal(new Set(ids).size, ids.length);
    assert.ok(ids.every((id) => /^(DR|DU|AS|DP)-\d{3}$/.test(id)));
  });

  it('keeps library items equal to what the tool emits, without a source', () => {
    const tool = matchLibrary({ blueprint, sheets: loadSeed(), max: 100 });
    const candidates = new Map();
    for (const list of [tool.assumptions, tool.dependencies, tool.deliveryRisks]) {
      list.entries.forEach((entry) => candidates.set(entry.libraryId, entry));
    }
    const libraryItems = [];
    for (const key of ['assumptions', 'dependencies', 'deliveryRisks']) {
      context[key].filter((item) => item.libraryId !== undefined).forEach((item) => libraryItems.push(item));
    }
    assert.ok(libraryItems.length > 0);
    for (const item of libraryItems) {
      const candidate = candidates.get(item.libraryId);
      assert.ok(candidate, `${item.libraryId} is not a candidate`);
      const { id, refs, ...rest } = item;
      assert.equal('source' in rest, false, `${item.libraryId} has a source`);
      assert.deepEqual(rest, candidate.item, item.libraryId);
    }
  });

  it('stays within the per-list cap for library items', () => {
    for (const key of ['assumptions', 'dependencies', 'deliveryRisks']) {
      assert.ok(context[key].filter((item) => item.libraryId !== undefined).length <= DEFAULT_MAX, key);
    }
  });

  it('leaves out entries that matched only a dismissed requirement or a source passage', () => {
    const seed = loadSeed();
    const proposedIds = (value) => new Set(allEntries(matchLibrary({ blueprint: value, sheets: seed, max: 100 })).map((e) => e.libraryId));
    // R-006 is dismissed and mentions hypercare and a rota; only the passage of R-008 mentions UAT.
    const control = structuredClone(blueprint);
    const dismissed = control.requirements.find((requirement) => requirement.id === 'R-006');
    assert.equal(dismissed.review.status, 'dismissed');
    dismissed.review.status = 'pending';
    const acceptance = control.requirements.find((requirement) => requirement.id === 'R-008');
    assert.equal(acceptance.statement.toLowerCase().includes('uat'), false);
    acceptance.statement += ' UAT';

    const withControl = proposedIds(control);
    const actual = proposedIds(blueprint);
    const inContext = [].concat(context.assumptions, context.dependencies, context.deliveryRisks);
    const leftOut = [...withControl].filter((id) => !actual.has(id));
    // The control must make a difference, or the checks below prove nothing.
    assert.ok(leftOut.length > 0, 'un-dismissing R-006 or editing R-008 changed nothing');
    for (const id of leftOut) {
      assert.equal(inContext.some((item) => item.libraryId === id), false, `${id} is in the sidecar`);
    }
    for (const id of ['asm-support-rota', 'risk-support-rota-gap', 'dep-test-tenant']) {
      assert.ok(withControl.has(id), `${id} is not in the control run`);
      assert.equal(actual.has(id), false, `${id} was proposed`);
    }
  });

  it('gives every risk that has no library id a document source', () => {
    const own = context.deliveryRisks.filter((item) => item.libraryId === undefined);
    assert.ok(own.length > 0);
    for (const item of own) {
      assert.ok(typeof item.source === 'string' && item.source !== '', `${item.id} has no source`);
    }
  });
});
