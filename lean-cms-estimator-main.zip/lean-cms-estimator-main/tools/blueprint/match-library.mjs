#!/usr/bin/env node
/**
 * Offline library matcher for the enrich skill (SPMVP-039).
 *
 * Reads the hub libraries (Assumption, Dependency, Risk) from the factors seed CSVs, matches their hints
 * against the requirement statements and question text of a Blueprint file, then orders and caps the
 * candidates per list. It prints one JSON document: for each candidate the evidence (matched hints,
 * requirement and question ids) and an `item` in Context sidecar v2 shape. The item has no `id`, `source`
 * or `refs`. The skill adds the `id` and the `refs`; an item that comes only from a library keeps no
 * `source`. Nothing here judges relevance, the skill does.
 *
 * Usage: see USAGE below. `--seed-dir` points at another seed directory (used by tests).
 * Exit 0 on success. Exit 1 when the libraries cannot be loaded, or the Blueprint or --existing file
 * cannot be read, is not JSON, has the wrong shape, or (--existing) fails the Context validator.
 * Exit 2 on bad usage, including an unknown --platform. Warnings (a platform that falls back to `all`,
 * entries skipped because they are malformed, existing ids that match no library entry) go to stderr and
 * never change the exit code.
 * Contract: docs/spfx/context-sidecar.md ("Enrich skill rules") and docs/spfx/delivery-defaults.md.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { KNOWN_PLATFORMS, LEVELS, PRIORITIES } from '../factors/validate-libraries.mjs';
import { readSuppressFile, suppressedLibraryIds } from './suppression.mjs';
import { validateContextValue } from './validate-context.mjs';

export const DEFAULT_MAX = 8;

const ALL_PLATFORM = 'all';
const ZERO_WIDTH = /[\u200B-\u200D\u2060\uFEFF]/g;
const USAGE =
  'Usage: node tools/blueprint/match-library.mjs <path-to-blueprint.json> [--platform <id>] [--max <n>] ' +
  '[--existing <path-to-context.json>] [--suppress <path-to-suppress.json>] [--seed-dir <dir>]';
const CONTEXT_LISTS = ['deliveryRisks', 'deliveryUnknowns', 'assumptions', 'dependencies'];

// Derived risk level: likelihood times severity (low 1, medium 2, high 3). 6 to 9 is HIGH, 3 to 5 MEDIUM,
// 1 to 2 LOW. Same bands as the Context sidecar doc. Only used to order risks, never written to an item.
const HIGH_SCORE = 6;
const MEDIUM_SCORE = 3;

/**
 * Per list: the sidecar key, the library sheet, the columns copied onto the item (sheet header text to
 * sidecar field, in output order) and the ordering rank (a smaller rank sorts first). Enum values are
 * guaranteed valid by the seed check that loadSeed runs.
 */
const LIST_SPECS = [
  {
    key: 'assumptions',
    sheet: 'Assumption library',
    fields: [
      ['statement', 'statement'],
      ['category', 'category'],
      ['confidence', 'confidence'],
      ['if it fails', 'ifFails']
    ],
    // Least certain first.
    rank: (cell) => LEVELS.indexOf(cell('confidence'))
  },
  {
    key: 'dependencies',
    sheet: 'Dependency library',
    fields: [
      ['statement', 'statement'],
      ['owner', 'owner'],
      ['needed', 'needed'],
      ['impact if missing', 'impactIfMissing'],
      ['priority', 'priority'],
      ['required week', 'requiredWeek']
    ],
    rank: (cell) => PRIORITIES.indexOf(cell('priority'))
  },
  {
    key: 'deliveryRisks',
    sheet: 'Risk library',
    fields: [
      ['statement', 'statement'],
      ['impact', 'impact'],
      ['likelihood', 'likelihood'],
      ['severity', 'severity'],
      ['mitigation', 'mitigation']
    ],
    rank: (cell) => riskRank(cell('likelihood'), cell('severity'))
  }
];

function requiredHeaders(spec) {
  return ['library id', 'platform', 'match hints'].concat(spec.fields.map((field) => field[0]));
}

/** Header text each list reads, so a test can check it against the workbook sheet definition. */
export const LIST_COLUMNS = LIST_SPECS.map((spec) => ({ sheet: spec.sheet, headers: requiredHeaders(spec) }));

/** 0 for a HIGH risk, 1 for MEDIUM, 2 for LOW. */
function riskRank(likelihood, severity) {
  const score = (LEVELS.indexOf(likelihood) + 1) * (LEVELS.indexOf(severity) + 1);
  if (score >= HIGH_SCORE) {
    return 0;
  }
  return score >= MEDIUM_SCORE ? 1 : 2;
}

function clean(text) {
  return String(text ?? '').replace(ZERO_WIDTH, '').trim();
}

function isObject(value) {
  return typeof value === 'object' && !!value && !Array.isArray(value);
}

function compareText(a, b) {
  if (a < b) {
    return -1;
  }
  return a > b ? 1 : 0;
}

function unknownPlatformMessage(value) {
  return `Unknown platform "${value}". Valid platforms: ${KNOWN_PLATFORMS.join(', ')}`;
}

// The stemming rules match tools/catalog/suggest.mjs, and the two should stay in step. The tokenizer is
// separate because suggest.mjs drops short tokens and stop words such as `aem` and `cloud`, which seed
// hints use.
function stem(token) {
  if (token.endsWith('ies') && token.length > 4) {
    return `${token.slice(0, -3)}y`;
  }
  if (token.endsWith('ing') && token.length > 5) {
    return token.slice(0, -3);
  }
  if (token.endsWith('ed') && token.length > 4) {
    return token.slice(0, -2);
  }
  if (token.endsWith('s') && !token.endsWith('ss') && token.length > 3) {
    return token.slice(0, -1);
  }
  return token;
}

/** Ordered, stemmed tokens. No stop words and no length filter, so hints like `sso` and `dam` survive. */
export function tokenize(text) {
  return String(text ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .split(' ')
    .filter((token) => token.length > 0)
    .map(stem);
}

/** True when `needle` appears in `tokens` as a contiguous run, in order. An empty needle never matches. */
export function containsSequence(tokens, needle) {
  if (needle.length === 0 || needle.length > tokens.length) {
    return false;
  }
  for (let start = 0; start + needle.length <= tokens.length; start += 1) {
    let same = true;
    for (let i = 0; i < needle.length; i += 1) {
      if (tokens[start + i] !== needle[i]) {
        same = false;
        break;
      }
    }
    if (same) {
      return true;
    }
  }
  return false;
}

/**
 * Picks the library platform. A valid override wins. Otherwise the Blueprint platform id is used when,
 * trimmed and lowercased, it equals a library platform. Anything else falls back to `all`.
 * @param {unknown} blueprint
 * @param {string} [override]
 * @returns {{ used: string, source: 'flag' | 'blueprint' | 'default', requested: string | null }}
 * @throws {Error} when the override is not a library platform
 */
export function resolvePlatform(blueprint, override) {
  const raw = isObject(blueprint) && isObject(blueprint.platform) ? blueprint.platform.id : undefined;
  const requested = typeof raw === 'string' && raw.trim() !== '' ? raw.trim() : null;
  if (override !== undefined) {
    if (KNOWN_PLATFORMS.indexOf(override) === -1) {
      throw new Error(unknownPlatformMessage(override));
    }
    return { used: override, source: 'flag', requested };
  }
  const normalised = requested === null ? '' : requested.toLowerCase();
  if (normalised !== '' && KNOWN_PLATFORMS.indexOf(normalised) !== -1) {
    return { used: normalised, source: 'blueprint', requested };
  }
  return { used: ALL_PLATFORM, source: 'default', requested };
}

function idOrUndefined(value) {
  return typeof value === 'string' && value !== '' ? value : undefined;
}

/**
 * The text units a hint may match: requirement statements and question text. Dismissed requirements are
 * skipped, and so are questions linked to one. Source passages are never read. Everything skipped, or
 * kept but not linkable, is counted in `input` so the caller can see it.
 */
function collectUnits(blueprint) {
  const requirements = Array.isArray(blueprint.requirements) ? blueprint.requirements : [];
  const questions = Array.isArray(blueprint.questions) ? blueprint.questions : [];
  const dismissed = new Set();
  const knownRequirementIds = new Set();
  const units = [];
  const input = {
    requirements: 0,
    requirementsSkippedDismissed: 0,
    requirementsSkippedMalformed: 0,
    questions: 0,
    questionsSkippedDismissed: 0,
    questionsSkippedMalformed: 0,
    questionsUnlinked: 0,
    unitsWithoutId: 0
  };

  for (const requirement of requirements) {
    if (!isObject(requirement)) {
      input.requirementsSkippedMalformed += 1;
      continue;
    }
    const id = idOrUndefined(requirement.id);
    if (id !== undefined) {
      knownRequirementIds.add(id);
    }
    if (isObject(requirement.review) && requirement.review.status === 'dismissed') {
      input.requirementsSkippedDismissed += 1;
      if (id !== undefined) {
        dismissed.add(id);
      }
    } else if (typeof requirement.statement !== 'string') {
      input.requirementsSkippedMalformed += 1;
    } else {
      input.requirements += 1;
      units.push({ kind: 'requirement', id, tokens: tokenize(requirement.statement) });
    }
  }

  for (const question of questions) {
    if (!isObject(question) || typeof question.text !== 'string') {
      input.questionsSkippedMalformed += 1;
    } else if (typeof question.requirementId === 'string' && dismissed.has(question.requirementId)) {
      input.questionsSkippedDismissed += 1;
    } else {
      input.questions += 1;
      if (typeof question.requirementId !== 'string' || !knownRequirementIds.has(question.requirementId)) {
        input.questionsUnlinked += 1;
      }
      units.push({ kind: 'question', id: idOrUndefined(question.id), tokens: tokenize(question.text) });
    }
  }

  input.unitsWithoutId = units.filter((unit) => unit.id === undefined).length;
  return { units, input };
}

function findSheet(sheets, name) {
  const sheet = sheets.find((candidate) => candidate.name === name);
  if (!sheet) {
    throw new Error(`The libraries are missing the "${name}" sheet`);
  }
  return sheet;
}

function readColumns(sheet, spec) {
  const columns = {};
  for (const header of requiredHeaders(spec)) {
    const index = sheet.headers.indexOf(header);
    if (index === -1) {
      throw new Error(`${spec.sheet}: the matcher expects a "${header}" column`);
    }
    columns[header] = index;
  }
  return columns;
}

function buildItem(spec, cell, libraryId) {
  const item = { libraryId };
  for (const [header, field] of spec.fields) {
    const value = cell(header);
    if (field === 'requiredWeek') {
      if (value !== '') {
        item.requiredWeek = Number(value);
      }
    } else {
      item[field] = value;
    }
  }
  item.review = { status: 'pending' };
  return item;
}

function unique(values) {
  return values.filter((value, index) => values.indexOf(value) === index);
}

/** Which hints appear in the text units, and which units they appear in (in Blueprint order). */
function matchHints(hints, units) {
  const matchedHints = [];
  const hitUnits = new Set();
  for (const hint of hints) {
    const needle = tokenize(hint);
    let matched = false;
    for (const unit of units) {
      if (containsSequence(unit.tokens, needle)) {
        matched = true;
        hitUnits.add(unit);
      }
    }
    if (matched) {
      matchedHints.push(hint);
    }
  }
  return { matchedHints, hitUnits: units.filter((unit) => hitUnits.has(unit)) };
}

function idsOfKind(hitUnits, kind) {
  return unique(hitUnits.filter((unit) => unit.kind === kind && unit.id !== undefined).map((unit) => unit.id));
}

function compareCandidates(a, b) {
  return (
    a.rank - b.rank ||
    b.entry.matchedHints.length - a.entry.matchedHints.length ||
    compareText(a.entry.libraryId, b.entry.libraryId)
  );
}

/** Every candidate for one list, ordered, with the counts of what was left out before the cap. */
function listCandidates(spec, sheet, { units, platformUsed, existing, suppressed }) {
  const columns = readColumns(sheet, spec);
  const candidates = [];
  let skipped = 0;
  let suppressedCount = 0;
  let excludedByPlatform = 0;

  for (const row of sheet.rows) {
    const cell = (header) => clean(row[columns[header]]);
    const entryPlatform = cell('platform');
    if (entryPlatform !== ALL_PLATFORM && entryPlatform !== platformUsed) {
      excludedByPlatform += 1;
      continue;
    }
    const libraryId = cell('library id');
    const hints = cell('match hints')
      .split(';')
      .map((hint) => hint.trim())
      .filter((hint) => hint !== '');
    const alwaysPropose = hints.length === 0 && entryPlatform === ALL_PLATFORM;
    const { matchedHints, hitUnits } = matchHints(hints, units);
    if (matchedHints.length === 0 && !alwaysPropose) {
      continue;
    }
    if (suppressed.has(libraryId.toLowerCase())) {
      suppressedCount += 1;
      continue;
    }
    if (existing.has(libraryId.toLowerCase())) {
      skipped += 1;
      continue;
    }
    candidates.push({
      rank: spec.rank(cell),
      entry: {
        libraryId,
        alwaysPropose,
        matchedHints,
        requirementIds: idsOfKind(hitUnits, 'requirement'),
        questionIds: idsOfKind(hitUnits, 'question'),
        item: buildItem(spec, cell, libraryId)
      }
    });
  }

  candidates.sort(compareCandidates);
  const libraryIds = sheet.rows.map((row) => clean(row[columns['library id']]).toLowerCase());
  return { candidates, skipped, suppressed: suppressedCount, excludedByPlatform, libraryIds };
}

/**
 * Candidate library entries for a Blueprint, ordered and capped per list.
 * @param {{
 *   blueprint: { platform?: { id?: string }, requirements?: unknown[], questions?: unknown[] },
 *   sheets: Array<{ name: string, headers: string[], rows: string[][] }>,
 *   platform?: string,
 *   max?: number,
 *   existingLibraryIds?: Iterable<string>,
 *   suppressedLibraryIds?: Iterable<string>
 * }} options sheets are loadSeed-shaped. Existing and suppressed ids are compared trimmed and lowercased.
 * @returns {{
 *   platform: { used: string, source: string, requested: string | null },
 *   max: number,
 *   input: Record<string, number>,
 *   existingUnmatched: string[],
 *   assumptions: object, dependencies: object, deliveryRisks: object
 * }} each list holds `candidates`, `dropped`, `skipped` (already in the sidecar), `suppressed` (in the suppression file), `excludedByPlatform` and `entries`
 * @throws {Error} for an unknown platform override, or a library sheet or column that is missing
 */
export function matchLibrary({ blueprint, sheets, platform, max = DEFAULT_MAX, existingLibraryIds = [], suppressedLibraryIds: suppressed = [] }) {
  const resolved = resolvePlatform(blueprint, platform);
  const existing = new Set(Array.from(existingLibraryIds, (id) => clean(id).toLowerCase()));
  // Suppressed ids (the team keeps rejecting them) are left out like existing ones, but an id that
  // matches no entry is not a mistake worth a warning: the libraries may have changed since the stats.
  const suppressedIds = new Set(Array.from(suppressed, (id) => clean(id).toLowerCase()));
  const { units, input } = collectUnits(blueprint);
  const knownIds = new Set();

  const result = { platform: resolved, max, input };
  for (const spec of LIST_SPECS) {
    const sheet = findSheet(sheets, spec.sheet);
    const { candidates, skipped, suppressed: suppressedCount, excludedByPlatform, libraryIds } = listCandidates(spec, sheet, {
      units,
      platformUsed: resolved.used,
      existing,
      suppressed: suppressedIds
    });
    libraryIds.forEach((id) => knownIds.add(id));
    const entries = candidates.slice(0, max).map((candidate) => candidate.entry);
    result[spec.key] = {
      candidates: candidates.length,
      dropped: candidates.length - entries.length,
      skipped,
      suppressed: suppressedCount,
      excludedByPlatform,
      entries
    };
  }
  result.existingUnmatched = Array.from(existing)
    .filter((id) => !knownIds.has(id))
    .sort(compareText);
  return result;
}

/** Messages for things the operator should see, written to stderr. */
export function collectWarnings(result) {
  const warnings = [];
  const { platform, input } = result;
  if (platform.source === 'default' && platform.requested !== null) {
    warnings.push(
      `Blueprint platform "${platform.requested}" is not a library platform, so only "${ALL_PLATFORM}" entries ` +
        'are listed (use --platform to override)'
    );
  }
  const malformedRequirements = input.requirementsSkippedMalformed;
  const malformedQuestions = input.questionsSkippedMalformed;
  if (malformedRequirements + malformedQuestions > 0) {
    warnings.push(
      `skipped ${malformedRequirements} requirement(s) and ${malformedQuestions} question(s) with no usable text`
    );
  }
  if (input.unitsWithoutId > 0) {
    warnings.push(`${input.unitsWithoutId} requirement(s) or question(s) have no id, so matches on them cannot be linked with refs`);
  }
  if (input.questionsUnlinked > 0) {
    warnings.push(`${input.questionsUnlinked} question(s) are not linked to a requirement in this Blueprint`);
  }
  if (result.existingUnmatched.length > 0) {
    warnings.push(`--existing has library ids that match no library entry: ${result.existingUnmatched.join(', ')}`);
  }
  return warnings;
}

const VALUE_FLAGS = ['--platform', '--max', '--existing', '--suppress', '--seed-dir'];

/** @returns {{ blueprintPath: string, platform?: string, max?: number, existing?: string, suppress?: string, seedDir?: string } | undefined} */
function parseArgs(args) {
  const parsed = {};
  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];
    if (VALUE_FLAGS.indexOf(arg) !== -1) {
      const next = args[i + 1];
      const name = arg.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      if (next === undefined || next === '' || next.indexOf('-') === 0 || parsed[name] !== undefined) {
        return undefined;
      }
      parsed[name] = next;
      i += 1;
    } else if (arg.indexOf('-') === 0 || parsed.blueprintPath !== undefined) {
      return undefined;
    } else {
      parsed.blueprintPath = arg;
    }
  }
  if (!parsed.blueprintPath) {
    return undefined;
  }
  if (parsed.max !== undefined) {
    if (!/^[1-9][0-9]*$/.test(parsed.max)) {
      return undefined;
    }
    parsed.max = Number(parsed.max);
  }
  return parsed;
}

function readJson(file, label) {
  const abs = path.resolve(file);
  let raw;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch (err) {
    console.error(`Cannot read ${abs}: ${err.message}`);
    process.exit(1);
  }
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.error(`(${label}): invalid JSON (${err.message})`);
    process.exit(1);
  }
}

/** Library ids already in a Context sidecar, from any of its four lists. */
function libraryIdsOf(context) {
  const ids = [];
  for (const key of CONTEXT_LISTS) {
    for (const item of Array.isArray(context[key]) ? context[key] : []) {
      if (isObject(item) && typeof item.libraryId === 'string' && item.libraryId.trim() !== '') {
        ids.push(item.libraryId);
      }
    }
  }
  return ids;
}

async function loadSheets(seedDir) {
  let workbook;
  try {
    // Imported here, not at the top, so usage errors are reported before the seed is read.
    workbook = await import('../factors/seed.mjs');
  } catch (err) {
    console.error(`Cannot load the library seed module (tools/factors/seed.mjs): ${err.message}`);
    process.exit(1);
  }
  try {
    return workbook.loadSeed(seedDir === undefined ? workbook.SEED_DIR : path.resolve(seedDir));
  } catch (err) {
    console.error(`Cannot load libraries: ${err.message}`);
    process.exit(1);
  }
}

async function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  if (parsed.platform !== undefined && KNOWN_PLATFORMS.indexOf(parsed.platform) === -1) {
    console.error(unknownPlatformMessage(parsed.platform));
    process.exit(2);
  }

  const blueprint = readJson(parsed.blueprintPath, 'blueprint');
  if (!isObject(blueprint)) {
    console.error('(blueprint): expected object');
    process.exit(1);
  }
  const shapeErrors = ['requirements', 'questions']
    .filter((key) => !Array.isArray(blueprint[key]))
    .map((key) => `(blueprint).${key}: expected array`);
  if (shapeErrors.length) {
    shapeErrors.forEach((message) => console.error(message));
    process.exit(1);
  }

  let existingLibraryIds = [];
  if (parsed.existing !== undefined) {
    const context = readJson(parsed.existing, 'existing');
    const errors = validateContextValue(context);
    if (errors.length) {
      errors.forEach((message) => console.error(`(existing) ${message}`));
      process.exit(1);
    }
    existingLibraryIds = libraryIdsOf(context);
  }

  const suppressed = parsed.suppress === undefined ? [] : suppressedLibraryIds(readSuppressFile(parsed.suppress));

  const sheets = await loadSheets(parsed.seedDir);
  const result = matchLibrary({
    blueprint,
    sheets,
    platform: parsed.platform,
    max: parsed.max,
    existingLibraryIds,
    suppressedLibraryIds: suppressed
  });
  collectWarnings(result).forEach((message) => console.error(`warning: ${message}`));
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main(process.argv).catch((err) => {
    console.error(`match-library: ${err.message}`);
    process.exit(1);
  });
}
