import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { acceptRequirements, assemblePlan, estimatePlan, formatSummary, summarizePlan, validatePlan } from './plan.mjs';
import { assembleDrivers } from './assemble-drivers.mjs';
import { buildEstimate, EstimateError, estimateTotals, kindOf, loadModelInputs, LABELS, PHASES, ratesOf, round2, staleWorkstreams, validateEstimate } from './estimate-model.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'plan.mjs');
const catalogMd = fs.readFileSync(DEFAULT_CATALOG, 'utf8');
const workPackages = parseActivities(catalogMd);
// An empty case library, not the repo's. A test that is about what cases do says so by passing
// its own; the rest must mean the same thing in a month, when the library has grown.
const inputs = { ...loadModelInputs(), cases: [] };
const NOW = '2026-11-13T12:00:00.000Z';

const blocks = [
  { id: 'src-rfp#p1.1', itemId: 'src-rfp', fileName: 'RFP.docx', label: 'RFP p.1', location: { kind: 'page', page: 1 }, text: 'The vendor shall migrate approximately 6,400 pages of content.' },
  { id: 'src-rfp#p1.2', itemId: 'src-rfp', fileName: 'RFP.docx', label: 'RFP p.1', location: { kind: 'page', page: 1 }, text: 'The site launches in four locales.' }
];
const extract = {
  schemaVersion: '1',
  producedBy: 'skill',
  requirements: [
    { statement: 'Migrate approximately 6,400 pages of content.', blockIds: ['src-rfp#p1.1'], workPackage: 'content-migration', coverage: 'accelerated', question: null, duplicateOf: null },
    { statement: 'The site launches in four locales.', blockIds: ['src-rfp#p1.2'], workPackage: 'localization', coverage: 'partly', question: null, duplicateOf: null }
  ],
  platform: { id: 'aem-eds', blockId: 'src-rfp#p1.1' },
  notes: null
};

function sketch() {
  return assembleDrivers({
    drivers: [{ workPackageId: 'content-migration', quantity: 6400, basis: 'stated', quote: 'migrate approximately 6,400 pages of content', blockIds: ['src-rfp#p1.1'], confidence: 'high' }]
  }, blocks, workPackages).sketch;
}

function freshPlan(withVolume = true) {
  return assemblePlan({ extract, blocks, catalogMd, projectName: 'Fabrikam', now: NOW, sketch: withVolume ? sketch() : undefined }).plan;
}

function estimated(plan, platform) {
  const copy = JSON.parse(JSON.stringify(plan));
  const { warnings } = estimatePlan(copy, inputs, { platform, workPackages, now: NOW });
  return { plan: copy, warnings };
}

const byId = (plan, id) => plan.workstreams.find((row) => row.id === id);

test('every starting figure belongs to an activity, and says what that shape of activity needs', () => {
  // The catalog names more activities than it has starting figures for, so the figures are a
  // subset. What matters is that each one is usable for the shape of activity it belongs to.
  const sized = Array.from(workPackages).filter(([, entry]) => entry.skillIds !== undefined);
  assert.ok(sized.length > 0 && sized.length < workPackages.size, `${sized.length} of ${workPackages.size}`);
  for (const [id, entry] of sized) {
    assert.ok(entry.skillIds.every((skillId) => inputs.skills.has(skillId)), `${id} skills`);
    assert.ok(entry.aiSavingPercent >= 0 && entry.aiSavingPercent <= 90, `${id} AI saving`);
    if (entry.shape === 'proportional') {
      assert.equal(entry.hoursPerUnit, null, `${id} is sized by its share, not by hours`);
      assert.equal(entry.volume, null, `${id} has no volume`);
    } else {
      assert.ok(entry.hoursPerUnit > 0 && entry.volume > 0, `${id} hours and volume`);
    }
  }
});

test('an activity with no starting figures is not sized, and the catalog has such activities', () => {
  const unsized = Array.from(workPackages).filter(([, entry]) => entry.skillIds === undefined).map(([id]) => id);
  assert.ok(unsized.includes('hypercare'), unsized.join(', '));
  const { warnings, workstreams } = buildEstimate(freshPlan(), inputs, { platform: 'aem', workPackages });
  assert.equal(workstreams.some((row) => unsized.includes(row.id)), false);
  const line = warnings.find((message) => message.includes('not sized'));
  for (const id of unsized) {
    assert.ok(line.includes(id), `${id} is not named in: ${line}`);
  }
});

test('the new business skills are on the skills sheet', () => {
  for (const id of ['change-management', 'content-strategy', 'ux-design', 'seo', 'accessibility', 'legal-compliance', 'training']) {
    assert.equal(inputs.skills.get(id).category, 'business', id);
  }
});

test('the AI-assisted rate is the traditional one less the saving, and only while a tool is ON', () => {
  const on = { tools: true };
  assert.deepEqual(ratesOf(24, on, 30), { traditional: 24, aiAssisted: 16.8 });
  assert.deepEqual(ratesOf(24, on, 0), { traditional: 24, aiAssisted: 24 }, '0 means the activity claims no saving');
  assert.deepEqual(ratesOf(24, { tools: false }, 30), { traditional: 24, aiAssisted: 24 }, 'no tool ON, no saving');
  assert.equal(ratesOf(24, on, 33).aiAssisted, 16.08);
  assert.equal(ratesOf(24, on, 90).aiAssisted, 2.4, 'the most a saving can take off');
});

test('every workstream carries the activity\'s saving percentage, and it is editable per activity', () => {
  // 30% everywhere except uat-support, which has no capability mapped to it and so claims no saving.
  const sized = Array.from(workPackages).filter(([, entry]) => entry.skillIds !== undefined);
  assert.equal(workPackages.get('uat-support').aiSavingPercent, 0);
  assert.ok(sized.every(([id, entry]) => entry.aiSavingPercent === 30 || id === 'uat-support'),
    'the default is 30% for every other activity');

  const edited = new Map(Array.from(workPackages, ([id, entry]) => [id, { ...entry }]));
  edited.get('content-migration').aiSavingPercent = 60;
  edited.get('component-build').aiSavingPercent = 0;
  const built = buildEstimate(freshPlan(), inputs, { platform: 'aem', workPackages: edited }).workstreams;
  const migration = built.find((row) => row.id === 'content-migration');
  assert.equal(migration.aiSavingPercent, 60);
  assert.deepEqual(migration.hoursPerUnit, { traditional: 2, aiAssisted: 0.8 });
  assert.equal(migration.aiAssistedHours, migration.volume * 0.8);
  const build = built.find((row) => row.id === 'component-build');
  assert.deepEqual(build.hoursPerUnit, { traditional: 24, aiAssisted: 24 }, '0% claims nothing');
});

test('a starting figure that is missing, out of range or the wrong shape is an error, not a guess', () => {
  const broken = (id, change) => {
    const copy = new Map(Array.from(workPackages, ([key, entry]) => [key, { ...entry }]));
    change(copy.get(id));
    return () => buildEstimate(freshPlan(), inputs, { platform: 'aem', workPackages: copy });
  };
  const figures = /Starting figures/;
  assert.throws(broken('content-migration', (e) => { e.aiSavingPercent = 95; }), figures);
  assert.throws(broken('content-migration', (e) => { e.aiSavingPercent = -5; }), /from 0 to 90/);
  assert.throws(broken('content-migration', (e) => { e.skillIds = []; }), /a default skill list is required/);
  assert.throws(broken('content-migration', (e) => { e.skillIds = ['not-a-skill']; }), /is not on skills\.csv/);
  assert.throws(broken('content-migration', (e) => { e.skillIds = ['seo', 'seo']; }), /a skill is listed twice/);
  assert.throws(broken('content-migration', (e) => { e.hoursPerUnit = null; }), /starting hours are required/);
  assert.throws(broken('content-migration', (e) => { e.volume = 0; }), /above zero/);
  assert.throws(broken('project-management', (e) => { e.hoursPerUnit = 80; }), /takes its hours from its share/);
});

test('the validator checks the saving percentage behind an AI-assisted rate', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  const rates = byId(plan, 'component-build').hoursPerUnit;
  assert.ok(rates.aiAssisted < rates.traditional, 'the saving was claimed');
  assert.deepEqual(validateEstimate(plan, { workPackages }), []);
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validateEstimate(copy, { workPackages });
  };
  assert.ok(broken((p) => { byId(p, 'component-build').aiSavingPercent = 50; }).some((m) => /is not 24 less 50%/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').aiSavingPercent = 0; }).some((m) => /so aiSavingPercent is above zero/.test(m)));
  assert.ok(broken((p) => { delete byId(p, 'component-build').aiSavingPercent; }).some((m) => /aiSavingPercent: expected a number from 0 to 90/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').aiSavingPercent = 99; }).some((m) => /aiSavingPercent: expected a number from 0 to 90/.test(m)));
});

test('with no case library every rate is derived, unaccepted, and owes a question', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  for (const row of plan.workstreams) {
    assert.equal(row.rateBasis, 'derived', row.id);
    assert.deepEqual(row.caseIds, [], row.id);
    assert.equal(row.caseCount, 0, row.id);
    assert.equal(row.rateAccepted, false, row.id);
    // A proportional activity has no rate of its own: what it is missing is a measured share,
    // so it says that instead.
    assert.match(row.rateQuestion, row.share ? /no past project records what share/ : /nobody has accepted a rate yet/, row.id);
  }
});

test('cases set the rate, name themselves, and stop asking once there are enough on the platform', () => {
  const library = ['C-001', 'C-002', 'C-003'].map((caseId, index) => ({
    caseId,
    platform: 'aem',
    activities: [{ activity: 'component-build', hours: 10 * (index + 1), volume: 1 }]
  }));
  const copy = JSON.parse(JSON.stringify(freshPlan()));
  estimatePlan(copy, { ...inputs, cases: library }, { platform: 'aem', workPackages, now: NOW });
  const row = byId(copy, 'component-build');
  assert.equal(row.rateBasis, 'cases');
  assert.equal(row.hoursPerUnit.traditional, 20);
  assert.deepEqual(row.caseIds, ['C-001', 'C-002', 'C-003']);
  assert.equal(row.caseCount, 3);
  assert.equal(row.rateQuestion, undefined);
  assert.equal(byId(copy, 'content-migration').rateBasis, 'derived');
  assert.deepEqual(validateEstimate(copy, { workPackages }), []);
});

test('an accepted rate decision in the plan is the rate a derived activity uses', () => {
  const copy = JSON.parse(JSON.stringify(freshPlan()));
  copy.rates = [{ activity: 'component-build', hoursPerUnit: 7, note: 'Matches the last two pursuits.', review: { status: 'accepted', via: 'rate', at: NOW } }];
  estimatePlan(copy, inputs, { platform: 'aem', workPackages, now: NOW });
  const row = byId(copy, 'component-build');
  assert.equal(row.hoursPerUnit.traditional, 7);
  assert.equal(row.rateAccepted, true);
  assert.deepEqual(validatePlan(copy, { blocks, workPackages }), []);
});

test('tiered activities are banded from the documents, and nothing else is banded at all', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  const tiered = plan.workstreams.filter((row) => workPackages.has(row.id) && workPackages.get(row.id).shape === 'tiered');
  assert.ok(tiered.length > 0);
  for (const row of tiered) {
    assert.ok(['small', 'medium', 'large'].includes(row.band), row.id);
    assert.equal(row.bandSignals.length === 0, Boolean(row.bandQuestion), row.id);
    assert.ok(row.bandReason);
  }
  for (const row of plan.workstreams.filter((other) => !tiered.includes(other))) {
    assert.equal(row.band, undefined, row.id);
  }
  assert.deepEqual(validateEstimate(plan, { workPackages }), []);
});

test('a band is rejected when nothing recorded why, or when it is on an activity that is not tiered', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  const tieredId = plan.workstreams.find((row) => row.band).id;
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validateEstimate(copy, { workPackages });
  };
  assert.ok(broken((p) => { byId(p, tieredId).band = 'enormous'; }).some((m) => /band: expected one of small, medium, large/.test(m)));
  assert.ok(broken((p) => { delete byId(p, tieredId).band; }).some((m) => /band: expected one of/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').band = 'large'; }).some((m) => /only a tiered activity is banded/.test(m)));
  assert.ok(broken((p) => { delete byId(p, tieredId).bandReason; }).some((m) => /bandReason: expected what the band was read from/.test(m)));
  assert.ok(broken((p) => {
    const row = byId(p, tieredId);
    row.bandSignals = [];
    delete row.bandQuestion;
  }).some((m) => /a band with no signal behind it asks the client about it/.test(m)));
  assert.ok(broken((p) => {
    const row = byId(p, tieredId);
    row.bandSignals = [{ band: 'medium', quoted: true, reason: 'r', matched: 'm' }];
    row.bandQuestion = 'Why?';
  }).some((m) => /the documents banded this, so there is nothing to ask/.test(m)));
});

test('three-point hours: the likely is the workstream hours, and cases are what widen the range', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  for (const row of plan.workstreams) {
    assert.deepEqual(row.hours, { low: row.traditionalHours, likely: row.traditionalHours, high: row.traditionalHours, spread: 'none' }, row.id);
  }

  const library = ['C-001', 'C-002', 'C-003'].map((caseId, index) => ({
    caseId,
    platform: 'aem',
    activities: [{ activity: 'component-build', hours: 10 * (index + 1), volume: 1 }]
  }));
  const copy = JSON.parse(JSON.stringify(freshPlan()));
  estimatePlan(copy, { ...inputs, cases: library }, { platform: 'aem', workPackages, now: NOW });
  const row = byId(copy, 'component-build');
  assert.equal(row.hours.spread, 'quartiles');
  assert.ok(row.hours.low < row.hours.likely && row.hours.likely < row.hours.high);
  assert.equal(row.hours.likely, row.traditionalHours);
  assert.deepEqual(validateEstimate(copy, { workPackages }), []);
});

test('the totals carry the range, and every phase the estimate touches rolls up inside it', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  const totals = estimateTotals(plan);
  assert.equal(totals.hours.likely, totals.traditionalHours);
  const sum = (rows, pick) => Math.round(rows.reduce((total, row) => total + row.hours[pick], 0) * 100) / 100;
  assert.equal(totals.hours.low, sum(plan.workstreams, 'low'));
  assert.equal(totals.hours.high, sum(plan.workstreams, 'high'));

  // A phase with no workstream is left out rather than reported at zero, and the phases that
  // are there account for every hour.
  assert.ok(totals.phases.length > 1);
  assert.deepEqual(totals.phases.map((row) => row.phase), PHASES.filter((phase) => totals.phases.some((row) => row.phase === phase)));
  assert.equal(totals.phases.reduce((total, row) => total + row.workstreams, 0), plan.workstreams.length);
  assert.equal(Math.round(totals.phases.reduce((total, row) => total + row.hours.likely, 0) * 100) / 100, totals.hours.likely);
});

test('a range is rejected when it is out of order, disagrees with the hours, or was never measured', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validateEstimate(copy, { workPackages });
  };
  assert.ok(broken((p) => { byId(p, 'component-build').hours.low = 1e6; }).some((m) => /expected low 1000000 <= likely/.test(m)));
  assert.ok(broken((p) => { delete byId(p, 'component-build').hours; }).some((m) => /hours: expected \{ low, likely, high \}/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').hours.likely += 10; }).some((m) => /is not the workstream's .* hours/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').hours.spread = 'guesswork'; }).some((m) => /hours.spread: expected one of/.test(m)));
  // The point of the rule: nobody gets to widen a figure that came from no evidence.
  assert.ok(broken((p) => { byId(p, 'component-build').hours.high *= 1.4; }).some((m) => /a rate with no measured spread has no range/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').phase = 'delivery'; }).some((m) => /phase: expected one of discover, design, build, assure, launch, run/.test(m)));
});

test('hours with no rung are rejected, and so is a rung that contradicts its evidence', () => {
  const { plan } = estimated(freshPlan(), 'aem');
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validateEstimate(copy, { workPackages });
  };
  assert.ok(broken((p) => { delete byId(p, 'component-build').rateBasis; }).some((m) => /rateBasis: expected one of cases, cases-adjusted, derived/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').rateBasis = 'vibes'; }).some((m) => /rateBasis: expected one of/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').caseIds = ['C-001']; }).some((m) => /a derived rate came from no case/.test(m)));
  assert.ok(broken((p) => { delete byId(p, 'component-build').rateAccepted; }).some((m) => /records whether the estimator accepted it/.test(m)));
  assert.ok(broken((p) => { delete byId(p, 'component-build').rateQuestion; }).some((m) => /owes the client a question/.test(m)));
  assert.ok(broken((p) => {
    const row = byId(p, 'component-build');
    row.rateBasis = 'cases';
    row.caseIds = ['C-001', 'C-002'];
    row.caseCount = 5;
    delete row.rateAccepted;
  }).some((m) => /caseCount: expected 2/.test(m)));
  assert.ok(broken((p) => {
    const row = byId(p, 'component-build');
    row.rateBasis = 'cases';
    row.caseIds = ['C-001'];
    row.caseCount = 1;
    delete row.rateAccepted;
  }).some((m) => /a rate from cases is evidence and asks nothing/.test(m)));
  assert.ok(broken((p) => {
    const row = byId(p, 'component-build');
    row.rateBasis = 'cases';
    row.caseCount = 0;
    delete row.rateAccepted;
    delete row.rateQuestion;
  }).some((m) => /a rate from cases names the cases it came from/.test(m)));
});

test('no workstream is at zero, with or without requirements or volumes', () => {
  const { plan } = estimated(freshPlan(false));
  const seeded = Array.from(workPackages.values()).filter((e) => e.skillIds !== undefined && kindOf(e) === 'delivery').length;
  assert.equal(plan.workstreams.filter((row) => row.kind === 'delivery').length, seeded);
  assert.equal(plan.workstreams.filter((row) => row.kind === 'overhead').length, 2);
  for (const row of plan.workstreams) {
    assert.ok(row.traditionalHours > 0 && row.aiAssistedHours > 0, row.id);
    assert.ok(row.aiAssistedHours <= row.traditionalHours, row.id);
  }
  assert.deepEqual(validatePlan(plan, { blocks, workPackages }), []);
});

test('an accepted, quoted volume sizes the workstream: volume x hours per unit', () => {
  const plan = freshPlan();
  acceptRequirements(plan, { all: true, now: NOW });
  const { plan: built } = estimated(plan);
  const migration = byId(built, 'content-migration');
  assert.equal(migration.volume, 6400);
  assert.equal(migration.volumeBasis, 'document');
  assert.deepEqual(migration.volumeIds, ['D-001']);
  assert.equal(migration.label, LABELS.document);
  assert.equal(migration.traditionalHours, 6400 * 2);
  assert.equal(migration.aiAssistedHours, 6400 * 1.4, 'the 30% saving, which is the only AI column there is');
  assert.equal(migration.clientQuestion, undefined);
  assert.deepEqual(migration.requirementIds, ['R-001']);
  assert.deepEqual(validatePlan(built, { blocks, workPackages }), []);
});

test('a quoted volume nobody accepted yet does not size the workstream; the placeholder does, and it says so', () => {
  const { plan, warnings } = estimated(freshPlan());
  const migration = byId(plan, 'content-migration');
  assert.equal(migration.volumeBasis, 'placeholder');
  assert.equal(migration.volume, workPackages.get('content-migration').volume);
  assert.equal(migration.label, LABELS.pendingVolume);
  assert.deepEqual(migration.pendingVolumeIds, ['D-001']);
  assert.ok(warnings.some((message) => /content-migration: D-001 \(6400\) is quoted but not accepted/.test(message)));
});

test('a placeholder is labelled, low confidence and carries a client question', () => {
  const { plan } = estimated(freshPlan());
  const noRequirement = byId(plan, 'environments-devops');
  assert.equal(noRequirement.label, LABELS.noRequirement);
  assert.equal(noRequirement.confidence, 'low');
  assert.equal(noRequirement.volume, workPackages.get('environments-devops').volume);
  assert.match(noRequirement.clientQuestion, /Environments and DevOps: how many environments are in scope\? The estimate assumes 3 until this is answered\./);
  const noVolume = byId(plan, 'localization');
  assert.equal(noVolume.label, LABELS.noVolume, 'a requirement is mapped but states no volume the tool accepted');
  assert.deepEqual(noVolume.requirementIds, ['R-002']);
});

test('project management is a share of the work it covers, not a flat placeholder', () => {
  const { plan } = estimated(freshPlan());
  const management = byId(plan, 'project-management');
  assert.equal(management.kind, 'overhead');
  assert.equal(management.share, inputs.shareFallbacks.get('project-management'));
  assert.equal(management.shareBasis, 'fallback');
  assert.equal(management.traditionalHours, round2(management.share * management.shareHours));
  assert.ok(Math.abs(management.aiAssistedHours - management.traditionalHours * 0.7) < 0.02, 'the 30% saving of the catalog');
  assert.equal(management.aiSavingPercent, 30);
  assert.equal(management.label, LABELS.proportional);
  assert.deepEqual(management.requirementIds, []);

  // It is a share of everything that is not itself a share, so the two reporting activities do
  // not size each other, and it covers the QA and UAT sized in the pass before it.
  assert.equal(management.shareOf.includes('delivery-governance'), false);
  assert.ok(management.shareOf.includes('qa-automation'));
  assert.equal(management.shareHours, round2(management.shareOf.reduce((total, id) => total + byId(plan, id).traditionalHours, 0)));
});

test('QA is sized over the engineering build, in the pass before project management', () => {
  const { plan } = estimated(freshPlan());
  const qa = byId(plan, 'qa-automation');
  assert.equal(qa.shareBasis, 'fallback');
  // What it names is what this estimate sized, which is the catalog's set less anything the
  // seed has no rate for yet.
  assert.deepEqual(qa.shareOf, workPackages.get('qa-automation').shareOf.filter((id) => byId(plan, id)));
  assert.ok(qa.shareOf.length > 0);
  assert.equal(qa.shareOf.includes('content-migration'), false, 'QA is a share of the engineering build, not of content');
  assert.ok(byId(plan, 'uat-support').shareOf.includes('content-migration'), 'the client tests migrated content too');
  // Sized before the reporting activities, so project management covers QA rather than the
  // other way round.
  assert.ok(plan.workstreams.findIndex((row) => row.id === 'qa-automation') < plan.workstreams.findIndex((row) => row.id === 'project-management'));
});

test('the skills roll-up adds up to the workstreams, by business category too', () => {
  const { plan } = estimated(freshPlan());
  const totals = estimateTotals(plan);
  const sum = (field) => plan.skills.reduce((total, row) => total + row[field], 0);
  assert.ok(Math.abs(sum('traditionalHours') - totals.traditionalHours) <= 0.25);
  assert.ok(Math.abs(sum('aiAssistedHours') - totals.aiAssistedHours) <= 0.25);
  assert.ok(plan.skills.some((row) => row.category === 'business' && row.skillId === 'seo'));
  const pm = plan.skills.find((row) => row.skillId === 'pm');
  assert.deepEqual(pm.workstreams, ['project-management']);
  assert.equal(pm.traditionalHours, round2(byId(plan, 'project-management').traditionalHours / 2), 'project management hours split evenly with the delivery lead');
});

test('the estimate refuses when no platform is named, but a platform it has never seen costs nothing', () => {
  const plan = freshPlan();
  const aem = estimated(plan, 'aem').plan;
  const eds = estimated(plan, 'aem-eds').plan;
  assert.equal(eds.estimateBasis.platform, 'aem-eds');
  assert.equal(eds.estimateBasis.platformSource, 'documents');
  assert.equal(aem.estimateBasis.platformSource, 'estimator');

  const unnamed = freshPlan();
  delete unnamed.platform;
  assert.throws(() => estimatePlan(unnamed, inputs, { workPackages }), (error) => error instanceof EstimateError && /do not name the platform/.test(error.message));
  // A platform with no cases used to mean a grid of invented rates before a single estimate
  // could run. Now it means every rate lands on the derived rung and says so.
  const aep = estimated(plan, 'aep').plan;
  assert.equal(aep.workstreams.length, aem.workstreams.length);
  assert.ok(aep.workstreams.every((row) => row.rateBasis === 'derived'));
});

test('a platform the estimator chose is kept when the estimate runs again, even if the documents name another', () => {
  const plan = freshPlan();
  estimatePlan(plan, inputs, { platform: 'aem', workPackages, now: NOW });
  assert.equal(plan.estimateBasis.platform, 'aem');
  assert.equal(plan.estimateBasis.platformSource, 'estimator');
  estimatePlan(plan, inputs, { workPackages, now: NOW });
  assert.equal(plan.estimateBasis.platform, 'aem', 'the documents name aem-eds; the estimator chose aem');
  estimatePlan(plan, inputs, { platform: 'aem-eds', workPackages, now: NOW });
  assert.equal(plan.estimateBasis.platformSource, 'documents');
});

test('dismissed requirements are not counted, and unmapped ones are reported, not sized', () => {
  const plan = freshPlan();
  acceptRequirements(plan, { dismiss: ['R-002'], now: NOW });
  plan.requirements[0].workPackage = 'unmapped';
  const { plan: built, warnings } = estimated(plan);
  assert.deepEqual(byId(built, 'localization').requirementIds, []);
  assert.equal(byId(built, 'localization').label, LABELS.noRequirement);
  assert.ok(warnings.some((message) => /1 requirement fit no work package/.test(message)));
});

test('re-estimating replaces only the derived sections', () => {
  const plan = freshPlan();
  acceptRequirements(plan, { all: true, now: NOW });
  const first = estimated(plan).plan;
  const again = JSON.parse(JSON.stringify(first));
  estimatePlan(again, inputs, { workPackages, now: '2026-11-14T00:00:00.000Z' });
  assert.deepEqual(again.requirements, first.requirements);
  assert.deepEqual(again.volumes, first.volumes);
  assert.deepEqual(again.workstreams, first.workstreams);
  assert.equal(again.estimateBasis.builtAt, '2026-11-14T00:00:00.000Z');
});

test('the validator catches hours that are not volume x rate, zero hours, a missing question and a volume from elsewhere', () => {
  const { plan } = estimated(freshPlan());
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validateEstimate(copy, { workPackages });
  };
  assert.deepEqual(validateEstimate(plan, { workPackages }), []);
  assert.ok(broken((p) => { byId(p, 'component-build').traditionalHours = 5; }).some((m) => /traditionalHours: 5 is not volume/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').aiAssistedHours = 0; }).some((m) => /aiAssistedHours: a workstream has hours above zero/.test(m)));
  assert.ok(broken((p) => { delete byId(p, 'environments-devops').clientQuestion; }).some((m) => /clientQuestion/.test(m)));
  assert.ok(broken((p) => { byId(p, 'environments-devops').label = 'quoted'; }).some((m) => /labelled "assumed/.test(m)));
  assert.ok(broken((p) => { byId(p, 'environments-devops').confidence = 'high'; }).some((m) => /low confidence/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').id = 'not-an-activity'; }).some((m) => /not an activity in the estimating catalog/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').id = 'WP-03'; }).some((m) => /WP-03 is retired; it is now "component-build"/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').id = 'WP-04'; }).some((m) => /WP-04 is retired; it split into "component-review" and "accessibility-audit"/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').volumeBasis = 'document'; byId(p, 'component-build').volumeIds = ['D-001']; }).some((m) => /not a volume of component-build/.test(m)));
  assert.ok(broken((p) => { p.skills[0].traditionalHours += 50; }).some((m) => /the skills add up/.test(m)));
  assert.ok(broken((p) => { delete p.estimateBasis; }).some((m) => /estimateBasis/.test(m)));
  assert.ok(broken((p) => { byId(p, 'component-build').requirementIds = ['R-999']; }).some((m) => /requirementIds/.test(m)));
});

test('a share set must name activities that exist, and must not lead back to itself', () => {
  const { plan } = estimated(freshPlan());
  const broken = (change) => {
    const copy = JSON.parse(JSON.stringify(plan));
    change(copy);
    return validateEstimate(copy, { workPackages });
  };
  assert.deepEqual(validateEstimate(plan, { workPackages }), [], 'the catalog resolves in four passes');

  // A set nobody can resolve: an id the catalog does not have, and no set at all.
  assert.ok(broken((p) => { byId(p, 'project-management').shareOf = ['component-build', 'not-an-activity']; })
    .some((m) => /shareOf: not-an-activity is not an activity in the estimating catalog/.test(m)));
  assert.ok(broken((p) => { byId(p, 'project-management').shareOf = []; })
    .some((m) => /shareOf: expected the activities the share was taken over/.test(m)));
  assert.ok(broken((p) => { byId(p, 'project-management').shareOf = ['project-management']; })
    .some((m) => /shareOf: an activity cannot be a share of itself/.test(m)));

  // Two activities each sized over the other: neither can be worked out first.
  assert.ok(broken((p) => {
    byId(p, 'qa-automation').shareOf = ['uat-support'];
    byId(p, 'uat-support').shareOf = ['qa-automation'];
  }).some((m) => /qa-automation is a share of a set that leads back to qa-automation/.test(m)));

  // The loop closes through a third activity rather than directly.
  assert.ok(broken((p) => {
    byId(p, 'qa-automation').shareOf = ['uat-support'];
    byId(p, 'uat-support').shareOf = ['project-management'];
    byId(p, 'project-management').shareOf = ['qa-automation'];
  }).some((m) => /project-management is a share of a set that leads back to project-management/.test(m)));

  // A share of a share is fine as long as it ends somewhere sized: only a loop is a problem.
  assert.equal(
    broken((p) => { byId(p, 'project-management').shareOf = ['qa-automation', 'component-build']; })
      .filter((m) => /leads back to/.test(m)).length,
    0
  );
});

test('work handed to the client leaves the estimate, but the activities sized as a share of it do not shrink', () => {
  const plan = freshPlan();
  estimatePlan(plan, inputs, { platform: 'aem', workPackages, now: NOW });
  const before = { uat: byId(plan, 'uat-support'), pm: byId(plan, 'project-management'), total: estimateTotals(plan).traditionalHours };
  // The catalog already calls UAT shared, and shared is sized at full until a case says otherwise.
  assert.equal(before.uat.owner, 'shared');
  assert.equal(before.uat.wholeHours, before.uat.traditionalHours);
  assert.match(before.uat.ownerQuestion, /How much of it are they doing\?/);

  plan.owners = [{
    activity: 'uat-support',
    owner: 'client',
    note: 'Their own business testers run it.',
    review: { status: 'accepted', via: 'owner', at: NOW }
  }];
  estimatePlan(plan, inputs, { platform: 'aem', workPackages, now: NOW });
  const uat = byId(plan, 'uat-support');
  assert.equal(uat.traditionalHours, 0);
  assert.equal(uat.aiAssistedHours, 0);
  assert.deepEqual(uat.hours, { low: 0, likely: 0, high: 0, spread: 'none' });
  assert.equal(uat.wholeHours, before.uat.wholeHours, 'the activity is still worth what it was worth');
  assert.match(uat.exclusion, /the client is doing it/);

  const pm = byId(plan, 'project-management');
  assert.equal(pm.shareHours, before.pm.shareHours, 'work the client runs still has to be managed');
  assert.equal(pm.traditionalHours, before.pm.traditionalHours);
  assert.equal(estimateTotals(plan).traditionalHours, round2(before.total - before.uat.wholeHours),
    'the total falls by exactly the hours that left, and by nothing else');

  assert.deepEqual(validateEstimate(plan, { workPackages }), []);
  const summary = summarizePlan(plan, workPackages);
  // Everything somebody else has a hand in, which is the shared rows as well as the handover.
  assert.deepEqual(summary.estimate.handedOver.find((row) => row.id === 'uat-support').owner, 'client');
  assert.ok(summary.estimate.handedOver.every((row) => row.owner !== 'us'));
  assert.match(formatSummary(summary, { markdown: true }), /### Who does the work[\s\S]*uat-support UAT support: the client/);
});

test('the validator holds a client-owned row to zero and an owned one to its whole hours', () => {
  const plan = freshPlan();
  estimatePlan(plan, inputs, { platform: 'aem', workPackages, now: NOW });
  const row = byId(plan, 'uat-support');

  row.owner = 'badger';
  assert.ok(validateEstimate(plan, { workPackages }).some((m) => /owner: expected one of us, shared, client/.test(m)));

  row.owner = 'client';
  const asClient = validateEstimate(plan, { workPackages });
  assert.ok(asClient.some((m) => /the estimate carries none of it/.test(m)));
  assert.ok(asClient.some((m) => /exclusion: work handed to the client is named as out of scope/.test(m)));
  assert.ok(asClient.some((m) => /ownerNote: handing work to the client is a decision/.test(m)));

  row.owner = 'us';
  row.exclusion = 'we are doing this really';
  const asOurs = validateEstimate(plan, { workPackages });
  assert.ok(asOurs.some((m) => /so it is not an exclusion/.test(m)));
  delete row.exclusion;
  delete row.ownerQuestion;
  row.wholeHours = row.traditionalHours + 100;
  assert.ok(validateEstimate(plan, { workPackages }).some((m) => /is not the .* hours this estimate carries/.test(m)));
});

test('a not-yet-estimated plan is valid, and an estimate that went stale is a warning, not an error', () => {
  const plan = freshPlan();
  assert.deepEqual(validateEstimate(plan, { workPackages }), []);
  const built = estimated(plan).plan;
  assert.deepEqual(staleWorkstreams(built), []);
  acceptRequirements(built, { all: true, now: NOW });
  assert.deepEqual(validatePlan(built, { blocks, workPackages }), []);
  assert.match(staleWorkstreams(built).join('\n'), /content-migration: volume D-001 \(6400\) is accepted now; the estimate still uses the placeholder/);
  const sized = estimated(built).plan;
  sized.volumes[0].quantity = 7000;
  assert.match(staleWorkstreams(sized).join('\n'), /content-migration: volume D-001 now holds 7000; the estimate uses 6400/);
  assert.deepEqual(validatePlan(sized, { workPackages }), []);
});

test('the summary shows the totals, the stale rows and the assumed volumes with their questions', () => {
  const { plan } = estimated(freshPlan());
  const summary = summarizePlan(plan, workPackages);
  assert.equal(summary.estimate.platform, 'aem-eds');
  assert.equal(summary.estimate.assumed, plan.workstreams.filter((row) => row.volumeBasis === 'placeholder').length);
  const markdown = formatSummary(summary);
  assert.match(markdown, /## Estimate/);
  assert.match(markdown, /### Assumed volumes/);
  assert.match(markdown, /environments-devops Environments and DevOps: 3 environments, assumed, no requirement\./);
  assert.equal(summarizePlan(freshPlan(), workPackages).estimate, undefined);
});

test('a cap is the volume the estimate is for, whether the figure under it was quoted or assumed', () => {
  const quoted = freshPlan();
  acceptRequirements(quoted, { all: true, now: NOW });
  quoted.assumptions = [{ id: 'AS-001', activity: 'content-migration', category: 'scope', cap: 500, note: 'Agreed with the client.', review: { status: 'accepted', via: 'cap', at: NOW } }];
  estimatePlan(quoted, inputs, { platform: 'aem-eds', workPackages, now: NOW });
  const migration = byId(quoted, 'content-migration');
  assert.equal(migration.volume, 500);
  assert.equal(migration.label, 'capped at 500 pages');
  assert.equal(migration.volumeBasis, 'document', 'the cap does not erase where the figure under it came from');
  assert.deepEqual(migration.volumeIds.length > 0, true, 'nor the volume it quoted');
  assert.equal(migration.traditionalHours, round2(500 * migration.hoursPerUnit.traditional));
  assert.deepEqual(validateEstimate(quoted, { workPackages }), []);

  // A placeholder is capped the same way, and stops saying "assumed" once it is a commitment.
  const assumed = freshPlan();
  assumed.assumptions = [{ id: 'AS-001', activity: 'component-build', category: 'scope', cap: 1, note: 'One component only.', review: { status: 'accepted', via: 'cap', at: NOW } }];
  estimatePlan(assumed, inputs, { platform: 'aem-eds', workPackages, now: NOW });
  const build = byId(assumed, 'component-build');
  assert.equal(build.volume, 1);
  assert.equal(build.label, 'capped at 1 component', 'one unit is singular');
  assert.equal(build.volumeBasis, 'placeholder');
  assert.deepEqual(validateEstimate(assumed, { workPackages }), []);
});

test('a cap recorded after the estimate is a stale warning, never an invalid plan', () => {
  const plan = freshPlan();
  acceptRequirements(plan, { all: true, now: NOW });
  estimatePlan(plan, inputs, { platform: 'aem-eds', workPackages, now: NOW });
  const sized = byId(plan, 'content-migration').volume;
  plan.assumptions = [{ id: 'AS-001', activity: 'content-migration', category: 'scope', cap: 500, note: 'Agreed.', review: { status: 'accepted', via: 'cap', at: NOW } }];

  // The estimator records a cap and the workstreams have not caught up yet. That is the whole
  // window between `assume` and `estimate`, and a plan nobody can validate in it is a plan
  // nobody can cap.
  assert.deepEqual(validateEstimate(plan, { workPackages }), []);
  assert.ok(staleWorkstreams(plan).some((m) => new RegExp(`content-migration: capped at 500; the estimate still uses ${sized}`).test(m)));

  estimatePlan(plan, inputs, { platform: 'aem-eds', workPackages, now: NOW });
  assert.deepEqual(staleWorkstreams(plan), [], 'and it is settled once the estimate runs again');
});

test('assume command: records the cap and its reason, and writes no commercial field', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'assume-cli-'));
  try {
    const file = path.join(dir, 'Fabrikam_Plan.json');
    const plan = freshPlan();
    estimatePlan(plan, inputs, { platform: 'aem', workPackages, now: NOW });
    fs.writeFileSync(file, `${JSON.stringify(plan, null, 2)}\n`);
    const run = (...args) => spawnSync(process.execPath, [script, 'assume', file, ...args], { encoding: 'utf8' });
    const read = () => JSON.parse(fs.readFileSync(file, 'utf8'));

    const ok = run('--activity', 'content-migration', '--cap', '5000', '--note', 'The 2019 archive is retired first.');
    assert.equal(ok.status, 0, ok.stderr);
    assert.match(ok.stdout, /content-migration: capped at 5000 \(accepted\)/);
    assert.match(ok.stdout, /run estimate again/, 'the hours do not move until it does');
    assert.deepEqual(read().assumptions, [{
      id: 'AS-001',
      activity: 'content-migration',
      category: 'scope',
      cap: 5000,
      note: 'The 2019 archive is retired first.',
      review: { status: 'accepted', via: 'cap', at: read().updatedAt }
    }]);

    // Scope Cut #2: a cap says how much work, never what it is worth.
    for (const field of ['cost', 'price', 'rate', 'contingency', 'margin', 'budget']) {
      assert.equal(read().assumptions[0][field], undefined, `a cap carries no ${field}`);
      const tampered = read();
      tampered.assumptions[0][field] = 1;
      assert.ok(validatePlan(tampered, { workPackages }).some((m) => new RegExp(`assumptions\\[0\\].${field}: a cap carries no commercial field`).test(m)));
    }

    const again = run('--activity', 'content-migration', '--cap', '4000', '--note', 'They cut it again.');
    assert.match(again.stdout, /content-migration: capped at 4000 \(edited\)/);
    assert.equal(read().assumptions.length, 1, 'one cap per activity');
    assert.equal(read().assumptions[0].id, 'AS-001', 'and it keeps its id');

    const before = fs.readFileSync(file, 'utf8');
    assert.equal(run('--activity', 'content-migration', '--cap', '5000').status, 2, 'a cap carries its reason');
    assert.equal(run('--activity', 'content-migration', '--cap', '0', '--note', 'why').status, 2);
    assert.equal(run('--activity', 'content-migration', '--cap', 'lots', '--note', 'why').status, 2);
    assert.equal(run('--activity', 'not-an-activity', '--cap', '5', '--note', 'why').status, 1);
    // project-management is a share of the activities it covers, so there is no volume to hold down.
    assert.equal(run('--activity', 'project-management', '--cap', '5', '--note', 'why').status, 1);
    assert.equal(fs.readFileSync(file, 'utf8'), before, 'nothing written');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('owner command: records the decision and its reason, refuses an owner nobody can act on', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'owner-cli-'));
  try {
    const file = path.join(dir, 'Fabrikam_Plan.json');
    const plan = freshPlan();
    estimatePlan(plan, inputs, { platform: 'aem', workPackages, now: NOW });
    fs.writeFileSync(file, `${JSON.stringify(plan, null, 2)}\n`);
    const run = (...args) => spawnSync(process.execPath, [script, 'owner', file, ...args], { encoding: 'utf8' });

    const ok = run('--activity', 'uat-support', '--set', 'client', '--note', 'Their testers run it.');
    assert.equal(ok.status, 0, ok.stderr);
    assert.match(ok.stdout, /uat-support: client \(accepted\)/);
    assert.deepEqual(JSON.parse(fs.readFileSync(file, 'utf8')).owners, [{
      activity: 'uat-support',
      owner: 'client',
      note: 'Their testers run it.',
      review: { status: 'accepted', via: 'owner', at: JSON.parse(fs.readFileSync(file, 'utf8')).updatedAt }
    }]);

    const again = run('--activity', 'uat-support', '--set', 'shared', '--note', 'They are only doing half.');
    assert.match(again.stdout, /uat-support: shared \(edited\)/);
    assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).owners.length, 1, 'one decision per activity');

    const before = fs.readFileSync(file, 'utf8');
    assert.equal(run('--activity', 'uat-support', '--set', 'them', '--note', 'why').status, 2);
    assert.equal(run('--activity', 'uat-support', '--set', 'client').status, 2, 'a handover carries its reason');
    assert.equal(run('--activity', 'not-an-activity', '--set', 'client', '--note', 'why').status, 1);
    assert.equal(fs.readFileSync(file, 'utf8'), before, 'nothing written');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('estimate command: writes the sections, keeps the rest, refuses when the platform is not named', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'estimate-cli-'));
  try {
    const file = path.join(dir, 'Fabrikam_Plan.json');
    const plan = freshPlan();
    fs.writeFileSync(file, `${JSON.stringify(plan, null, 2)}\n`);
    const run = (...args) => spawnSync(process.execPath, [script, 'estimate', file, ...args], { encoding: 'utf8' });

    const ok = run();
    assert.equal(ok.status, 0, ok.stderr);
    assert.match(ok.stdout, /traditional \d+(\.\d+)? h, AI-assisted \d+(\.\d+)? h/);
    const written = JSON.parse(fs.readFileSync(file, 'utf8'));
    assert.deepEqual(written.requirements, plan.requirements);
    assert.equal(written.workstreams.length, Array.from(workPackages.values()).filter((e) => e.skillIds !== undefined).length);
    const validated = spawnSync(process.execPath, [script, 'validate', file], { encoding: 'utf8' });
    assert.equal(validated.status, 0, validated.stderr);

    delete plan.platform;
    fs.writeFileSync(file, `${JSON.stringify(plan, null, 2)}\n`);
    const before = fs.readFileSync(file, 'utf8');
    const refused = run();
    assert.equal(refused.status, 1);
    assert.match(refused.stderr, /do not name the platform/);
    assert.equal(fs.readFileSync(file, 'utf8'), before, 'nothing written');
    assert.equal(run('--platform', 'aem').status, 0);
    assert.equal(run('--platform').status, 2, 'a flag with no value is a usage error');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
