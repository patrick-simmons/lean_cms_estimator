import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';
import { assembleWorkingFile } from './assemble-working-file.mjs';
import { capabilitiesFor, parseEstimatingCatalog } from './derive-capabilities.mjs';
import { validateWorkingFileValue } from './validate-working-file.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const catalogMd = readFileSync(join(root, 'docs', 'catalogs', 'estimating-catalog.md'), 'utf8');

const blocks = [
  {
    id: 'src-rfp#p1',
    itemId: 'src-rfp',
    fileName: 'RFP.pdf',
    text: 'Migrate 18,240 pages.',
    location: { kind: 'page', page: 1, section: '1.1' }
  },
  {
    id: 'src-deck#s9',
    itemId: 'src-deck',
    fileName: 'Deck.pptx',
    text: 'Launch with two locales.',
    location: { kind: 'slide', slide: 9 }
  },
  {
    id: 'src-rfp#p2',
    itemId: 'src-rfp',
    fileName: 'RFP.pdf',
    text: 'Launch with four locales.',
    location: { kind: 'page', page: 2 }
  }
];

describe('derive-capabilities', () => {
  it('unions all with aem platform row', () => {
    const { capabilities } = parseEstimatingCatalog(catalogMd);
    const aem = capabilitiesFor(capabilities, 'discovery-audit', 'aem');
    const allOnly = capabilitiesFor(capabilities, 'discovery-audit', null);
    assert.ok(aem.length >= allOnly.length);
    assert.ok(aem.includes('cmk-audit'));
  });

  it('unknown platform uses all row only', () => {
    const { capabilities } = parseEstimatingCatalog(catalogMd);
    const caps = capabilitiesFor(capabilities, 'discovery-audit', 'sitecore');
    const allOnly = capabilitiesFor(capabilities, 'discovery-audit', null);
    assert.deepEqual(caps, allOnly);
  });
});

describe('assemble-working-file', () => {
  it('assigns R-ids, pending review, and catalog capabilities', () => {
    const { working, stats } = assembleWorkingFile({
      extract: {
        requirements: [{
          statement: 'Migrate approximately 18,240 pages.',
          blockIds: ['src-rfp#p1'],
          workPackage: 'content-migration',
          coverage: 'accelerated',
          question: null,
          capabilities: ['invented-capability']
        }],
        platform: { id: 'aem', blockId: 'src-rfp#p1' }
      },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot', runId: 'run-1' }
    });
    assert.equal(working.requirements.length, 1);
    assert.equal(working.requirements[0].id, 'R-001');
    assert.equal(working.requirements[0].review.status, 'pending');
    assert.ok(working.requirements[0].capabilities.includes('cmk-migration-assess'));
    assert.ok(!working.requirements[0].capabilities.includes('invented-capability'));
    assert.equal(working.revision, 0);
    assert.equal(working.estimate, null);
    assert.equal(working.handoff, null);
    assert.equal(stats.droppedNoSource, 0);
    assert.deepEqual(validateWorkingFileValue(working), []);
  });

  it('coerces unknown work packages to unmapped', () => {
    const { working, stats } = assembleWorkingFile({
      extract: {
        requirements: [{
          statement: 'Something odd.',
          blockIds: ['src-rfp#p1'],
          workPackage: 'WP-99',
          coverage: 'human-led',
          question: null
        }],
        platform: { id: null, blockId: null }
      },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(working.requirements[0].workPackage, 'unmapped');
    assert.equal(stats.unknownWorkPackage, 1);
    assert.deepEqual(working.requirements[0].capabilities, []);
  });

  it('downgrades one-source conflict and counts it', () => {
    const { working, stats } = assembleWorkingFile({
      extract: {
        requirements: [{
          statement: 'Conflict with only one surviving source.',
          blockIds: ['src-rfp#p1', 'missing#x'],
          workPackage: 'localization',
          coverage: 'conflict',
          question: 'Which is it?'
        }],
        platform: { id: null, blockId: null }
      },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(stats.conflictDowngraded, 1);
    assert.equal(stats.droppedBlockIds, 1);
    assert.notEqual(working.requirements[0].coverage, 'conflict');
    assert.equal(working.requirements[0].coverage, 'partly'); // localization default
    assert.equal(working.questions.length, 1);
  });

  it('keeps two-source conflict', () => {
    const { working, stats } = assembleWorkingFile({
      extract: {
        requirements: [{
          statement: 'Deck says two locales; RFP says four.',
          blockIds: ['src-deck#s9', 'src-rfp#p2'],
          workPackage: 'localization',
          coverage: 'conflict',
          question: 'Which launch scope?'
        }],
        platform: { id: 'aem-eds', blockId: null }
      },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(stats.conflictDowngraded, 0);
    assert.equal(working.requirements[0].coverage, 'conflict');
    assert.equal(working.requirements[0].sources.length, 2);
    assert.equal(working.platform.id, 'aem-eds');
  });
});
