/**
 * Deterministic local parsing for the offline skill pack (SAPP-013).
 *
 * One source of readers: the Office readers, passage grouper, sniffer and citation labels are the Azure
 * function's own compiled modules (function/dist/src/localParse.js). Nothing here copies them. PDFs are
 * read from their text layer by pdf-text.mjs because Document Intelligence is not available locally.
 * Images are reported as not read: that would need OCR, which this tool does not do.
 */
import { readdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { basename, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { formatPageRanges, readPdfText } from './pdf-text.mjs';
import { isIgnoredName, isSourceCandidate, skipReason } from './source-candidates.mjs';
import * as readers from '../../function/dist/src/localParse.js';

export { isSourceCandidate, skipReason };

export const PARSE_LOCAL_VERSION = '1.1.0';
export const IMAGE_NOT_READ = 'Images need OCR, which the local parse tool does not do. Use the extraction service or supply the text.';
export const SCANNED_PDF = 'No readable text was found. The PDF has no text layer (it may be a scan), and the local tool does no OCR.';
export const ENCRYPTED_PDF = 'The PDF is password protected or encrypted, so it could not be read. Supply an unprotected copy.';
export const LOCAL_BUDGET_MS = 180000;

/** The selection named a file that is missing or outside the project folder. Not a crash: the caller reports it. */
export class SelectionError extends Error {
  constructor(message) {
    super(message);
    this.name = 'SelectionError';
  }
}

/** pdf.js reports a password-protected file as a PasswordException; anything else is treated as damage. */
export function classifyPdfError(error) {
  return error && error.name === 'PasswordException' ? 'encrypted' : 'damaged';
}

/** `src-` plus a slug of the file name without its extension; the caller makes ids unique. */
export function itemIdFor(fileName) {
  const base = readers.baseName(fileName).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return `src-${base || 'file'}`;
}

/**
 * @param {string[]} names file names in the order they were given
 * @returns {Map<string, string>} name to unique item id
 */
export function assignItemIds(names) {
  const used = new Set();
  const ids = new Map();
  for (const name of names) {
    let id = itemIdFor(name);
    let n = 2;
    while (used.has(id)) {
      id = `${itemIdFor(name)}-${n}`;
      n += 1;
    }
    used.add(id);
    ids.set(name, id);
  }
  return ids;
}

function notRead(format, reason) {
  return { format, blocks: [], notRead: [{ reason }] };
}

/**
 * Parse one file's bytes. Mirrors parseFile in function/src/parse.ts without the layout service.
 *
 * @param {Uint8Array} bytes
 * @param {string} fileName
 * @param {string} itemId
 * @param {{ now?: () => number, budgetMs?: number, logFailure?: (detail: string) => void, readPdfText?: typeof readPdfText }} [options]
 *   `readPdfText` replaces the pdf.js reader; it exists so tests can force the failure paths.
 * @returns {Promise<{ format: string, blocks: object[], notRead: object[], totalPages?: number, pagesRead?: string }>}
 */
export async function parseLocalFile(bytes, fileName, itemId, options = {}) {
  const now = options.now || Date.now;
  const logFailure = options.logFailure || (() => undefined);
  const deadline = now() + (options.budgetMs ?? LOCAL_BUDGET_MS);
  const checkBudget = () => {
    if (now() > deadline) {
      throw new readers.UnsafeContentError('budget');
    }
  };
  const kind = readers.sniff(bytes);
  if (kind.kind === 'ole2') {
    return notRead('ole2', readers.LEGACY_OFFICE);
  }
  if (kind.kind === 'unknown') {
    return notRead('unknown', readers.UNSUPPORTED);
  }
  if (kind.kind === 'image') {
    return notRead('image', IMAGE_NOT_READ);
  }
  if (kind.kind === 'zip') {
    return readers.readOffice(bytes, fileName, itemId, checkBudget, logFailure);
  }
  return readLocalPdf(bytes, fileName, itemId, checkBudget, logFailure, options.readPdfText || readPdfText);
}

async function readLocalPdf(bytes, fileName, itemId, checkBudget, logFailure, readText) {
  // pdf-lib's page count is only a hint: it is more forgiving than pdf.js about encryption but stricter
  // about structure, so a count failure alone does not make the file damaged. pdf.js has the final say.
  const counted = await readers.countPdfPages(bytes);
  const hintedTotal = counted.kind === 'ok' ? counted.total : undefined;
  let read;
  try {
    read = await readText(bytes, fileName, itemId, readers, checkBudget);
  } catch (error) {
    const withPages = (entry) => (hintedTotal === undefined ? entry : { ...entry, totalPages: hintedTotal });
    if (error instanceof readers.UnsafeContentError) {
      return withPages({ format: 'pdf', blocks: [], notRead: [{ reason: readers.FILE_TIMEOUT }] });
    }
    logFailure(`pdf text ${error && error.name ? error.name : 'error'}`);
    const reason = classifyPdfError(error) === 'encrypted' ? ENCRYPTED_PDF : readers.DAMAGED;
    return withPages({ format: 'pdf', blocks: [], notRead: [{ reason }] });
  }
  if (counted.kind === 'damaged') {
    logFailure('pdf page count failed; used the pdf.js count');
  }
  const total = read.totalPages;
  const result = { format: 'pdf', blocks: read.blocks, notRead: [], totalPages: total };
  if (read.blocks.length === 0) {
    result.notRead.push({ reason: SCANNED_PDF, pages: `1-${total}` });
    return result;
  }
  // pagesRead is what was actually read: up to the last page that produced a block. A capped read stops
  // before the end, so it must not claim the whole range.
  const lastPage = Math.max(...read.blocks.map((block) => (block.location && block.location.page) || 0));
  result.pagesRead = `1-${read.capped ? lastPage : total}`;
  if (read.capped) {
    result.notRead.push(lastPage < total ? { reason: readers.TEXT_CAP, pages: `${lastPage + 1}-${total}` } : { reason: readers.TEXT_CAP });
  }
  const unreadPages = (read.noTextPages || []).filter((page) => !read.capped || page <= lastPage);
  if (unreadPages.length > 0) {
    const ranges = formatPageRanges(unreadPages);
    const many = unreadPages.length > 1;
    result.notRead.push({
      reason: `${many ? 'Pages' : 'Page'} ${ranges.replace(/,/g, ', ')} ${many ? 'have' : 'has'} no text layer and ${many ? 'were' : 'was'} not read (${unreadPages.length} of ${total} pages). Supply the text for ${many ? 'those pages' : 'that page'}.`,
      pages: ranges
    });
  }
  return result;
}

export function readStateOf(blocks, notRead, pagesRead) {
  if (blocks.length === 0 && pagesRead === undefined) {
    return 'not read';
  }
  return notRead.length === 0 ? 'read' : 'partial';
}

function isInside(root, file) {
  const rel = relative(root, file);
  return rel !== '' && rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
}

/** Resolve one selected name to a file inside the folder, following links before checking containment. */
function resolveSelected(root, realRoot, name) {
  const file = resolve(root, name);
  if (!isInside(root, file)) {
    throw new SelectionError(`${name} is outside the project folder ${root}`);
  }
  let real;
  try {
    real = realpathSync(file);
  } catch {
    throw new SelectionError(`Selected file not found: ${name}`);
  }
  if (!isInside(realRoot, real)) {
    throw new SelectionError(`${name} resolves to a file outside the project folder ${root}`);
  }
  if (!statSync(real).isFile()) {
    throw new SelectionError(`Selected path is not a file: ${name}`);
  }
  return { name: relative(root, file).split(sep).join('/'), path: file };
}

/**
 * List the source files of a project folder (top level only), or check an explicit list.
 *
 * An explicit list, even an empty one, is the whole selection: `[]` means no sources. Only `undefined`
 * means "everything at the top level". Duplicate names are listed once.
 *
 * @param {string} folder
 * @param {string[]} [selected] file names relative to the folder
 * @returns {{ name: string, path: string }[]}
 */
export function listSources(folder, selected) {
  const root = resolve(folder);
  if (selected !== undefined) {
    const realRoot = realpathSync(root);
    const seen = new Map();
    for (const name of selected) {
      const entry = resolveSelected(root, realRoot, name);
      if (!seen.has(entry.name)) {
        seen.set(entry.name, entry);
      }
    }
    return [...seen.values()];
  }
  return scanFolder(root).sources;
}

/**
 * The top level of a folder: the source files, and what was passed over (unsupported file types and
 * subfolders) so that a project whose documents sit in a subfolder is not silently read as empty.
 * Hidden files, the agent bootstrap and Blueprint outputs are never sources and are not reported.
 */
export function scanFolder(folder) {
  const root = resolve(folder);
  const sources = [];
  const skipped = [];
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (!entry.name.startsWith('.')) {
        skipped.push({ name: `${entry.name}/`, reason: 'subfolder: only the top level of the project folder is read. Move the files up or select them.' });
      }
    } else if (entry.isFile()) {
      if (isSourceCandidate(entry.name)) {
        sources.push({ name: entry.name, path: join(root, entry.name) });
      } else if (!isIgnoredName(entry.name)) {
        skipped.push({ name: entry.name, reason: skipReason(entry.name) });
      }
    }
  }
  const byName = (a, b) => a.name.localeCompare(b.name, 'en');
  return { sources: sources.sort(byName), skipped: skipped.sort(byName) };
}

/**
 * Parse every source of a folder and return the Start-quality `sources[]`, all blocks and a manifest.
 *
 * @param {string} folder
 * @param {{ selected?: string[], now?: () => number, log?: (line: string) => void }} [options]
 */
export async function parseSources(folder, options = {}) {
  const log = options.log || (() => undefined);
  const selection = options.selected === undefined ? 'folder' : 'selected';
  const listing = options.selected === undefined ? scanFolder(folder) : { sources: listSources(folder, options.selected), skipped: [] };
  const files = listing.sources;
  const ids = assignItemIds(files.map((file) => file.name));
  const sources = [];
  // The folder is recorded relative to itself: the manifest sits inside the project, and an absolute path
  // would put the estimator's local user name and temp folders into files that get shared and committed.
  const manifest = { tool: 'parse-local', version: PARSE_LOCAL_VERSION, folder: '.', selection, files: [], skipped: listing.skipped };
  for (const file of files) {
    const itemId = ids.get(file.name);
    const fileName = basename(file.name);
    let bytes;
    let stats;
    try {
      stats = statSync(file.path);
      bytes = new Uint8Array(readFileSync(file.path));
    } catch (error) {
      const reason = `The file could not be opened: ${error.code || error.message}.`;
      sources.push(sourceEntry({ itemId, name: fileName, bytes: 0, modified: new Date(0).toISOString(), blocks: [], notRead: [{ reason }] }));
      manifest.files.push({ name: file.name, itemId, read: 'not read', notRead: [{ reason }] });
      log(`not read  ${file.name}: ${reason}`);
      continue;
    }
    const failures = [];
    const parsed = await parseLocalFile(bytes, fileName, itemId, { now: options.now, logFailure: (d) => failures.push(d) });
    const read = readStateOf(parsed.blocks, parsed.notRead, parsed.pagesRead);
    sources.push(sourceEntry({
      itemId,
      name: fileName,
      bytes: stats.size,
      modified: stats.mtime.toISOString(),
      blocks: parsed.blocks,
      notRead: parsed.notRead,
      pagesRead: parsed.pagesRead,
      totalPages: parsed.totalPages
    }));
    manifest.files.push({
      name: file.name,
      itemId,
      format: parsed.format,
      bytes: stats.size,
      read,
      blocks: parsed.blocks.length,
      notRead: parsed.notRead,
      ...(parsed.totalPages !== undefined ? { totalPages: parsed.totalPages } : {}),
      ...(failures.length ? { detail: failures } : {})
    });
    log(`${read.padEnd(9)} ${file.name}: ${parsed.blocks.length} blocks${parsed.notRead.length ? `, ${parsed.notRead.map((n) => n.reason).join(' ')}` : ''}`);
  }
  const blocks = sources.flatMap((source) => source.blocks);
  return { sources, blocks, manifest };
}

function sourceEntry({ itemId, name, bytes, modified, blocks, notRead, pagesRead, totalPages }) {
  const entry = { itemId, name, webUrl: '', bytes, modified, read: readStateOf(blocks, notRead, pagesRead), blocks, notRead };
  if (pagesRead !== undefined) {
    entry.pagesRead = pagesRead;
  }
  if (totalPages !== undefined) {
    entry.totalPages = totalPages;
  }
  return entry;
}
