import assert from 'node:assert/strict';
import { test } from 'node:test';
import { acceptedRates, questionOwed, rateFor } from './rate-ladder.mjs';

const BUILD = { id: 'component-build', name: 'Component build', shape: 'per-unit', unit: 'component' };

function cases(...rows) {
  return rows.map(([caseId, platform, hours, volume]) => ({
    caseId,
    platform,
    activities: [{ activity: 'component-build', hours, volume }]
  }));
}

const THREE_AEM = cases(['C-001', 'aem', 10, 1], ['C-002', 'aem', 20, 1], ['C-003', 'aem', 30, 1]);

test('rung 1 is the only rung that asks nothing', () => {
  assert.equal(questionOwed('cases'), false);
  assert.equal(questionOwed('cases-adjusted'), true);
  assert.equal(questionOwed('derived'), true);
});

test('enough cases on the platform is evidence: no question, and the cases are named', () => {
  const rate = rateFor(THREE_AEM, BUILD, 'aem', 99, undefined);
  assert.equal(rate.rateBasis, 'cases');
  assert.equal(rate.rate, 20);
  assert.equal(rate.caseCount, 3);
  assert.deepEqual(rate.caseIds, ['C-001', 'C-002', 'C-003']);
  assert.equal(rate.rateQuestion, undefined);
  assert.equal(rate.rateAccepted, undefined);
});

test('cases bring their own range; a figure nobody measured brings none', () => {
  const measured = rateFor(THREE_AEM, BUILD, 'aem', 99, undefined);
  assert.deepEqual([measured.rateLow, measured.rate, measured.rateHigh], [15, 20, 25]);
  assert.equal(measured.rateSpread, 'quartiles');

  const thin = rateFor(cases(['C-001', 'aem', 10, 1], ['C-002', 'aem', 30, 1]), BUILD, 'aem', 99, undefined);
  assert.deepEqual([thin.rateLow, thin.rate, thin.rateHigh], [10, 20, 30]);
  assert.equal(thin.rateSpread, 'observed', 'two points are not a distribution, so the range is what was seen');

  const derived = rateFor([], BUILD, 'aem', 12, undefined);
  assert.deepEqual([derived.rateLow, derived.rate, derived.rateHigh], [12, 12, 12]);
  assert.equal(derived.rateSpread, 'none');
});

test('thin evidence still beats the seed, but owes a question that names the cases', () => {
  const rate = rateFor(cases(['C-001', 'aem', 10, 1], ['C-002', 'aem', 30, 1]), BUILD, 'aem', 99, undefined);
  assert.equal(rate.rateBasis, 'cases-adjusted');
  assert.equal(rate.rate, 20);
  assert.match(rate.rateQuestion, /2 past projects \(C-001, C-002\)/);
});

test('cases from another platform say so in the question', () => {
  const rate = rateFor(THREE_AEM, BUILD, 'drupal', 99, undefined);
  assert.equal(rate.rateBasis, 'cases-adjusted');
  assert.match(rate.rateQuestion, /on another platform/);
});

test('no case means the seed figure, marked as nobody has accepted it', () => {
  const rate = rateFor([], BUILD, 'aem', 12, undefined);
  assert.equal(rate.rateBasis, 'derived');
  assert.equal(rate.rate, 12);
  assert.deepEqual(rate.caseIds, []);
  assert.equal(rate.caseCount, 0);
  assert.equal(rate.rateAccepted, false);
  assert.match(rate.rateQuestion, /nobody has accepted a rate yet/);
});

test('an accepted decision replaces the seed figure and changes what the question asks', () => {
  const rate = rateFor([], BUILD, 'aem', 12, { activity: 'component-build', hoursPerUnit: 18 });
  assert.equal(rate.rate, 18);
  assert.equal(rate.rateBasis, 'derived');
  assert.equal(rate.rateAccepted, true);
  assert.match(rate.rateQuestion, /the rate is one we set rather than measured/);
});

test('evidence outranks an accepted rate: a decision does not override a measurement', () => {
  const rate = rateFor(THREE_AEM, BUILD, 'aem', 12, { activity: 'component-build', hoursPerUnit: 18 });
  assert.equal(rate.rateBasis, 'cases');
  assert.equal(rate.rate, 20);
});

test('only an accepted or edited rate counts as a decision', () => {
  const plan = {
    rates: [
      { activity: 'a', hoursPerUnit: 1, review: { status: 'accepted' } },
      { activity: 'b', hoursPerUnit: 2, review: { status: 'edited' } },
      { activity: 'c', hoursPerUnit: 3, review: { status: 'pending' } },
      { activity: 'd', hoursPerUnit: 4, review: { status: 'dismissed' } },
      { activity: 'e', hoursPerUnit: 5 }
    ]
  };
  assert.deepEqual([...acceptedRates(plan).keys()], ['a', 'b']);
});

test('a plan with no rates has no decisions, rather than failing', () => {
  assert.equal(acceptedRates({}).size, 0);
});
