/**
 * Fills a template workbook (.xlsx) the way the estimate workbook needs it, with fflate and no spreadsheet library,
 * so the tool ships in the skill pack as one bundled file.
 *
 * It opens the template as a zip and rewrites only two things:
 *  - the `sheetData` of a data sheet: row 1 (the template's header) is kept as it is, every row below it is
 *    replaced by the rows given, written as inline strings and numbers;
 *  - the cell a defined name points at, keeping that cell's style.
 * Every other part of the package (styles, formulas, other sheets, widths, freeze panes, defined names) is left
 * as it is. The workbook is marked to recalculate in full when it is opened, because the formulas of the template
 * hold no values until Excel computes them.
 *
 * Rules for what is written (docs/spfx/workbook-template.md):
 *  - a string is always text, never a formula, even when it starts with `=`; a number is a number;
 *  - a cell holds at most 32,767 characters and no character XML cannot carry;
 *  - a written cell takes the style its column has in the template (number format, wrapping), because a cell
 *    without a style would otherwise ignore the column's.
 */
import { strFromU8, strToU8, unzipSync, zipSync } from 'fflate';

export const MAX_CELL_CHARACTERS = 32767;
export const MAX_ROWS = 1048576;

export class XlsxFillError extends Error {}

/** 1 -> A, 27 -> AA */
export function columnLetters(index) {
  let n = index;
  let out = '';
  while (n > 0) {
    const rest = (n - 1) % 26;
    out = String.fromCharCode(65 + rest) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

function columnIndex(letters) {
  let n = 0;
  for (const ch of letters) {
    n = n * 26 + (ch.charCodeAt(0) - 64);
  }
  return n;
}

function decodeXml(text) {
  return text.replace(/&(lt|gt|quot|apos|amp);/g, (whole, name) => ({ lt: '<', gt: '>', quot: '"', apos: "'", amp: '&' }[name]));
}

/** XML 1.0 forbids most control characters, even escaped. */
const FORBIDDEN = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g;

export function escapeText(value) {
  const clean = String(value).replace(FORBIDDEN, '').slice(0, MAX_CELL_CHARACTERS);
  return clean.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function readAttributes(tag) {
  const out = {};
  for (const match of tag.matchAll(/([\w:]+)="([^"]*)"/g)) {
    out[match[1]] = match[2];
  }
  return out;
}

/** Style index of each column the template styles: Map<columnIndex, styleIndex>. */
function columnStyles(sheetXml) {
  const styles = new Map();
  const cols = /<cols>([\s\S]*?)<\/cols>/.exec(sheetXml);
  if (!cols) {
    return styles;
  }
  for (const match of cols[1].matchAll(/<col\b[^>]*\/?>/g)) {
    const attributes = readAttributes(match[0]);
    if (attributes.style === undefined) {
      continue;
    }
    for (let column = Number(attributes.min); column <= Number(attributes.max); column += 1) {
      styles.set(column, attributes.style);
    }
  }
  return styles;
}

function cellXml(reference, value, style) {
  const s = style === undefined ? '' : ` s="${style}"`;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) {
      throw new XlsxFillError(`${reference}: ${value} is not a number a workbook can hold`);
    }
    return `<c r="${reference}"${s}><v>${value}</v></c>`;
  }
  if (value === null || value === undefined || value === '') {
    return style === undefined ? '' : `<c r="${reference}"${s}/>`;
  }
  return `<c r="${reference}"${s} t="inlineStr"><is><t xml:space="preserve">${escapeText(value)}</t></is></c>`;
}

function rowsXml(rows, styles, firstRow) {
  return rows.map((row, offset) => {
    const number = firstRow + offset;
    const cells = row.map((value, index) => cellXml(`${columnLetters(index + 1)}${number}`, value, styles.get(index + 1))).join('');
    return `<row r="${number}">${cells}</row>`;
  }).join('');
}

/** The `<sheet>` entries of the workbook, with the part each one lives in. */
function sheetParts(files) {
  const workbook = strFromU8(files['xl/workbook.xml']);
  const rels = strFromU8(files['xl/_rels/workbook.xml.rels']);
  const targets = new Map();
  for (const match of rels.matchAll(/<Relationship\b[^>]*\/?>/g)) {
    const attributes = readAttributes(match[0]);
    targets.set(attributes.Id, attributes.Target);
  }
  const parts = new Map();
  for (const match of workbook.matchAll(/<sheet\b[^>]*\/?>/g)) {
    const attributes = readAttributes(match[0]);
    const target = targets.get(attributes['r:id']);
    if (target) {
      parts.set(decodeXml(attributes.name), target.startsWith('/') ? target.slice(1) : `xl/${target}`);
    }
  }
  return { workbook, parts };
}

function definedNames(workbookXml) {
  const names = new Map();
  for (const match of workbookXml.matchAll(/<definedName\b([^>]*)>([^<]*)<\/definedName>/g)) {
    const attributes = readAttributes(match[1]);
    const ref = /^(?:'((?:[^']|'')+)'|([^!']+))!\$?([A-Z]+)\$?(\d+)$/.exec(decodeXml(match[2]).trim());
    if (attributes.name && ref) {
      names.set(attributes.name, { sheet: (ref[1] ? ref[1].replace(/''/g, "'") : ref[2]), column: columnIndex(ref[3]), row: Number(ref[4]) });
    }
  }
  return names;
}

function fillRows(sheetXml, sheetName, rows) {
  if (rows.length + 1 > MAX_ROWS) {
    throw new XlsxFillError(`${sheetName}: ${rows.length} rows do not fit on a sheet`);
  }
  const styles = columnStyles(sheetXml);
  const open = sheetXml.indexOf('<sheetData');
  const selfClosing = /<sheetData\s*\/>/.exec(sheetXml);
  let before;
  let inner = '';
  let after;
  if (selfClosing) {
    before = sheetXml.slice(0, selfClosing.index);
    after = sheetXml.slice(selfClosing.index + selfClosing[0].length);
  } else {
    const close = sheetXml.indexOf('</sheetData>');
    if (open < 0 || close < 0) {
      throw new XlsxFillError(`${sheetName}: the template sheet has no sheetData`);
    }
    before = sheetXml.slice(0, open);
    inner = sheetXml.slice(sheetXml.indexOf('>', open) + 1, close);
    after = sheetXml.slice(close + '</sheetData>'.length);
  }
  const header = /<row\b[^>]*\br="1"[^>]*>[\s\S]*?<\/row>|<row\b[^>]*\br="1"[^>]*\/>/.exec(inner);
  const width = Math.max(1, ...rows.map((row) => row.length));
  const headerWidth = header ? Math.max(1, ...Array.from(header[0].matchAll(/<c r="([A-Z]+)1"/g), (match) => columnIndex(match[1]))) : 1;
  const lastRow = rows.length + 1;
  const dimension = `<dimension ref="A1:${columnLetters(Math.max(width, headerWidth))}${lastRow}"/>`;
  const next = `${before}<sheetData>${header ? header[0] : ''}${rowsXml(rows, styles, 2)}</sheetData>${after}`;
  return /<dimension\b[^>]*\/>/.test(next) ? next.replace(/<dimension\b[^>]*\/>/, dimension) : next;
}

function fillCell(sheetXml, sheetName, name, at, value) {
  const pattern = new RegExp(`<c r="${columnLetters(at.column)}${at.row}"((?:\\s+[\\w:]+="[^"]*")*)\\s*(?:/>|>[\\s\\S]*?</c>)`);
  const found = pattern.exec(sheetXml);
  if (!found) {
    throw new XlsxFillError(`${sheetName}: the cell ${columnLetters(at.column)}${at.row} behind the name ${name} is not in the template`);
  }
  const style = readAttributes(found[1]).s;
  return sheetXml.replace(pattern, () => cellXml(`${columnLetters(at.column)}${at.row}`, value, style) || `<c r="${columnLetters(at.column)}${at.row}"${style === undefined ? '' : ` s="${style}"`}/>`);
}

/**
 * @param {Uint8Array} template the .xlsx bytes
 * @param {{ sheets: Record<string, Array<Array<string | number | null>>>, names: Record<string, string | number> }} content
 * @returns {Uint8Array}
 */
export function fillWorkbook(template, { sheets, names }) {
  let files;
  try {
    files = unzipSync(template);
  } catch (error) {
    throw new XlsxFillError(`the template is not a workbook: ${error.message}`);
  }
  for (const key of Object.keys(files)) {
    if (key.endsWith('/')) {
      delete files[key];
    }
  }
  for (const part of ['xl/workbook.xml', 'xl/_rels/workbook.xml.rels']) {
    if (!files[part]) {
      throw new XlsxFillError(`the template is not a workbook: ${part} is missing`);
    }
  }
  const { workbook, parts } = sheetParts(files);
  const known = definedNames(workbook);

  const missing = [...Object.keys(sheets).filter((sheet) => !parts.has(sheet)), ...Object.keys(names).filter((name) => !known.has(name)).map((name) => `the name ${name}`)];
  if (missing.length > 0) {
    throw new XlsxFillError(`the template lacks ${missing.join(', ')}`);
  }

  const touched = new Map();
  const read = (sheet) => touched.get(sheet) ?? strFromU8(files[parts.get(sheet)]);
  for (const [sheet, rows] of Object.entries(sheets)) {
    touched.set(sheet, fillRows(read(sheet), sheet, rows));
  }
  for (const [name, value] of Object.entries(names)) {
    const at = known.get(name);
    if (!parts.has(at.sheet)) {
      throw new XlsxFillError(`the name ${name} points at ${at.sheet}, which the template does not have`);
    }
    touched.set(at.sheet, fillCell(read(at.sheet), at.sheet, name, at, value));
  }
  for (const [sheet, xml] of touched) {
    files[parts.get(sheet)] = strToU8(xml);
  }

  // Recalculate everything on open, and drop a calculation chain that no longer matches.
  let nextWorkbook = workbook;
  if (/<calcPr\b[^>]*\/>/.test(nextWorkbook)) {
    nextWorkbook = nextWorkbook.replace(/<calcPr\b([^>]*?)\s*\/>/, (whole, attributes) => (/fullCalcOnLoad=/.test(attributes) ? whole : `<calcPr${attributes} fullCalcOnLoad="1"/>`));
  } else {
    nextWorkbook = nextWorkbook.replace('</workbook>', '<calcPr fullCalcOnLoad="1"/></workbook>');
  }
  files['xl/workbook.xml'] = strToU8(nextWorkbook);
  if (files['xl/calcChain.xml']) {
    delete files['xl/calcChain.xml'];
    files['xl/_rels/workbook.xml.rels'] = strToU8(strFromU8(files['xl/_rels/workbook.xml.rels']).replace(/<Relationship\b[^>]*calcChain[^>]*\/>/g, ''));
    files['[Content_Types].xml'] = strToU8(strFromU8(files['[Content_Types].xml']).replace(/<Override\b[^>]*calcChain[^>]*\/>/g, ''));
  }
  return zipSync(files, { level: 6 });
}
