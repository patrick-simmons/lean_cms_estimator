/**
 * The estimate model (stage 3): every workstream for the platform has hours, whether or not a requirement
 * names it.
 *
 * What it does, and what it never does:
 *  - A workstream is an activity of the estimating catalog. There is no second class of them.
 *  - Hours of an activity are volume x hours per unit. The hours per unit come from the rate ladder
 *    (rate-ladder.mjs): past projects where they cover the activity, otherwise the catalog's starting figure,
 *    labelled `derived` and carrying a question. The volume is an accepted (or edited) volume of the plan,
 *    which quotes the documents; without one it is the catalog's assumed volume, labelled as assumed and
 *    given a client question.
 *  - A proportional activity is not sized that way at all: it is a share of the activities it covers.
 *  - AI-assisted hours are the rate less the activity's AI saving percentage, which applies only while the
 *    AI plan (ai-plan.mjs) has a capability for the workstream ON. The percentage is the catalog owner's
 *    figure; this file adds none.
 *  - Skills: each workstream's hours are split evenly over its default skill list and added up per skill.
 *
 * It never reads a requirement statement for a number and never invents a figure: every number is a volume
 * from the plan, a past project, or a starting figure the catalog marks as one nobody has measured.
 */
import fs from 'node:fs';
import path from 'node:path';
import { deriveShare } from '../cases/derive.mjs';
import { validateCase } from '../cases/validate.mjs';
import { bandFor, BANDS, loadTierSignals } from './band.mjs';
import { ownerDecisions, OWNERS, ownershipOf } from './ownership.mjs';
import { loadShareFallbacks, proportionalPasses, referenceSetOf } from './proportional.mjs';
import { loadSeed, parseCsv, SEED_DIR } from '../factors/seed.mjs';
import { replacementFor } from './activity-ids.mjs';
import { acceptedRates, questionOwed, rateFor, RATE_BASES } from './rate-ladder.mjs';

const ACTIVITY_ID = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;

/** The case library the estimate derives rates from. */
export const CASES_DIR = path.join(path.dirname(SEED_DIR), '..', '..', 'cases');

/** Where the figures an estimate falls back on live, for error messages that say where to go. */
const CATALOG_FIGURES = 'the estimating catalog, Starting figures';
/** The most an AI saving can take off a rate: a workstream never drops to zero hours. */
export const MAX_AI_SAVING_PERCENT = 90;
export const CONFIDENCES = ['low', 'medium', 'high'];
export const VOLUME_BASES = ['document', 'placeholder'];
export const WORKSTREAM_KINDS = ['delivery', 'overhead'];

/**
 * Delivery work, or the running of the project. The seed used to say which; now it follows from
 * the catalog, because the only activities that are neither sized nor scheduled against the work
 * itself are the two that are a share of all of it and sit in Run.
 */
export function kindOf(catalogEntry) {
  return catalogEntry.shape === 'proportional' && catalogEntry.phase === 'run' ? 'overhead' : 'delivery';
}
/** Where a three-point range came from: the quartiles of the cases, their whole span, or nowhere. */
export const SPREADS = ['quartiles', 'observed', 'none'];
/** Where a proportional activity's share came from. `fallback` is a published ratio, not our data. */
export const SHARE_BASES = ['cases', 'cases-adjusted', 'fallback'];
export const SHARE_FALLBACKS_FILE = 'proportional-fallbacks.json';

/** The labels a placeholder workstream carries into the workbook. */
export const LABELS = {
  document: 'quoted in the documents',
  noRequirement: 'assumed, no requirement',
  noVolume: 'assumed, no volume in the documents',
  pendingVolume: 'assumed, quoted volume not accepted yet',
  proportional: 'assumed, sized as a share of other activities'
};

/**
 * The volume label of an activity the estimator capped. It replaces the label the volume would
 * otherwise carry, because once there is a cap that is where the figure came from: a quoted
 * volume the estimator capped is no longer simply quoted, and a placeholder they capped is no
 * longer simply assumed. Story B-19.
 */
export const capLabel = (cap, unit) => `capped at ${cap} ${unit}${cap === 1 ? '' : 's'}`;

/** The estimator's cap on each activity, by activity id. */
export function capsOf(plan) {
  const caps = new Map();
  for (const row of Array.isArray(plan.assumptions) ? plan.assumptions : []) {
    if (isObject(row) && text(row.activity) && typeof row.cap === 'number') {
      caps.set(row.activity, row);
    }
  }
  return caps;
}

/** Hours from the volumes and factors add up to the skill roll-up within this many hours (rounding only). */
const ROLLUP_TOLERANCE = 0.25;
const HOURS_TOLERANCE = 0.01;

/** What a workstream may use when there is no AI plan yet: everything. */
const ALL_ELIGIBLE = { tools: true };
export const AI_COLUMNS = ['methods', 'opt-in', 'percent', 'base'];

export class EstimateError extends Error {}

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function text(value) {
  return typeof value === 'string' && value.trim() !== '';
}

export function round2(value) {
  return Math.round(value * 100) / 100;
}

function reviewOf(item) {
  return isObject(item) && isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
}

function optionalNumber(raw, where) {
  const cell = (raw ?? '').trim();
  if (cell === '') {
    return null;
  }
  const value = Number(cell);
  if (!Number.isFinite(value) || value <= 0) {
    throw new EstimateError(`${where}: "${cell}" is not a number above zero`);
  }
  return value;
}

// ---------------------------------------------------------------------------------------------------------
// Inputs

/**
 * The case library, or an empty one. Reading an invalid case would put hours in the estimate
 * that `cases.mjs validate` would reject, so a broken library stops the estimate rather than
 * quietly sizing part of it.
 */
export function loadCases(casesDir = CASES_DIR) {
  if (!fs.existsSync(casesDir)) {
    return [];
  }
  const cases = [];
  for (const name of fs.readdirSync(casesDir).filter((file) => file.endsWith('.json')).sort()) {
    const file = path.join(casesDir, name);
    let value;
    try {
      value = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (error) {
      throw new EstimateError(`${name}: not valid JSON (${error.message})`);
    }
    const problems = validateCase(value, path.basename(name, '.json'));
    if (problems.length > 0) {
      throw new EstimateError(`${name}: ${problems[0]} (run npm run cases:validate)`);
    }
    cases.push(value);
  }
  return cases;
}

/**
 * Read what the estimate needs that is not the plan: the skills, the case library, the tier
 * signals and the fallback shares. The hours themselves come from the cases, and the figures
 * an estimate falls back on before it has any come from the estimating catalog.
 * @returns {{ skills: Map<string, object>, cases: object[], signals: Map<string, object[]>,
 *   shareFallbacks: Map<string, number> }}
 */
export function loadModelInputs(seedDir = SEED_DIR, casesDir = CASES_DIR) {
  const sheets = Object.fromEntries(loadSeed(seedDir).map((sheet) => [sheet.name, sheet]));
  const skills = new Map();
  for (const row of sheets.Skills.rows) {
    skills.set(row[0].trim(), { skillId: row[0].trim(), name: row[1].trim(), category: row[2].trim() });
  }
  return { skills, cases: loadCases(casesDir), signals: loadTierSignals(), shareFallbacks: loadShareFallbacks() };
}

/**
 * The catalog's Starting figures for one activity, checked. An activity with no row is not
 * sized at all, which is the caller's business; a row that is there has to be usable.
 */
function startingFigures(id, entry, shape, skills) {
  const where = `${CATALOG_FIGURES}: ${id}`;
  const { aiSavingPercent, skillIds } = entry;
  if (!Number.isFinite(aiSavingPercent) || aiSavingPercent < 0 || aiSavingPercent > MAX_AI_SAVING_PERCENT) {
    throw new EstimateError(`${where}: AI saving must be a number from 0 to ${MAX_AI_SAVING_PERCENT} (0 means the activity claims none)`);
  }
  if (skillIds.length === 0) {
    throw new EstimateError(`${where}: a default skill list is required`);
  }
  if (new Set(skillIds).size !== skillIds.length) {
    throw new EstimateError(`${where}: a skill is listed twice`);
  }
  for (const skillId of skillIds) {
    if (!skills.has(skillId)) {
      throw new EstimateError(`${where}: skill "${skillId}" is not on skills.csv`);
    }
  }
  // A proportional activity is sized by its share, so a starting figure for it would be a
  // number nothing reads. Every other shape needs both to produce hours at all.
  const sizedByShare = shape === 'proportional';
  if (sizedByShare !== (entry.hoursPerUnit === null)) {
    throw new EstimateError(sizedByShare
      ? `${where}: a proportional activity takes its hours from its share, so starting hours are a dash`
      : `${where}: starting hours are required, or the activity has no row here at all`);
  }
  if (sizedByShare !== (entry.volume === null)) {
    throw new EstimateError(sizedByShare
      ? `${where}: a proportional activity has no volume, so its assumed volume is a dash`
      : `${where}: an assumed volume is required, or the activity has no row here at all`);
  }
  if (!sizedByShare && !(entry.hoursPerUnit > 0 && entry.volume > 0)) {
    throw new EstimateError(`${where}: starting hours and assumed volume are above zero`);
  }
  return entry;
}

// ---------------------------------------------------------------------------------------------------------
// Build

/**
 * The two hours per unit of a workstream: the rate the ladder resolved, and that rate less the
 * activity's AI saving percentage. The saving applies only while the AI plan has a capability
 * for the workstream ON; with no AI plan yet, it is allowed.
 *
 * There is one saving mechanism, not three. `factors.csv` carried separate rate columns for
 * opt-in tools and delivery methods, which meant the catalog owner maintaining the same rate
 * three times over for every platform. Splitting the one percentage into the IP and GenAI
 * tracks is stage E's job, and it splits a number rather than reintroducing a grid.
 */
export function ratesOf(rate, eligible = ALL_ELIGIBLE, savingPercent = 0) {
  return savingPercent > 0 && eligible.tools
    ? { traditional: rate, aiAssisted: percentRate(rate, savingPercent) }
    : { traditional: rate, aiAssisted: rate };
}

/** A rate less a percentage, to six decimals, so the hours the workstream stores are volume x this rate. */
export function percentRate(rate, savingPercent) {
  return Math.round(rate * (1 - savingPercent / 100) * 1e6) / 1e6;
}

/** Hours of a workstream: the volume times the stored rate, to two decimals. */
export function hoursOf(volume, rate) {
  return round2(volume * rate);
}

/** The phases of the estimating catalog, in the order work happens. */
export const PHASES = ['discover', 'design', 'build', 'assure', 'launch', 'run'];

/**
 * The three-point hours of a workstream (story B-08).
 *
 * The range is on the delivered hours, because that is what the cases measured. The AI-assisted
 * figure is a projection off the likely rate and carries no range of its own: a projection of a
 * range is two uncertainties multiplied together and shown as one number, which reads as more
 * precision than there is.
 */
function threePointOf(volume, ladder) {
  return {
    low: hoursOf(volume, ladder.rateLow),
    likely: hoursOf(volume, ladder.rate),
    high: hoursOf(volume, ladder.rateHigh),
    spread: ladder.rateSpread
  };
}

function volumesOf(plan, workPackageId) {
  const held = (Array.isArray(plan.volumes) ? plan.volumes : []).filter((volume) => isObject(volume) && volume.workPackageId === workPackageId);
  return {
    usable: held.filter((volume) => ['accepted', 'edited'].indexOf(reviewOf(volume)) !== -1),
    pending: held.filter((volume) => reviewOf(volume) === 'pending')
  };
}

function clientQuestionFor(name, unit, volume) {
  return `${name}: how many ${unit === 'fixed' ? 'units' : `${unit}s`} are in scope? The estimate assumes ${volume} until this is answered.`;
}

/**
 * The hours an activity contributes, once ownership is applied.
 *
 * `wholeHours` is the activity sized as if we did all of it, and it stays on the row whoever
 * owns it: it is what a proportional activity is a share of, and it is the figure the client
 * question carries. `traditionalHours` is our portion, which is what the estimate adds up.
 */
function ownedHours(activity, catalogOwner, decision, sized, volume) {
  const whole = sized.traditional;
  // ourPortion is how the hours below were worked out rather than a fact about the plan, so it
  // does not go on the row: the owner and the hours say everything a reader needs.
  const { ourPortion, ...ownership } = ownershipOf(activity, catalogOwner, decision, whole, volume);
  const take = (value) => round2(value * ourPortion);
  return {
    traditionalHours: take(sized.traditional),
    aiAssistedHours: take(sized.aiAssisted),
    hours: {
      low: take(sized.three.low),
      likely: take(sized.three.likely),
      high: take(sized.three.high),
      spread: ourPortion === 0 ? 'none' : sized.three.spread
    },
    wholeHours: whole,
    ...ownership
  };
}

function shareQuestionFor(name, share, basis, caseIds) {
  if (basis === 'fallback') {
    return `${name}: no past project records what share of the work this took, so the estimate uses a published ${Math.round(share * 1000) / 10}% until one does. Does that match how this programme is run?`;
  }
  return `${name}: ${Math.round(share * 1000) / 10}% comes from ${caseIds.length} past project${caseIds.length === 1 ? '' : 's'} (${caseIds.join(', ')}), which is thin. Is this programme run like those?`;
}

/**
 * One proportional activity, sized over the activities already sized.
 *
 * The share applies to the traditional hours, and the AI-assisted figure is then built from it
 * the way every other workstream's is. Sizing the AI column off the reference set's AI column
 * instead would make this activity's saving a consequence of everyone else's, which is a
 * different claim from the one the AI plan is making.
 */
function proportionalWorkstream({ id, catalogEntry, entry, references, sized, cases, shareFallbacks, platform, eligible, requirementIds, owner }) {
  const covered = references.map((reference) => sized.get(reference)).filter(Boolean);
  // The whole activity, not our portion of it: work the client is doing still has to be
  // managed and governed, so a client-run UAT must not shrink project management.
  const over = round2(covered.reduce((total, row) => total + row.wholeHours, 0));
  const fromCases = deriveShare(cases, { id }, references, platform);
  const fallbackShare = shareFallbacks.get(id);
  if (!fromCases && fallbackShare === undefined) {
    throw new EstimateError(`${id} is a share of other activities, but no case covers it and ${SHARE_FALLBACKS_FILE} has no fallback share for it. Add one.`);
  }
  const share = fromCases ? fromCases.likely : fallbackShare;
  const shareBasis = fromCases ? fromCases.basis : 'fallback';
  const rates = ratesOf(round2(share * over), eligible, entry.aiSavingPercent);
  const band = (fraction) => round2(fraction * over);
  return {
    id,
    name: catalogEntry.name,
    kind: kindOf(catalogEntry),
    phase: catalogEntry.phase,
    unit: 'fixed',
    volume: 1,
    volumeBasis: 'placeholder',
    volumeIds: [],
    label: LABELS.proportional,
    aiSavingPercent: entry.aiSavingPercent,
    hoursPerUnit: rates,
    ...ownedHours(
      { id, name: catalogEntry.name, unit: 'fixed' },
      catalogEntry.owner,
      owner,
      {
        traditional: hoursOf(1, rates.traditional),
        aiAssisted: hoursOf(1, rates.aiAssisted),
        three: fromCases
          ? { low: band(fromCases.low), likely: band(fromCases.likely), high: band(fromCases.high), spread: fromCases.spread }
          : { low: band(share), likely: band(share), high: band(share), spread: 'none' }
      },
      1
    ),
    share,
    shareBasis,
    // What the share was actually taken over, so a reader can add the denominator up rather
    // than infer it. An activity the catalog names but this estimate never sized is not in it:
    // a share cannot be a share of hours that are not there.
    shareOf: covered.map((row) => row.id),
    shareHours: over,
    rateBasis: shareBasis === 'fallback' ? 'derived' : shareBasis,
    caseIds: fromCases ? fromCases.caseIds : [],
    caseCount: fromCases ? fromCases.n : 0,
    ...(shareBasis === 'fallback' ? { rateAccepted: false } : {}),
    ...(shareBasis === 'cases' ? {} : { rateQuestion: shareQuestionFor(catalogEntry.name, share, shareBasis, fromCases ? fromCases.caseIds : []) }),
    confidence: shareBasis === 'cases' ? 'high' : 'low',
    requirementIds,
    skills: entry.skillIds
  };
}

/**
 * The workstreams and the skills roll-up for a plan.
 *
 * @param {object} plan a valid plan
 * @param {{ factors: object[], skills: Map<string, object>, defaults: Map<string, object> }} inputs from loadModelInputs
 * @param {{ platform: string, workPackages: Map<string, { name: string, unit: string }>,
 *   eligibility?: Map<string, { methods: boolean, optIn: boolean }> }} options `eligibility` comes from the AI plan
 * @returns {{ workstreams: object[], skills: object[], warnings: string[] }}
 */
export function buildEstimate(plan, inputs, { platform, workPackages, eligibility }) {
  const { skills, cases = [], signals, shareFallbacks = new Map() } = inputs;
  const accepted = acceptedRates(plan);
  const owners = ownerDecisions(plan);
  const caps = capsOf(plan);
  const warnings = [];
  const live = (Array.isArray(plan.requirements) ? plan.requirements : []).filter((row) => reviewOf(row) !== 'dismissed');
  const unmapped = live.filter((row) => row.workPackage === 'unmapped').length;
  if (unmapped > 0) {
    warnings.push(`${unmapped} requirement${unmapped === 1 ? '' : 's'} fit no work package and ${unmapped === 1 ? 'is' : 'are'} not sized.`);
  }

  const workstreams = [];
  const unrated = [];
  for (const [id, catalogEntry] of Array.from(workPackages.entries()).sort(([a], [b]) => a.localeCompare(b))) {
    // A proportional activity is a share of the ones sized here, so it cannot be sized in the
    // same pass as them. It is picked up after this loop.
    if (catalogEntry.shape === 'proportional') {
      continue;
    }
    // The catalog names more activities than it has starting figures for. One with no row is
    // not estimated yet, and saying so beats guessing a number for it.
    if (catalogEntry.skillIds === undefined) {
      unrated.push(id);
      continue;
    }
    const fallback = startingFigures(id, catalogEntry, catalogEntry.shape, skills);
    // A tiered activity has no unit, so it is sized as whole hours over a volume of 1 until a
    // complexity band sizes it. That is B-09's half of the job.
    const unit = catalogEntry.unit || 'fixed';
    const requirementIds = live.filter((row) => row.workPackage === id).map((row) => row.id);
    const { usable, pending } = volumesOf(plan, id);
    const eligible = eligibility ? eligibility.get(id) || { tools: false } : undefined;
    // A tiered activity is sized by how complicated the work is, not by a volume, so the band
    // is read from the documents here. It records what the documents say; the hours behind a
    // band come from cases, which is B-10's half of the job.
    const banding = catalogEntry.shape === 'tiered' && signals
      ? bandFor(plan, id, signals, catalogEntry.name)
      : undefined;
    const ladder = rateFor(cases, { ...catalogEntry, id }, platform, fallback.hoursPerUnit, accepted.get(id));
    const rates = ratesOf(ladder.rate, eligible, fallback.aiSavingPercent);

    let volume;
    let basis;
    let label;
    let volumeIds = [];
    let extra = {};
    if (usable.length > 0) {
      volume = usable[0].quantity;
      basis = 'document';
      label = LABELS.document;
      volumeIds = [usable[0].id];
      if (usable.some((other) => other.quantity !== volume)) {
        warnings.push(`${id}: the plan holds more than one accepted volume with different figures (${usable.map((v) => `${v.id}: ${v.quantity}`).join(', ')}). ${usable[0].id} was used; dismiss the others.`);
      }
    } else {
      volume = fallback.volume;
      basis = 'placeholder';
      if (pending.length > 0) {
        label = LABELS.pendingVolume;
        extra = { pendingVolumeIds: pending.map((v) => v.id) };
        warnings.push(`${id}: ${pending.map((v) => `${v.id} (${v.quantity})`).join(', ')} is quoted but not accepted yet, so the placeholder ${volume} was used.`);
      } else {
        label = requirementIds.length > 0 ? LABELS.noVolume : LABELS.noRequirement;
      }
    }
    // A cap is what the estimate is for, so it is the volume, whether the figure under it was
    // quoted or assumed. The basis is left alone: where the figure came from before the estimator
    // capped it is still worth knowing, and the label is what says a cap is now in front of it.
    const cap = caps.get(id);
    if (cap) {
      volume = cap.cap;
      label = capLabel(cap.cap, unit);
    }
    workstreams.push({
      id,
      name: catalogEntry.name,
      kind: kindOf(catalogEntry),
      phase: catalogEntry.phase,
      unit,
      volume,
      volumeBasis: basis,
      volumeIds,
      ...extra,
      label,
      aiSavingPercent: fallback.aiSavingPercent,
      hoursPerUnit: rates,
      ...ownedHours(
        { id, name: catalogEntry.name, unit },
        catalogEntry.owner,
        owners.get(id),
        { traditional: hoursOf(volume, rates.traditional), aiAssisted: hoursOf(volume, rates.aiAssisted), three: threePointOf(volume, ladder) },
        volume
      ),
      ...(banding || {}),
      rateBasis: ladder.rateBasis,
      caseIds: ladder.caseIds,
      caseCount: ladder.caseCount,
      ...(ladder.rateAccepted === undefined ? {} : { rateAccepted: ladder.rateAccepted }),
      ...(ladder.rateQuestion ? { rateQuestion: ladder.rateQuestion } : {}),
      confidence: basis === 'document' ? 'medium' : 'low',
      requirementIds,
      skills: fallback.skillIds,
      ...(basis === 'placeholder' ? { clientQuestion: clientQuestionFor(catalogEntry.name, catalogEntry.unit, volume) } : {})
    });
  }

  // Passes 3 and 4: each proportional activity, over the activities already sized. The passes
  // come from the catalog's share sets rather than a list of ids here, so adding a proportional
  // activity is a catalog change.
  for (const pass of proportionalPasses(workPackages)) {
    const sized = new Map(workstreams.map((row) => [row.id, row]));
    for (const id of pass.slice().sort()) {
      const catalogEntry = workPackages.get(id);
      if (catalogEntry.skillIds === undefined) {
        unrated.push(id);
        continue;
      }
      workstreams.push(proportionalWorkstream({
        id,
        catalogEntry,
        entry: startingFigures(id, catalogEntry, 'proportional', skills),
        references: referenceSetOf(id, workPackages),
        sized,
        cases,
        shareFallbacks,
        platform,
        eligible: eligibility ? eligibility.get(id) || { tools: false } : undefined,
        requirementIds: live.filter((row) => row.workPackage === id).map((row) => row.id),
        owner: owners.get(id)
      }));
    }
  }

  if (unrated.length > 0) {
    warnings.push(`${unrated.length} ${unrated.length === 1 ? 'activity has' : 'activities have'} no rate on ${platform} yet and ${unrated.length === 1 ? 'is' : 'are'} not sized: ${unrated.join(', ')}.`);
  }

  return { workstreams, skills: rollUpSkills(workstreams, skills), warnings };
}

/** Hours by skill: each workstream's hours split evenly over its skill list, added up per skill. */
export function rollUpSkills(workstreams, skillCatalog) {
  const byId = new Map();
  for (const workstream of workstreams) {
    const share = workstream.skills.length;
    for (const skillId of workstream.skills) {
      const entry = byId.get(skillId) || { traditionalHours: 0, aiAssistedHours: 0, workstreams: [] };
      entry.traditionalHours += workstream.traditionalHours / share;
      entry.aiAssistedHours += workstream.aiAssistedHours / share;
      entry.workstreams.push(workstream.id);
      byId.set(skillId, entry);
    }
  }
  const order = ['delivery', 'platform', 'martech', 'business'];
  return Array.from(byId.entries())
    .map(([skillId, entry]) => {
      const skill = skillCatalog.get(skillId);
      return {
        skillId,
        name: skill ? skill.name : skillId,
        category: skill ? skill.category : 'unknown',
        traditionalHours: round2(entry.traditionalHours),
        aiAssistedHours: round2(entry.aiAssistedHours),
        workstreams: entry.workstreams
      };
    })
    .sort((a, b) => (order.indexOf(a.category) - order.indexOf(b.category)) || a.skillId.localeCompare(b.skillId));
}

/**
 * The three-point total over a set of workstreams.
 *
 * Low is the sum of the lows and high the sum of the highs, which is the widest the range can
 * be: it is the estimate where every activity lands at its low, or every one at its high. A
 * statistical roll-up would be narrower and more defensible on paper, but nobody in a pursuit
 * review can check it, and a range an estimator cannot explain is a range they will not stand
 * behind. Adding the columns up is what the spreadsheet it replaces did.
 */
function threePointTotal(rows) {
  const sum = (pick) => round2(rows.reduce((total, row) => total + (isObject(row.hours) ? Number(row.hours[pick]) || 0 : 0), 0));
  return { low: sum('low'), likely: sum('likely'), high: sum('high') };
}

/** Totals for the summary. */
export function estimateTotals(plan) {
  const workstreams = Array.isArray(plan.workstreams) ? plan.workstreams : [];
  const traditionalHours = round2(workstreams.reduce((sum, row) => sum + (Number(row.traditionalHours) || 0), 0));
  const aiAssistedHours = round2(workstreams.reduce((sum, row) => sum + (Number(row.aiAssistedHours) || 0), 0));
  return {
    traditionalHours,
    aiAssistedHours,
    hours: threePointTotal(workstreams),
    // Every phase the estimate touches, in the order work happens. A phase with no workstream
    // is left out rather than reported at zero.
    phases: PHASES
      .map((phase) => ({ phase, rows: workstreams.filter((row) => row.phase === phase) }))
      .filter(({ rows }) => rows.length > 0)
      .map(({ phase, rows }) => ({
        phase,
        workstreams: rows.length,
        hours: threePointTotal(rows),
        aiAssistedHours: round2(rows.reduce((sum, row) => sum + (Number(row.aiAssistedHours) || 0), 0))
      })),
    savingHours: round2(traditionalHours - aiAssistedHours),
    savingPercent: traditionalHours > 0 ? Math.round(((traditionalHours - aiAssistedHours) / traditionalHours) * 1000) / 10 : 0,
    fromDocuments: workstreams.filter((row) => row.kind === 'delivery' && row.volumeBasis === 'document').length,
    assumed: workstreams.filter((row) => row.volumeBasis === 'placeholder').length
  };
}

// ---------------------------------------------------------------------------------------------------------
// Validate

/**
 * The ids whose share set leads back to themselves, directly or through other shares. Only a
 * proportional workstream has a `shareOf`, so a set that reaches a sized activity simply ends.
 * @param {object[]} workstreams
 * @returns {string[]} in the order the workstreams are in, so the message names a real index
 */
function cyclicShares(workstreams) {
  const shareOf = new Map();
  for (const row of workstreams) {
    if (isObject(row) && text(row.id) && Array.isArray(row.shareOf)) {
      shareOf.set(row.id, row.shareOf.filter((id) => text(id)));
    }
  }
  const settled = new Map();
  const reachesItself = (id, path) => {
    if (path.has(id)) {
      return true;
    }
    if (settled.has(id)) {
      return settled.get(id);
    }
    path.add(id);
    const bad = (shareOf.get(id) || []).some((next) => shareOf.has(next) && reachesItself(next, path));
    path.delete(id);
    settled.set(id, bad);
    return bad;
  };
  return [...shareOf.keys()].filter((id) => (shareOf.get(id) || []).some((next) => shareOf.has(next) && reachesItself(next, new Set([id]))));
}

/**
 * Field-path errors for the `workstreams`, `skills` and `estimateBasis` sections of a plan. Both sections empty
 * (not estimated yet) is valid. With `workPackages` a delivery workstream must be a work package of the catalog.
 * @returns {string[]}
 */
export function validateEstimate(plan, { workPackages } = {}) {
  const errors = [];
  const workstreams = Array.isArray(plan.workstreams) ? plan.workstreams : [];
  const skills = Array.isArray(plan.skills) ? plan.skills : [];
  const caps = capsOf(plan);
  if (workstreams.length === 0 && skills.length === 0 && plan.estimateBasis === undefined) {
    return errors;
  }
  if (workstreams.length === 0) {
    errors.push('workstreams: expected the workstreams (the skills roll-up has nothing to add up)');
  }

  const basis = plan.estimateBasis;
  if (!isObject(basis) || !text(basis.platform) || !text(basis.builtAt) || Number.isNaN(Date.parse(basis.builtAt))) {
    errors.push('estimateBasis: expected { platform, builtAt }');
  } else if (basis.platformSource !== undefined && ['documents', 'estimator'].indexOf(basis.platformSource) === -1) {
    errors.push('estimateBasis.platformSource: expected documents or estimator');
  }

  const requirementIds = new Set((Array.isArray(plan.requirements) ? plan.requirements : []).map((row) => row.id));
  const volumes = new Map((Array.isArray(plan.volumes) ? plan.volumes : []).map((volume) => [volume.id, volume]));
  const seen = new Set();
  workstreams.forEach((row, index) => {
    const where = `workstreams[${index}]`;
    if (!isObject(row)) {
      errors.push(`${where}: expected an object`);
      return;
    }
    if (!text(row.id)) {
      errors.push(`${where}.id: expected a workstream id`);
    } else if (seen.has(row.id)) {
      errors.push(`${where}.id: ${row.id} is used twice`);
    } else {
      seen.add(row.id);
    }
    if (WORKSTREAM_KINDS.indexOf(row.kind) === -1) {
      errors.push(`${where}.kind: expected one of ${WORKSTREAM_KINDS.join(', ')}`);
    } else if (!ACTIVITY_ID.test(String(row.id))) {
      const retired = replacementFor(row.id);
      errors.push(`${where}.id: ${retired || `a workstream id is an activity slug, like component-build, not "${row.id}"`}`);
    } else if (workPackages && !workPackages.has(row.id)) {
      const retired = replacementFor(row.id);
      errors.push(`${where}.id: ${retired || `"${row.id}" is not an activity in the estimating catalog`}`);
    }
    if (!text(row.name) || !text(row.unit)) {
      errors.push(`${where}: expected name and unit`);
    }
    if (typeof row.volume !== 'number' || !(row.volume > 0)) {
      errors.push(`${where}.volume: expected a number above zero`);
    }
    if (VOLUME_BASES.indexOf(row.volumeBasis) === -1) {
      errors.push(`${where}.volumeBasis: expected one of ${VOLUME_BASES.join(', ')}`);
    }
    if (!text(row.label)) {
      errors.push(`${where}.label: expected the label that says where the volume came from`);
    }
    if (!Array.isArray(row.volumeIds) || row.volumeIds.some((id) => !text(id))) {
      errors.push(`${where}.volumeIds: expected an array of volume ids`);
    } else if (row.volumeBasis === 'document') {
      if (row.volumeIds.length === 0) {
        errors.push(`${where}.volumeIds: a workstream sized from the documents names its volume`);
      }
      row.volumeIds.forEach((id) => {
        const held = volumes.get(id);
        if (!held || held.workPackageId !== row.id) {
          errors.push(`${where}.volumeIds: ${id} is not a volume of ${row.id} in this file`);
        }
      });
    } else if (row.volumeBasis === 'placeholder' && row.volumeIds.length > 0) {
      errors.push(`${where}.volumeIds: a placeholder volume names no document volume`);
    }
    // A capped row is the exception: the cap is where its figure came from now, and saying
    // "assumed" in front of a number the estimator committed to would be the wrong word.
    if (row.volumeBasis === 'placeholder' && text(row.label) && !/^assumed|^capped at /.test(row.label)) {
      errors.push(`${where}.label: a placeholder volume is labelled "assumed, ..." unless it is capped`);
    }
    const shape = workPackages && workPackages.has(row.id) ? workPackages.get(row.id).shape : undefined;
    // A proportional activity has no volume to be unsure about or to ask the client for: it is
    // sized over other activities, and its share is what carries the doubt and the question.
    // The row's own share is what says so, because some callers validate without the catalog
    // and would otherwise ask a share for a volume it does not have.
    const sizedByVolume = shape !== 'proportional' && row.share === undefined;
    if (sizedByVolume && row.volumeBasis === 'placeholder' && row.confidence !== 'low') {
      errors.push(`${where}.confidence: a placeholder volume has low confidence`);
    }
    if (sizedByVolume && row.kind === 'delivery' && row.volumeBasis === 'placeholder' && !text(row.clientQuestion)) {
      errors.push(`${where}.clientQuestion: an assumed volume carries the question that would replace it`);
    }
    // Hours with no rung are hours with no story about where they came from, which is the one
    // thing the estimate is not allowed to produce.
    if (RATE_BASES.indexOf(row.rateBasis) === -1) {
      errors.push(`${where}.rateBasis: expected one of ${RATE_BASES.join(', ')}`);
    } else {
      if (!Array.isArray(row.caseIds) || row.caseIds.some((id) => !text(id))) {
        errors.push(`${where}.caseIds: expected an array of case ids`);
      } else if (row.caseCount !== row.caseIds.length) {
        errors.push(`${where}.caseCount: expected ${row.caseIds.length}, the number of cases named`);
      }
      if (row.rateBasis === 'cases' && row.caseIds.length === 0) {
        errors.push(`${where}.caseIds: a rate from cases names the cases it came from`);
      }
      if (row.rateBasis === 'derived' && row.caseIds.length > 0) {
        errors.push(`${where}.caseIds: a derived rate came from no case, so it names none`);
      }
      if (row.rateBasis === 'derived' && typeof row.rateAccepted !== 'boolean') {
        errors.push(`${where}.rateAccepted: a derived rate records whether the estimator accepted it`);
      }
      if (questionOwed(row.rateBasis) !== text(row.rateQuestion)) {
        errors.push(questionOwed(row.rateBasis)
          ? `${where}.rateQuestion: a ${row.rateBasis} rate owes the client a question about where it came from`
          : `${where}.rateQuestion: a rate from cases is evidence and asks nothing`);
      }
    }
    if (PHASES.indexOf(row.phase) === -1) {
      errors.push(`${where}.phase: expected one of ${PHASES.join(', ')}`);
    }
    // Without the catalog there is no way to know which shape an activity is, so the shape
    // rules sit out rather than guessing. Every caller that has it gets them.
    if (shape !== undefined && shape !== 'tiered' && row.band !== undefined) {
      errors.push(`${where}.band: only a tiered activity is banded`);
    } else if (shape === 'tiered') {
      if (BANDS.indexOf(row.band) === -1) {
        errors.push(`${where}.band: expected one of ${BANDS.join(', ')}`);
      }
      if (CONFIDENCES.indexOf(row.bandConfidence) === -1) {
        errors.push(`${where}.bandConfidence: expected one of ${CONFIDENCES.join(', ')}`);
      }
      if (!Array.isArray(row.bandSignals)) {
        errors.push(`${where}.bandSignals: expected the signals that were read, even when there were none`);
      } else if ((row.bandSignals.length === 0) !== text(row.bandQuestion)) {
        // A band nothing pointed at is an assumption, and an assumption the client has not
        // seen is the kind that turns up after the estimate is signed.
        errors.push(row.bandSignals.length === 0
          ? `${where}.bandQuestion: a band with no signal behind it asks the client about it`
          : `${where}.bandQuestion: the documents banded this, so there is nothing to ask`);
      }
      if (!text(row.bandReason)) {
        errors.push(`${where}.bandReason: expected what the band was read from, in words`);
      }
    }
    if (OWNERS.indexOf(row.owner) === -1) {
      errors.push(`${where}.owner: expected one of ${OWNERS.join(', ')}`);
    } else {
      if (typeof row.wholeHours !== 'number' || !(row.wholeHours > 0)) {
        errors.push(`${where}.wholeHours: expected what the activity is worth before ownership, above zero`);
      } else if (row.owner !== 'client' && typeof row.traditionalHours === 'number'
        && Math.abs(row.wholeHours - row.traditionalHours) > HOURS_TOLERANCE) {
        // Nothing yet measures how a shared activity splits, so until a case does, our portion
        // of it is all of it. When that changes this rule is what has to be relaxed.
        errors.push(`${where}.wholeHours: ${row.wholeHours} is not the ${row.traditionalHours} hours this estimate carries, and only a client-owned activity differs`);
      }
      if ((row.owner === 'client') !== text(row.exclusion)) {
        errors.push(row.owner === 'client'
          ? `${where}.exclusion: work handed to the client is named as out of scope`
          : `${where}.exclusion: we are doing this, so it is not an exclusion`);
      }
      if (row.owner !== 'us' && !text(row.ownerQuestion)) {
        errors.push(`${where}.ownerQuestion: a ${row.owner} activity owes the client a question about who does what`);
      }
      if (row.owner === 'client' && !text(row.ownerNote)) {
        errors.push(`${where}.ownerNote: handing work to the client is a decision somebody made, with a reason`);
      }
    }
    if (shape !== undefined && shape !== 'proportional' && row.share !== undefined) {
      errors.push(`${where}.share: only a proportional activity is a share of others`);
    } else if (shape === 'proportional') {
      if (typeof row.share !== 'number' || !(row.share > 0) || row.share >= 1) {
        errors.push(`${where}.share: expected a share above 0 and below 1`);
      }
      if (SHARE_BASES.indexOf(row.shareBasis) === -1) {
        errors.push(`${where}.shareBasis: expected one of ${SHARE_BASES.join(', ')}`);
      } else if ((row.shareBasis === 'fallback') !== (row.rateBasis === 'derived')) {
        // The two say the same thing about the same number, so they cannot disagree: a share
        // nobody measured is a derived rate, and a measured one is not.
        errors.push(`${where}.rateBasis: a ${row.shareBasis} share is ${row.shareBasis === 'fallback' ? 'derived' : `rateBasis ${row.shareBasis}`}, not ${row.rateBasis}`);
      }
      if (!Array.isArray(row.shareOf) || row.shareOf.length === 0) {
        errors.push(`${where}.shareOf: expected the activities the share was taken over`);
      } else if (workPackages && row.shareOf.some((id) => !workPackages.has(id))) {
        errors.push(`${where}.shareOf: ${row.shareOf.filter((id) => !workPackages.has(id)).join(', ')} is not an activity in the estimating catalog`);
      } else if (row.shareOf.includes(row.id)) {
        errors.push(`${where}.shareOf: an activity cannot be a share of itself`);
      }
      if (typeof row.shareHours !== 'number' || row.shareHours < 0) {
        errors.push(`${where}.shareHours: expected the hours the share was taken over`);
      } else if (typeof row.share === 'number' && typeof row.wholeHours === 'number'
        && Math.abs(row.wholeHours - row.share * row.shareHours) > HOURS_TOLERANCE) {
        // Against the whole activity, not our portion: ownership is applied after sizing.
        errors.push(`${where}.wholeHours: ${row.wholeHours} is not ${row.share} of ${row.shareHours}`);
      }
    }
    const hours = row.hours;
    // Zero is a real answer here, and only here: the client owns the activity, so our estimate
    // carries none of it.
    const atZero = row.owner === 'client';
    const badHour = (value) => typeof value !== 'number' || (atZero ? value !== 0 : !(value > 0));
    if (!isObject(hours) || ['low', 'likely', 'high'].some((key) => badHour(hours[key]))) {
      errors.push(`${where}.hours: expected { low, likely, high } ${atZero ? 'at zero, because the client owns this' : 'with hours above zero'}`);
    } else {
      if (!(hours.low <= hours.likely && hours.likely <= hours.high)) {
        errors.push(`${where}.hours: expected low ${hours.low} <= likely ${hours.likely} <= high ${hours.high}`);
      }
      if (typeof row.traditionalHours === 'number' && Math.abs(hours.likely - row.traditionalHours) > HOURS_TOLERANCE) {
        errors.push(`${where}.hours.likely: ${hours.likely} is not the workstream's ${row.traditionalHours} hours`);
      }
      if (SPREADS.indexOf(hours.spread) === -1) {
        errors.push(`${where}.hours.spread: expected one of ${SPREADS.join(', ')}`);
      } else if (hours.spread === 'none' && hours.low !== hours.high) {
        // A range on top of a figure nobody measured reads as evidence of a width that was
        // never seen. The reverse is fine: cases that all landed on the same rate are a
        // measured spread that happens to be zero wide.
        errors.push(`${where}.hours: a rate with no measured spread has no range`);
      }
    }
    if (CONFIDENCES.indexOf(row.confidence) === -1) {
      errors.push(`${where}.confidence: expected one of ${CONFIDENCES.join(', ')}`);
    }
    const rates = row.hoursPerUnit;
    if (!isObject(rates) || !(rates.traditional > 0) || !(rates.aiAssisted > 0)) {
      errors.push(`${where}.hoursPerUnit: expected { traditional, aiAssisted } with hours above zero`);
    } else {
      if (typeof row.aiSavingPercent !== 'number' || row.aiSavingPercent < 0 || row.aiSavingPercent > MAX_AI_SAVING_PERCENT) {
        errors.push(`${where}.aiSavingPercent: expected a number from 0 to ${MAX_AI_SAVING_PERCENT}`);
      } else if (rates.aiAssisted < rates.traditional) {
        // The saving is a single percentage off the rate, so the AI-assisted figure is either
        // the traditional one or exactly that percentage below it. There is nowhere else for
        // it to have come from, and a third number would be one nobody can trace.
        if (!(row.aiSavingPercent > 0)) {
          errors.push(`${where}.hoursPerUnit: the AI-assisted rate is below the traditional one, so aiSavingPercent is above zero`);
        } else if (Math.abs(rates.aiAssisted - percentRate(rates.traditional, row.aiSavingPercent)) > 1e-6) {
          errors.push(`${where}.hoursPerUnit: ${rates.aiAssisted} is not ${rates.traditional} less ${row.aiSavingPercent}%`);
        }
      } else if (rates.aiAssisted > rates.traditional) {
        errors.push(`${where}.hoursPerUnit: AI-assisted hours per unit are above the traditional hours`);
      }
      for (const [field, rate] of [['traditionalHours', rates.traditional], ['aiAssistedHours', rates.aiAssisted]]) {
        if (typeof row[field] !== 'number' || row[field] < 0) {
          errors.push(`${where}.${field}: expected hours, not below zero`);
        } else if (row.owner === 'client') {
          if (row[field] !== 0) {
            errors.push(`${where}.${field}: the client owns this, so the estimate carries none of it`);
          }
        } else if (!(row[field] > 0)) {
          errors.push(`${where}.${field}: a workstream has hours above zero`);
        } else if (sizedByVolume && typeof row.volume === 'number' && Math.abs(row[field] - row.volume * rate) > HOURS_TOLERANCE) {
          errors.push(`${where}.${field}: ${row[field]} is not volume ${row.volume} x ${rate}`);
        }
      }
    }
    if (!Array.isArray(row.requirementIds) || row.requirementIds.some((id) => !requirementIds.has(id))) {
      errors.push(`${where}.requirementIds: expected requirement ids that are in this file`);
    }
    if (!Array.isArray(row.skills) || row.skills.length === 0 || row.skills.some((id) => !text(id))) {
      errors.push(`${where}.skills: expected the default skill list`);
    }
  });

  // A share taken over a set that leads back to itself has no value to compute: resolving it
  // would need its own answer as an input. The catalog is checked for this, but a plan file can
  // be edited by hand, and the four fixed passes cannot detect it at build time.
  for (const id of cyclicShares(workstreams)) {
    const index = workstreams.findIndex((row) => row.id === id);
    errors.push(`workstreams[${index}].shareOf: ${id} is a share of a set that leads back to ${id}, so its hours cannot be worked out`);
  }

  const skillSeen = new Set();
  skills.forEach((row, index) => {
    const where = `skills[${index}]`;
    if (!isObject(row) || !text(row.skillId) || !text(row.name) || !text(row.category)) {
      errors.push(`${where}: expected skillId, name and category`);
      return;
    }
    if (skillSeen.has(row.skillId)) {
      errors.push(`${where}.skillId: ${row.skillId} is used twice`);
    }
    skillSeen.add(row.skillId);
    if (typeof row.traditionalHours !== 'number' || typeof row.aiAssistedHours !== 'number' || row.traditionalHours < 0 || row.aiAssistedHours < 0) {
      errors.push(`${where}: expected traditionalHours and aiAssistedHours, not below zero`);
    }
    if (!Array.isArray(row.workstreams) || row.workstreams.some((id) => !seen.has(id))) {
      errors.push(`${where}.workstreams: expected workstream ids that are in this file`);
    }
  });
  if (workstreams.length > 0 && errors.length === 0) {
    const totals = estimateTotals(plan);
    const traditional = skills.reduce((sum, row) => sum + row.traditionalHours, 0);
    const aiAssisted = skills.reduce((sum, row) => sum + row.aiAssistedHours, 0);
    if (Math.abs(traditional - totals.traditionalHours) > ROLLUP_TOLERANCE || Math.abs(aiAssisted - totals.aiAssistedHours) > ROLLUP_TOLERANCE) {
      errors.push(`skills: the skills add up to ${round2(traditional)} / ${round2(aiAssisted)} hours, the workstreams to ${totals.traditionalHours} / ${totals.aiAssistedHours}`);
    }
  }
  return errors;
}

/**
 * Where the workstreams no longer match the plan, so the estimate should be run again. These are warnings, not
 * errors: a person may accept a volume or edit one after the estimate, and that must not make the plan invalid.
 * @returns {string[]}
 */
export function staleWorkstreams(plan) {
  const messages = [];
  const caps = capsOf(plan);
  for (const row of Array.isArray(plan.workstreams) ? plan.workstreams : []) {
    if (!isObject(row) || row.kind !== 'delivery') {
      continue;
    }
    // A cap replaces the volume, so once one is in force it is the only figure this row can be
    // out of date against: the document volume it differs from is what the estimator capped.
    const cap = caps.get(row.id);
    if (cap) {
      if (row.volume !== cap.cap) {
        messages.push(`${row.id}: capped at ${cap.cap}; the estimate still uses ${row.volume}.`);
      }
      continue;
    }
    const { usable } = volumesOf(plan, row.id);
    if (row.volumeBasis === 'placeholder' && usable.length > 0) {
      messages.push(`${row.id}: volume ${usable[0].id} (${usable[0].quantity}) is accepted now; the estimate still uses the placeholder ${row.volume}.`);
    } else if (row.volumeBasis === 'document') {
      const held = usable.find((volume) => volume.id === (row.volumeIds || [])[0]);
      if (!held) {
        messages.push(`${row.id}: volume ${(row.volumeIds || [])[0]} is no longer accepted; the estimate still uses ${row.volume}.`);
      } else if (held.quantity !== row.volume) {
        messages.push(`${row.id}: volume ${held.id} now holds ${held.quantity}; the estimate uses ${row.volume}.`);
      }
    }
  }
  return messages;
}
