#!/usr/bin/env node
/**
 * Compares two independent reads of a bid and turns the disagreements into pending delivery unknowns.
 *
 * The first read is the design sketch (`.blueprint/design-sketch.json`). The second read was made by another
 * agent that saw only the parsed blocks and the catalog, never the first read: it wrote its drivers in the
 * same format, and assemble-drivers.mjs checked them into a second sketch file. This tool does not run any
 * agent and cannot tell that the second read was blind: the skill's rules and the way it is run do that.
 *
 * It reports, per work package:
 *   agree          both reads give the same count
 *   disagree       both give a count and the counts differ
 *   one-sided      only one read found a count
 * and it checks the challenger's objections to "accelerated" coverage. An objection is kept only when it
 * names a live requirement whose coverage is `accelerated`, one of the listed categories, the cited block it
 * comes from and a quote that is in that block. The others are rejected with the reason.
 *
 * Every kept disagreement and objection comes with a ready delivery unknown in Context sidecar v2 shape
 * (no id; pending; with a `source` that names the package or the requirement). The skill keeps or drops
 * each one and adds the id. Nothing here changes hours, coverage, a requirement or a count, and no hours,
 * weeks or dates are written. An item already in the sidecar (`--existing`), in any review status, is not
 * proposed again, so a dismissal is kept.
 *
 * Usage: node tools/blueprint/second-opinion.mjs --blueprint <Project>_Blueprint.json --first <design-sketch.json>
 *        --second <second-sketch.json> --blocks <blocks.json> [--objections <objections.json>]
 *        [--existing <Project>_Context.json] [--estimating <estimating-catalog.md>] [--markdown]
 * Exit 0 on success. Exit 1 when a file cannot be read, is not JSON, has the wrong shape, or a sketch no longer
 * matches the blocks. Exit 2 on bad usage.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkSketch, containsPhrase, weakQuote } from './assemble-drivers.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';
import { validateContextValue } from './validate-context.mjs';

export const OBJECTION_CATEGORIES = {
  'custom-integration': 'a custom integration is not the kind of work that AI assistance speeds up',
  'unclear-scope': 'the scope is unclear, so there is little to accelerate yet',
  'client-dependency': 'the work waits on the client or a third party',
  'legacy-source': 'the source content or system is old or irregular, which resists automation',
  'regulated-or-security': 'compliance or security review limits how much can be automated',
  'novel-work': 'the work is new for the team and has no pattern to reuse'
};
const REASON_MAX = 400;
const NO_DURATION = /\b(hours?|weeks?|days?|months?)\b/i;
const USAGE =
  'Usage: node tools/blueprint/second-opinion.mjs --blueprint <Blueprint.json> --first <design-sketch.json> --second <second-sketch.json> --blocks <blocks.json> ' +
  '[--objections <objections.json>] [--existing <Context.json>] [--estimating <file>] [--markdown]';

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function normalize(text) {
  return String(text ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
}

export function packageSource(workPackageId) {
  return `Second opinion ${workPackageId}`;
}

export function objectionSource(requirementId) {
  return `Second opinion objection ${requirementId}`;
}

function status(row) {
  return isObject(row.review) && typeof row.review.status === 'string' ? row.review.status : 'pending';
}

function liveRowsOf(blueprint, workPackageId) {
  return (Array.isArray(blueprint.requirements) ? blueprint.requirements : [])
    .filter((row) => isObject(row) && row.workPackage === workPackageId && status(row) !== 'dismissed' && typeof row.id === 'string')
    .map((row) => row.id);
}

function pluralUnit(unit, quantity) {
  return quantity === 1 ? unit : `${unit}s`;
}

/** Counts per package from a sketch's drivers. */
function countsOf(sketch) {
  // A driver the estimator dismissed is not a read of the documents any more.
  return new Map(sketch.drivers.filter((driver) => status(driver) !== 'dismissed').map((driver) => [driver.workPackageId, driver]));
}

/** Errors for one objection; empty means it is kept. */
export function checkObjection(objection, { requirements, blocks }) {
  const errors = [];
  if (!isObject(objection)) {
    return ['expected an object'];
  }
  const row = typeof objection.requirementId === 'string' ? requirements.get(objection.requirementId) : undefined;
  if (!row) {
    errors.push(`requirementId: "${objection.requirementId}" is not a requirement in the Blueprint`);
  } else if (status(row) === 'dismissed') {
    errors.push(`requirementId: ${objection.requirementId} was dismissed by the estimator`);
  } else if (row.coverage !== 'accelerated') {
    errors.push(`requirementId: ${objection.requirementId} is not claimed as accelerated (it is ${row.coverage})`);
  }
  if (!Object.prototype.hasOwnProperty.call(OBJECTION_CATEGORIES, objection.category)) {
    errors.push(`category: expected one of ${Object.keys(OBJECTION_CATEGORIES).join(', ')}`);
  }
  if (typeof objection.reason !== 'string' || objection.reason.trim() === '' || objection.reason.length > REASON_MAX) {
    errors.push(`reason: expected text of up to ${REASON_MAX} characters`);
  } else if (NO_DURATION.test(objection.reason)) {
    errors.push('reason: do not state hours, days, weeks or months');
  }
  const blockIds = Array.isArray(objection.blockIds) ? objection.blockIds : [];
  const texts = [];
  if (blockIds.length === 0 || blockIds.some((id) => typeof id !== 'string')) {
    errors.push('blockIds: expected at least one block id');
  }
  for (const id of blockIds) {
    if (typeof id === 'string' && !blocks.has(id)) {
      errors.push(`blockIds: "${id}" is not in the blocks file`);
    } else if (typeof id === 'string') {
      texts.push(blocks.get(id));
    }
  }
  if (typeof objection.quote !== 'string' || objection.quote.trim() === '') {
    errors.push('quote: expected the words copied from the cited block');
  } else if (weakQuote(objection.quote, 3)) {
    errors.push(`quote: ${weakQuote(objection.quote, 3)}`);
  } else if (!texts.some((text) => containsPhrase(text, objection.quote))) {
    errors.push('quote: this text is not in the cited blocks');
  }
  return errors;
}

/**
 * @param {{ blueprint: object, first: object, second: object, objections?: object, existingSources?: Iterable<string>,
 *           blocks: object[], workPackages: Map<string, { name: string, unit: string }> }} options
 */
export function compareReads({ blueprint, first, second, objections, existingSources = [], blocks, workPackages }) {
  const existing = new Set(Array.from(existingSources, (source) => String(source).trim().toLowerCase()));
  const blockText = new Map(blocks.filter((block) => isObject(block) && typeof block.id === 'string').map((block) => [block.id, normalize(block.text)]));
  const requirements = new Map((Array.isArray(blueprint.requirements) ? blueprint.requirements : []).filter(isObject).map((row) => [row.id, row]));

  const result = { agree: [], disagree: [], oneSided: [], alreadyProposed: [], objections: { kept: [], rejected: [] } };
  const a = countsOf(first);
  const b = countsOf(second);
  const ids = Array.from(new Set([...a.keys(), ...b.keys()])).sort();
  for (const id of ids) {
    const pack = workPackages.get(id) || { name: id, unit: 'unit' };
    const one = a.get(id);
    const two = b.get(id);
    if (one && two && one.quantity === two.quantity) {
      result.agree.push({ workPackageId: id, quantity: one.quantity });
      continue;
    }
    if (existing.has(packageSource(id).toLowerCase())) {
      result.alreadyProposed.push(id);
      continue;
    }
    const refs = liveRowsOf(blueprint, id);
    if (one && two) {
      result.disagree.push({
        workPackageId: id,
        name: pack.name,
        unit: pack.unit,
        first: one.quantity,
        second: two.quantity,
        unknown: {
          statement: `Two independent reads of the documents count ${one.quantity} and ${two.quantity} ${pluralUnit(pack.unit, 2)} for ${pack.name} (${id}). Check the cited blocks and confirm the count.`,
          source: packageSource(id),
          ...(refs.length ? { refs } : {}),
          review: { status: 'pending' }
        }
      });
    } else {
      const side = one ? 'first' : 'second';
      const found = one || two;
      result.oneSided.push({
        workPackageId: id,
        name: pack.name,
        unit: pack.unit,
        side,
        quantity: found.quantity,
        unknown: {
          statement: `Only one of two independent reads of the documents found a count for ${pack.name} (${id}): ${found.quantity} ${pluralUnit(pack.unit, found.quantity)}. Check the documents and confirm whether the count holds.`,
          source: packageSource(id),
          ...(refs.length ? { refs } : {}),
          review: { status: 'pending' }
        }
      });
    }
  }

  const list = isObject(objections) && Array.isArray(objections.objections) ? objections.objections : [];
  const seen = new Set();
  list.forEach((objection, index) => {
    const errors = checkObjection(objection, { requirements, blocks: blockText });
    if (errors.length === 0 && seen.has(objection.requirementId)) {
      errors.push(`requirementId: ${objection.requirementId} already has an objection`);
    }
    if (errors.length > 0) {
      result.objections.rejected.push({ index, requirementId: isObject(objection) ? objection.requirementId : undefined, errors });
      return;
    }
    seen.add(objection.requirementId);
    if (existing.has(objectionSource(objection.requirementId).toLowerCase())) {
      result.alreadyProposed.push(objection.requirementId);
      return;
    }
    const row = requirements.get(objection.requirementId);
    result.objections.kept.push({
      requirementId: row.id,
      workPackageId: row.workPackage,
      category: objection.category,
      reason: objection.reason.trim(),
      blockIds: objection.blockIds.slice(),
      quote: objection.quote.trim(),
      unknown: {
        statement: `The accelerated coverage of ${row.id} (${row.workPackage}) is challenged because ${OBJECTION_CATEGORIES[objection.category]}: ${objection.reason.trim()}`,
        source: objectionSource(row.id),
        refs: [row.id],
        review: { status: 'pending' }
      }
    });
  });
  return result;
}

/** The report for the run summary: where the two reads differ and which objections held. */
export function formatMarkdown(result) {
  const lines = ['## Second opinion', ''];
  lines.push(`Agree: ${result.agree.length === 0 ? 'none' : result.agree.map((item) => `${item.workPackageId} (${item.quantity})`).join(', ')}`, '');
  if (result.disagree.length > 0) {
    lines.push('### Counts that differ', '');
    for (const item of result.disagree) {
      lines.push(`- ${item.workPackageId} ${item.name}: ${item.first} against ${item.second} ${item.unit}s (first read, second read)`);
    }
    lines.push('');
  }
  if (result.oneSided.length > 0) {
    lines.push('### Found by one read only', '');
    for (const item of result.oneSided) {
      lines.push(`- ${item.workPackageId} ${item.name}: ${item.quantity} ${pluralUnit(item.unit, item.quantity)}, found by the ${item.side} read`);
    }
    lines.push('');
  }
  if (result.objections.kept.length > 0) {
    lines.push('### Objections to accelerated coverage', '');
    for (const item of result.objections.kept) {
      lines.push(`- ${item.requirementId} (${item.workPackageId}, ${item.category}): ${item.reason}`);
    }
    lines.push('');
  }
  if (result.objections.rejected.length > 0) {
    lines.push('### Objections rejected', '');
    for (const item of result.objections.rejected) {
      lines.push(`- #${item.index + 1}${item.requirementId ? ` ${item.requirementId}` : ''}: ${item.errors.join('; ')}`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

function readText(file) {
  const abs = path.resolve(file);
  try {
    return fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`Cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
}

function readJson(file, label) {
  try {
    return JSON.parse(readText(file));
  } catch (error) {
    console.error(`(${label}): invalid JSON (${error.message})`);
    process.exit(1);
  }
}

function parseArgs(args) {
  const valueFlags = ['blueprint', 'first', 'second', 'blocks', 'objections', 'existing', 'estimating'];
  const parsed = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    const name = arg.slice(2);
    if (arg === '--markdown') {
      parsed.markdown = true;
    } else if (arg.startsWith('--') && valueFlags.indexOf(name) !== -1) {
      const next = args[index + 1];
      if (next === undefined || next === '' || next.startsWith('--') || parsed[name] !== undefined) {
        return undefined;
      }
      parsed[name] = next;
      index += 1;
    } else {
      return undefined;
    }
  }
  return parsed.blueprint && parsed.first && parsed.second && parsed.blocks ? parsed : undefined;
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  const blueprint = readJson(parsed.blueprint, 'blueprint');
  if (!isObject(blueprint) || !Array.isArray(blueprint.requirements)) {
    console.error('(blueprint): expected an object with a requirements array');
    process.exit(1);
  }
  const blocks = readJson(parsed.blocks, 'blocks');
  if (!Array.isArray(blocks)) {
    console.error('(blocks): expected an array of blocks');
    process.exit(1);
  }
  const workPackages = parseActivities(readText(parsed.estimating || DEFAULT_CATALOG));
  if (workPackages.size === 0) {
    console.error('The estimating catalog has no Activities table');
    process.exit(1);
  }
  if (path.resolve(parsed.first) === path.resolve(parsed.second)) {
    console.error('--first and --second are the same file: a second read has to be made separately from the first');
    process.exit(1);
  }
  const sketches = {};
  let failed = false;
  for (const name of ['first', 'second']) {
    sketches[name] = readJson(parsed[name], `${name} sketch`);
    for (const message of checkSketch(sketches[name], blocks, workPackages)) {
      console.error(`(${name} sketch) ${message}`);
      failed = true;
    }
  }
  if (failed) {
    process.exit(1);
  }
  if (JSON.stringify(sketches.first.drivers) === JSON.stringify(sketches.second.drivers)) {
    console.error('warning: the two sketches hold identical drivers; check that the second read was made separately from the first');
  }
  const objections = parsed.objections !== undefined ? readJson(parsed.objections, 'objections') : undefined;
  if (objections !== undefined && !(isObject(objections) && Array.isArray(objections.objections))) {
    console.error('(objections): expected an object with an objections array');
    process.exit(1);
  }
  let existingSources = [];
  if (parsed.existing !== undefined) {
    const context = readJson(parsed.existing, 'existing');
    const errors = validateContextValue(context);
    if (errors.length) {
      errors.forEach((message) => console.error(`(existing) ${message}`));
      process.exit(1);
    }
    existingSources = (Array.isArray(context.deliveryUnknowns) ? context.deliveryUnknowns : [])
      .filter((item) => isObject(item) && typeof item.source === 'string')
      .map((item) => item.source);
  }
  const result = compareReads({ blueprint, first: sketches.first, second: sketches.second, objections, existingSources, blocks, workPackages });
  process.stdout.write(parsed.markdown ? formatMarkdown(result) : `${JSON.stringify(result, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
