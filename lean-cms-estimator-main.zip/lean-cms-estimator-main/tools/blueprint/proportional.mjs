/**
 * Proportional activities (story B-10).
 *
 * Project management is not an overhead class, it is an activity sized as a share of the work
 * it covers. The same goes for delivery governance, QA automation and UAT support: each one is
 * a percentage of a named set of other activities, and the percentage comes from cases.
 *
 * Sizing this way is what makes the phase ratios right by construction. QA lands at a healthy
 * share of build because that is how it is sized, rather than because an auditor checked it
 * afterwards and nobody had to argue.
 *
 * Shares of shares would never settle, so resolution runs in passes and the order is fixed:
 *
 *   pass 1  per-unit activities, volume x hours per unit
 *   pass 2  tiered activities, band to hours
 *   pass 3  qa-automation and uat-support, over sets drawn only from passes 1 and 2
 *   pass 4  project-management and delivery-governance, over everything from passes 1 to 3
 *
 * Which pass an activity falls in is read from its share set rather than from a list of ids
 * here: an activity that is a share of another proportional activity resolves after it. The
 * catalog is what forbids a cycle (`npm run catalog:check`), so a set that cannot be ordered
 * is caught where it is written rather than here, where it would be hours that never settle.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_SHARE_FALLBACKS = path.join(HERE, 'data', 'proportional-fallbacks.json');

/** A share set of every activity that is not itself a share, so the two reporting activities do not size each other. */
export const EVERYTHING_ELSE = 'everything-else';

export class ProportionalError extends Error {}

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * The activities a proportional one is a share of, with `everything-else` expanded.
 *
 * `activities` is a Map keyed by activity id, so this works on anything that carries `shape`
 * and `shareOf` — both the catalog validator's rows and the estimate's.
 *
 * @returns {string[]}
 */
export function referenceSetOf(id, activities) {
  const activity = activities.get(id);
  if (!activity || activity.shape !== 'proportional') {
    return [];
  }
  if (!activity.shareOf.includes(EVERYTHING_ELSE)) {
    return activity.shareOf;
  }
  return [...activities.keys()].filter((other) => {
    const entry = activities.get(other);
    return other !== id && !(entry.shape === 'proportional' && entry.shareOf.includes(EVERYTHING_ELSE));
  });
}

/**
 * The proportional activities in the order they can be resolved: an activity comes after
 * everything it is a share of.
 *
 * @returns {string[][]} one list per pass, the first pass being the one that needs no other
 *   proportional activity sized first
 */
export function proportionalPasses(activities) {
  const pending = [...activities.keys()].filter((id) => activities.get(id).shape === 'proportional');
  const done = new Set();
  const passes = [];
  let left = pending;
  while (left.length > 0) {
    const ready = left.filter((id) => referenceSetOf(id, activities)
      .every((reference) => !pending.includes(reference) || done.has(reference)));
    if (ready.length === 0) {
      // The catalog check rejects a cycle, so reaching here means the estimate was run against
      // a catalog that never passed it. Stopping beats looping.
      throw new ProportionalError(`these activities are shares of each other and cannot be sized: ${left.join(', ')}`);
    }
    ready.forEach((id) => done.add(id));
    passes.push(ready);
    left = left.filter((id) => !done.has(id));
  }
  return passes;
}

/** @returns {string[]} what is wrong with a fallbacks file, empty when it is usable. */
export function validateShareFallbacks(doc) {
  if (!isObject(doc) || doc.schemaVersion !== '1' || !isObject(doc.shares)) {
    return ['expected { schemaVersion: "1", shares: {} }'];
  }
  const errors = [];
  for (const [id, share] of Object.entries(doc.shares)) {
    if (typeof share !== 'number' || !(share > 0) || share >= 1) {
      errors.push(`shares.${id}: expected a share above 0 and below 1`);
    }
  }
  return errors;
}

export function loadShareFallbacks(file = DEFAULT_SHARE_FALLBACKS) {
  let doc;
  try {
    doc = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw new ProportionalError(`${file} could not be read as JSON: ${error.message}`);
  }
  const errors = validateShareFallbacks(doc);
  if (errors.length > 0) {
    throw new ProportionalError(`${file} is not a usable fallbacks file: ${errors[0]}`);
  }
  return new Map(Object.entries(doc.shares));
}
