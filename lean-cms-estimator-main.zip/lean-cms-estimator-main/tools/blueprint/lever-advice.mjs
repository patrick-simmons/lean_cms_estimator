#!/usr/bin/env node
/**
 * Lever advice for the enrich stage: which opt-in assets and delivery methods of the estimating catalog the
 * source documents give a reason to enable, each with the words that point to it.
 *
 * The app's own "Suggest levers" picks assets from what the requirements map to. This looks at the documents:
 * a Figma link, an existing site to migrate, an accessibility standard, a stated move from an older AEM
 * installation. The evidence list is tools/blueprint/data/lever-evidence.json (a lever id and signal words).
 * A lever is advised only when
 *   - the estimating catalog offers it for the project's platform (an opt-in asset through its Capabilities row,
 *     a method through the Delivery methods table, and not one that is already on by default), and
 *   - a signal word is in a parsed block, which is quoted with its block id.
 * A lever with evidence that the catalog does not offer on this platform is listed as `notOffered`.
 *
 * Each advised lever comes with a ready working assumption in Context sidecar v2 shape (no id; pending;
 * `source` "Lever advice <id>"). The skill keeps or rejects each one and adds the id. The estimator confirms in
 * two places: the assumption in review, and the lever itself on the AI levers tab. Nothing here changes the
 * working file's `levers`, hours, coverage or a requirement. No hours, weeks, dates or quantities are written.
 * An advised lever already in the sidecar (`--existing`), in any review status, is not advised again.
 *
 * Usage: node tools/blueprint/lever-advice.mjs --blueprint <Project>_Blueprint.json --blocks <blocks.json>
 *        [--existing <Project>_Context.json] [--suppress <file>] [--estimating <estimating-catalog.md>] [--data <file>] [--markdown]
 * Exit 0 on success. Exit 1 when a file cannot be read, is not JSON, or has the wrong shape. Exit 2 on bad usage.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { containsSequence, tokenize } from './match-library.mjs';
import { DEFAULT_CATALOG } from './rank-questions.mjs';
import { readSuppressFile, suppressedSources } from './suppression.mjs';
import { validateContextValue } from './validate-context.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_DATA = path.join(HERE, 'data', 'lever-evidence.json');
export const DATA_SCHEMA_VERSION = '1';

const CAPABILITY_ROW = /^\| `([a-z][a-z0-9-]*)` \| (all|aem|aem-eds) \| (.*) \| (?:[^|]*) \| (?:[^|]*) \|\s*$/;
const QUOTE_MAX = 240;
const USAGE =
  'Usage: node tools/blueprint/lever-advice.mjs --blueprint <Blueprint.json> --blocks <blocks.json> [--existing <Context.json>] [--suppress <file>] [--estimating <file>] [--data <file>] [--markdown]';

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** The `source` every advised lever carries. It is also how a re-run knows the lever was already advised. */
export function leverSource(leverId) {
  return `Lever advice ${leverId}`;
}

/**
 * The levers the catalog offers: opt-in assets per work package and platform, and delivery methods.
 * @returns {{ optIn: Map<string, { platforms: Map<string, Set<string>> }>, methods: Map<string, { workPackageIds: string[], prerequisites: string, isDefault: boolean }> }}
 */
export function parseLevers(catalogMd) {
  const optIn = new Map();
  const methods = new Map();
  let inMethods = false;
  for (const line of catalogMd.split(/\r?\n/)) {
    if (/^## /.test(line)) {
      inMethods = /^## Delivery methods\b/.test(line);
      continue;
    }
    if (inMethods) {
      const cells = line.split('|').slice(1, -1).map((cell) => cell.trim());
      const id = cells.length === 5 ? /^`([^`]+)`$/.exec(cells[0]) : null;
      if (id) {
        methods.set(id[1], {
          workPackageIds: Array.from(cells[2].matchAll(/`([a-z][a-z0-9-]*)`/g), (match) => match[1]),
          prerequisites: cells[3],
          isDefault: cells[4].toLowerCase() === 'yes'
        });
      }
      continue;
    }
    const row = CAPABILITY_ROW.exec(line);
    if (!row) {
      continue;
    }
    for (const item of row[3].matchAll(/`([^`]+)`(\s*\(opt-in\))?/g)) {
      if (!item[2]) {
        continue;
      }
      const entry = optIn.get(item[1]) || { platforms: new Map() };
      const packages = entry.platforms.get(row[2]) || new Set();
      packages.add(row[1]);
      entry.platforms.set(row[2], packages);
      optIn.set(item[1], entry);
    }
  }
  return { optIn, methods };
}

/** Field-path errors for the evidence file; empty means it can be used. */
export function validateEvidence(data) {
  const errors = [];
  if (!isObject(data)) {
    return ['(root): expected an object'];
  }
  if (data.schemaVersion !== DATA_SCHEMA_VERSION) {
    errors.push(`schemaVersion: expected "${DATA_SCHEMA_VERSION}"`);
  }
  if (!Array.isArray(data.levers) || data.levers.length === 0) {
    errors.push('levers: expected a non-empty array');
    return errors;
  }
  const seen = new Set();
  data.levers.forEach((entry, index) => {
    const where = `levers[${index}]`;
    if (!isObject(entry)) {
      errors.push(`${where}: expected an object`);
      return;
    }
    if (typeof entry.id !== 'string' || entry.id.trim() === '') {
      errors.push(`${where}.id: expected a lever id`);
    } else if (seen.has(entry.id)) {
      errors.push(`${where}.id: ${entry.id} is listed twice`);
    } else {
      seen.add(entry.id);
    }
    if (typeof entry.reason !== 'string' || entry.reason.trim() === '') {
      errors.push(`${where}.reason: expected non-empty text`);
    } else if (/\d|\b(hours?|days?|weeks?|months?)\b/i.test(entry.reason)) {
      errors.push(`${where}.reason: no numbers, hours, days, weeks or months`);
    }
    if (!Array.isArray(entry.signals) || entry.signals.length === 0 ||
      entry.signals.some((word) => typeof word !== 'string' || tokenize(word).length === 0)) {
      errors.push(`${where}.signals: expected a non-empty list of words`);
    }
  });
  return errors;
}

function status(row) {
  return isObject(row.review) && typeof row.review.status === 'string' ? row.review.status : 'pending';
}

/** The line of the block that holds the signal, cut to a length a person can read. */
function quoteOf(text, signalTokens) {
  const lines = String(text).split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== '');
  const line = lines.find((item) => containsSequence(tokenize(item), signalTokens)) || lines[0] || '';
  return line.length > QUOTE_MAX ? `${line.slice(0, QUOTE_MAX - 1).trimEnd()}\u2026` : line;
}

/**
 * @param {{ blueprint: object, blocks: object[], levers: ReturnType<typeof parseLevers>, evidence: { levers: object[] },
 *           existingSources?: Iterable<string>, suppressedSources?: Iterable<string> }} options sources are compared trimmed and lowercased
 */
export function adviseLevers({ blueprint, blocks, levers, evidence, existingSources = [], suppressedSources: suppressedList = [] }) {
  const existing = new Set(Array.from(existingSources, (source) => String(source).trim().toLowerCase()));
  const suppressed = new Set(Array.from(suppressedList, (source) => String(source).trim().toLowerCase()));
  const platformId = isObject(blueprint.platform) && typeof blueprint.platform.id === 'string' && blueprint.platform.id.trim() !== ''
    ? blueprint.platform.id.trim().toLowerCase()
    : undefined;
  const requirements = (Array.isArray(blueprint.requirements) ? blueprint.requirements : []).filter(isObject);
  const live = requirements.filter((row) => status(row) !== 'dismissed' && typeof row.id === 'string');
  const readable = blocks.filter((block) => isObject(block) && typeof block.id === 'string' && typeof block.text === 'string')
    .map((block) => ({ block, tokens: tokenize(block.text) }));

  const result = {
    platform: platformId || null,
    blocksRead: readable.length,
    advised: [],
    alreadyProposed: [],
    suppressed: [],
    alreadyOnByDefault: [],
    notOffered: [],
    noEvidence: []
  };

  for (const entry of evidence.levers) {
    const method = levers.methods.get(entry.id);
    const asset = levers.optIn.get(entry.id);
    // The evidence comes first: a lever with no signal in the documents is not worth a line, whatever the catalog says.
    const signalTokens = entry.signals.map((word) => tokenize(word));
    const hits = [];
    for (const { block, tokens } of readable) {
      const matched = entry.signals.filter((word, index) => containsSequence(tokens, signalTokens[index]));
      if (matched.length > 0) {
        hits.push({ block, matched, signalTokens: signalTokens[entry.signals.indexOf(matched[0])] });
      }
    }
    if (hits.length === 0) {
      result.noEvidence.push(entry.id);
      continue;
    }
    if (!method && !asset) {
      result.notOffered.push({ id: entry.id, reason: 'the estimating catalog does not list it' });
      continue;
    }
    // A lever can sit in both tables. It counts as a method unless the method is on by default, in which
    // case the opt-in row (if any) still decides.
    const methodOffered = method !== undefined && !method.isDefault;
    if (method && method.isDefault && !asset) {
      result.alreadyOnByDefault.push(entry.id);
      continue;
    }
    const found = new Set(methodOffered ? method.workPackageIds : []);
    if (asset) {
      for (const [platform, packages] of asset.platforms) {
        if (platform === 'all' || platform === platformId) {
          packages.forEach((id) => found.add(id));
        }
      }
    }
    const workPackageIds = Array.from(found).sort();
    const kind = methodOffered ? 'method' : 'optIn';
    if (workPackageIds.length === 0) {
      result.notOffered.push({ id: entry.id, reason: `the catalog offers it only on other platforms than ${platformId || 'the project\'s'}` });
      continue;
    }
    const marker = leverSource(entry.id).toLowerCase();
    if (suppressed.has(marker)) {
      result.suppressed.push(entry.id);
      continue;
    }
    if (existing.has(marker)) {
      result.alreadyProposed.push(entry.id);
      continue;
    }

    const first = hits[0];
    const quote = quoteOf(first.block.text, first.signalTokens);
    const label = typeof first.block.label === 'string' && first.block.label !== '' ? first.block.label : first.block.id;
    const liveRows = live.filter((row) => workPackageIds.indexOf(row.workPackage) !== -1 && row.coverage !== 'human-led');
    const kindLabel = kind === 'method' ? 'delivery method' : 'opt-in asset';
    const prerequisites = methodOffered && method.prerequisites ? ` Prerequisites: ${method.prerequisites}.` : '';
    result.advised.push({
      id: entry.id,
      kind,
      workPackageIds,
      reason: entry.reason,
      evidence: {
        signals: Array.from(new Set(hits.flatMap((hit) => hit.matched))),
        blockIds: hits.map((hit) => hit.block.id),
        quote
      },
      hasLiveRequirement: liveRows.length > 0,
      requirementIds: liveRows.map((row) => row.id),
      assumption: {
        statement: `The team enables the ${kindLabel} ${entry.id} for ${workPackageIds.join(', ')}. ${entry.reason} Evidence: \u201c${quote}\u201d (${label}).${prerequisites}`,
        category: 'delivery',
        confidence: 'low',
        ifFails: `Without ${entry.id} the packages it speeds up (${workPackageIds.join(', ')}) are sized at the traditional rate.`,
        source: leverSource(entry.id),
        review: { status: 'pending' }
      }
    });
  }
  result.selection = {
    optIn: result.advised.filter((item) => item.kind === 'optIn').map((item) => item.id).sort(),
    methods: result.advised.filter((item) => item.kind === 'method').map((item) => item.id).sort()
  };
  return result;
}

/** The part of the run summary the estimator reads. */
export function formatMarkdown(result) {
  const lines = ['## Lever advice', ''];
  if (result.advised.length === 0) {
    lines.push('The documents give no reason to enable an extra lever.', '');
  } else {
    lines.push('Enable these on the AI levers tab once you agree with the evidence:', '');
    for (const item of result.advised) {
      const note = item.hasLiveRequirement ? '' : ' (no requirement in its packages yet, so it changes nothing until one exists)';
      lines.push(`- \`${item.id}\` (${item.kind === 'method' ? 'method' : 'opt-in'}, ${item.workPackageIds.join(', ')})${note}`);
      lines.push(`  - ${item.reason}`);
      lines.push(`  - Evidence: \u201c${item.evidence.quote}\u201d (${item.evidence.blockIds.join(', ')})`);
    }
    lines.push('');
  }
  if (result.notOffered.length > 0) {
    lines.push('Evidence found, but the catalog does not offer the lever here:', '');
    result.notOffered.forEach((item) => lines.push(`- \`${item.id}\`: ${item.reason}`));
    lines.push('');
  }
  return lines.join('\n');
}

function readText(file) {
  const abs = path.resolve(file);
  try {
    return fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`Cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
}

function readJson(file, label) {
  try {
    return JSON.parse(readText(file));
  } catch (error) {
    console.error(`(${label}): invalid JSON (${error.message})`);
    process.exit(1);
  }
}

function parseArgs(args) {
  const valueFlags = ['blueprint', 'blocks', 'existing', 'suppress', 'estimating', 'data'];
  const parsed = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    const name = arg.slice(2);
    if (arg === '--markdown') {
      parsed.markdown = true;
    } else if (arg.startsWith('--') && valueFlags.indexOf(name) !== -1) {
      const next = args[index + 1];
      if (next === undefined || next === '' || next.startsWith('--') || parsed[name] !== undefined) {
        return undefined;
      }
      parsed[name] = next;
      index += 1;
    } else {
      return undefined;
    }
  }
  return parsed.blueprint && parsed.blocks ? parsed : undefined;
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  const blueprint = readJson(parsed.blueprint, 'blueprint');
  if (!isObject(blueprint) || !Array.isArray(blueprint.requirements)) {
    console.error('(blueprint): expected an object with a requirements array');
    process.exit(1);
  }
  const blocks = readJson(parsed.blocks, 'blocks');
  if (!Array.isArray(blocks)) {
    console.error('(blocks): expected an array of blocks');
    process.exit(1);
  }
  const levers = parseLevers(readText(parsed.estimating || DEFAULT_CATALOG));
  if (levers.optIn.size === 0 && levers.methods.size === 0) {
    console.error('The estimating catalog has no Capabilities or Delivery methods table');
    process.exit(1);
  }
  const evidence = readJson(parsed.data || DEFAULT_DATA, 'evidence');
  const evidenceErrors = validateEvidence(evidence);
  if (evidenceErrors.length) {
    evidenceErrors.forEach((message) => console.error(`(evidence) ${message}`));
    process.exit(1);
  }
  let existingSources = [];
  if (parsed.existing !== undefined) {
    const context = readJson(parsed.existing, 'existing');
    const errors = validateContextValue(context);
    if (errors.length) {
      errors.forEach((message) => console.error(`(existing) ${message}`));
      process.exit(1);
    }
    existingSources = (Array.isArray(context.assumptions) ? context.assumptions : [])
      .filter((item) => isObject(item) && typeof item.source === 'string')
      .map((item) => item.source);
  }
  let suppressed = [];
  if (parsed.suppress !== undefined) {
    try {
      suppressed = suppressedSources(readSuppressFile(parsed.suppress), 'lever-advice');
    } catch (error) {
      console.error(error.message);
      process.exit(1);
    }
  }
  const result = adviseLevers({ blueprint, blocks, levers, evidence, existingSources, suppressedSources: suppressed });
  process.stdout.write(parsed.markdown ? formatMarkdown(result) : `${JSON.stringify(result, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
