/**
 * The rows of the estimate workbook (stage 5), built from the plan file and nothing else.
 *
 * The workbook is an output: every cell is a field of the plan (volumes, hours, tools, opt-outs, questions)
 * or a statement of a fact the plan holds (a volume is assumed, a source was not read). This file adds no
 * number and no judgement. Hours are the ones the estimate wrote; the template adds up the totals.
 *
 * The column lists below are the contract with the template: a sheet is matched by name and its columns by
 * position, so the order and count cannot change without the template changing (a test compares them).
 */
import { capsOf, estimateTotals, round2, staleWorkstreams } from './estimate-model.mjs';
import { staleAiPlan } from './ai-plan.mjs';
import { HIGH_AT, MEDIUM_AT, rankQuestions } from './rank-questions.mjs';

export const SHEET_COLUMNS = {
  Sources: ['Item id', 'File', 'Read', 'Not read reason'],
  Requirements: ['Id', 'Statement', 'Citation', 'Work package', 'Capabilities', 'Coverage', 'Review', 'Reviewed via', 'Reviewed at', 'Question id', 'AI tools', 'AI methods', 'AI reason'],
  Questions: ['Rank', 'Id', 'Tier', 'Audience', 'Question', 'Requirement', 'Work package', 'Why this rank'],
  Workstreams: ['Id', 'Name', 'Kind', 'Phase', 'Lane', 'Owner', 'Unit', 'Band', 'Volume', 'Volume basis', 'Source of the volume', 'Confidence', 'Traditional hrs/unit', 'AI-assisted hrs/unit', 'Rate basis', 'Cases behind the rate', 'Low hours', 'Traditional hours', 'High hours', 'AI-assisted hours', 'Saved hours', 'Saved %', 'Requirements', 'Skills', 'Volume ids', 'Client question'],
  'AI plan': ['Section', 'Item', 'Kind', 'Source', 'Status', 'Workstreams', 'Opt-out reason', 'Opt-out note', 'Detail'],
  Skills: ['Skill id', 'Name', 'Category', 'Traditional hours', 'AI-assisted hours', 'Saved hours', 'Workstreams'],
  'Assumptions and risks': ['Id', 'Type', 'Statement', 'Applies to', 'Basis', 'If it is wrong']
};

/** The named cells on Coverage that the tool writes. */
export const NAMED_CELLS = ['ProjectName', 'Platform', 'PlatformSource', 'CmkCommit', 'ToolkitCommit', 'EstimatingVersion', 'EstimatedAt', 'BuiltAt'];

/** The phase that takes a delivery workstream no phase of the seed covers, and the label of an overhead workstream. */
export const OVERHEAD_PHASE = 'overhead';

const OPT_OUT_LABEL = {
  'not-licensed': 'not licensed',
  'not-installed': 'not installed',
  'client-restriction': 'client restriction',
  'not-suitable': 'not suitable'
};
const SOURCE_LABEL = { cmk: 'CMK', vendor: 'CMK vendor asset', toolkit: 'toolkit' };

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function list(value) {
  return Array.isArray(value) ? value : [];
}

function status(item) {
  return isObject(item) && isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
}

function plural(count, word) {
  return `${count} ${word}${count === 1 ? '' : 's'}`;
}

/**
 * The phases of the seed (`Phase packs`): [{ id, name, weeks, after, lag }]. The seed says how long
 * each phase runs and what it follows; which activities are in it is the estimating catalog's to say.
 * @param {{ headers: string[], rows: string[][] }} sheet
 */
export function phasesOf(sheet) {
  return sheet.rows.map((row) => ({
    id: row[0].trim(),
    name: row[1].trim(),
    weeks: Number(row[2]),
    after: row[3].trim(),
    lag: Number(row[4] || 0)
  }));
}

/**
 * The lanes of the seed (`Lanes`): [{ id, phase, name, offset, weeks, activities: string[] }]. A lane
 * is a track inside a phase that runs alongside the others rather than after them.
 * @param {{ headers: string[], rows: string[][] }} sheet
 */
export function lanesOf(sheet) {
  return sheet.rows.map((row) => ({
    id: row[0].trim(),
    phase: row[1].trim(),
    name: row[2].trim(),
    offset: Number(row[3] || 0),
    weeks: Number(row[4]),
    activities: row[5].split(/[;,]/).map((id) => id.trim()).filter(Boolean)
  }));
}

/**
 * The phase a workstream's hours fall in. The estimating catalog puts every activity in a phase, so
 * this reads what the plan already carries rather than matching it against a list in the seed.
 */
export function phaseOf(workstream) {
  return workstream.kind === 'overhead' ? OVERHEAD_PHASE : workstream.phase;
}

/** The lane a workstream runs in, or '' when its phase has no lanes. */
export function laneOf(workstream, lanes) {
  const lane = list(lanes).find((entry) => entry.activities.includes(workstream.id));
  return lane ? lane.id : '';
}

function sourceRows(plan) {
  return list(plan.sources).map((source) => {
    const reasons = list(source.notRead).map((entry) => (isObject(entry) ? `${entry.reason || ''}${entry.pages ? ` (pages ${entry.pages})` : ''}` : String(entry)));
    return [source.itemId, source.name, source.read || '', reasons.join('; ')];
  });
}

function requirementRows(plan) {
  const ai = new Map(list(plan.aiPlan && plan.aiPlan.requirements).map((entry) => [entry.requirementId, entry]));
  return list(plan.requirements).map((row) => {
    const entry = ai.get(row.id);
    const review = isObject(row.review) ? row.review : {};
    return [
      row.id,
      row.statement,
      list(row.sources).map((source) => source.label).join(' vs '),
      row.workPackage,
      list(row.capabilities).join(', '),
      row.coverage,
      status(row),
      review.via || '',
      review.at || '',
      row.questionId || '',
      entry ? entry.tools.join(', ') : '',
      entry ? entry.methods.join(', ') : '',
      entry && entry.reason ? entry.reason : ''
    ];
  });
}

/**
 * The questions to ask, most useful first: the ranked questions of the plan, plus one for each workstream that
 * is sized on an assumed volume (the client answer replaces the placeholder).
 */
export function questionItems(plan, workPackages) {
  const { ranked } = rankQuestions(plan, undefined, workPackages);
  const items = ranked.map((item) => ({
    id: item.id,
    score: item.score,
    audience: item.audience,
    text: item.text,
    requirementId: item.requirementId || '',
    workPackageId: item.workPackageId || '',
    why: item.reasons.join('; ')
  }));
  const workstreams = list(plan.workstreams);
  const total = workstreams.reduce((sum, row) => sum + (Number(row.traditionalHours) || 0), 0);
  for (const row of workstreams) {
    if (row.kind !== 'delivery' || row.volumeBasis !== 'placeholder' || typeof row.clientQuestion !== 'string') {
      continue;
    }
    const share = total > 0 ? row.traditionalHours / total : 0;
    items.push({
      id: row.id,
      score: 3 + (share >= 0.25 ? 3 : share >= 0.1 ? 2 : share > 0 ? 1 : 0),
      audience: 'client',
      text: row.clientQuestion,
      requirementId: '',
      workPackageId: row.id,
      why: `${row.id} is sized on an assumed ${row.volume} ${row.unit}${row.volume === 1 ? '' : 's'}; the answer replaces it; ${row.id} carries ${Math.round(share * 100)}% of the estimated hours`
    });
  }
  return items
    .map((item, order) => ({ ...item, order }))
    .sort((a, b) => b.score - a.score || a.order - b.order)
    .map((item, index) => ({ ...item, rank: index + 1, tier: item.score >= HIGH_AT ? 'high' : item.score >= MEDIUM_AT ? 'medium' : 'low' }));
}

function questionRows(plan, workPackages) {
  return questionItems(plan, workPackages).map((item) => [
    item.rank,
    item.id,
    item.tier,
    item.audience,
    item.text,
    item.requirementId,
    item.workPackageId ? `${item.workPackageId}${workPackages.has(item.workPackageId) ? ` ${workPackages.get(item.workPackageId).name}` : ''}` : '',
    item.why
  ]);
}

function workstreamRows(plan, lanes) {
  const skillNames = new Map(list(plan.skills).map((skill) => [skill.skillId, skill.name]));
  return list(plan.workstreams).map((row) => [
    row.id,
    row.name,
    row.kind,
    phaseOf(row),
    laneOf(row, lanes),
    row.owner,
    row.unit,
    // Only a tiered activity has one, and a reader should see a blank rather than a dash they
    // might take for a value.
    row.band || '',
    row.volume,
    row.volumeBasis,
    row.label,
    row.confidence,
    row.hoursPerUnit.traditional,
    row.hoursPerUnit.aiAssisted,
    row.rateBasis,
    row.caseCount,
    row.hours.low,
    row.traditionalHours,
    row.hours.high,
    row.aiAssistedHours,
    round2(row.traditionalHours - row.aiAssistedHours),
    row.traditionalHours > 0 ? Math.round(((row.traditionalHours - row.aiAssistedHours) / row.traditionalHours) * 1000) / 10 : 0,
    list(row.requirementIds).length,
    list(row.skills).map((id) => skillNames.get(id) || id).join(', '),
    list(row.volumeIds).join(', '),
    row.clientQuestion || ''
  ]);
}

function aiPlanRows(plan) {
  const aiPlan = plan.aiPlan;
  if (!isObject(aiPlan)) {
    return [];
  }
  const optOuts = new Map(list(aiPlan.optOuts).map((item) => [item.id, item]));
  const reasonOf = (id) => (optOuts.has(id) ? OPT_OUT_LABEL[optOuts.get(id).reason] || optOuts.get(id).reason : '');
  const noteOf = (id) => (optOuts.has(id) ? optOuts.get(id).note : '');
  const rows = [];
  for (const method of list(aiPlan.methods)) {
    rows.push([
      'Method', method.id, 'delivery method', 'estimating catalog', method.status, list(method.workstreams).join(', '), reasonOf(method.id), noteOf(method.id),
      `${method.default ? 'default method' : 'not a default method'}; tools: ${list(method.tools).join(', ') || 'none'}`
    ]);
  }
  for (const tool of list(aiPlan.tools)) {
    const methodsOff = list(tool.methods).length > 0 && tool.status === 'off' && !optOuts.has(tool.id);
    const detail = [
      tool.optIn ? 'opt-in' : '',
      tool.plugin ? `plugin ${tool.plugin}` : '',
      list(tool.methods).length ? `methods: ${tool.methods.join(', ')}` : '',
      methodsOff ? 'off because every delivery method that carries it is opted out' : ''
    ].filter(Boolean).join('; ');
    rows.push(['Tool', tool.id, tool.kind, SOURCE_LABEL[tool.source] || tool.source, tool.status, list(tool.workstreams).join(', '), reasonOf(tool.id), noteOf(tool.id), detail]);
  }
  for (const id of list(aiPlan.unusedTools)) {
    rows.push(['Unused', id, '', '', 'unused', '', '', '', 'The catalogs offer it on this platform; the estimating catalog maps it to no workstream.']);
  }
  for (const item of list(aiPlan.readiness)) {
    rows.push(['Readiness', item.item, item.kind, '', 'needed', list(item.workstreams).join(', '), '', '', `${item.needs} (${plural(item.tools, 'tool')})`]);
  }
  return rows;
}

function skillRows(plan) {
  return list(plan.skills).map((skill) => [
    skill.skillId, skill.name, skill.category, skill.traditionalHours, skill.aiAssistedHours, round2(skill.traditionalHours - skill.aiAssistedHours), list(skill.workstreams).join(', ')
  ]);
}

/**
 * Assumptions and risks, each a fact about the plan: a volume that is assumed, an opt-out, a document that was not
 * read, a requirement nobody decided on. Nothing here is a figure the tool made up.
 */
export function assumptionsAndRisks(plan) {
  const rows = [];
  const add = (type, statement, appliesTo, basis, ifWrong) => rows.push([`AR-${String(rows.length + 1).padStart(3, '0')}`, type, statement, appliesTo, basis, ifWrong]);
  const workstreams = list(plan.workstreams);
  const totals = estimateTotals(plan);

  const basis = isObject(plan.estimateBasis) ? plan.estimateBasis : {};
  if (basis.platformSource === 'estimator') {
    add('Assumption', `The platform is ${basis.platform}; the documents do not name it.`, 'All workstreams', 'Chosen by the estimator', 'The hours per unit change with the platform; run the estimate again.');
  }

  for (const row of workstreams) {
    if (row.volumeBasis !== 'placeholder') {
      continue;
    }
    if (row.kind === 'overhead') {
      add('Assumption', `${row.name} is a fixed ${row.traditionalHours} h.`, row.id, 'Starting figures of the estimating catalog', 'Replace with the catalog owner\'s figure; the hours move one for one.');
    } else {
      add(
        'Assumption',
        `${row.name} is sized on an assumed ${row.volume} ${row.unit}${row.volume === 1 ? '' : 's'}.`,
        row.id,
        `${row.label}; placeholder default of the catalog`,
        `Each ${row.unit} is ${row.hoursPerUnit.traditional} h traditional and ${row.hoursPerUnit.aiAssisted} h AI-assisted.${row.clientQuestion ? ` Ask: ${row.clientQuestion}` : ''}`
      );
    }
  }

  // A cap is the one assumption the reader has to agree to rather than just know about: it says
  // what the estimate is for, so anything past it is a change. It renders here with the rest
  // rather than in a register of its own, so a reader has one list to read (B-19).
  const capped = capsOf(plan);
  for (const row of workstreams) {
    const cap = capped.get(row.id);
    if (!cap) {
      continue;
    }
    const units = `${cap.cap} ${row.unit}${cap.cap === 1 ? '' : 's'}`;
    add(
      'Assumption',
      `${row.name} is capped at ${units}. More than that is a change to the estimate.`,
      row.id,
      `${row.volumeBasis === 'document' ? 'Capped by the estimator over a volume the documents quote' : 'Capped by the estimator over an assumed volume'}: ${cap.note}`,
      `Each ${row.unit} past the cap is ${row.hoursPerUnit.traditional} h traditional and ${row.hoursPerUnit.aiAssisted} h AI-assisted.`
    );
  }

  // Who does the work is a fact about the estimate the reader cannot get from the hours: a client
  // row reads as a small number rather than as work that left, and a shared row reads as ours.
  for (const row of workstreams) {
    if (row.owner === 'client') {
      add('Assumption', row.exclusion, row.id, `The estimator handed it to the client${row.wholeHours ? `; it would have been ${row.wholeHours} h` : ''}`, `Ask: ${row.ownerQuestion}`);
    } else if (row.owner === 'shared') {
      add('Assumption', `${row.name} is shared with the client, and the estimate carries all ${row.wholeHours} h of it.`, row.id, 'No past project records how shared work splits', `Ask: ${row.ownerQuestion}`);
    }
  }

  const aiPlan = isObject(plan.aiPlan) ? plan.aiPlan : undefined;
  if (aiPlan) {
    const off = list(aiPlan.tools).filter((tool) => tool.status === 'off').length;
    add(
      'Assumption',
      `Every available tool for ${aiPlan.platform} is used: ${aiPlan.inventory.on} of the ${aiPlan.inventory.used} tools a workstream uses are on${aiPlan.optOuts.length ? `, ${plural(aiPlan.optOuts.length, 'opt-out')} recorded` : ''}.`,
      'AI-assisted hours',
      'The AI plan (every tool and delivery method on unless opted out)',
      `Each tool that is not available moves the hours it supports back to the traditional rate.${off ? ` ${plural(off, 'tool')} off today.` : ''}`
    );
    for (const item of list(aiPlan.optOuts)) {
      const target = list(aiPlan.methods).find((method) => method.id === item.id) || list(aiPlan.tools).find((tool) => tool.id === item.id);
      add(
        'Assumption',
        `${item.id} is not used: ${OPT_OUT_LABEL[item.reason] || item.reason}. ${item.note}`,
        target ? list(target.workstreams).join(', ') : '',
        `Opt-out (${item.kind}) recorded ${item.at}`,
        'The hours it supported are at the traditional rate. Restore it if it becomes available.'
      );
    }
  }

  const bulk = [...list(plan.requirements), ...list(plan.volumes)].filter((row) => isObject(row.review) && row.review.via === 'bulk' && status(row) !== 'pending' && status(row) !== 'dismissed').length;
  if (bulk > 0) {
    add('Assumption', `${plural(bulk, 'requirement or volume')} were accepted together, not one at a time.`, 'Requirements, volumes', 'Accepted (bulk)', 'A wrong requirement or volume sizes a workstream. Walk through the ones that matter before the numbers are used.');
  }

  for (const source of list(plan.sources)) {
    if (source.read === 'partial' || source.read === 'not read') {
      const reasons = list(source.notRead).map((entry) => (isObject(entry) ? `${entry.reason || ''}${entry.pages ? ` (pages ${entry.pages})` : ''}` : String(entry))).join('; ');
      add('Risk', `${source.name} was ${source.read === 'partial' ? 'only partly read' : 'not read'}${reasons ? `: ${reasons}` : ''}.`, source.name, 'Parse stage', 'Requirements and volumes in the unread part are missing from the estimate.');
    }
  }

  const live = list(plan.requirements).filter((row) => status(row) !== 'dismissed');
  const pending = live.filter((row) => status(row) === 'pending').length;
  if (pending > 0) {
    add('Risk', `${plural(pending, 'requirement')} are still pending review.`, 'Requirements', 'Review column', 'A pending requirement may change the work package, the coverage or the volume.');
  }
  const unmapped = live.filter((row) => row.workPackage === 'unmapped').length;
  if (unmapped > 0) {
    add('Risk', `${plural(unmapped, 'requirement')} map to no work package.`, 'Requirements', 'Work package column', 'They add no workstream hours; each is a candidate for a missing workstream or a missing volume.');
  }
  for (const row of live.filter((item) => item.coverage === 'conflict')) {
    add('Risk', `The sources disagree on ${row.id}: ${row.statement}`, row.workPackage, list(row.sources).map((source) => source.label).join(' vs '), 'The workstream may be sized on the wrong figure; ask the client.');
  }
  const pendingVolumes = list(plan.volumes).filter((row) => status(row) === 'pending');
  if (pendingVolumes.length > 0) {
    add('Risk', `${plural(pendingVolumes.length, 'quoted volume')} are not accepted yet, so those workstreams still use a placeholder.`, pendingVolumes.map((row) => row.workPackageId).join(', '), 'Volumes of the plan', 'Accept them, or answer the client question, then run the estimate again.');
  }

  const placeholderHours = workstreams.filter((row) => row.kind === 'delivery' && row.volumeBasis === 'placeholder').reduce((sum, row) => sum + row.traditionalHours, 0);
  const placeholderCount = workstreams.filter((row) => row.kind === 'delivery' && row.volumeBasis === 'placeholder').length;
  const deliveryCount = workstreams.filter((row) => row.kind === 'delivery').length;
  if (placeholderCount > 0 && totals.traditionalHours > 0) {
    add(
      'Risk',
      `${placeholderCount} of ${deliveryCount} delivery workstreams (${Math.round((placeholderHours / totals.traditionalHours) * 100)}% of the traditional hours) rest on placeholder volumes.`,
      'Workstreams',
      'Volume basis column',
      'The total moves with every answer; treat it as a range until the client answers the questions.'
    );
  }

  for (const message of [...staleWorkstreams(plan), ...staleAiPlan(plan)]) {
    add('Risk', `The estimate is out of date: ${message}`, 'Workstreams', 'The plan changed after the estimate', 'Run the estimate and the AI plan again before the numbers are used.');
  }
  return rows;
}

/**
 * Everything the filler writes.
 * @param {object} plan a valid, estimated plan with an AI plan
 * @param {{ workPackages: Map<string, { name: string, unit: string }>, lanes: object[], now: string }} context
 */
export function buildSheetRows(plan, { workPackages, lanes, now }) {
  const basis = isObject(plan.estimateBasis) ? plan.estimateBasis : {};
  const catalog = isObject(plan.catalog) ? plan.catalog : {};
  const platformName = isObject(plan.platform) && plan.platform.name ? plan.platform.name : basis.platform;
  return {
    sheets: {
      Sources: sourceRows(plan),
      Requirements: requirementRows(plan),
      Questions: questionRows(plan, workPackages),
      Workstreams: workstreamRows(plan, lanes),
      'AI plan': aiPlanRows(plan),
      Skills: skillRows(plan),
      'Assumptions and risks': assumptionsAndRisks(plan)
    },
    names: {
      ProjectName: plan.projectName,
      Platform: basis.platform ? (platformName && platformName !== basis.platform ? `${platformName} (${basis.platform})` : basis.platform) : '',
      PlatformSource: basis.platformSource === 'estimator' ? 'chosen by the estimator' : 'named in the documents',
      CmkCommit: catalog.cmkCommit || '',
      ToolkitCommit: catalog.toolkitCommit || '',
      EstimatingVersion: catalog.estimatingVersion || '',
      EstimatedAt: basis.builtAt || '',
      BuiltAt: now
    }
  };
}
