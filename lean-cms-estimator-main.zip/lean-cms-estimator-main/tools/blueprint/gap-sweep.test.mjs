import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { gapSource, gapSweep, validateChecklist, DEFAULT_DATA } from './gap-sweep.mjs';
import { validateContextValue } from './validate-context.mjs';
import { parseEstimatingCatalog } from './derive-capabilities.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'gap-sweep.mjs');
const checklist = JSON.parse(fs.readFileSync(DEFAULT_DATA, 'utf8'));
const catalogMd = fs.readFileSync(path.join(root, 'docs', 'catalogs', 'estimating-catalog.md'), 'utf8');

function req(id, workPackage, statement, status) {
  return { id, workPackage, statement, ...(status ? { review: { status } } : {}) };
}

function small(extra = {}) {
  return {
    packages: [
      { workPackageId: 'content-model', name: 'Content modeling', basis: 'usual', unknown: 'U2', assumption: 'A2', ifFails: 'F2' },
      {
        workPackageId: 'search',
        name: 'Search',
        basis: 'signalled',
        signals: ['search', 'facet'],
        unknown: 'U8',
        assumption: 'A8',
        ifFails: 'F8'
      }
    ],
    ...extra
  };
}

test('the checklist is valid and lists exactly the activities of the estimating catalog, with the same names', () => {
  assert.deepEqual(validateChecklist(checklist), []);
  const catalog = parseEstimatingCatalog(catalogMd);
  assert.deepEqual(checklist.packages.map((entry) => entry.workPackageId).sort(), Array.from(catalog.workPackages).sort());
  for (const entry of checklist.packages) {
    assert.ok(catalogMd.includes(`| \`${entry.workPackageId}\` | ${entry.name} |`), `${entry.workPackageId} name differs from the catalog`);
  }
});

test('checklist text carries no numbers, hours or weeks', () => {
  for (const entry of checklist.packages) {
    for (const field of ['unknown', 'assumption', 'ifFails']) {
      assert.doesNotMatch(entry[field], /\d/, `${entry.workPackageId}.${field} has a digit`);
      assert.doesNotMatch(entry[field], /\b(hours?|weeks?|days?)\b/i, `${entry.workPackageId}.${field} names a duration`);
    }
  }
});

test('validateChecklist names the field that is wrong', () => {
  const errors = validateChecklist({
    schemaVersion: '2',
    packages: [
      { workPackageId: 'WP-5', name: '', basis: 'sometimes', unknown: 'u', assumption: 'a', ifFails: 'f' },
      { workPackageId: 'integrations', name: 'n', basis: 'signalled', signals: [], unknown: 'u', assumption: 'a', ifFails: 'f' },
      { workPackageId: 'integrations', name: 'n', basis: 'usual', signals: ['x'], unknown: 'u', assumption: 'a', ifFails: 'f' }
    ]
  });
  assert.ok(errors.some((text) => text.startsWith('schemaVersion')));
  assert.ok(errors.some((text) => text.startsWith('packages[0].workPackageId')));
  assert.ok(errors.some((text) => text.startsWith('packages[0].name')));
  assert.ok(errors.some((text) => text.startsWith('packages[0].basis')));
  assert.ok(errors.some((text) => text.startsWith('packages[1].signals')));
  assert.ok(errors.some((text) => text.includes('listed twice')));
  assert.ok(errors.some((text) => text.startsWith('packages[2].signals')));
});

test('a usual package with no requirement is a gap, and one that has a requirement is covered', () => {
  const result = gapSweep({ requirements: [req('R-1', 'content-model', 'Model the content')] }, small());
  assert.deepEqual(result.covered, ['content-model']);
  assert.deepEqual(result.gaps, []);
  const none = gapSweep({ requirements: [] }, small());
  assert.deepEqual(none.gaps.map((gap) => gap.workPackageId), ['content-model']);
  assert.deepEqual(none.notSignalled, ['search']);
});

test('a signalled package is a gap only when a requirement or question of another package carries a signal', () => {
  const blueprint = {
    requirements: [req('R-1', 'content-model', 'Editors need faceted navigation of the product pages'), req('R-2', 'component-build', 'Build the hero component')],
    questions: [{ id: 'Q1', requirementId: 'R-2', text: 'Is site search needed in the footer?' }]
  };
  const result = gapSweep(blueprint, small());
  const gap = result.gaps.find((item) => item.workPackageId === 'search');
  assert.ok(gap);
  assert.deepEqual(gap.evidence.matchedSignals, ['search', 'facet']);
  assert.deepEqual(gap.evidence.requirementIds, ['R-1']);
  assert.deepEqual(gap.evidence.questionIds, ['Q1']);
});

test('a signal in a dismissed requirement, or in a question about one, does not count', () => {
  const blueprint = {
    requirements: [req('R-1', 'content-model', 'Provide search', 'dismissed'), req('R-2', 'component-build', 'Build the hero')],
    questions: [{ id: 'Q1', requirementId: 'R-1', text: 'Which search tool?' }]
  };
  const result = gapSweep(blueprint, small());
  assert.deepEqual(result.notSignalled, ['search']);
  assert.deepEqual(result.dismissedOnly, ['content-model']);
});

test('a package the estimator dismissed is never a gap', () => {
  const result = gapSweep({ requirements: [req('R-1', 'content-model', 'Model the content', 'dismissed')] }, small());
  assert.deepEqual(result.dismissedOnly, ['content-model']);
  assert.deepEqual(result.gaps, []);
});

test('a gap already in the Context sidecar is not proposed again, whatever its review status', () => {
  const result = gapSweep({ requirements: [] }, small(), { existingSources: [gapSource('content-model').toUpperCase()] });
  assert.deepEqual(result.alreadyProposed, ['content-model']);
  assert.deepEqual(result.gaps, []);
});

test('each gap has a pending unknown and a scope assumption in the shape the Context validator accepts', () => {
  const result = gapSweep({ requirements: [] }, checklist);
  assert.ok(result.gaps.length > 0);
  const context = {
    meta: { schemaVersion: '2', producedBy: 'skill' },
    deliveryUnknowns: result.gaps.map((gap, index) => ({ id: `DU-${String(index + 1).padStart(3, '0')}`, ...gap.unknown })),
    assumptions: result.gaps.map((gap, index) => ({
      id: `AS-${String(index + 1).padStart(3, '0')}`,
      ...gap.assumption,
      refs: [`DU-${String(index + 1).padStart(3, '0')}`]
    }))
  };
  assert.deepEqual(validateContextValue(context), []);
  for (const gap of result.gaps) {
    assert.deepEqual(gap.unknown.review, { status: 'pending' });
    assert.equal(gap.unknown.source, gapSource(gap.workPackageId));
    assert.equal(gap.assumption.category, 'scope');
    assert.equal(gap.assumption.confidence, 'low');
  }
});

test('a package id outside the checklist is reported, but "unmapped" is not', () => {
  const result = gapSweep({ requirements: [req('R-1', 'WP-99', 'x'), req('R-2', 'unmapped', 'y')] }, small());
  assert.deepEqual(result.unknownPackageIds, ['WP-99']);
});

function runCli(args) {
  return spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
}

test('the CLI sweeps the synthetic sample: covered packages are left out and the usual gaps are found', () => {
  const run = runCli([path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json')]);
  assert.equal(run.status, 0, run.stderr);
  assert.equal(run.stderr, '');
  const result = JSON.parse(run.stdout);
  assert.deepEqual(result.gaps.map((gap) => gap.workPackageId), ['content-model', 'component-build', 'qa-automation', 'solution-architecture', 'workflow-governance', 'accessibility-audit', 'cutover', 'training-enablement', 'hypercare', 'project-management', 'delivery-governance']);
  assert.ok(result.covered.includes('content-migration'));
});

test('the CLI skips a gap that --existing already holds and rejects an invalid sidecar', () => {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'gap-sweep-'));
  const blueprint = path.join(root, 'samples', 'agent-run', 'Fabrikam Outdoor_Blueprint.json');
  const context = path.join(folder, 'context.json');
  fs.writeFileSync(
    context,
    JSON.stringify({
      meta: { schemaVersion: '2', producedBy: 'skill' },
      deliveryUnknowns: [{ id: 'DU-001', statement: 's', source: gapSource('content-model'), review: { status: 'dismissed' } }]
    })
  );
  const run = runCli([blueprint, '--existing', context]);
  assert.equal(run.status, 0, run.stderr);
  const result = JSON.parse(run.stdout);
  assert.deepEqual(result.alreadyProposed, ['content-model']);
  assert.deepEqual(result.gaps.map((gap) => gap.workPackageId), ['component-build', 'qa-automation', 'solution-architecture', 'workflow-governance', 'accessibility-audit', 'cutover', 'training-enablement', 'hypercare', 'project-management', 'delivery-governance']);
  fs.writeFileSync(context, JSON.stringify({ deliveryUnknowns: 'no' }));
  const bad = runCli([blueprint, '--existing', context]);
  assert.equal(bad.status, 1);
  assert.match(bad.stderr, /\(existing\)/);
});

test('the CLI exits 1 for a missing or malformed Blueprint and 2 for bad usage', () => {
  assert.equal(runCli([path.join(os.tmpdir(), 'no-such-blueprint.json')]).status, 1);
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'gap-sweep-'));
  const file = path.join(folder, 'b.json');
  fs.writeFileSync(file, JSON.stringify({ questions: [] }));
  assert.equal(runCli([file]).status, 1);
  assert.equal(runCli([]).status, 2);
  assert.equal(runCli([file, '--bogus']).status, 2);
  assert.equal(runCli([file, '--existing']).status, 2);
});

test('the gap assumption carries the same source marker as the unknown, so either one marks the gap as proposed', () => {
  const result = gapSweep({ requirements: [req('R-1', 'search', 'Search the site')] }, small());
  const gap = result.gaps.find((item) => item.workPackageId === 'content-model');
  assert.equal(gap.unknown.source, gapSource('content-model'));
  assert.equal(gap.assumption.source, gapSource('content-model'));
  const again = gapSweep({ requirements: [req('R-1', 'search', 'Search the site')] }, small(), { existingSources: [gapSource('content-model')] });
  assert.deepEqual(again.alreadyProposed, ['content-model']);
});

test('a suppressed gap is listed apart from one already in the sidecar', () => {
  const result = gapSweep({ requirements: [req('R-1', 'search', 'Search the site')] }, small(), {
    suppressedSources: ['  gap sweep checklist content-model ']
  });
  assert.deepEqual(result.suppressed, ['content-model']);
  assert.deepEqual(result.alreadyProposed, []);
  assert.equal(result.gaps.some((item) => item.workPackageId === 'content-model'), false);
});

test('the command reads a gap from an assumption in the sidecar and stops with 1 on a bad suppression file', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gap-sweep-'));
  try {
    const blueprint = path.join(dir, 'P_Blueprint.json');
    fs.writeFileSync(blueprint, JSON.stringify({ requirements: [req('R-1', 'search', 'Search the site')] }));
    const context = path.join(dir, 'P_Context.json');
    fs.writeFileSync(context, JSON.stringify({
      schemaVersion: '2',
      assumptions: [{ id: 'AS-001', statement: 'A2', category: 'scope', confidence: 'low', ifFails: 'F2', source: gapSource('content-model'), review: { status: 'dismissed' } }]
    }));
    const data = path.join(dir, 'data.json');
    fs.writeFileSync(data, JSON.stringify({ schemaVersion: '1', ...small() }));
    const run = spawnSync(process.execPath, [script, blueprint, '--data', data, '--existing', context], { encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.deepEqual(JSON.parse(run.stdout).alreadyProposed, ['content-model']);
    const bad = path.join(dir, 'bad.json');
    fs.writeFileSync(bad, JSON.stringify({ schemaVersion: '1', items: [{ key: 'content-model', family: 'gap-sweep' }] }));
    const stopped = spawnSync(process.execPath, [script, blueprint, '--data', data, '--suppress', bad], { encoding: 'utf8' });
    assert.equal(stopped.status, 1);
    assert.match(stopped.stderr, /\(suppress\) items\[0\]\.key/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
