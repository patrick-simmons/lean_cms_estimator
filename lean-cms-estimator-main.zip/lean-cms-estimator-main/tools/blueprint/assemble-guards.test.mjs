import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import { assembleWorkingFile, hasReviewState, proposeChanges } from './assemble-working-file.mjs';
import { blocks, catalogMd, estimatingPath, reviewedBlueprint, rerunExtract, root } from './fixtures/assemble-fixtures.mjs';
import { validateProposalsValue } from './validate-proposals.mjs';

const script = join(root, 'tools', 'blueprint', 'assemble-working-file.mjs');

/** Run the assembler in a scratch folder with the given extract and blocks. */
function cli(scratch, extract, blockList, args) {
  writeFileSync(join(scratch, 'extract.json'), JSON.stringify(extract));
  writeFileSync(join(scratch, 'blocks.json'), JSON.stringify(blockList));
  const common = ['--extract', join(scratch, 'extract.json'), '--blocks', join(scratch, 'blocks.json'), '--estimating', estimatingPath];
  return spawnSync(process.execPath, [script, ...common, ...args], { encoding: 'utf8' });
}

function withScratch(fn) {
  const scratch = mkdtempSync(join(tmpdir(), 'assemble-guards-'));
  try {
    fn(scratch);
  } finally {
    rmSync(scratch, { recursive: true, force: true });
  }
}

const firstArgs = (out) => ['--project-id', 'p1', '--project-name', 'Pilot', '--out', out];
const proposalsArgs = (existing, out) => ['--mode', 'proposals', '--existing', existing, '--out', out];
const oneRow = { requirements: [{ statement: 'Migrate 18,240 pages.', blockIds: ['src-rfp#p1'], workPackage: 'content-migration', coverage: 'accelerated' }], platform: { id: null, blockId: null } };

describe('assemble-working-file first-run guards', () => {
  it('refuses to overwrite a Blueprint it cannot read, and leaves the bytes alone', () => {
    const unreadable = [
      ['truncated', '{"revision":3,"requirements":[{"review":{"status":"accepted"'],
      ['empty', ''],
      ['an array', '[]'],
      ['a string', '"x"']
    ];
    for (const [label, content] of unreadable) {
      withScratch((scratch) => {
        const out = join(scratch, 'Pilot_Blueprint.json');
        writeFileSync(out, content);
        const result = cli(scratch, oneRow, blocks, firstArgs(out));
        assert.equal(result.status, 3, `${label}: ${result.stderr}`);
        assert.match(result.stderr, /not overwritten/);
        assert.equal(readFileSync(out, 'utf8'), content, `${label}: the file is unchanged`);
      });
    }
  });

  it('writes a first run when the file is missing or untouched, and leaves no temp file behind', () => {
    withScratch((scratch) => {
      const out = join(scratch, 'Pilot_Blueprint.json');
      const first = cli(scratch, oneRow, blocks, firstArgs(out));
      assert.equal(first.status, 0, first.stderr);
      const again = cli(scratch, oneRow, blocks, firstArgs(out));
      assert.equal(again.status, 0, 'a repeat first run may rewrite an untouched file');
      assert.deepEqual(readdirSync(scratch).filter((name) => name.endsWith('.tmp')), []);
    });
  });

  it('counts notes, proposals, edited rows and questions the agent did not write as review state', () => {
    const { working } = assembleWorkingFile({
      extract: { requirements: [{ statement: 'A', blockIds: ['src-rfp#p1'], workPackage: 'content-migration', coverage: 'accelerated', question: 'Which?' }], platform: { id: null, blockId: null } },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(working.questions.length, 1);
    assert.equal(hasReviewState(working), false, 'the question the agent wrote is not review state');
    assert.equal(hasReviewState({ ...working, notes: [{ text: 'call the client' }] }), true);
    assert.equal(hasReviewState({ ...working, proposals: [{ id: 'P-001' }] }), true);
    assert.equal(hasReviewState({ ...working, requirements: [{ ...working.requirements[0], original: { statement: 'x' } }] }), true);
    assert.equal(hasReviewState({ ...working, questions: [...working.questions, { id: 'Q9', requirementId: 'R-001', text: 'Added by a person' }] }), true);
  });

  it('exits 1 and writes nothing when the Blueprint it would write is not valid', () => {
    withScratch((scratch) => {
      const out = join(scratch, 'Pilot_Blueprint.json');
      const noItem = [{ id: 'b1', fileName: 'x.pdf', text: 'Migrate pages.', location: { kind: 'page', page: 1 } }];
      const result = cli(scratch, { requirements: [{ statement: 'S', blockIds: ['b1'], workPackage: 'content-migration', coverage: 'partly' }] }, noItem, firstArgs(out));
      assert.equal(result.status, 1, result.stderr);
      assert.match(result.stderr, /sources\[0\]\.itemId/);
      assert.equal(existsSync(out), false);
    });
  });
});

describe('assemble-working-file empty and lossy extractions', () => {
  it('exits 4 and writes nothing when the extract has no requirements or every block id is unknown', () => {
    withScratch((scratch) => {
      const out = join(scratch, 'Pilot_Blueprint.json');
      const empty = cli(scratch, { requirements: [] }, blocks, firstArgs(out));
      assert.equal(empty.status, 4, empty.stderr);
      assert.match(empty.stderr, /lists no requirements/);
      const wrongIds = cli(scratch, { requirements: [{ statement: 'S', blockIds: ['nope#1'], workPackage: 'content-migration', coverage: 'partly' }] }, blocks, firstArgs(out));
      assert.equal(wrongIds.status, 4, wrongIds.stderr);
      assert.match(wrongIds.stderr, /1 blockId\(s\) are not in the blocks file/);
      assert.equal(existsSync(out), false);
    });
  });

  it('exits 1 for an extract that is not an object with requirements', () => {
    withScratch((scratch) => {
      const result = cli(scratch, [], blocks, firstArgs(join(scratch, 'Pilot_Blueprint.json')));
      assert.equal(result.status, 1, result.stderr);
    });
  });

  it('warns when more than half is dropped, when --sources is missing, and when a coverage was coerced', () => {
    withScratch((scratch) => {
      const out = join(scratch, 'Pilot_Blueprint.json');
      const extract = {
        requirements: [
          { statement: 'Kept.', blockIds: ['src-rfp#p1'], workPackage: 'content-migration', coverage: 'banana' },
          { statement: '   ', blockIds: ['src-rfp#p1'] },
          { statement: 'No block.', blockIds: ['nope'] }
        ],
        platform: { id: null, blockId: null }
      };
      const result = cli(scratch, extract, blocks, firstArgs(out));
      assert.equal(result.status, 0, result.stderr);
      assert.match(result.stderr, /warning: more than half of the extracted requirements were dropped \(2 of 3\)/);
      assert.match(result.stderr, /warning: --sources was not given/);
      assert.match(result.stderr, /warning: 1 requirement\(s\) had an unknown or missing coverage/);
      assert.match(result.stderr, /warning: 1 requirement\(s\) dropped for an empty statement/);
      const stats = JSON.parse(/^stats (.*)$/m.exec(result.stdout)[1]);
      assert.equal(stats.droppedEmptyStatement, 1);
      assert.equal(stats.droppedNoSource, 1);
      assert.equal(stats.coverageCoerced, 1);
    });
  });

  it('does not cite a block with no text', () => {
    const blank = [{ id: 'b1', itemId: 'src-x', fileName: 'X.pdf', text: '  ', location: { kind: 'page', page: 1 } }];
    const { stats } = assembleWorkingFile({
      extract: { requirements: [{ statement: 'S', blockIds: ['b1'], workPackage: 'content-migration', coverage: 'partly' }] },
      blocks: blank,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(stats.droppedEmptyBlocks, 1);
    assert.equal(stats.droppedNoSource, 1);
  });
});

describe('assemble-working-file conflicts', () => {
  const conflictRow = (extra = {}) => ({
    statement: 'The deck says two launch locales.',
    blockIds: ['src-deck#s9'],
    workPackage: 'localization',
    coverage: 'conflict',
    question: null,
    ...extra
  });

  it('downgrades a conflict with one citation on a first run, even when duplicateOf is set', () => {
    for (const duplicateOf of [null, 'Launch in four locales.']) {
      const { working, stats } = assembleWorkingFile({
        extract: { requirements: [conflictRow({ duplicateOf })] },
        blocks,
        catalogMd,
        meta: { projectId: 'p1', projectName: 'Pilot' }
      });
      assert.notEqual(working.requirements[0].coverage, 'conflict');
      assert.equal(stats.conflictDowngraded, 1);
    }
  });

  it('keeps a first-run conflict that cites two blocks', () => {
    const { working, stats } = assembleWorkingFile({
      extract: { requirements: [conflictRow({ blockIds: ['src-deck#s9', 'src-rfp#p2'] })] },
      blocks,
      catalogMd,
      meta: { projectId: 'p1', projectName: 'Pilot' }
    });
    assert.equal(working.requirements[0].coverage, 'conflict');
    assert.equal(stats.conflictDowngraded, 0);
  });

  it('on a re-run, a duplicateOf that names no row becomes an ordinary add with a warning', () => {
    const { proposals, stats, warnings } = proposeChanges({
      extract: { requirements: [conflictRow({ duplicateOf: 'A statement that is not in the Blueprint.' })] },
      blocks,
      catalogMd,
      existing: reviewedBlueprint(),
      meta: { runId: 'run-2', now: '2026-11-09T10:00:00Z' }
    });
    assert.equal(stats.duplicateTargetMissing, 1);
    assert.equal(stats.conflictDowngraded, 1);
    assert.equal(proposals.proposals.length, 1);
    assert.equal(proposals.proposals[0].kind, 'add');
    assert.notEqual(proposals.proposals[0].coverage, 'conflict');
    assert.deepEqual(validateProposalsValue(proposals), []);
    assert.ok(warnings.some((w) => /duplicateOf row that is not in the Blueprint/.test(w)), warnings.join('\n'));
  });

  it('on a re-run, a conflict with one new citation is a conflict against the named row', () => {
    const { proposals, stats } = proposeChanges({
      extract: { requirements: [conflictRow({ duplicateOf: 'Launch in four locales, EN first.' })] },
      blocks,
      catalogMd,
      existing: reviewedBlueprint(),
      meta: { runId: 'run-2', now: '2026-11-09T10:00:00Z' }
    });
    assert.equal(stats.conflicts, 1);
    assert.equal(proposals.proposals[0].kind, 'conflict');
    assert.equal(proposals.proposals[0].requirementId, 'R-002');
    assert.equal(stats.conflictQuestionGenerated, 1, 'the model sent no question, so one is written from the two statements');
    assert.match(proposals.proposals[0].question, /Launch in four locales, EN first\./);
    assert.deepEqual(validateProposalsValue(proposals), []);
  });
});

describe('assemble-working-file proposals mode guards', () => {
  it('refuses --out equal to --existing and leaves the Blueprint alone', () => {
    withScratch((scratch) => {
      const blueprintPath = join(scratch, 'Pilot_Blueprint.json');
      writeFileSync(blueprintPath, JSON.stringify(reviewedBlueprint()));
      const before = readFileSync(blueprintPath, 'utf8');
      const result = cli(scratch, rerunExtract, blocks, proposalsArgs(blueprintPath, blueprintPath));
      assert.equal(result.status, 2, result.stderr);
      assert.match(result.stderr, /never changes the Blueprint/);
      assert.equal(readFileSync(blueprintPath, 'utf8'), before);
    });
  });

  it('refuses an invalid, foreign or unreadable previous proposals file and does not touch it', () => {
    withScratch((scratch) => {
      const blueprintPath = join(scratch, 'Pilot_Blueprint.json');
      const out = join(scratch, 'Pilot_Proposals.json');
      writeFileSync(blueprintPath, JSON.stringify(reviewedBlueprint()));
      const valid = proposeChanges({ extract: rerunExtract, blocks, catalogMd, existing: reviewedBlueprint(), meta: { runId: 'run-2', now: '2026-11-09T10:00:00Z' } }).proposals;

      const invalid = JSON.stringify({ ...valid, schemaVersion: '9' });
      writeFileSync(out, invalid);
      const first = cli(scratch, rerunExtract, blocks, proposalsArgs(blueprintPath, out));
      assert.equal(first.status, 1, first.stderr);
      assert.match(first.stderr, /schemaVersion/);
      assert.equal(readFileSync(out, 'utf8'), invalid);

      const foreign = JSON.stringify({ ...valid, projectId: 'other' });
      writeFileSync(out, foreign);
      const second = cli(scratch, rerunExtract, blocks, proposalsArgs(blueprintPath, out));
      assert.equal(second.status, 1, second.stderr);
      assert.match(second.stderr, /belongs to project "other"/);
      assert.equal(readFileSync(out, 'utf8'), foreign);

      writeFileSync(out, '{"truncated"');
      const third = cli(scratch, rerunExtract, blocks, proposalsArgs(blueprintPath, out));
      assert.equal(third.status, 1, third.stderr);
      assert.equal(readFileSync(out, 'utf8'), '{"truncated"');
    });
  });

  it('exits 4 on a re-run whose extract has nothing usable, and writes no proposals file', () => {
    withScratch((scratch) => {
      const blueprintPath = join(scratch, 'Pilot_Blueprint.json');
      const out = join(scratch, 'Pilot_Proposals.json');
      writeFileSync(blueprintPath, JSON.stringify(reviewedBlueprint()));
      const result = cli(scratch, { requirements: [{ statement: 'S', blockIds: ['nope'] }] }, blocks, proposalsArgs(blueprintPath, out));
      assert.equal(result.status, 4, result.stderr);
      assert.equal(existsSync(out), false);
    });
  });

  it('replaces the proposals file in one step: no temp file is left and the result validates', () => {
    withScratch((scratch) => {
      const blueprintPath = join(scratch, 'Pilot_Blueprint.json');
      const out = join(scratch, 'Pilot_Proposals.json');
      writeFileSync(blueprintPath, JSON.stringify(reviewedBlueprint()));
      const result = cli(scratch, rerunExtract, blocks, proposalsArgs(blueprintPath, out));
      assert.equal(result.status, 0, result.stderr);
      assert.deepEqual(readdirSync(scratch).filter((name) => name.endsWith('.tmp')), []);
      assert.deepEqual(validateProposalsValue(JSON.parse(readFileSync(out, 'utf8'))), []);
    });
  });
});
