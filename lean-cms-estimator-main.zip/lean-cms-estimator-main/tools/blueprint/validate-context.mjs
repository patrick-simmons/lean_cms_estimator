#!/usr/bin/env node
/**
 * Offline Context sidecar validator (schemaVersion 1 and 2).
 * Exit 0 when legal. Exit 1 for field-path errors on stderr, or when the context
 * file or the --blueprint file cannot be read, is not JSON, or (Blueprint) lacks
 * `requirements` and `questions` arrays. Exit 2 on bad usage.
 * Warnings (dangling references, v2 content under another schemaVersion) go to
 * stderr as `warning: ...`, only when there are no errors, and never change the
 * exit code. `OK: <file>` goes to stdout.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const REVIEW_STATUSES = new Set(['pending', 'accepted', 'edited', 'dismissed']);
const PRODUCED_BY = new Set(['skill', 'ui', 'mixed']);
const LEVELS = ['low', 'medium', 'high'];
const PRIORITIES = ['high', 'medium', 'low'];
const ASSUMPTION_CATEGORIES = ['scope', 'architecture', 'dependency', 'resource', 'delivery', 'estimate'];
const LIST_KEYS = ['deliveryRisks', 'deliveryUnknowns', 'assumptions', 'dependencies'];
const RISK_V2_FIELDS = ['likelihood', 'severity', 'impact', 'mitigation'];
const SIDECAR_REF = /^(DR|DU|AS|DP)-\d+$/;
const REQUIREMENT_REF = /^R-\d+$/;
const QUESTION_REF = /^Q\d+$/;
const USAGE = 'Usage: node tools/blueprint/validate-context.mjs <path-to-context.json> [--blueprint <path-to-blueprint.json>]';
const DENIED_TOP = new Set([
  'accountHistory',
  'newLogo',
  'commercialRisks',
  'workEnvironment',
  'clientDifficulty',
  'difficultyMultipliers',
  'staffingProfiles'
]);

function isObject(value) {
  return typeof value === 'object' && !!value && !Array.isArray(value);
}

function isString(value) {
  return typeof value === 'string';
}

function isText(value) {
  return isString(value) && value.trim().length > 0;
}

function isStringOrNumber(value) {
  return isString(value) || (typeof value === 'number' && Number.isFinite(value));
}

function checkString(errors, p, item, key) {
  if (item[key] !== undefined && !isString(item[key])) {
    errors.push(`${p}.${key}: expected string`);
  }
}

function checkEnum(errors, p, item, key, allowed) {
  const v = item[key];
  if (v !== undefined && (!isString(v) || allowed.indexOf(v) === -1)) {
    errors.push(`${p}.${key}: expected ${allowed.join('|')}`);
  }
}

/**
 * Errors only. Mirrors validateContextValue in
 * src/webparts/blueprint/projects/contextFile.ts: keep the text and order identical
 * (both suites run tools/blueprint/fixtures/context-validator-cases.json).
 * @param {unknown} value
 * @param {string} base
 * @returns {string[]}
 */
export function validateContextValue(value, base = '') {
  const errors = [];
  if (!isObject(value)) {
    return [`${base || '(root)'}: expected object`];
  }

  for (const key of Object.keys(value)) {
    if (DENIED_TOP.has(key)) {
      errors.push(`${base}${key}: out-of-scope field (do not put on Context sidecar)`);
    }
  }

  if (value.constraints !== undefined) {
    if (!isObject(value.constraints)) {
      errors.push(`${base}constraints: expected object`);
    } else {
      const c = value.constraints;
      for (const key of ['budgetCap', 'priceToWin']) {
        if (c[key] !== undefined && !isStringOrNumber(c[key])) {
          errors.push(`${base}constraints.${key}: expected string or number`);
        }
      }
      for (const key of ['calendar', 'geoResourcing']) {
        if (c[key] !== undefined && !isString(c[key])) {
          errors.push(`${base}constraints.${key}: expected string`);
        }
      }
    }
  }

  if (value.framing !== undefined) {
    if (!isObject(value.framing)) {
      errors.push(`${base}framing: expected object`);
    } else {
      for (const key of ['problemStatement', 'desiredOutcome', 'winTheme']) {
        if (value.framing[key] !== undefined && !isString(value.framing[key])) {
          errors.push(`${base}framing.${key}: expected string`);
        }
      }
    }
  }

  const firstSeen = new Map();
  for (const listKey of LIST_KEYS) {
    if (value[listKey] === undefined) {
      continue;
    }
    if (!Array.isArray(value[listKey])) {
      errors.push(`${base}${listKey}: expected array`);
      continue;
    }
    value[listKey].forEach((item, i) => {
      const p = `${base}${listKey}[${i}]`;
      if (!isObject(item)) {
        errors.push(`${p}: expected object`);
        return;
      }
      if (!isText(item.id)) {
        errors.push(`${p}.id: required non-empty string`);
      } else {
        const id = item.id.trim();
        const first = firstSeen.get(id);
        if (first !== undefined) {
          errors.push(`${p}.id: duplicate id "${id}" (also ${first})`);
        } else {
          firstSeen.set(id, `${p}.id`);
        }
      }
      if (!isText(item.statement)) {
        errors.push(`${p}.statement: required non-empty string`);
      }
      if (item.source !== undefined && !isString(item.source)) {
        errors.push(`${p}.source: expected string`);
      }
      if (item.review !== undefined) {
        if (!isObject(item.review)) {
          errors.push(`${p}.review: expected object`);
        } else if (!isString(item.review.status) || !REVIEW_STATUSES.has(item.review.status)) {
          errors.push(`${p}.review.status: expected pending|accepted|edited|dismissed`);
        }
      }
      if (item.refs !== undefined) {
        if (!Array.isArray(item.refs)) {
          errors.push(`${p}.refs: expected array of non-empty strings`);
        } else {
          item.refs.forEach((ref, j) => {
            if (!isText(ref)) {
              errors.push(`${p}.refs[${j}]: expected non-empty string`);
            }
          });
        }
      }
      checkString(errors, p, item, 'libraryId');
      if (listKey === 'deliveryRisks') {
        checkEnum(errors, p, item, 'likelihood', LEVELS);
        checkEnum(errors, p, item, 'severity', LEVELS);
        checkString(errors, p, item, 'impact');
        checkString(errors, p, item, 'mitigation');
        for (const key of ['level', 'score']) {
          if (item[key] !== undefined) {
            errors.push(`${p}.${key}: derived field, do not store`);
          }
        }
      } else if (listKey === 'assumptions') {
        checkEnum(errors, p, item, 'category', ASSUMPTION_CATEGORIES);
        checkEnum(errors, p, item, 'confidence', LEVELS);
        checkString(errors, p, item, 'ifFails');
        checkString(errors, p, item, 'appliesTo');
      } else if (listKey === 'dependencies') {
        checkString(errors, p, item, 'owner');
        checkString(errors, p, item, 'needed');
        checkString(errors, p, item, 'impactIfMissing');
        checkEnum(errors, p, item, 'priority', PRIORITIES);
        const week = item.requiredWeek;
        if (week !== undefined && !(typeof week === 'number' && Number.isInteger(week) && week >= 1)) {
          errors.push(`${p}.requiredWeek: expected whole number of 1 or more`);
        }
      }
    });
  }

  if (value.meta !== undefined) {
    if (!isObject(value.meta)) {
      errors.push(`${base}meta: expected object`);
    } else {
      if (value.meta.schemaVersion !== undefined && !isString(value.meta.schemaVersion)) {
        errors.push(`${base}meta.schemaVersion: expected string`);
      }
      if (value.meta.producedBy !== undefined) {
        if (!isString(value.meta.producedBy) || !PRODUCED_BY.has(value.meta.producedBy)) {
          errors.push(`${base}meta.producedBy: expected skill|ui|mixed`);
        }
      }
      if (value.meta.updatedAt !== undefined && !isString(value.meta.updatedAt)) {
        errors.push(`${base}meta.updatedAt: expected string`);
      }
    }
  }

  return errors;
}

/**
 * Non-fatal findings for a value that already passes validateContextValue.
 * Returns text without the `warning: ` prefix. Tolerates malformed input.
 * A sidecar reference resolves only by exact match to a trimmed item id (`DR-1`
 * does not match `DR-001`).
 * @param {unknown} value
 * @param {{ requirements: Set<string>, questions: Set<string> }} [blueprintIds]
 *   When given, R-n and Qn references are checked against these ids.
 * @returns {string[]}
 */
export function collectContextWarnings(value, blueprintIds) {
  const warnings = [];
  if (!isObject(value)) {
    return warnings;
  }
  const isV2 = isObject(value.meta) && value.meta.schemaVersion === '2';
  const notV2 = 'but meta.schemaVersion is not "2"';

  const ids = new Set();
  for (const listKey of LIST_KEYS) {
    if (Array.isArray(value[listKey])) {
      for (const item of value[listKey]) {
        if (isObject(item) && isText(item.id)) {
          ids.add(item.id.trim());
        }
      }
    }
  }

  for (const listKey of LIST_KEYS) {
    if (value[listKey] === undefined) {
      continue;
    }
    if (!isV2 && (listKey === 'assumptions' || listKey === 'dependencies')) {
      warnings.push(`${listKey}: v2 array present ${notV2}`);
    }
    if (!Array.isArray(value[listKey])) {
      continue;
    }
    value[listKey].forEach((item, i) => {
      if (!isObject(item)) {
        return;
      }
      const p = `${listKey}[${i}]`;
      if (!isV2 && (listKey === 'deliveryRisks' || listKey === 'deliveryUnknowns')) {
        const fields = ['refs', 'libraryId'].concat(listKey === 'deliveryRisks' ? RISK_V2_FIELDS : []);
        for (const key of fields) {
          if (item[key] !== undefined) {
            warnings.push(`${p}.${key}: v2 field present ${notV2}`);
          }
        }
      }
      if (!Array.isArray(item.refs)) {
        return;
      }
      item.refs.forEach((ref, j) => {
        if (!isString(ref) || ids.has(ref)) {
          return;
        }
        const at = `${p}.refs[${j}]`;
        if (SIDECAR_REF.test(ref)) {
          warnings.push(`${at}: reference "${ref}" matches no item in this file`);
        } else if (REQUIREMENT_REF.test(ref)) {
          if (blueprintIds && !blueprintIds.requirements.has(ref)) {
            warnings.push(`${at}: reference "${ref}" matches no requirement in the Blueprint file`);
          }
        } else if (QUESTION_REF.test(ref)) {
          if (blueprintIds && !blueprintIds.questions.has(ref)) {
            warnings.push(`${at}: reference "${ref}" matches no question in the Blueprint file`);
          }
        } else {
          warnings.push(`${at}: unrecognised reference "${ref}" (expected DR-n, DU-n, AS-n, DP-n, R-n or Qn)`);
        }
      });
    });
  }

  return warnings;
}

function idsOf(list) {
  const out = new Set();
  if (Array.isArray(list)) {
    for (const item of list) {
      if (isObject(item) && isString(item.id)) {
        out.add(item.id);
      }
    }
  }
  return out;
}

/** @returns {{ filePath?: string, blueprintPath?: string } | undefined} undefined on bad usage */
function parseArgs(args) {
  const parsed = {};
  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];
    if (arg === '--blueprint') {
      const next = args[i + 1];
      if (next === undefined || next === '' || next.indexOf('-') === 0 || parsed.blueprintPath !== undefined) {
        return undefined;
      }
      parsed.blueprintPath = next;
      i += 1;
    } else if (arg.indexOf('-') === 0 || parsed.filePath !== undefined) {
      return undefined;
    } else {
      parsed.filePath = arg;
    }
  }
  return parsed.filePath ? parsed : undefined;
}

function main(argv) {
  const parsedArgs = parseArgs(argv.slice(2));
  if (!parsedArgs) {
    console.error(USAGE);
    process.exit(2);
  }
  const abs = path.resolve(parsedArgs.filePath);
  let raw;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch (err) {
    console.error(`Cannot read ${abs}: ${err.message}`);
    process.exit(1);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    console.error(`(root): invalid JSON (${err.message})`);
    process.exit(1);
  }
  const errors = validateContextValue(parsed);
  if (errors.length) {
    for (const e of errors) {
      console.error(e);
    }
    process.exit(1);
  }

  let blueprintIds;
  if (parsedArgs.blueprintPath !== undefined) {
    const blueprintAbs = path.resolve(parsedArgs.blueprintPath);
    let blueprintRaw;
    try {
      blueprintRaw = fs.readFileSync(blueprintAbs, 'utf8');
    } catch (err) {
      console.error(`Cannot read ${blueprintAbs}: ${err.message}`);
      process.exit(1);
    }
    let blueprint;
    try {
      blueprint = JSON.parse(blueprintRaw);
    } catch (err) {
      console.error(`(blueprint): invalid JSON (${err.message})`);
      process.exit(1);
    }
    // Same shape the working-file validator requires; anything else would leave
    // every R- and Q reference silently unchecked.
    if (!isObject(blueprint)) {
      console.error('(blueprint): expected object');
      process.exit(1);
    }
    const shapeErrors = ['requirements', 'questions']
      .filter((key) => !Array.isArray(blueprint[key]))
      .map((key) => `(blueprint).${key}: expected array`);
    if (shapeErrors.length) {
      for (const e of shapeErrors) {
        console.error(e);
      }
      process.exit(1);
    }
    blueprintIds = {
      requirements: idsOf(blueprint.requirements),
      questions: idsOf(blueprint.questions)
    };
  }

  for (const w of collectContextWarnings(parsed, blueprintIds)) {
    console.error(`warning: ${w}`);
  }
  console.log(`OK: ${path.basename(abs)}`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main(process.argv);
}
