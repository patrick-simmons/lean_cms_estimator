import assert from 'node:assert/strict';
import test from 'node:test';

import { OWNERS, ownerDecisions, ownershipOf } from './ownership.mjs';

const uat = { id: 'uat-support', name: 'UAT support', unit: 'fixed' };
const build = { id: 'component-build', name: 'Component build', unit: 'component' };

function decision(owner, note = 'because somebody said so', status = 'accepted') {
  return { activity: 'uat-support', owner, note, review: { status, via: 'owner', at: '2026-01-01T00:00:00.000Z' } };
}

test('client is never a catalog default, only a decision', () => {
  assert.equal(ownershipOf(uat, 'us', undefined, 100, 1).owner, 'us');
  assert.equal(ownershipOf(uat, 'shared', undefined, 100, 1).owner, 'shared');
  assert.equal(ownershipOf(uat, 'us', decision('client'), 100, 1).owner, 'client');
});

test('a client-owned activity contributes nothing and says what it would have been', () => {
  const owned = ownershipOf(uat, 'us', decision('client', 'Their own testers run it.'), 240, 1);
  assert.equal(owned.ourPortion, 0);
  assert.match(owned.exclusion, /UAT support is not in this estimate/);
  assert.match(owned.exclusion, /Their own testers run it\./);
  assert.match(owned.ownerQuestion, /240 hours/);
});

test('the client question names the volume when the activity is sized over one', () => {
  const owned = ownershipOf(build, 'us', { ...decision('client'), activity: 'component-build' }, 480, 24);
  assert.match(owned.ownerQuestion, /24 components, 480 hours/);
});

test('a shared activity is sized at full and says so, because no case records the split', () => {
  const owned = ownershipOf(uat, 'shared', undefined, 240, 1);
  assert.equal(owned.ourPortion, 1);
  assert.match(owned.ownerQuestion, /all 240 hours/);
  assert.equal(owned.exclusion, undefined);
});

test('an activity we own asks nothing and excludes nothing', () => {
  const owned = ownershipOf(uat, 'us', undefined, 240, 1);
  assert.deepEqual(owned, { owner: 'us', ourPortion: 1 });
});

test('a decision carries its note onto the row whoever owns the work', () => {
  const owned = ownershipOf(uat, 'shared', decision('us', 'We took it back after the kickoff.'), 240, 1);
  assert.equal(owned.owner, 'us');
  assert.equal(owned.ownerNote, 'We took it back after the kickoff.');
});

test('only accepted and edited decisions count', () => {
  const plan = {
    owners: [
      decision('client', 'accepted one', 'accepted'),
      { ...decision('shared', 'edited one', 'edited'), activity: 'qa-automation' },
      { ...decision('client', 'not yet', 'pending'), activity: 'content-migration' },
      { ...decision('client', 'no thanks', 'dismissed'), activity: 'training' }
    ]
  };
  assert.deepEqual([...ownerDecisions(plan).keys()], ['uat-support', 'qa-automation']);
});

test('a plan with no ownership decisions reads as an empty map', () => {
  assert.equal(ownerDecisions({}).size, 0);
  assert.equal(ownerDecisions({ owners: 'not an array' }).size, 0);
});

test('every owner the catalog or a decision can carry is one the list names', () => {
  assert.deepEqual(OWNERS, ['us', 'shared', 'client']);
});
