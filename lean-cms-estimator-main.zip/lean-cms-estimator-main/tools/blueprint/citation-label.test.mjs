import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { baseName, blockId, citationLabel, splitHeading } from './citation-label.mjs';

describe('citation-label', () => {
  it('baseName strips extension', () => {
    assert.equal(baseName('Northwind_RFP_2026.pdf'), 'Northwind_RFP_2026');
    assert.equal(baseName('noext'), 'noext');
  });

  it('splitHeading parses numbered headings', () => {
    assert.deepEqual(splitHeading('3.6.1 Content migration'), {
      section: '3.6.1',
      heading: 'Content migration'
    });
  });

  it('labels page locations', () => {
    assert.equal(
      citationLabel('RFP.pdf', { kind: 'page', page: 38, section: '3.6.1' }),
      `RFP p.38 \u00A73.6.1`
    );
  });

  it('labels section with heading truncation', () => {
    const long = 'A'.repeat(80);
    const label = citationLabel('Notes.docx', { kind: 'section', heading: long });
    assert.ok(label.includes('\u2026'));
  });

  it('labels slides and notes', () => {
    assert.equal(
      citationLabel('Deck.pptx', { kind: 'slide', slide: 9, notes: true }),
      'Deck slide 9 notes'
    );
  });

  it('labels sheet rows', () => {
    assert.equal(
      citationLabel('Inventory.xlsx', { kind: 'sheet', sheet: 'Pages', rowStart: 2, rowEnd: 5 }),
      `Inventory Pages rows 2\u20135`
    );
    assert.equal(
      citationLabel('Inventory.xlsx', { kind: 'sheet', sheet: 'Pages', rowStart: 3, rowEnd: 3 }),
      'Inventory Pages row 3'
    );
  });

  it('blockId joins item and anchor', () => {
    assert.equal(blockId('src-rfp', 'p38.3-6-1'), 'src-rfp#p38.3-6-1');
  });
});
