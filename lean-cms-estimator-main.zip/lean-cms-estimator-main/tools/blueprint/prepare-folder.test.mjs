import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import {
  buildBootstrapFiles,
  catalogPinsFromFrontMatter,
  findInstalledPack,
  looksGenerated,
  PACK_MISSING,
  renderAgentsFile,
  safeName,
  selectionProblem,
  starterPrompt,
  writeBootstrap
} from './prepare-folder.mjs';
import { GOLDEN_INPUT, goldenFiles, HOSTILE_INPUT, hostileAgents } from './fixtures/bootstrap/write-golden.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'prepare-folder.mjs');
const golden = join(root, 'tools', 'blueprint', 'fixtures', 'bootstrap');
const sources = join(root, 'samples', 'sources', 'synthetic-aem');
const scratch = mkdtempSync(join(tmpdir(), 'prepare-'));

/** The CLI with no pack installed anywhere it looks, including the developer's own skills folders, so results do not depend on the machine. */
function cli(args, extraEnv = {}) {
  return spawnSync(process.execPath, [script, ...args], {
    cwd: root,
    encoding: 'utf8',
    env: { ...process.env, BLUEPRINT_PACK: '', HOME: join(scratch, 'nohome'), USERPROFILE: join(scratch, 'nohome'), ...extraEnv }
  });
}

after(() => rmSync(scratch, { recursive: true, force: true }));

function read(file) {
  return readFileSync(file, 'utf8').replace(/\r\n/g, '\n');
}

describe('prepare-folder bootstrap', () => {
  it('matches the committed golden files (regenerate with fixtures/bootstrap/write-golden.mjs)', () => {
    for (const file of goldenFiles()) {
      const expected = read(join(golden, file.path.replace('.blueprint/', 'blueprint-')));
      assert.equal(file.content, expected, file.path);
    }
    assert.deepEqual(JSON.parse(read(join(golden, 'input.json'))), GOLDEN_INPUT);
  });

  it('names the selected sources and nothing else, and carries no client text', () => {
    const agents = renderAgentsFile(GOLDEN_INPUT);
    for (const name of GOLDEN_INPUT.sources) {
      assert.match(agents, new RegExp(`- \`${name.replace(/\./g, '\\.')}\``));
    }
    assert.match(agents, /Expected pack version: 0\.1\.0/);
    assert.match(agents, /blueprint 1, context 2, proposals 1, runRecord 1/);
    assert.match(agents, /estimating catalog v3, CMK e81d7ff, toolkit 5d1f76e/);
    assert.doesNotMatch(agents, /\{\{/, 'every placeholder is filled');
    assert.doesNotMatch(agents, /6,400|locales|Fabrikam Outdoor will/, 'no text from the documents');
    const empty = renderAgentsFile({ ...GOLDEN_INPUT, sources: [], catalog: {} });
    assert.match(empty, /no source files were selected/);
    assert.match(empty, /Catalogs: not pinned/);
  });

  it('renders hostile names literally and matches the committed hostile golden file (the app is checked against the same file)', () => {
    assert.deepEqual(JSON.parse(read(join(golden, 'hostile-input.json'))), HOSTILE_INPUT);
    const agents = hostileAgents();
    assert.equal(agents, read(join(golden, 'hostile-AGENTS.md')));
    assert.match(agents, /^# Blueprint project: Acme \$& Co \$\$ \$' \{\{sourcesList\}\} 'quoted' 'tick' second line$/m, 'replacement patterns, a token name and quotes stay literal');
    assert.match(agents, /^- `Q&A \$'25 \{\{schemas\}\}\.docx`$/m);
    assert.match(agents, /^- `back'tick\.pdf`$/m);
    assert.match(agents, /Schemas: blueprint 1, context 2, proposals 1, runRecord 1\./, 'a token inside a name is not expanded');
    assert.equal(agents.split('\n').filter((line) => line.startsWith('# ')).length, 1, 'a line break in the name does not start a new heading');
  });

  it('makes names safe for code spans and one-line headings', () => {
    assert.equal(safeName('a`b"c\nd\r\ne\tf'), "a'b'c d e f");
    assert.equal(safeName('$& $$ {{x}}'), '$& $$ {{x}}');
    assert.match(starterPrompt('P\nQ'), /project "P Q"/);
  });

  it('reads catalog pins from the estimating catalog front matter', () => {
    const pins = catalogPinsFromFrontMatter(readFileSync(join(root, 'docs', 'catalogs', 'estimating-catalog.md'), 'utf8'));
    assert.equal(pins.estimatingVersion, '4');
    assert.match(pins.cmkCommit, /^[0-9a-f]{40}$/);
    assert.deepEqual(catalogPinsFromFrontMatter('# no front matter'), {});
  });

  it('writes only files whose content changed', () => {
    const folder = join(scratch, 'write');
    const files = buildBootstrapFiles(GOLDEN_INPUT);
    const first = writeBootstrap(folder, files);
    assert.deepEqual(first.written, ['AGENTS.md', 'CLAUDE.md', '.blueprint/sources.json', '.blueprint/expect.json']);
    const second = writeBootstrap(folder, files);
    assert.deepEqual(second.written, []);
    assert.equal(second.unchanged.length, 4);
    const changed = writeBootstrap(folder, buildBootstrapFiles({ ...GOLDEN_INPUT, sources: ['Only.pdf'] }));
    assert.deepEqual(changed.written, ['AGENTS.md', '.blueprint/sources.json']);
  });

  it('does not replace an AGENTS.md or CLAUDE.md a person wrote, unless forced', () => {
    const folder = join(scratch, 'handwritten');
    mkdirSync(folder, { recursive: true });
    writeFileSync(join(folder, 'AGENTS.md'), '# Our house rules\n\nDo it our way.\n');
    writeFileSync(join(folder, 'CLAUDE.md'), 'Be brief.\n');
    const files = buildBootstrapFiles(GOLDEN_INPUT);
    const first = writeBootstrap(folder, files);
    assert.deepEqual(first.skipped.map((s) => s.path), ['AGENTS.md', 'CLAUDE.md']);
    assert.deepEqual(first.written, ['.blueprint/sources.json', '.blueprint/expect.json']);
    assert.equal(read(join(folder, 'AGENTS.md')), '# Our house rules\n\nDo it our way.\n');
    const forced = writeBootstrap(folder, files, { force: true });
    assert.deepEqual(forced.written, ['AGENTS.md', 'CLAUDE.md']);
    assert.equal(read(join(folder, 'AGENTS.md')), files[0].content);
    assert.ok(looksGenerated('AGENTS.md', files[0].content.replace(/\n/g, '\r\n')));
    assert.ok(!looksGenerated('AGENTS.md', 'notes'));
    assert.deepEqual(readdirSync(folder).filter((name) => name.endsWith('.tmp')), [], 'no temporary files are left behind');
  });

  it('checks a selection before anything is written', () => {
    assert.equal(selectionProblem(sources, ['Workshop_Notes.docx']), undefined);
    assert.match(selectionProblem(sources, ['Nope.docx']), /no such file/);
    assert.match(selectionProblem(sources, ['../Workshop_Notes.docx']), /inside the project folder/);
    assert.match(selectionProblem(sources, [join(sources, 'Workshop_Notes.docx')]), /inside the project folder/);
    assert.match(selectionProblem(sources, ['..']), /inside the project folder/);
    assert.match(selectionProblem(sources, ['.']), /inside the project folder/);
  });

  it('finds an installed pack in the folder or at BLUEPRINT_PACK, and says what to install otherwise', () => {
    const folder = join(scratch, 'pack');
    assert.equal(findInstalledPack(folder, join(scratch, 'home'), {}), undefined);
    const pack = join(scratch, 'the-pack');
    mkdirSync(join(pack, 'skills', 'blueprint-offline'), { recursive: true });
    writeFileSync(join(pack, 'skills', 'blueprint-offline', 'SKILL.md'), '# skill');
    assert.equal(findInstalledPack(folder, join(scratch, 'home'), { BLUEPRINT_PACK: pack }), join(pack, 'skills'));
    mkdirSync(join(folder, '.claude', 'skills', 'blueprint-offline'), { recursive: true });
    writeFileSync(join(folder, '.claude', 'skills', 'blueprint-offline', 'SKILL.md'), '# skill');
    assert.equal(findInstalledPack(folder, join(scratch, 'home'), {}), join(folder, '.claude', 'skills'));
    assert.match(PACK_MISSING, /Install it before running the agent/);
  });

  it('gives a prompt a person can paste', () => {
    assert.match(starterPrompt('Fabrikam Outdoor'), /run the estimate skill/);
    assert.match(starterPrompt('Fabrikam Outdoor'), /Read AGENTS\.md first/);
  });
});

describe('prepare-folder CLI', () => {
  const folder = join(scratch, 'project');

  it('prepares a folder from its source files and records the prepared stage', () => {
    cpSync(sources, folder, { recursive: true });
    const result = cli([folder, '--project', 'Fabrikam Outdoor', '--prompt']);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /wrote {5}AGENTS\.md/);
    assert.match(result.stdout, /6 source files selected/);
    assert.match(result.stdout, /Paste this into Cursor or Claude/);
    const selection = JSON.parse(read(join(folder, '.blueprint', 'sources.json')));
    assert.deepEqual(selection.sources.map((s) => s.name), [
      'Content_Inventory.xlsx', 'Fabrikam_Kickoff_Deck.pptx', 'Fabrikam_RFP_2027.pdf', 'Legacy_Brief.doc', 'Signed_NDA_scan.pdf', 'Workshop_Notes.docx'
    ]);
    const record = JSON.parse(read(join(folder, '.blueprint', 'run.json')));
    assert.equal(record.stage, 'prepared');
    assert.ok(existsSync(join(folder, 'CLAUDE.md')));
    const expect = JSON.parse(read(join(folder, '.blueprint', 'expect.json')));
    assert.equal(expect.packVersion, JSON.parse(read(join(root, 'tools', 'release', 'pack.config.json'))).version);
  });

  it('a second run with the same selection changes nothing, and a new selection changes only the selection files', () => {
    const before = ['AGENTS.md', 'CLAUDE.md', '.blueprint/sources.json', '.blueprint/expect.json', '.blueprint/run.json']
      .map((name) => [name, read(join(folder, name))]);
    const again = cli([folder, '--project', 'Fabrikam Outdoor']);
    assert.equal(again.status, 0, again.stderr);
    assert.doesNotMatch(again.stdout, /^wrote/m);
    for (const [name, content] of before) {
      assert.equal(read(join(folder, name)), content, `${name} unchanged`);
    }
    const narrowed = cli([folder, '--project', 'Fabrikam Outdoor', '--select', 'Workshop_Notes.docx']);
    assert.equal(narrowed.status, 0, narrowed.stderr);
    assert.match(narrowed.stdout, /wrote {5}AGENTS\.md/);
    assert.match(narrowed.stdout, /wrote {5}\.blueprint\/sources\.json/);
    assert.match(narrowed.stdout, /unchanged CLAUDE\.md/);
    assert.match(narrowed.stdout, /unchanged \.blueprint\/expect\.json/);
    assert.equal(read(join(folder, 'CLAUDE.md')), before[1][1]);
  });

  it('exits 4 with --require-pack when no pack is installed', () => {
    const lonely = join(scratch, 'lonely');
    cpSync(sources, lonely, { recursive: true });
    const result = cli([lonely, '--project', 'P', '--require-pack']);
    assert.equal(result.status, 4, result.stdout);
    assert.match(result.stdout, /was not found/);
    assert.ok(statSync(join(lonely, 'AGENTS.md')).isFile(), 'the bootstrap is still written');
  });

  it('exits with usage when the project name is missing', () => {
    const result = cli([folder]);
    assert.equal(result.status, 2);
    assert.match(result.stderr, /Usage/);
  });

  it("leaves a person's own AGENTS.md alone, exits 5, and replaces it with --force", () => {
    const own = join(scratch, 'own');
    mkdirSync(own, { recursive: true });
    writeFileSync(join(own, 'AGENTS.md'), '# Our house rules\n');
    const result = cli([own, '--project', 'P']);
    assert.equal(result.status, 5, result.stdout);
    assert.match(result.stdout, /skipped {3}AGENTS\.md/);
    assert.equal(read(join(own, 'AGENTS.md')), '# Our house rules\n');
    assert.ok(existsSync(join(own, '.blueprint', 'sources.json')), 'the rest of the bootstrap is written');
    const forced = cli([own, '--project', 'P', '--force']);
    assert.equal(forced.status, 0, forced.stdout);
    assert.match(read(join(own, 'AGENTS.md')), /^# Blueprint project: P/);
  });

  it('refuses a selection that is missing, outside the folder or not a source, and writes nothing', () => {
    const picky = join(scratch, 'picky');
    cpSync(sources, picky, { recursive: true });
    writeFileSync(join(picky, 'notes.txt'), 'x');
    for (const bad of [['Nope.docx'], ['../x.docx'], ['Workshop_Notes.docx', 'Nope.docx'], ['notes.txt']]) {
      const result = cli([picky, '--project', 'P', '--select', ...bad]);
      assert.equal(result.status, 2, `${bad}: ${result.stdout}`);
      assert.match(result.stderr, /--select/);
    }
    assert.ok(!existsSync(join(picky, 'AGENTS.md')));
    assert.ok(!existsSync(join(picky, '.blueprint')));
  });

  it('fails clearly on a damaged run record and writes nothing', () => {
    const broken = join(scratch, 'broken');
    cpSync(sources, broken, { recursive: true });
    mkdirSync(join(broken, '.blueprint'), { recursive: true });
    writeFileSync(join(broken, '.blueprint', 'run.json'), '{"schemaVersion":');
    const result = cli([broken, '--project', 'P']);
    assert.equal(result.status, 2);
    assert.match(result.stderr, /run\.json is not valid JSON/);
    assert.ok(!existsSync(join(broken, 'AGENTS.md')));
  });

  it('renders a hostile project name literally through the command line too', () => {
    const odd = join(scratch, 'odd');
    cpSync(sources, odd, { recursive: true });
    const result = cli([odd, '--project', 'Acme $& Co $$ {{schemas}}']);
    assert.equal(result.status, 0, result.stderr);
    assert.match(read(join(odd, 'AGENTS.md')), /^# Blueprint project: Acme \$& Co \$\$ \{\{schemas\}\}$/m);
  });
});
