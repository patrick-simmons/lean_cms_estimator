/**
 * Bands for the tiered activities (story B-09).
 *
 * A tiered activity is not sized by a volume, it is sized by how complicated the work is. This
 * reads that complexity out of the documents instead of assuming it: each activity has a list
 * of signals, each signal points at a band, and the band the signals point at is recorded with
 * the words that decided it and the block they came from.
 *
 * Nothing here sets an hour figure. The hours behind a band come from cases, exactly as a
 * per-unit rate does; what this fixes is which band, so that two runs over the same documents
 * land in the same place.
 *
 * Three rules decide a band, in this order:
 *
 *   1. Quoted beats inferred. A signal found in a passage the documents actually contain
 *      outranks one found only in a requirement statement, which is the model's paraphrase.
 *      When any quoted signal matches, the inferred ones are not consulted at all.
 *   2. Among what is left, the higher band wins. Small under-prices, which is the common
 *      failure; large loses deals, which is the visible one.
 *   3. Signals that disagree raise a challenge, not a question. Something in the documents
 *      says this is bigger than the rest of them suggest, and that is worth arguing about
 *      rather than asking the client to settle.
 *
 * No signal at all means medium, low confidence and a client question.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { containsSequence, tokenize } from './match-library.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_TIER_SIGNALS = path.join(HERE, 'data', 'tier-signals.json');

/** Small to large. The index is the order, so a later band outranks an earlier one. */
export const BANDS = ['small', 'medium', 'large'];

/** What a tiered activity bands to when the documents say nothing either way. */
export const NO_SIGNAL_BAND = 'medium';

export class BandError extends Error {}

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function reviewOf(item) {
  return isObject(item) && isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
}

/** @returns {string[]} what is wrong with a signals file, empty when it is usable. */
export function validateTierSignals(doc) {
  const errors = [];
  if (!isObject(doc) || doc.schemaVersion !== '1' || !Array.isArray(doc.activities)) {
    return ['expected { schemaVersion: "1", activities: [] }'];
  }
  const seen = new Set();
  doc.activities.forEach((entry, index) => {
    const where = `activities[${index}]`;
    if (!isObject(entry) || typeof entry.activity !== 'string' || entry.activity === '') {
      errors.push(`${where}.activity: expected an activity id`);
      return;
    }
    if (seen.has(entry.activity)) {
      errors.push(`${where}.activity: ${entry.activity} is listed twice`);
    }
    seen.add(entry.activity);
    if (!Array.isArray(entry.signals) || entry.signals.length === 0) {
      errors.push(`${where}.signals: expected at least one signal`);
      return;
    }
    entry.signals.forEach((signal, position) => {
      const at = `${where}.signals[${position}]`;
      if (!isObject(signal) || BANDS.indexOf(signal.band) === -1) {
        errors.push(`${at}.band: expected one of ${BANDS.join(', ')}`);
        return;
      }
      if (typeof signal.reason !== 'string' || signal.reason === '') {
        errors.push(`${at}.reason: expected what the signal means, in words`);
      }
      const words = Array.isArray(signal.words);
      const volume = typeof signal.volume === 'string';
      if (words === volume) {
        errors.push(`${at}: expected either words or a volume, not both and not neither`);
        return;
      }
      if (words && signal.words.some((word) => typeof word !== 'string' || tokenize(word).length === 0)) {
        errors.push(`${at}.words: expected phrases with words in them`);
      }
      if (volume) {
        const bounds = ['atLeast', 'atMost'].filter((key) => signal[key] !== undefined);
        if (bounds.length !== 1 || typeof signal[bounds[0]] !== 'number') {
          errors.push(`${at}: expected one of atLeast or atMost, as a number`);
        }
      }
    });
  });
  return errors;
}

export function loadTierSignals(file = DEFAULT_TIER_SIGNALS) {
  let doc;
  try {
    doc = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw new BandError(`${file} could not be read as JSON: ${error.message}`);
  }
  const errors = validateTierSignals(doc);
  if (errors.length > 0) {
    throw new BandError(`${file} is not a usable signals file: ${errors[0]}`);
  }
  return new Map(doc.activities.map((entry) => [entry.activity, entry.signals]));
}

/**
 * What the plan offers a signal to match against.
 *
 * A passage is text the documents contain, so a match in one is quoted. A statement is the
 * model's summary of a passage, so a match in one is inferred: true of the plan, but a step
 * away from the words anybody can point at.
 */
function evidenceOf(plan) {
  const quoted = [];
  const inferred = [];
  const volumes = new Map();
  const live = (Array.isArray(plan.requirements) ? plan.requirements : []).filter((row) => isObject(row) && reviewOf(row) !== 'dismissed');
  for (const row of live) {
    inferred.push({ tokens: tokenize(row.statement), requirementId: row.id, text: row.statement });
    for (const source of Array.isArray(row.sources) ? row.sources : []) {
      if (isObject(source) && typeof source.passage === 'string') {
        quoted.push({ tokens: tokenize(source.passage), requirementId: row.id, blockId: source.blockId, text: source.passage });
      }
    }
  }
  // Only a volume somebody accepted, which is the same volume that sizes a per-unit workstream.
  // A quoted figure nobody has agreed to does not get to set a band either.
  for (const volume of Array.isArray(plan.volumes) ? plan.volumes : []) {
    if (isObject(volume) && ['accepted', 'edited'].indexOf(reviewOf(volume)) !== -1 && typeof volume.quantity === 'number' && !volumes.has(volume.workPackageId)) {
      volumes.set(volume.workPackageId, volume);
    }
  }
  return { quoted, inferred, volumes };
}

function volumeHit(signal, volumes) {
  const volume = volumes.get(signal.volume);
  if (!volume) {
    return undefined;
  }
  const matched = signal.atLeast === undefined ? volume.quantity <= signal.atMost : volume.quantity >= signal.atLeast;
  const unit = volume.unit ? `${volume.unit}${volume.quantity === 1 ? '' : 's'}` : 'units';
  return matched ? { volumeId: volume.id, blockId: (volume.blockIds || [])[0], detail: `${volume.quantity} ${unit}` } : undefined;
}

function wordHit(signal, units) {
  for (const word of signal.words) {
    const needle = tokenize(word);
    const unit = units.find((candidate) => containsSequence(candidate.tokens, needle));
    if (unit) {
      return { requirementId: unit.requirementId, blockId: unit.blockId, detail: word };
    }
  }
  return undefined;
}

/** Every signal that matches, in the order the signals file lists them, so the answer is stable. */
function matchesFor(signals, evidence) {
  const found = [];
  for (const signal of signals) {
    const hit = signal.volume
      ? volumeHit(signal, evidence.volumes)
      // A volume is a figure from a document, so it is quoted wherever it is read; words are
      // quoted only when they turn up in a passage.
      : wordHit(signal, evidence.quoted) || wordHit(signal, evidence.inferred);
    if (!hit) {
      continue;
    }
    const quoted = Boolean(signal.volume) || evidence.quoted.some((unit) => unit.requirementId === hit.requirementId && unit.blockId === hit.blockId);
    found.push({ band: signal.band, quoted, reason: signal.reason, matched: hit.detail, ...(hit.blockId ? { blockId: hit.blockId } : {}), ...(hit.requirementId ? { requirementId: hit.requirementId } : {}), ...(hit.volumeId ? { volumeId: hit.volumeId } : {}) });
  }
  return found;
}

function highest(matches) {
  return matches.reduce((best, match) => (BANDS.indexOf(match.band) > BANDS.indexOf(best) ? match.band : best), BANDS[0]);
}

/**
 * The band for one tiered activity.
 *
 * @param {object} plan a valid plan
 * @param {string} activity a tiered activity id
 * @param {Map<string, object[]>} signals from loadTierSignals
 * @param {string} name the activity's name, for the question and the challenge
 * @returns {{band: string, bandConfidence: string, bandSignals: object[], bandReason: string,
 *   bandQuestion?: string, bandChallenge?: string}}
 */
export function bandFor(plan, activity, signals, name) {
  const rules = signals.get(activity) || [];
  const all = matchesFor(rules, evidenceOf(plan));
  // Quoted evidence is not weighed against inferred evidence, it replaces it. A paraphrase
  // cannot argue with the document it was made from.
  const considered = all.some((match) => match.quoted) ? all.filter((match) => match.quoted) : all;

  if (considered.length === 0) {
    return {
      band: NO_SIGNAL_BAND,
      bandConfidence: 'low',
      bandSignals: [],
      bandReason: 'Nothing in the documents says how complicated this is.',
      bandQuestion: `${name}: nothing in the documents says how complicated this is, so the estimate assumes ${NO_SIGNAL_BAND}. What is the scope here?`
    };
  }

  const band = highest(considered);
  const deciding = considered.find((match) => match.band === band);
  const quoted = considered.some((match) => match.quoted);
  const disagreeing = considered.filter((match) => match.band !== band);
  return {
    band,
    bandConfidence: quoted ? 'high' : 'medium',
    bandSignals: considered,
    bandReason: deciding.reason,
    ...(disagreeing.length > 0
      ? {
        bandChallenge: `${name}: banded ${band} on "${deciding.matched}", but ${disagreeing.map((match) => `"${match.matched}" reads ${match.band}`).join(' and ')}. The higher band was taken; say why if that is wrong.`
      }
      : {})
  };
}

/**
 * Bands for every tiered activity in the catalog.
 * @returns {Map<string, object>} activity id to what bandFor returned
 */
export function bandAll(plan, workPackages, signals) {
  const bands = new Map();
  for (const [id, entry] of workPackages) {
    if (entry.shape === 'tiered') {
      bands.set(id, bandFor(plan, id, signals, entry.name));
    }
  }
  return bands;
}
