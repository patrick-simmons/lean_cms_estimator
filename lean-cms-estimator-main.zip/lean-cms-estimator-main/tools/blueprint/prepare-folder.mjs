#!/usr/bin/env node
/**
 * Prepare a project folder for the agent (SAPP-016). Writes the bootstrap the agent reads first:
 *
 *   AGENTS.md                 what this folder is, which files to read, what to write, the contract, the guardrails
 *   CLAUDE.md                 points Claude Code at AGENTS.md
 *   .blueprint/sources.json   the selected source files, read by parse-local.mjs
 *   .blueprint/expect.json    the pack version, schema versions and catalog pins the app expects
 *
 * The bootstrap carries file names and versions only: no client text. Every file is deterministic, so a
 * second run changes only what the source selection changed. The run record (`.blueprint/run.json`) is
 * created at stage `prepared` when there is none; otherwise a note is added when the selection changed.
 *
 * An `AGENTS.md` or `CLAUDE.md` that was not written by this tool (a person's own file) is never replaced:
 * it is reported as skipped and the exit code is 5. Pass `--force` to replace it.
 * Exit codes: 0 done, 2 bad command line or unusable run record, 4 `--require-pack` and no pack found,
 * 5 a file was skipped.
 *
 * The standalone app writes the same files from src/webparts/blueprint/projects/agentHandoff.ts; the
 * golden copies under tools/blueprint/fixtures/bootstrap/ keep the two in step.
 *
 * Usage:
 *   node tools/blueprint/prepare-folder.mjs <project-folder> --project "<Project name>" [--select <file>...] [--prompt] [--require-pack] [--force]
 */
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { homedir } from 'node:os';
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { catalogPins } from './derive-capabilities.mjs';
import { packInfo } from './pack-info.mjs';
import { readRunRecord, updateRunRecord } from './run-record.mjs';
import { isSourceCandidate } from './source-candidates.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';

const here = dirname(fileURLToPath(import.meta.url));
export const AGENTS_TEMPLATE = readFileSync(join(here, 'templates', 'AGENTS.md'), 'utf8').replace(/\r\n/g, '\n');
export const CLAUDE_FILE = '# Claude Code\n\nRead `AGENTS.md` in this folder and follow it. It names the Blueprint skill to run, the files to read and the files to write.\n';
export const BOOTSTRAP_SCHEMA_VERSION = '1';

/**
 * @typedef {{ projectName: string, sources: string[], packVersion: string, schemas: Record<string, string>,
 *   catalog: { cmkCommit?: string, toolkitCommit?: string, estimatingVersion?: string } }} BootstrapInput
 */

/** Catalog pins from the estimating catalog front matter, when the repo or pack carries it. */
export const catalogPinsFromFrontMatter = catalogPins;

/**
 * A name as it may appear in AGENTS.md: inside a markdown code span, a heading and a quoted file name.
 * Line breaks and tabs become a space, and backticks and double quotes become an apostrophe, so a name
 * cannot close the span or the quote or start a new line of instructions. The same rule is in
 * src/webparts/blueprint/projects/agentHandoff.ts (`safeName`).
 */
export function safeName(name) {
  return String(name)
    .replace(/[\r\n\t\v\f\x85]+/g, ' ')
    .split(String.fromCharCode(0x2028)).join(' ')
    .split(String.fromCharCode(0x2029)).join(' ')
    .replace(/[`"]/g, "'");
}

function describeCatalog(catalog) {
  const parts = [];
  if (catalog.estimatingVersion) {
    parts.push(`estimating catalog v${catalog.estimatingVersion}`);
  }
  if (catalog.cmkCommit) {
    parts.push(`CMK ${catalog.cmkCommit.slice(0, 7)}`);
  }
  if (catalog.toolkitCommit) {
    parts.push(`toolkit ${catalog.toolkitCommit.slice(0, 7)}`);
  }
  return parts.length ? parts.join(', ') : 'not pinned';
}

/**
 * Every `{{token}}` is replaced in one pass, so a value that contains `$&`, `$$` or another token's name
 * is written literally.
 * @param {BootstrapInput} input
 */
export function renderAgentsFile(input) {
  const sourcesList = input.sources.length
    ? input.sources.map((name) => `- \`${safeName(name)}\``).join('\n')
    : '- (no source files were selected; ask the estimator to choose them in the app)';
  const schemas = Object.keys(input.schemas).sort().map((key) => `${key} ${input.schemas[key]}`).join(', ');
  const values = {
    projectName: safeName(input.projectName),
    sourcesList,
    packVersion: input.packVersion,
    schemas,
    catalogs: describeCatalog(input.catalog)
  };
  return AGENTS_TEMPLATE.replace(/\{\{(\w+)\}\}/g, (token, key) => (Object.prototype.hasOwnProperty.call(values, key) ? values[key] : token));
}

/**
 * The bootstrap files as path and content pairs, relative to the project folder.
 * @param {BootstrapInput} input
 * @returns {{ path: string, content: string }[]}
 */
export function buildBootstrapFiles(input) {
  const sources = { schemaVersion: BOOTSTRAP_SCHEMA_VERSION, projectName: input.projectName, sources: input.sources.map((name) => ({ name })) };
  const expect = { schemaVersion: BOOTSTRAP_SCHEMA_VERSION, packVersion: input.packVersion, schemas: input.schemas, catalog: input.catalog };
  return [
    { path: 'AGENTS.md', content: renderAgentsFile(input) },
    { path: 'CLAUDE.md', content: CLAUDE_FILE },
    { path: '.blueprint/sources.json', content: `${JSON.stringify(sources, null, 2)}\n` },
    { path: '.blueprint/expect.json', content: `${JSON.stringify(expect, null, 2)}\n` }
  ];
}

/** The prompt a person pastes into Cursor or Claude instead of invoking the skill by name. */
export function starterPrompt(projectName) {
  return `Open this folder (the Blueprint project "${safeName(projectName)}") and run the estimate skill on it. ` +
    'Read AGENTS.md first: it lists the source files to read, the files to write and the guardrails. ' +
    'Stop and tell me if the Blueprint skill pack is not installed.';
}

/** Where an installed pack's skills may be, for the "is the pack installed" check. */
export function skillLocations(folder, home = homedir(), env = process.env) {
  const places = [
    join(folder, '.claude', 'skills'),
    join(folder, '.cursor', 'skills'),
    join(home, '.claude', 'skills'),
    join(home, '.cursor', 'skills')
  ];
  if (env.BLUEPRINT_PACK) {
    places.push(join(env.BLUEPRINT_PACK, 'skills'));
    places.push(join(env.BLUEPRINT_PACK, '.claude', 'skills'));
  }
  return places;
}

export function findInstalledPack(folder, home, env) {
  return skillLocations(folder, home, env).find((place) => existsSync(join(place, 'blueprint-offline', 'SKILL.md')));
}

export const PACK_MISSING = 'The Blueprint skill pack was not found in this folder, in your Claude or Cursor skills, or at $BLUEPRINT_PACK. ' +
  'Install it before running the agent: see README.md in the pack (docs/standalone/agent-skill-pack.md in the repository).';

/** Whether an existing file is one this tool (or the app) wrote, as opposed to a person's own AGENTS.md or CLAUDE.md. */
export function looksGenerated(path, content) {
  const text = content.replace(/\r\n/g, '\n');
  if (path === 'AGENTS.md') {
    return text.startsWith('# Blueprint project: ');
  }
  if (path === 'CLAUDE.md') {
    return text.startsWith('# Claude Code\n\nRead `AGENTS.md` in this folder');
  }
  return true;
}

/**
 * Write the bootstrap into a folder. Only files whose content differs are written, each through a
 * temporary file and a rename. An AGENTS.md or CLAUDE.md that was not generated is skipped unless `force`.
 * @param {string} folder
 * @param {{ path: string, content: string }[]} files
 * @param {{ force?: boolean }} [options]
 * @returns {{ written: string[], unchanged: string[], skipped: { path: string, reason: string }[] }}
 */
export function writeBootstrap(folder, files, options = {}) {
  const written = [];
  const unchanged = [];
  const skipped = [];
  for (const file of files) {
    const target = join(folder, file.path);
    const current = existsSync(target) ? readFileSync(target, 'utf8').replace(/\r\n/g, '\n') : undefined;
    if (current === file.content) {
      unchanged.push(file.path);
      continue;
    }
    if (current !== undefined && !options.force && !looksGenerated(file.path, current)) {
      skipped.push({ path: file.path, reason: 'it exists and was not written by prepare-folder; pass --force to replace it' });
      continue;
    }
    writeFileAtomic(target, file.content);
    written.push(file.path);
  }
  return { written, unchanged, skipped };
}

/**
 * The names in `--select`, checked before anything is written: each must stay inside the folder, be a
 * file and be a supported source type.
 * @returns {string | undefined} the first problem, or undefined when every name is fine
 */
export function selectionProblem(folder, names) {
  const root = resolve(folder);
  for (const name of names) {
    const target = resolve(root, name);
    const rel = relative(root, target);
    if (isAbsolute(name) || isAbsolute(rel) || rel === '' || rel === '..' || rel.startsWith(`..${sep}`)) {
      return `${name}: must name a file inside the project folder`;
    }
    if (!existsSync(target) || !statSync(target).isFile()) {
      return `${name}: no such file in the project folder`;
    }
    if (!isSourceCandidate(basename(name))) {
      return `${name}: not a supported source file type`;
    }
  }
  return undefined;
}

const USAGE = 'Usage: node tools/blueprint/prepare-folder.mjs <project-folder> --project "<Project name>" [--select <file>...] [--prompt] [--require-pack] [--force]';

function parseArgs(argv) {
  const out = { folder: undefined, project: undefined, select: [], prompt: false, requirePack: false, force: false };
  let mode;
  for (const arg of argv) {
    if (arg === '--prompt') {
      out.prompt = true;
      mode = undefined;
    } else if (arg === '--require-pack') {
      out.requirePack = true;
      mode = undefined;
    } else if (arg === '--force') {
      out.force = true;
      mode = undefined;
    } else if (arg === '--select' || arg === '--project') {
      mode = arg;
    } else if (arg.startsWith('--')) {
      return undefined;
    } else if (mode === '--project') {
      out.project = arg;
      mode = undefined;
    } else if (mode === '--select') {
      out.select.push(arg);
    } else if (out.folder === undefined) {
      out.folder = arg;
    } else {
      return undefined;
    }
  }
  return out.folder === undefined || !out.project ? undefined : out;
}

/**
 * @param {string[]} argv arguments after the script name
 * @param {{ env?: NodeJS.ProcessEnv, home?: string }} [context] where to look for an installed pack
 */
export function main(argv, context = {}) {
  const args = parseArgs(argv);
  if (!args) {
    console.error(USAGE);
    return 2;
  }
  const folder = resolve(args.folder);
  if (!existsSync(folder) || !statSync(folder).isDirectory()) {
    console.error(`prepare-folder: ${folder} is not a folder`);
    return 2;
  }
  const problem = selectionProblem(folder, args.select);
  if (problem) {
    console.error(`prepare-folder: --select ${problem}`);
    return 2;
  }
  let previous;
  try {
    previous = readRunRecord(folder);
  } catch (error) {
    console.error(`prepare-folder: ${error.message}`);
    return 2;
  }
  const sources = args.select.length
    ? args.select
    : readdirSync(folder, { withFileTypes: true }).filter((e) => e.isFile() && isSourceCandidate(e.name)).map((e) => e.name).sort((a, b) => a.localeCompare(b, 'en'));
  const info = packInfo();
  const catalogPath = join(info.root, 'docs', 'catalogs', 'estimating-catalog.md');
  const catalog = existsSync(catalogPath) ? catalogPins(readFileSync(catalogPath, 'utf8')) : {};
  const files = buildBootstrapFiles({ projectName: args.project, sources, packVersion: info.version, schemas: info.schemas, catalog });
  const result = writeBootstrap(folder, files, { force: args.force });

  if (!previous || result.written.includes('.blueprint/sources.json')) {
    updateRunRecord(folder, { stage: previous ? undefined : 'prepared', note: `prepared with ${sources.length} sources` });
  }

  for (const path of result.written) {
    console.log(`wrote     ${path}`);
  }
  for (const path of result.unchanged) {
    console.log(`unchanged ${path}`);
  }
  for (const skip of result.skipped) {
    console.log(`skipped   ${skip.path}: ${skip.reason}`);
  }
  console.log(`${sources.length} source files selected`);
  const installed = findInstalledPack(folder, context.home, context.env);
  if (installed) {
    console.log(`skill pack found at ${installed}`);
  } else {
    console.log(PACK_MISSING);
    if (args.requirePack) {
      return 4;
    }
  }
  if (args.prompt) {
    console.log('');
    console.log('Paste this into Cursor or Claude:');
    console.log(starterPrompt(args.project));
  }
  return result.skipped.length ? 5 : 0;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  process.exitCode = main(process.argv.slice(2));
}
