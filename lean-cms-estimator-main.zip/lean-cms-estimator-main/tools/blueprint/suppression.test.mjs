import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { readSuppressFile, suppressedLibraryIds, suppressedSources, validateSuppress } from './suppression.mjs';

const good = {
  schemaVersion: '1',
  items: [
    { key: 'AS-LIB-1', family: 'library' },
    { key: 'Gap sweep checklist content-model', family: 'gap-sweep' },
    { key: 'Lever advice aem-eds-figma-to-content', family: 'lever-advice' }
  ]
};

test('a valid file passes, and each family reads its own keys', () => {
  assert.deepEqual(validateSuppress(good), []);
  assert.deepEqual(suppressedLibraryIds(good), ['AS-LIB-1']);
  assert.deepEqual(suppressedSources(good, 'gap-sweep'), ['Gap sweep checklist content-model']);
  assert.deepEqual(suppressedSources(good, 'lever-advice'), ['Lever advice aem-eds-figma-to-content']);
});

test('the file is rejected with the field path for the wrong version, shape, family and key', () => {
  assert.match(validateSuppress(null).join('\n'), /\(root\)/);
  assert.match(validateSuppress({ schemaVersion: '2', items: [] }).join('\n'), /schemaVersion/);
  assert.match(validateSuppress({ schemaVersion: '1' }).join('\n'), /items: expected an array/);
  assert.match(validateSuppress({ schemaVersion: '1', items: ['x'] }).join('\n'), /items\[0\]: expected an object/);
  assert.match(validateSuppress({ schemaVersion: '1', items: [{ key: ' ', family: 'library' }] }).join('\n'), /items\[0\]\.key/);
  assert.match(validateSuppress({ schemaVersion: '1', items: [{ key: 'a', family: 'other' }] }).join('\n'), /items\[0\]\.family/);
});

test('a key has to look like the marker its family uses', () => {
  const wrong = validateSuppress({
    schemaVersion: '1',
    items: [{ key: 'content-model', family: 'gap-sweep' }, { key: 'figma', family: 'lever-advice' }, { key: 'Gap sweep checklist WP-xx', family: 'gap-sweep' }]
  });
  assert.equal(wrong.length, 3);
  assert.match(wrong[0], /gap-sweep key looks like "Gap sweep checklist integrations"/);
  assert.match(wrong[1], /lever-advice key looks like/);
});

test('readSuppressFile throws with every reason instead of ending the process', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'suppression-'));
  try {
    const file = path.join(dir, 's.json');
    fs.writeFileSync(file, JSON.stringify(good));
    assert.deepEqual(readSuppressFile(file), good);
    assert.throws(() => readSuppressFile(path.join(dir, 'missing.json')), /\(suppress\) cannot read/);
    fs.writeFileSync(file, '{ nope');
    assert.throws(() => readSuppressFile(file), /\(suppress\) cannot read/);
    fs.writeFileSync(file, JSON.stringify({ schemaVersion: '1', items: [{ key: '', family: 'x' }] }));
    assert.throws(() => readSuppressFile(file), (error) => error.message.split('\n').length === 2 && /items\[0\]\.key/.test(error.message));
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
