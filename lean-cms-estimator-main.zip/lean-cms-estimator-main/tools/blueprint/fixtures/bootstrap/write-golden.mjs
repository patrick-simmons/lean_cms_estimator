#!/usr/bin/env node
/**
 * Regenerates the golden bootstrap files in this folder from tools/blueprint/prepare-folder.mjs with
 * the fixed input below. Both prepare-folder.test.mjs and agentHandoff.test.ts compare against them.
 *
 * Usage: node tools/blueprint/fixtures/bootstrap/write-golden.mjs
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildBootstrapFiles } from '../../prepare-folder.mjs';

const here = dirname(fileURLToPath(import.meta.url));

export const GOLDEN_INPUT = {
  projectName: 'Fabrikam Outdoor',
  sources: ['Content_Inventory.xlsx', 'Fabrikam_Kickoff_Deck.pptx', 'Fabrikam_RFP_2027.pdf', 'Workshop_Notes.docx'],
  packVersion: '0.1.0',
  schemas: { blueprint: '1', context: '2', proposals: '1', runRecord: '1' },
  catalog: {
    cmkCommit: 'e81d7ff6cf1f918544dd8b336e0e1e5344eb73dc',
    toolkitCommit: '5d1f76eeeaa01826f3906f012b21244c1be83584',
    estimatingVersion: '3'
  }
};

/** Names that would break a naive template fill: replacement patterns, another token, quotes, backticks, a line break. */
export const HOSTILE_INPUT = {
  ...GOLDEN_INPUT,
  projectName: 'Acme $& Co $$ $\' {{sourcesList}} "quoted" `tick`\nsecond line',
  sources: ['Q&A $\'25 {{schemas}}.docx', 'back`tick.pdf', 'plain.xlsx']
};

export function goldenFiles() {
  return buildBootstrapFiles(GOLDEN_INPUT);
}

export function hostileAgents() {
  return buildBootstrapFiles(HOSTILE_INPUT)[0].content;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  writeFileSync(join(here, 'hostile-input.json'), `${JSON.stringify(HOSTILE_INPUT, null, 2)}\n`);
  writeFileSync(join(here, 'hostile-AGENTS.md'), hostileAgents());
  for (const file of goldenFiles()) {
    const target = join(here, file.path.replace('.blueprint/', 'blueprint-'));
    mkdirSync(dirname(target), { recursive: true });
    writeFileSync(target, file.content);
    console.log(`wrote ${target}`);
  }
  writeFileSync(join(here, 'input.json'), `${JSON.stringify(GOLDEN_INPUT, null, 2)}\n`);
}
