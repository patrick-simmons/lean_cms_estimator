/**
 * Minimal OOXML builders for tests and for the committed synthetic sources (tools/samples/synthetic-sources.mjs).
 * A JavaScript sibling of function/src/readers/ooxml.fixture.ts, which the function build does not compile.
 * Entries get a fixed timestamp so a rebuilt file is byte-identical.
 */
import { strToU8, zipSync } from 'fflate';

const CT_NS = 'http://schemas.openxmlformats.org/package/2006/content-types';
const REL_NS = 'http://schemas.openxmlformats.org/package/2006/relationships';
const R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
export const W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
export const P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main';
export const A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main';
export const S_NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const REL_TYPE = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const FIXED_TIME = new Date('2026-01-01T00:00:00Z');

export function xmlEscape(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export function zipOf(entries) {
  const files = {};
  for (const name of Object.keys(entries)) {
    const value = entries[name];
    files[name] = [typeof value === 'string' ? strToU8(value) : value, { mtime: FIXED_TIME }];
  }
  return zipSync(files);
}

function contentTypes(overrides) {
  const items = overrides.map((item) => `<Override PartName="/${item.part}" ContentType="${item.type}"/>`).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="${CT_NS}"><Default Extension="xml" ContentType="application/xml"/>${items}</Types>`;
}

function relationships(items) {
  const rels = items.map((item) =>
    `<Relationship Id="${item.id}" Type="${REL_TYPE}/${item.type}" Target="${item.target}"${item.external ? ' TargetMode="External"' : ''}/>`
  ).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="${REL_NS}">${rels}</Relationships>`;
}

/** A Word paragraph; `style` such as `Heading1` needs a matching entry in the styles part. */
export function wPara(text, style) {
  const pPr = style ? `<w:pPr><w:pStyle w:val="${style}"/></w:pPr>` : '';
  return `<w:p>${pPr}<w:r><w:t xml:space="preserve">${xmlEscape(text)}</w:t></w:r></w:p>`;
}

/** Heading styles 1 to 3 with outline levels, as Word writes them. */
export const HEADING_STYLES = [1, 2, 3].map((level) =>
  `<w:style w:type="paragraph" w:styleId="Heading${level}"><w:name w:val="heading ${level}"/><w:pPr><w:outlineLvl w:val="${level - 1}"/></w:pPr></w:style>`
).join('');

export function docxFixture(options) {
  const entries = {
    '[Content_Types].xml': contentTypes([
      { part: 'word/document.xml', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml' }
    ]),
    'word/document.xml': `<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="${W_NS}" xmlns:r="${R_NS}"><w:body>${options.body}</w:body></w:document>`
  };
  if (options.styles) {
    entries['word/styles.xml'] = `<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="${W_NS}">${options.styles}</w:styles>`;
  }
  return zipOf({ ...entries, ...(options.extra || {}) });
}

export function shape(text, placeholder) {
  const ph = placeholder ? `<p:ph type="${placeholder}"/>` : '';
  const paragraphs = text.split('\n').map((line) => `<a:p><a:r><a:t>${xmlEscape(line)}</a:t></a:r></a:p>`).join('');
  return `<p:sp><p:nvSpPr><p:cNvPr id="1" name="s"/><p:cNvSpPr/><p:nvPr>${ph}</p:nvPr></p:nvSpPr><p:txBody>${paragraphs}</p:txBody></p:sp>`;
}

export function pptxFixture(options) {
  const entries = {
    '[Content_Types].xml': contentTypes([
      { part: 'ppt/presentation.xml', type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml' }
    ])
  };
  const ids = options.order.map((file, index) => `<p:sldId id="${256 + index}" r:id="rId${file}"/>`).join('');
  entries['ppt/presentation.xml'] = `<?xml version="1.0" encoding="UTF-8"?><p:presentation xmlns:p="${P_NS}" xmlns:r="${R_NS}"><p:sldIdLst>${ids}</p:sldIdLst></p:presentation>`;
  entries['ppt/_rels/presentation.xml.rels'] = relationships(
    options.slides.map((slide) => ({ id: `rId${slide.file}`, type: 'slide', target: `slides/slide${slide.file}.xml` }))
  );
  for (const slide of options.slides) {
    entries[`ppt/slides/slide${slide.file}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><p:sld xmlns:p="${P_NS}" xmlns:a="${A_NS}" xmlns:r="${R_NS}"><p:cSld><p:spTree>${slide.shapes}</p:spTree></p:cSld></p:sld>`;
    if (slide.notes !== undefined) {
      entries[`ppt/slides/_rels/slide${slide.file}.xml.rels`] = relationships([
        { id: 'rId1', type: 'notesSlide', target: `../notesSlides/notesSlide${slide.file}.xml` }
      ]);
      entries[`ppt/notesSlides/notesSlide${slide.file}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><p:notes xmlns:p="${P_NS}" xmlns:a="${A_NS}"><p:cSld><p:spTree>${shape(slide.notes, 'body')}${shape('3', 'sldNum')}</p:spTree></p:cSld></p:notes>`;
    }
  }
  return zipOf({ ...entries, ...(options.extra || {}) });
}

/** A sheet row of inline strings or numbers: `row(1, ['Page', 'Count'])`. */
export function sheetRow(number, values) {
  const cells = values.map((value, index) => {
    const ref = `${String.fromCharCode(65 + index)}${number}`;
    return typeof value === 'number'
      ? `<c r="${ref}"><v>${value}</v></c>`
      : `<c r="${ref}" t="inlineStr"><is><t>${xmlEscape(value)}</t></is></c>`;
  }).join('');
  return `<row r="${number}">${cells}</row>`;
}

export function xlsxFixture(options) {
  const entries = {
    '[Content_Types].xml': contentTypes([
      { part: 'xl/workbook.xml', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml' }
    ])
  };
  const sheets = options.sheets.map((sheet, index) =>
    `<sheet name="${xmlEscape(sheet.name)}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`
  ).join('');
  entries['xl/workbook.xml'] = `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="${S_NS}" xmlns:r="${R_NS}"><sheets>${sheets}</sheets></workbook>`;
  const rels = options.sheets.map((sheet, index) => ({ id: `rId${index + 1}`, type: 'worksheet', target: `worksheets/sheet${index + 1}.xml` }));
  if (options.sharedStrings) {
    rels.push({ id: 'rIdS', type: 'sharedStrings', target: 'sharedStrings.xml' });
    const items = options.sharedStrings.map((value) => `<si><t>${xmlEscape(value)}</t></si>`).join('');
    entries['xl/sharedStrings.xml'] = `<?xml version="1.0" encoding="UTF-8"?><sst xmlns="${S_NS}">${items}</sst>`;
  }
  entries['xl/_rels/workbook.xml.rels'] = relationships(rels);
  options.sheets.forEach((sheet, index) => {
    entries[`xl/worksheets/sheet${index + 1}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="${S_NS}"><sheetData>${sheet.rows}</sheetData></worksheet>`;
  });
  return zipOf(entries);
}
