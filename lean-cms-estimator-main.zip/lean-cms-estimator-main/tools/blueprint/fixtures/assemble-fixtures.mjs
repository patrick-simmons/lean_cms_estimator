// Shared inputs for the assembler tests: blocks, a reviewed Blueprint and a re-run extract.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assembleWorkingFile } from '../assemble-working-file.mjs';

export const root = fileURLToPath(new URL('../../..', import.meta.url));
export const estimatingPath = join(root, 'docs', 'catalogs', 'estimating-catalog.md');
export const catalogMd = readFileSync(estimatingPath, 'utf8');

export const blocks = [
  { id: 'src-rfp#p1', itemId: 'src-rfp', fileName: 'RFP.pdf', text: 'Migrate 18,240 pages.', location: { kind: 'page', page: 1, section: '1.1' } },
  { id: 'src-deck#s9', itemId: 'src-deck', fileName: 'Deck.pptx', text: 'Launch with two locales.', location: { kind: 'slide', slide: 9 } },
  { id: 'src-rfp#p2', itemId: 'src-rfp', fileName: 'RFP.pdf', text: 'Launch with four locales.', location: { kind: 'page', page: 2 } },
  { id: 'src-addendum#p1.1', itemId: 'src-addendum', fileName: 'Addendum.pdf', text: 'After the clean-up, 15,000 pages remain in scope.', location: { kind: 'page', page: 1 } },
  { id: 'src-addendum#p1.2', itemId: 'src-addendum', fileName: 'Addendum.pdf', text: 'Editors receive two days of training before go-live.', location: { kind: 'page', page: 1 } }
];

/** A Blueprint after review: one accepted row, one edited row, one dismissed row, revision 1. */
export function reviewedBlueprint() {
  const { working } = assembleWorkingFile({
    extract: {
      requirements: [
        { statement: 'Migrate approximately 18,240 pages.', blockIds: ['src-rfp#p1'], workPackage: 'content-migration', coverage: 'accelerated', question: null },
        { statement: 'The platform launches in four locales.', blockIds: ['src-rfp#p2'], workPackage: 'localization', coverage: 'partly', question: null },
        { statement: 'Provide hypercare for thirty days.', blockIds: ['src-rfp#p2'], workPackage: 'qa-automation', coverage: 'human-led', question: null }
      ],
      platform: { id: 'aem', blockId: 'src-rfp#p1' }
    },
    blocks: blocks.slice(0, 3),
    catalogMd,
    meta: { projectId: 'p1', projectName: 'Pilot', runId: 'run-1' }
  });
  const stamp = (status) => ({ status, by: 'e@example.com', byName: 'E', at: '2026-11-01T10:00:00Z' });
  working.requirements[0].review = stamp('accepted');
  working.requirements[1] = {
    ...working.requirements[1],
    original: { statement: 'The platform launches in four locales.', workPackage: 'localization', coverage: 'partly' },
    statement: 'Launch in four locales, EN first.',
    review: stamp('edited')
  };
  working.requirements[2].review = stamp('dismissed');
  working.revision = 1;
  return working;
}

export const rerunExtract = {
  requirements: [
    // Same statement as the accepted row: nothing to propose.
    { statement: 'Migrate approximately 18,240 pages.', blockIds: ['src-rfp#p1'], workPackage: 'content-migration', coverage: 'accelerated', question: null, duplicateOf: null },
    // A new document disagrees with the edited row: a conflict against it, no winner.
    { statement: 'The deck says two launch locales; the RFP says four.', blockIds: ['src-deck#s9'], workPackage: 'localization', coverage: 'conflict', question: 'Which is the launch scope?', duplicateOf: 'Launch in four locales, EN first.' },
    // A new document changes a value of the accepted row: an update.
    { statement: 'Migrate approximately 15,000 pages after the clean-up.', blockIds: ['src-addendum#p1.1'], workPackage: 'content-migration', coverage: 'accelerated', question: null, duplicateOf: 'Migrate approximately 18,240 pages.' },
    // A new requirement: an add.
    { statement: 'Editors receive two days of training before go-live.', blockIds: ['src-addendum#p1.2'], workPackage: 'multisite', coverage: 'human-led', question: null, duplicateOf: null },
    // Restates a dismissed row: skipped.
    { statement: 'Provide hypercare for thirty days.', blockIds: ['src-rfp#p2'], workPackage: 'qa-automation', coverage: 'human-led', question: null, duplicateOf: null }
  ],
  platform: { id: 'aem', blockId: 'src-rfp#p1' }
};
