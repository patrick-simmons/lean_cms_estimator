/**
 * Which files of a project folder count as source documents. Kept dependency-free (no pdf.js, no
 * function/dist) so prepare-folder.mjs and the app can use the same rule without loading the readers.
 */
import { extname } from 'node:path';

/** Files the tool never treats as sources: the Blueprint outputs and the agent bootstrap. */
export const OUTPUT_SUFFIXES = ['_Blueprint.json', '_Context.json', '_Proposals.json', '_Blueprint.xlsx', '_Pricer.json', '_Pricer.xlsx'];
export const BOOTSTRAP_NAMES = ['AGENTS.md', 'CLAUDE.md', 'desktop.ini', 'Thumbs.db', '.DS_Store'];
export const SOURCE_EXTENSIONS = ['.pdf', '.docx', '.docm', '.dotx', '.pptx', '.pptm', '.ppsx', '.xlsx', '.xlsm', '.xlsb', '.doc', '.ppt', '.xls', '.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp', '.heic'];

/**
 * True for files that are never sources and never worth mentioning: hidden and temporary files, the
 * agent bootstrap and the Blueprint's own output files.
 */
export function isIgnoredName(name) {
  return name.startsWith('.') || name.startsWith('~$') || BOOTSTRAP_NAMES.includes(name) || OUTPUT_SUFFIXES.some((suffix) => name.endsWith(suffix));
}

export function isSourceCandidate(name) {
  return !isIgnoredName(name) && SOURCE_EXTENSIONS.includes(extname(name).toLowerCase());
}

/**
 * Why a top-level file is not a source, or undefined when it is one. Shown to the estimator in the
 * parse manifest, so a file that was passed over is never invisible.
 */
export function skipReason(name) {
  if (isSourceCandidate(name)) {
    return undefined;
  }
  if (isIgnoredName(name)) {
    return 'hidden, temporary, agent bootstrap or Blueprint output file';
  }
  const extension = extname(name).toLowerCase();
  return extension ? `unsupported file type ${extension}` : 'unsupported file type (no extension)';
}
