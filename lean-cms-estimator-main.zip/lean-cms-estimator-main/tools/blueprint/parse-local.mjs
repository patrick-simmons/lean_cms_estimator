#!/usr/bin/env node
/**
 * Parse a project folder's source files into citation-bearing blocks, locally and deterministically
 * (SAPP-013). Writes `.blueprint/parsed/` next to the sources:
 *
 *   manifest.json   what was read, what was not and why, what was skipped, and the tool version
 *   sources.json    Start-quality `sources[]` for assemble-working-file.mjs --sources
 *   blocks.json     every block, for assemble-working-file.mjs --blocks
 *   <itemId>.json   one file per source: its `sources[]` entry with its blocks, for the extract stage
 *
 * It also records the `parse` stage in `.blueprint/run.json`. It makes no network call.
 *
 * Usage:
 *   node tools/blueprint/parse-local.mjs <project-folder> [--out <dir>] [--select <file>...] [--allow-empty] [--quiet]
 *
 * `--select` names the files to parse (relative to the folder). Without it, the tool reads
 * `.blueprint/sources.json` written by prepare-folder (SAPP-016) when it exists, and otherwise every
 * supported file at the top level of the folder. A `.blueprint/sources.json` that lists no files means
 * nothing was selected: the tool parses nothing and says so.
 *
 * `--out` is where the parsed files go (default `.blueprint/parsed` in the folder). The tool only ever
 * writes its own files there, and refuses a directory that is the project folder, contains it or any of
 * its sources, or holds anything this tool did not write.
 *
 * Exit codes:
 *   0  parsed, at least one block produced
 *   1  unexpected failure
 *   2  bad usage, an unsafe `--out`, a missing folder, or a selection that cannot be used (unreadable
 *      `.blueprint/sources.json`, a file that is missing or outside the folder)
 *   3  no sources were selected (`.blueprint/sources.json` lists none); nothing was parsed or written
 *   4  nothing could be read: zero blocks were produced. The manifest is still written so the reasons
 *      are visible, but the run record is not advanced. `--allow-empty` turns this into exit 0.
 */
import { existsSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs';
import { isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { updateRunRecord } from './run-record.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';

const USAGE = 'Usage: node tools/blueprint/parse-local.mjs <project-folder> [--out <dir>] [--select <file>...] [--allow-empty] [--quiet]';
const BUILD_HINT = 'The document readers are not built. From the repository run: npm --prefix function install && npm --prefix function run build';
const RESERVED_OUTPUTS = ['manifest.json', 'sources.json', 'blocks.json'];

export const EXIT = { OK: 0, FAILED: 1, USAGE: 2, NO_SELECTION: 3, NOTHING_READ: 4 };

const defaultOutDir = (folder) => join(folder, '.blueprint', 'parsed');

function parseArgs(argv) {
  const out = { folder: undefined, out: undefined, select: [], selectGiven: false, quiet: false, allowEmpty: false };
  let mode;
  for (const arg of argv) {
    if (arg === '--quiet') {
      out.quiet = true;
      mode = undefined;
    } else if (arg === '--allow-empty') {
      out.allowEmpty = true;
      mode = undefined;
    } else if (arg === '--out' || arg === '--select') {
      mode = arg;
      out.selectGiven = out.selectGiven || arg === '--select';
    } else if (arg.startsWith('--')) {
      return undefined;
    } else if (mode === '--out') {
      out.out = arg;
      mode = undefined;
    } else if (mode === '--select') {
      out.select.push(arg);
    } else if (out.folder === undefined) {
      out.folder = arg;
    } else {
      return undefined;
    }
  }
  if (out.folder === undefined || (out.selectGiven && out.select.length === 0) || mode === '--out') {
    return undefined;
  }
  return out;
}

async function loadCore() {
  try {
    return await import('./parse-local-core.mjs');
  } catch (error) {
    if (error && error.code === 'ERR_MODULE_NOT_FOUND' && /function[\\/]dist/.test(String(error.message))) {
      throw new Error(BUILD_HINT);
    }
    throw error;
  }
}

/** Thrown for a selection or output directory the tool must not act on; the message is for the user. */
class Refusal extends Error {}

/**
 * The files to parse, by name: those given with `--select`, else those listed in `.blueprint/sources.json`,
 * else `undefined` meaning every supported file at the top level. An empty array is a real answer: nothing selected.
 */
function selectedFrom(folder, explicit) {
  if (explicit.length > 0) {
    return explicit;
  }
  const file = join(folder, '.blueprint', 'sources.json');
  if (!existsSync(file)) {
    return undefined;
  }
  let value;
  try {
    value = JSON.parse(readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Refusal(`${file} is not valid JSON (${error.message}). Fix or delete it, or pass --select.`);
  }
  const list = Array.isArray(value) ? value : value && Array.isArray(value.sources) ? value.sources : undefined;
  if (list === undefined) {
    throw new Refusal(`${file} must be a list of sources or an object with a "sources" list. Fix or delete it, or pass --select.`);
  }
  const names = [];
  const malformed = [];
  list.forEach((item, index) => {
    const name = typeof item === 'string' ? item : item && item.name;
    if (typeof name === 'string' && name.length > 0) {
      names.push(name);
    } else {
      malformed.push(`#${index + 1}`);
    }
  });
  if (malformed.length > 0) {
    throw new Refusal(`${file} has entries without a file name (${malformed.join(', ')}). Each source needs a "name".`);
  }
  return names;
}

function isWithin(parent, child) {
  const rel = relative(parent, child);
  return rel === '' || (rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel));
}

/** What a previous run of this tool wrote into a directory, or undefined when the directory is not ours. */
function previousManifest(outDir) {
  try {
    const manifest = JSON.parse(readFileSync(join(outDir, 'manifest.json'), 'utf8'));
    return manifest && manifest.tool === 'parse-local' ? manifest : undefined;
  } catch {
    return undefined;
  }
}

/** Refuse an output directory the tool could damage or that would mix its files into the project's. */
function checkOutDir(folder, outDir, sourcePaths) {
  if (isWithin(outDir, folder)) {
    throw new Refusal(`--out ${outDir} is the project folder or contains it. Choose a separate directory such as .blueprint/parsed.`);
  }
  if (sourcePaths.some((path) => isWithin(outDir, path))) {
    throw new Refusal(`--out ${outDir} contains source files. Choose a directory that holds none of the sources.`);
  }
  if (!existsSync(outDir) || outDir === defaultOutDir(folder)) {
    return;
  }
  if (!statSync(outDir).isDirectory()) {
    throw new Refusal(`--out ${outDir} is a file, not a directory.`);
  }
  if (readdirSync(outDir).length > 0 && previousManifest(outDir) === undefined) {
    throw new Refusal(`--out ${outDir} is not empty and was not written by parse-local. Choose an empty or new directory.`);
  }
}

const toJson = (value) => `${JSON.stringify(value, null, 2)}\n`;

function describeSkipped(skipped) {
  const shown = skipped.slice(0, 5).map((entry) => entry.name).join(', ');
  return `${skipped.length} skipped (${shown}${skipped.length > 5 ? ', ...' : ''}); see manifest.json`;
}

export async function main(argv) {
  const args = parseArgs(argv);
  if (!args) {
    console.error(USAGE);
    return EXIT.USAGE;
  }
  const folder = resolve(args.folder);
  if (!existsSync(folder) || !statSync(folder).isDirectory()) {
    console.error(`parse-local: ${folder} is not a folder that exists`);
    return EXIT.USAGE;
  }
  const log = args.quiet ? () => undefined : (line) => console.log(line);
  const core = await loadCore();
  const outDir = resolve(args.out || defaultOutDir(folder));

  let selected;
  try {
    selected = selectedFrom(folder, args.select);
    if (selected !== undefined && selected.length === 0) {
      console.error(`parse-local: no sources were selected (${join(folder, '.blueprint', 'sources.json')} lists none). Nothing was parsed. Ask the estimator to select source files, or pass --select <file>...`);
      return EXIT.NO_SELECTION;
    }
    checkOutDir(folder, outDir, core.listSources(folder, selected).map((file) => file.path));
  } catch (error) {
    if (error instanceof Refusal || error instanceof core.SelectionError) {
      console.error(`parse-local: ${error.message}`);
      return EXIT.USAGE;
    }
    throw error;
  }

  const result = await core.parseSources(folder, { selected, log });
  const previous = previousManifest(outDir);
  const manifest = {
    ...result.manifest,
    writtenAt: new Date().toISOString(),
    output: { sources: 'sources.json', blocks: 'blocks.json', perSource: result.sources.map((s) => `${s.itemId}.json`) }
  };
  // Each file is replaced whole; the manifest goes last so it also marks a complete write. Nothing is
  // deleted except per-source files that an earlier run of this tool wrote and this run no longer produces.
  for (const source of result.sources) {
    writeFileAtomic(join(outDir, `${source.itemId}.json`), toJson(source));
  }
  writeFileAtomic(join(outDir, 'sources.json'), toJson(result.sources));
  writeFileAtomic(join(outDir, 'blocks.json'), toJson(result.blocks));
  writeFileAtomic(join(outDir, 'manifest.json'), toJson(manifest));
  const kept = new Set([...RESERVED_OUTPUTS, ...manifest.output.perSource]);
  const stale = previous && previous.output && Array.isArray(previous.output.perSource) ? previous.output.perSource : [];
  for (const name of stale) {
    if (!kept.has(name) && /^[A-Za-z0-9._-]+\.json$/.test(name)) {
      rmSync(join(outDir, name), { force: true });
    }
  }

  const notReadCount = result.manifest.files.filter((f) => f.read === 'not read').length;
  const summary = `${result.sources.length} sources, ${result.blocks.length} blocks, ${notReadCount} not read`;
  if (result.manifest.skipped.length > 0) {
    log(`skipped   ${describeSkipped(result.manifest.skipped)}`);
  }
  if (result.blocks.length === 0 && !args.allowEmpty) {
    const why = result.sources.length === 0
      ? 'no supported source files were found at the top level of the folder'
      : 'every source was unreadable (scanned, legacy, protected or damaged)';
    console.error(`parse-local: nothing could be read: ${why}. ${summary}. See ${join(outDir, 'manifest.json')} for the reasons. The run record was not advanced.`);
    return EXIT.NOTHING_READ;
  }

  const inFolder = isWithin(folder, outDir);
  try {
    updateRunRecord(folder, {
      stage: 'parse',
      parseTool: { name: 'parse-local', version: core.PARSE_LOCAL_VERSION },
      files: {
        parsed: {
          path: inFolder ? relative(folder, outDir).split(sep).join('/') : outDir,
          sources: result.sources.length,
          blocks: result.blocks.length,
          notRead: notReadCount
        }
      },
      note: summary
    });
  } catch (error) {
    // The parsed files are already written and valid; a damaged run record must not turn that into a crash.
    console.error(`warning: parse-local could not update ${join(folder, '.blueprint', 'run.json')}: ${error.message}`);
  }
  log(`wrote ${outDir} (${summary})`);
  return EXIT.OK;
}

if (process.argv[1] && resolve(fileURLToPath(import.meta.url)) === resolve(process.argv[1])) {
  main(process.argv.slice(2)).then(
    (code) => process.exit(code),
    (error) => {
      console.error(`parse-local: ${error.message}`);
      process.exit(EXIT.FAILED);
    }
  );
}
