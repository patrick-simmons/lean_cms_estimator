#!/usr/bin/env node
/**
 * Gap sweep for the enrich stage.
 *
 * Checks every work package against a checklist (tools/blueprint/data/implied-scope.json, one entry per
 * package in the estimating catalog). A package with no requirement at all is a gap. A `usual` package
 * (part of nearly every build) is always reported as a gap. A `signalled` package is reported only when one
 * of its signal words appears in a live requirement or question that belongs to another package.
 *
 * It prints one JSON document. Each gap carries a ready `unknown` and `assumption` in Context sidecar v2
 * shape, without ids or refs. The skill keeps or rejects each one and adds the ids and refs. An implied
 * requirement cannot be written: a requirement must cite a document, and this checklist is not one. So the
 * gap becomes a delivery unknown plus a working assumption, both pending, and the estimator decides.
 *
 * Nothing here invents a quantity or hours. A package the estimator dismissed is never a gap, and a gap
 * already in the Context sidecar (`--existing`), whatever its review status, is not proposed again.
 *
 * Usage: node tools/blueprint/gap-sweep.mjs <Project>_Blueprint.json [--existing <Project>_Context.json] [--data <file>]
 * Exit 0 on success. Exit 1 when a file cannot be read, is not JSON, or has the wrong shape. Exit 2 on bad usage.
 * Warnings (requirements with an unknown package id) go to stderr and never change the exit code.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { containsSequence, tokenize } from './match-library.mjs';
import { readSuppressFile, suppressedSources } from './suppression.mjs';
import { validateContextValue } from './validate-context.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_DATA = path.join(HERE, 'data', 'implied-scope.json');
export const DATA_SCHEMA_VERSION = '1';

const BASES = ['usual', 'signalled'];
const USAGE = 'Usage: node tools/blueprint/gap-sweep.mjs <Project>_Blueprint.json [--existing <Project>_Context.json] [--suppress <file>] [--data <file>]';

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** The `source` every gap item carries. It is also how a re-run knows the gap was already proposed. */
export function gapSource(workPackageId) {
  return `Gap sweep checklist ${workPackageId}`;
}

/** Field-path errors for the checklist file; empty means it can be used. */
export function validateChecklist(data) {
  const errors = [];
  if (!isObject(data)) {
    return ['(root): expected an object'];
  }
  if (data.schemaVersion !== DATA_SCHEMA_VERSION) {
    errors.push(`schemaVersion: expected "${DATA_SCHEMA_VERSION}"`);
  }
  if (!Array.isArray(data.packages) || data.packages.length === 0) {
    errors.push('packages: expected a non-empty array');
    return errors;
  }
  const seen = new Set();
  data.packages.forEach((entry, index) => {
    const where = `packages[${index}]`;
    if (!isObject(entry)) {
      errors.push(`${where}: expected an object`);
      return;
    }
    if (typeof entry.workPackageId !== 'string' || !/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(entry.workPackageId)) {
      errors.push(`${where}.workPackageId: expected an id such as integrations`);
    } else if (seen.has(entry.workPackageId)) {
      errors.push(`${where}.workPackageId: ${entry.workPackageId} is listed twice`);
    } else {
      seen.add(entry.workPackageId);
    }
    for (const field of ['name', 'unknown', 'assumption', 'ifFails']) {
      if (typeof entry[field] !== 'string' || entry[field].trim() === '') {
        errors.push(`${where}.${field}: expected non-empty text`);
      }
    }
    if (BASES.indexOf(entry.basis) === -1) {
      errors.push(`${where}.basis: expected one of ${BASES.join(', ')}`);
    }
    const signals = entry.signals;
    if (entry.basis === 'signalled') {
      if (!Array.isArray(signals) || signals.length === 0 || signals.some((word) => typeof word !== 'string' || tokenize(word).length === 0)) {
        errors.push(`${where}.signals: a signalled package needs a non-empty list of words`);
      }
    } else if (signals !== undefined) {
      errors.push(`${where}.signals: only a signalled package has signals`);
    }
  });
  return errors;
}

function reviewStatus(row) {
  return isObject(row.review) && typeof row.review.status === 'string' ? row.review.status : 'pending';
}

/**
 * @param {{ requirements?: unknown[], questions?: unknown[] }} blueprint
 * @param {{ packages: object[] }} checklist a checklist that passed validateChecklist
 * @param {{ existingSources?: Iterable<string>, suppressedSources?: Iterable<string> }} [options] sources are compared trimmed and lowercased
 */
export function gapSweep(blueprint, checklist, options = {}) {
  const existingSources = new Set(Array.from(options.existingSources || [], (source) => String(source).trim().toLowerCase()));
  const suppressed = new Set(Array.from(options.suppressedSources || [], (source) => String(source).trim().toLowerCase()));
  const requirements = (Array.isArray(blueprint.requirements) ? blueprint.requirements : []).filter(isObject);
  const questions = (Array.isArray(blueprint.questions) ? blueprint.questions : []).filter(isObject);
  const known = new Set(checklist.packages.map((entry) => entry.workPackageId));

  const live = requirements.filter((row) => reviewStatus(row) !== 'dismissed' && typeof row.statement === 'string');
  const dismissedIds = new Set(requirements.filter((row) => reviewStatus(row) === 'dismissed').map((row) => row.id));
  const packageOf = new Map(requirements.map((row) => [row.id, row.workPackage]));

  const withLive = new Set(live.map((row) => row.workPackage).filter((id) => typeof id === 'string'));
  const withDismissed = new Set(
    requirements.filter((row) => reviewStatus(row) === 'dismissed').map((row) => row.workPackage).filter((id) => typeof id === 'string')
  );

  const units = [];
  for (const row of live) {
    units.push({ kind: 'requirement', id: row.id, workPackage: row.workPackage, tokens: tokenize(row.statement) });
  }
  for (const question of questions) {
    if (typeof question.text !== 'string' || dismissedIds.has(question.requirementId)) {
      continue;
    }
    units.push({ kind: 'question', id: question.id, workPackage: packageOf.get(question.requirementId), tokens: tokenize(question.text) });
  }

  const result = {
    input: { requirements: live.length, requirementsDismissed: dismissedIds.size, questions: units.filter((unit) => unit.kind === 'question').length },
    unknownPackageIds: Array.from(new Set(live.map((row) => row.workPackage).filter((id) => typeof id === 'string' && id !== 'unmapped' && !known.has(id)))).sort(),
    covered: [],
    dismissedOnly: [],
    alreadyProposed: [],
    suppressed: [],
    notSignalled: [],
    gaps: []
  };

  for (const entry of checklist.packages) {
    const id = entry.workPackageId;
    if (withLive.has(id)) {
      result.covered.push(id);
      continue;
    }
    if (withDismissed.has(id)) {
      result.dismissedOnly.push(id);
      continue;
    }
    if (suppressed.has(gapSource(id).toLowerCase())) {
      result.suppressed.push(id);
      continue;
    }
    if (existingSources.has(gapSource(id).toLowerCase())) {
      result.alreadyProposed.push(id);
      continue;
    }
    let matchedSignals = [];
    let requirementIds = [];
    let questionIds = [];
    if (entry.basis === 'signalled') {
      const hits = units.filter((unit) => unit.workPackage !== id);
      matchedSignals = entry.signals.filter((word) => hits.some((unit) => containsSequence(unit.tokens, tokenize(word))));
      if (matchedSignals.length === 0) {
        result.notSignalled.push(id);
        continue;
      }
      const hitUnits = hits.filter((unit) => entry.signals.some((word) => containsSequence(unit.tokens, tokenize(word))));
      requirementIds = hitUnits.filter((unit) => unit.kind === 'requirement' && unit.id !== undefined).map((unit) => unit.id);
      questionIds = hitUnits.filter((unit) => unit.kind === 'question' && unit.id !== undefined).map((unit) => unit.id);
    }
    result.gaps.push({
      workPackageId: id,
      name: entry.name,
      basis: entry.basis,
      evidence: { matchedSignals, requirementIds, questionIds },
      unknown: { statement: entry.unknown, source: gapSource(id), review: { status: 'pending' } },
      assumption: { statement: entry.assumption, category: 'scope', confidence: 'low', ifFails: entry.ifFails, source: gapSource(id), review: { status: 'pending' } }
    });
  }
  return result;
}

function readJson(file, label) {
  const abs = path.resolve(file);
  let raw;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`Cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.error(`(${label}): invalid JSON (${error.message})`);
    process.exit(1);
  }
}

function parseArgs(args) {
  const parsed = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === '--existing' || arg === '--data' || arg === '--suppress') {
      const next = args[index + 1];
      const name = arg.slice(2);
      if (next === undefined || next === '' || next.startsWith('-') || parsed[name] !== undefined) {
        return undefined;
      }
      parsed[name] = next;
      index += 1;
    } else if (arg.startsWith('-') || parsed.blueprintPath !== undefined) {
      return undefined;
    } else {
      parsed.blueprintPath = arg;
    }
  }
  return parsed.blueprintPath ? parsed : undefined;
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  const blueprint = readJson(parsed.blueprintPath, 'blueprint');
  if (!isObject(blueprint) || !Array.isArray(blueprint.requirements)) {
    console.error('(blueprint): expected an object with a requirements array');
    process.exit(1);
  }
  const checklist = readJson(parsed.data || DEFAULT_DATA, 'checklist');
  const checklistErrors = validateChecklist(checklist);
  if (checklistErrors.length) {
    checklistErrors.forEach((message) => console.error(`(checklist) ${message}`));
    process.exit(1);
  }
  let existingSources = [];
  if (parsed.existing !== undefined) {
    const context = readJson(parsed.existing, 'existing');
    const errors = validateContextValue(context);
    if (errors.length) {
      errors.forEach((message) => console.error(`(existing) ${message}`));
      process.exit(1);
    }
    // A gap proposes an unknown and an assumption; either one in the sidecar, in any status, means it was proposed.
    existingSources = [context.deliveryUnknowns, context.assumptions]
      .flatMap((list) => (Array.isArray(list) ? list : []))
      .filter((item) => isObject(item) && typeof item.source === 'string')
      .map((item) => item.source);
  }
  let suppressed = [];
  if (parsed.suppress !== undefined) {
    try {
      suppressed = suppressedSources(readSuppressFile(parsed.suppress), 'gap-sweep');
    } catch (error) {
      console.error(error.message);
      process.exit(1);
    }
  }
  const result = gapSweep(blueprint, checklist, { existingSources, suppressedSources: suppressed });
  if (result.unknownPackageIds.length > 0) {
    console.error(`warning: requirements use package ids the checklist does not list: ${result.unknownPackageIds.join(', ')}`);
  }
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
