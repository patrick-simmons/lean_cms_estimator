#!/usr/bin/env node
/**
 * The plan file: `{Project}_Plan.json`, the one file the agent writes into the project folder and the
 * workbook is built from. It holds the requirements the documents give, the questions they raise, and the
 * volumes (counts that quote the documents). The skills, the questions and the workstream estimate all read
 * it. The field names of requirements and questions are the ones the carried-over tools (gap sweep, lever
 * advice, question ranking) already read, so those tools take a plan file wherever they take a Blueprint.
 * Contract: docs/spfx/plan-contract.md.
 *
 * Commands:
 *   assemble  <folder> [--project <name>] [--estimating <md>]
 *             Reads `.blueprint/extract.json` and `.blueprint/parsed/blocks.json` (and, when present,
 *             `.blueprint/parsed/sources.json` and `.blueprint/design-sketch.json`) and writes the plan file.
 *             When a plan file exists the run only adds: a requirement with the same statement, or a volume
 *             for a package that has one, is left as it is and nothing a person decided is changed.
 *   validate  <plan.json> [--blocks <blocks.json>] [--estimating <md>]
 *   accept    <plan.json> (--all | --workstream WP-nn | --ids R-001,R-002) [--dismiss R-003,...] [--via bulk|walk]
 *   summary   <plan.json> [--estimating <md>] [--markdown]
 *   estimate  <plan.json> [--platform aem|aem-eds] [--estimating <md>]
 *             Stage 3. Sizes every workstream (volume x hours per unit, a placeholder volume where the plan
 *             has no accepted one, the overhead defaults) and writes `workstreams`, `skills` and
 *             `estimateBasis`. These sections are derived, so a second run replaces them; nothing else changes.
 *   ai-plan   <plan.json>          Stage 4. The tool inventory for the platform (every tool ON), a tool or a reason
 *             per requirement, the readiness list, the unused tools. Opt-outs already in the file are kept.
 *   ai-opt-out <plan.json> --id <tool|method> --reason <r> --note "<why>"   (a reason and a typed note are required)
 *   ai-restore <plan.json> --id <tool|method>
 *             Both size the estimate again: the hours a tool that is OFF supported go back to traditional.
 *   ai-report <plan.json> [--markdown]
 *
 * Exit codes: 0 done; 1 invalid input or output (nothing written); 2 usage; 4 the extraction produced no
 * requirements (nothing written).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { assembleWorkingFile, normalizeStatement } from './assemble-working-file.mjs';
import { checkSketch } from './assemble-drivers.mjs';
import { COVERAGES } from './validate-working-file.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';
import { AiPlanError, buildAiPlan, eligibilityOf, formatAiReport, optOutTargets, readCatalogs, staleAiPlan, totalsOf as aiTotalsOf, validateAiPlan, withOptOut, withoutOptOut } from './ai-plan.mjs';
import { buildEstimate, capsOf, EstimateError, estimateTotals, kindOf, loadModelInputs, staleWorkstreams, validateEstimate } from './estimate-model.mjs';
import { OWNERS } from './ownership.mjs';

export const PLAN_SCHEMA_VERSION = '1';
export const REVIEW_STATUSES = ['pending', 'accepted', 'edited', 'dismissed'];
/** How a decision was made. `rate`, `owner` and `cap` are their own routes: one command writes each. */
export const REVIEW_VIA = ['bulk', 'walk', 'edit', 'rate', 'owner', 'cap'];

/** The Context sidecar's assumption categories. There is deliberately no `commercial` one. */
export const ASSUMPTION_CATEGORIES = ['scope', 'architecture', 'dependency', 'resource', 'delivery', 'estimate'];

const USAGE = [
  'Usage:',
  '  node tools/blueprint/plan.mjs assemble <folder> [--project <name>] [--estimating <md>]',
  '  node tools/blueprint/plan.mjs validate <plan.json> [--blocks <blocks.json>] [--estimating <md>]',
  '  node tools/blueprint/plan.mjs accept <plan.json> (--all | --workstream <activity> | --ids R-001,R-002) [--dismiss R-003,...] [--via bulk|walk]',
  '  node tools/blueprint/plan.mjs summary <plan.json> [--estimating <md>] [--markdown]',
  '  node tools/blueprint/plan.mjs estimate <plan.json> [--platform aem|aem-eds] [--estimating <md>]',
  '  node tools/blueprint/plan.mjs rate <plan.json> --activity <id> --hours <n> --note "<why>"',
  '  node tools/blueprint/plan.mjs owner <plan.json> --activity <id> --set us|shared|client --note "<why>"',
  '  node tools/blueprint/plan.mjs assume <plan.json> --activity <id> --cap <n> --note "<why>"',
  '  node tools/blueprint/plan.mjs ai-plan <plan.json>',
  '  node tools/blueprint/plan.mjs ai-opt-out <plan.json> --id <tool-or-method> --reason not-licensed|not-installed|client-restriction|not-suitable --note "<why>"',
  '  node tools/blueprint/plan.mjs ai-restore <plan.json> --id <tool-or-method>',
  '  node tools/blueprint/plan.mjs ai-report <plan.json> [--markdown]'
].join('\n');

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function text(value) {
  return typeof value === 'string' && value.trim() !== '';
}

function reviewOf(item) {
  return isObject(item) && isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
}

/** `R-007` to 7, or 0. */
function numberOf(id, prefix) {
  const match = new RegExp(`^${prefix}-?(\\d+)$`).exec(typeof id === 'string' ? id : '');
  return match ? Number(match[1]) : 0;
}

function nextNumber(items, prefix) {
  return items.reduce((max, item) => Math.max(max, numberOf(isObject(item) ? item.id : '', prefix)), 0) + 1;
}

// ---------------------------------------------------------------------------------------------------------
// Validate

/**
 * Field-path errors for a plan file. With `blocks` and `workPackages` the volumes are checked against the
 * documents (every quote must be in a cited block), and a requirement's work package must be in the catalog.
 * @returns {string[]}
 */
export function validatePlan(plan, { blocks, workPackages } = {}) {
  const errors = [];
  if (!isObject(plan)) {
    return ['(root): expected an object'];
  }
  if (plan.schemaVersion !== PLAN_SCHEMA_VERSION) {
    errors.push(`schemaVersion: expected "${PLAN_SCHEMA_VERSION}"`);
  }
  if (plan.producedBy !== 'skill') {
    errors.push('producedBy: expected "skill"');
  }
  if (!text(plan.projectName)) {
    errors.push('projectName: expected the project name');
  }
  if (plan.platform !== undefined && !(isObject(plan.platform) && text(plan.platform.id) && text(plan.platform.name))) {
    errors.push('platform: expected { id, name } or no platform');
  }

  if (!Array.isArray(plan.sources)) {
    errors.push('sources: expected an array');
  } else {
    plan.sources.forEach((source, index) => {
      if (!isObject(source) || !text(source.itemId) || !text(source.name)) {
        errors.push(`sources[${index}]: expected itemId and name`);
      }
    });
  }

  const questions = Array.isArray(plan.questions) ? plan.questions : undefined;
  const requirements = Array.isArray(plan.requirements) ? plan.requirements : undefined;
  if (!requirements) {
    errors.push('requirements: expected an array');
  }
  if (!questions) {
    errors.push('questions: expected an array');
  }

  const requirementIds = new Set();
  (requirements || []).forEach((row, index) => {
    const where = `requirements[${index}]`;
    if (!isObject(row)) {
      errors.push(`${where}: expected an object`);
      return;
    }
    if (typeof row.id !== 'string' || !/^R-\d{3,}$/.test(row.id)) {
      errors.push(`${where}.id: expected an id such as R-012`);
    } else if (requirementIds.has(row.id)) {
      errors.push(`${where}.id: ${row.id} is used twice`);
    } else {
      requirementIds.add(row.id);
    }
    if (!text(row.statement)) {
      errors.push(`${where}.statement: expected the statement`);
    }
    if (!Array.isArray(row.sources) || row.sources.length === 0) {
      errors.push(`${where}.sources: expected at least one source`);
    } else {
      row.sources.forEach((source, at) => {
        if (!isObject(source) || !text(source.itemId) || !text(source.fileName) || !text(source.blockId) || !text(source.label)) {
          errors.push(`${where}.sources[${at}]: expected itemId, fileName, blockId and label`);
        }
      });
    }
    if (!text(row.workPackage)) {
      errors.push(`${where}.workPackage: expected an activity id or "unmapped"`);
    } else if (workPackages && row.workPackage !== 'unmapped' && !workPackages.has(row.workPackage)) {
      errors.push(`${where}.workPackage: "${row.workPackage}" is not an activity in the estimating catalog`);
    }
    if (!Array.isArray(row.capabilities) || row.capabilities.some((id) => !text(id))) {
      errors.push(`${where}.capabilities: expected an array of capability ids`);
    }
    if (COVERAGES.indexOf(row.coverage) === -1) {
      errors.push(`${where}.coverage: expected one of ${COVERAGES.join(', ')}`);
    }
    errors.push(...reviewErrors(row.review, `${where}.review`));
  });

  const questionIds = new Set();
  (questions || []).forEach((question, index) => {
    const where = `questions[${index}]`;
    if (!isObject(question)) {
      errors.push(`${where}: expected an object`);
      return;
    }
    if (typeof question.id !== 'string' || !/^Q\d+$/.test(question.id)) {
      errors.push(`${where}.id: expected an id such as Q6`);
    } else if (questionIds.has(question.id)) {
      errors.push(`${where}.id: ${question.id} is used twice`);
    } else {
      questionIds.add(question.id);
    }
    if (!requirementIds.has(question.requirementId)) {
      errors.push(`${where}.requirementId: "${question.requirementId}" is not a requirement in this file`);
    }
    if (!text(question.text)) {
      errors.push(`${where}.text: expected the question`);
    }
  });
  (requirements || []).forEach((row, index) => {
    if (isObject(row) && row.questionId !== undefined && !questionIds.has(row.questionId)) {
      errors.push(`requirements[${index}].questionId: "${row.questionId}" is not a question in this file`);
    }
  });

  if (!Array.isArray(plan.volumes)) {
    errors.push('volumes: expected an array');
  } else if (blocks && workPackages) {
    checkSketch({ schemaVersion: '1', producedBy: 'skill', drivers: plan.volumes }, blocks, workPackages)
      .forEach((message) => errors.push(message.replace(/^drivers\[/, 'volumes[').replace(/^drivers:/, 'volumes:')));
  } else {
    plan.volumes.forEach((volume, index) => {
      if (!isObject(volume) || !text(volume.id) || !text(volume.workPackageId) || !Number.isInteger(volume.quantity) || volume.quantity <= 0) {
        errors.push(`volumes[${index}]: expected id, workPackageId and a whole quantity above zero`);
      } else {
        errors.push(...reviewErrors(volume.review, `volumes[${index}].review`));
      }
    });
  }

  // Sections the later stages fill: present as arrays (or null for the AI plan), checked by those stages.
  for (const key of ['skills', 'workstreams']) {
    if (plan[key] !== undefined && !Array.isArray(plan[key])) {
      errors.push(`${key}: expected an array`);
    }
  }
  if (plan.aiPlan !== undefined && plan.aiPlan !== null && !isObject(plan.aiPlan)) {
    errors.push('aiPlan: expected an object or null');
  }
  // The estimator's rate decisions. Only `plan.mjs rate` writes these, and each one is a
  // number somebody stood behind, so each carries its reason and its review stamp.
  if (plan.rates !== undefined) {
    if (!Array.isArray(plan.rates)) {
      errors.push('rates: expected an array');
    } else {
      const seenRates = new Set();
      plan.rates.forEach((row, index) => {
        const where = `rates[${index}]`;
        if (!isObject(row) || !text(row.activity)) {
          errors.push(`${where}: expected an activity`);
          return;
        }
        if (seenRates.has(row.activity)) {
          errors.push(`${where}.activity: ${row.activity} has more than one rate`);
        }
        seenRates.add(row.activity);
        if (workPackages && !workPackages.has(row.activity)) {
          errors.push(`${where}.activity: "${row.activity}" is not an activity in the estimating catalog`);
        }
        if (typeof row.hoursPerUnit !== 'number' || !(row.hoursPerUnit > 0)) {
          errors.push(`${where}.hoursPerUnit: expected a number above zero`);
        }
        if (!text(row.note)) {
          errors.push(`${where}.note: a rate nobody measured carries the reason it was chosen`);
        }
        errors.push(...reviewErrors(row.review, `${where}.review`));
      });
    }
  }
  // The estimator's ownership decisions. Only `plan.mjs owner` writes these, and each one
  // changes what the estimate is quoting for, so each carries its reason and its review stamp.
  if (plan.owners !== undefined) {
    if (!Array.isArray(plan.owners)) {
      errors.push('owners: expected an array');
    } else {
      const seenOwners = new Set();
      plan.owners.forEach((row, index) => {
        const where = `owners[${index}]`;
        if (!isObject(row) || !text(row.activity)) {
          errors.push(`${where}: expected an activity`);
          return;
        }
        if (seenOwners.has(row.activity)) {
          errors.push(`${where}.activity: ${row.activity} has more than one owner`);
        }
        seenOwners.add(row.activity);
        if (workPackages && !workPackages.has(row.activity)) {
          errors.push(`${where}.activity: "${row.activity}" is not an activity in the estimating catalog`);
        }
        if (OWNERS.indexOf(row.owner) === -1) {
          errors.push(`${where}.owner: expected one of ${OWNERS.join(', ')}`);
        }
        if (!text(row.note)) {
          errors.push(`${where}.note: changing who does the work carries the reason it changed`);
        }
        errors.push(...reviewErrors(row.review, `${where}.review`));
      });
    }
  }
  // The estimator's scope caps. Only `plan.mjs assume` writes these. A cap is a commitment the
  // client is asked to agree to, so like an ownership decision it carries its reason and its stamp.
  if (plan.assumptions !== undefined) {
    if (!Array.isArray(plan.assumptions)) {
      errors.push('assumptions: expected an array');
    } else {
      const seenAssumptions = new Set();
      plan.assumptions.forEach((row, index) => {
        const where = `assumptions[${index}]`;
        if (!isObject(row) || !text(row.activity)) {
          errors.push(`${where}: expected an activity`);
          return;
        }
        if (seenAssumptions.has(row.activity)) {
          errors.push(`${where}.activity: ${row.activity} has more than one cap`);
        }
        seenAssumptions.add(row.activity);
        if (!/^AS-\d{3,}$/.test(row.id || '')) {
          errors.push(`${where}.id: expected AS-### (at least three digits)`);
        }
        if (workPackages && !workPackages.has(row.activity)) {
          errors.push(`${where}.activity: "${row.activity}" is not an activity in the estimating catalog`);
        } else if (workPackages && workPackages.get(row.activity).shape === 'proportional') {
          // It is sized as a share of other activities, so there is no volume for a cap to hold
          // down. Capping the activities it covers is what moves it.
          errors.push(`${where}.activity: ${row.activity} is sized as a share of other activities, so it has no volume to cap`);
        }
        if (ASSUMPTION_CATEGORIES.indexOf(row.category) === -1) {
          errors.push(`${where}.category: expected one of ${ASSUMPTION_CATEGORIES.join(', ')}`);
        }
        if (typeof row.cap !== 'number' || !Number.isFinite(row.cap) || row.cap <= 0) {
          errors.push(`${where}.cap: expected a number above zero`);
        }
        if (!text(row.note)) {
          errors.push(`${where}.note: a cap carries the reason the estimator set it`);
        }
        // Scope Cut #2: a cap says how much work, never what it is worth.
        for (const banned of ['cost', 'price', 'rate', 'contingency', 'margin', 'budget']) {
          if (row[banned] !== undefined) {
            errors.push(`${where}.${banned}: a cap carries no commercial field`);
          }
        }
        errors.push(...reviewErrors(row.review, `${where}.review`));
      });
    }
  }
  if (!errors.some((message) => /^(workstreams|skills): expected an array/.test(message))) {
    const estimateErrors = validateEstimate(plan, { workPackages });
    errors.push(...estimateErrors);
    if (estimateErrors.length === 0 && isObject(plan.aiPlan)) {
      errors.push(...validateAiPlan(plan));
    }
  }
  return errors;
}

function reviewErrors(review, where) {
  if (!isObject(review) || REVIEW_STATUSES.indexOf(review.status) === -1) {
    return [`${where}.status: expected one of ${REVIEW_STATUSES.join(', ')}`];
  }
  if (review.status === 'pending') {
    return [];
  }
  const errors = [];
  if (REVIEW_VIA.indexOf(review.via) === -1) {
    errors.push(`${where}.via: expected one of ${REVIEW_VIA.join(', ')}`);
  }
  if (!text(review.at) || Number.isNaN(Date.parse(review.at))) {
    errors.push(`${where}.at: expected an ISO time`);
  }
  return errors;
}

// ---------------------------------------------------------------------------------------------------------
// Assemble

/** The plan file's name for a project: the project name with the characters a file name cannot hold removed. */
export function planFileName(projectName) {
  return `${String(projectName).replace(/[\\/:*?"<>|]+/g, '').trim() || 'Project'}_Plan.json`;
}

function sourcesOf(parsedSources, blocks) {
  if (Array.isArray(parsedSources) && parsedSources.length > 0) {
    return parsedSources.filter((source) => isObject(source) && text(source.itemId) && text(source.name)).map((source) => ({
      itemId: source.itemId,
      name: source.name,
      ...(text(source.read) ? { read: source.read } : {}),
      ...(Array.isArray(source.notRead) && source.notRead.length ? { notRead: source.notRead } : {})
    }));
  }
  const seen = new Map();
  for (const block of blocks) {
    if (isObject(block) && text(block.itemId) && !seen.has(block.itemId)) {
      seen.set(block.itemId, { itemId: block.itemId, name: block.fileName || block.itemId });
    }
  }
  return Array.from(seen.values());
}

function volumeFrom(driver, number) {
  return { ...driver, id: `D-${String(number).padStart(3, '0')}`, review: { status: 'pending' } };
}

/**
 * Build the plan from the extract, or add to the plan already there.
 *
 * @param {{ extract: object, blocks: object[], catalogMd: string, projectName: string, sketch?: object,
 *   parsedSources?: object[], existing?: object, now?: string, catalogPins?: object }} opts
 * @returns {{ plan: object, stats: object, warnings: string[] }}
 */
export function assemblePlan(opts) {
  const { extract, blocks, catalogMd, projectName, sketch, parsedSources, existing, now = new Date().toISOString(), catalogPins } = opts;
  const { working, stats: workingStats, warnings } = assembleWorkingFile({
    extract,
    blocks,
    catalogMd,
    meta: { projectId: projectName, projectName, runId: 'plan', sources: [] },
    catalogPins
  });
  const stats = { ...workingStats, addedRequirements: 0, addedQuestions: 0, addedVolumes: 0, unchangedRequirements: 0, volumeDisagreements: 0 };
  const drivers = isObject(sketch) && Array.isArray(sketch.drivers) ? sketch.drivers.filter(isObject) : [];

  if (!existing) {
    const plan = {
      schemaVersion: PLAN_SCHEMA_VERSION,
      producedBy: 'skill',
      projectName,
      createdAt: now,
      updatedAt: now,
      catalog: working.catalog,
      ...(working.platform ? { platform: working.platform } : {}),
      sources: sourcesOf(parsedSources, blocks),
      requirements: working.requirements,
      questions: working.questions,
      volumes: drivers.map((driver, index) => volumeFrom(driver, index + 1)),
      skills: [],
      workstreams: [],
      aiPlan: null
    };
    stats.addedRequirements = plan.requirements.length;
    stats.addedQuestions = plan.questions.length;
    stats.addedVolumes = plan.volumes.length;
    return { plan, stats, warnings };
  }

  // A re-run only adds. Nothing already in the file is changed, whatever its review status.
  const plan = JSON.parse(JSON.stringify(existing));
  const byStatement = new Map(plan.requirements.map((row) => [normalizeStatement(row.statement), row]));
  const idMap = new Map();
  for (const row of working.requirements) {
    if (byStatement.has(normalizeStatement(row.statement))) {
      stats.unchangedRequirements += 1;
      continue;
    }
    const id = `R-${String(nextNumber(plan.requirements, 'R')).padStart(3, '0')}`;
    idMap.set(row.id, id);
    const added = { ...row, id, review: { status: 'pending' } };
    delete added.questionId;
    const question = working.questions.find((candidate) => candidate.id === row.questionId);
    if (question) {
      const questionId = `Q${nextNumber(plan.questions, 'Q')}`;
      plan.questions.push({ id: questionId, requirementId: id, text: question.text });
      added.questionId = questionId;
      stats.addedQuestions += 1;
    }
    plan.requirements.push(added);
    byStatement.set(normalizeStatement(added.statement), added);
    stats.addedRequirements += 1;
  }
  for (const driver of drivers) {
    const held = plan.volumes.find((volume) => volume.workPackageId === driver.workPackageId);
    if (held) {
      if (held.quantity !== driver.quantity) {
        stats.volumeDisagreements += 1;
        warnings.push(`${driver.workPackageId}: this run found ${driver.quantity} ${driver.unit || 'units'}, the plan holds ${held.quantity}. The plan was not changed.`);
      }
      continue;
    }
    plan.volumes.push(volumeFrom(driver, nextNumber(plan.volumes, 'D')));
    stats.addedVolumes += 1;
  }
  if (!plan.platform && working.platform) {
    plan.platform = working.platform;
  }
  const known = new Set(plan.sources.map((source) => source.itemId));
  for (const source of sourcesOf(parsedSources, blocks)) {
    if (!known.has(source.itemId)) {
      plan.sources.push(source);
    }
  }
  plan.updatedAt = now;
  return { plan, stats, warnings };
}

// ---------------------------------------------------------------------------------------------------------
// Accept

/**
 * Mark pending requirements (and the pending volumes of the same packages) accepted, or dismissed. Only
 * `pending` rows change: a row a person already edited, accepted or dismissed keeps what they chose.
 * @param {object} plan a valid plan, changed in place
 * @param {{ all?: boolean, workstream?: string, ids?: string[], dismiss?: string[], via?: string, now?: string }} choice
 */
export function acceptRequirements(plan, choice) {
  const { all = false, workstream, ids = [], dismiss = [], via = 'bulk', now = new Date().toISOString() } = choice;
  const result = { accepted: 0, dismissed: 0, volumesAccepted: 0, unknownIds: [] };
  const stamp = { via, at: now };
  const byId = new Map(plan.requirements.map((row) => [row.id, row]));
  for (const id of [...ids, ...dismiss]) {
    if (!byId.has(id)) {
      result.unknownIds.push(id);
    }
  }
  const dismissing = new Set(dismiss);
  const accepting = new Set(ids);
  const packages = new Set();
  for (const row of plan.requirements) {
    if (reviewOf(row) !== 'pending') {
      continue;
    }
    if (dismissing.has(row.id)) {
      row.review = { status: 'dismissed', ...stamp };
      result.dismissed += 1;
    } else if (all || accepting.has(row.id) || (workstream !== undefined && row.workPackage === workstream)) {
      row.review = { status: 'accepted', ...stamp };
      result.accepted += 1;
      packages.add(row.workPackage);
    }
  }
  for (const volume of plan.volumes) {
    if (reviewOf(volume) === 'pending' && (all || packages.has(volume.workPackageId) || volume.workPackageId === workstream)) {
      volume.review = { status: 'accepted', ...stamp };
      result.volumesAccepted += 1;
    }
  }
  if (result.accepted + result.dismissed + result.volumesAccepted > 0) {
    plan.updatedAt = now;
  }
  return result;
}

// ---------------------------------------------------------------------------------------------------------
// Summary

/**
 * The counts the estimator sees at the first checkpoint: what was found, by workstream, and what is missing.
 * Dismissed requirements are left out of every count except `dismissed`.
 */
export function summarizePlan(plan, workPackages) {
  const live = plan.requirements.filter((row) => reviewOf(row) !== 'dismissed');
  const byPackage = new Map();
  for (const row of live) {
    byPackage.set(row.workPackage, (byPackage.get(row.workPackage) || 0) + 1);
  }
  const liveIds = new Set(live.map((row) => row.id));
  const volumes = plan.volumes.filter((volume) => reviewOf(volume) !== 'dismissed');
  const volumePackages = new Set(volumes.map((volume) => volume.workPackageId));
  const named = Array.from(byPackage.keys()).filter((id) => id !== 'unmapped');
  const catalogIds = workPackages ? Array.from(workPackages.keys()) : [];
  const noRequirement = catalogIds.filter((id) => !byPackage.has(id));
  const counts = { pending: 0, accepted: 0, edited: 0, dismissed: 0 };
  for (const row of plan.requirements) {
    counts[reviewOf(row)] += 1;
  }
  const workstreams = Array.isArray(plan.workstreams) ? plan.workstreams : [];
  const caps = capsOf(plan);
  const estimate = workstreams.length === 0 ? undefined : {
    ...estimateTotals(plan),
    platform: plan.estimateBasis ? plan.estimateBasis.platform : null,
    stale: staleWorkstreams(plan),
    assumedWorkstreams: workstreams
      .filter((row) => row.kind === 'delivery' && row.volumeBasis === 'placeholder')
      .map((row) => ({ id: row.id, name: row.name, volume: row.volume, unit: row.unit, label: row.label, clientQuestion: row.clientQuestion })),
    shares: workstreams
      .filter((row) => typeof row.share === 'number')
      .map((row) => ({ id: row.id, name: row.name, share: row.share, basis: row.shareBasis, over: row.shareOf.length, hours: row.traditionalHours })),
    bands: workstreams
      .filter((row) => text(row.band))
      .map((row) => ({ id: row.id, name: row.name, band: row.band, confidence: row.bandConfidence, reason: row.bandReason, question: row.bandQuestion, challenge: row.bandChallenge })),
    capped: workstreams
      .filter((row) => caps.has(row.id))
      .map((row) => ({ id: row.id, name: row.name, cap: caps.get(row.id).cap, unit: row.unit, note: caps.get(row.id).note })),
    // Only the activities somebody else has a hand in. `us` is the answer on most rows and
    // saying so on each of them would bury the few that matter.
    handedOver: workstreams
      .filter((row) => row.owner === 'client' || row.owner === 'shared')
      .map((row) => ({ id: row.id, name: row.name, owner: row.owner, note: row.ownerNote, exclusion: row.exclusion, question: row.ownerQuestion, wholeHours: row.wholeHours }))
  };
  return {
    projectName: plan.projectName,
    platform: plan.platform ? plan.platform.name : null,
    requirements: live.length,
    workstreams: named.length,
    unmapped: byPackage.get('unmapped') || 0,
    conflicts: live.filter((row) => row.coverage === 'conflict').length,
    questions: plan.questions.filter((question) => liveIds.has(question.requirementId)).length,
    volumes: volumes.length,
    review: counts,
    byWorkstream: Array.from(byPackage.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([id, count]) => ({
      id,
      name: workPackages && workPackages.has(id) ? workPackages.get(id).name : id === 'unmapped' ? 'No work package fits' : id,
      requirements: count,
      volume: volumePackages.has(id)
    })),
    noRequirement: noRequirement.map((id) => ({ id, name: workPackages.get(id).name, volume: volumePackages.has(id) })),
    ...(estimate ? { estimate } : {}),
    ...(isObject(plan.aiPlan) ? { ai: { ...aiTotalsOf(plan), stale: staleAiPlan(plan) } } : {})
  };
}

export function formatSummary(summary) {
  const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
  const lines = [
    `# ${summary.projectName}`,
    '',
    `${plural(summary.requirements, 'requirement')} in ${plural(summary.workstreams, 'workstream')}, ${plural(summary.volumes, 'volume')} found, ${plural(summary.questions, 'question')}` +
      `${summary.conflicts ? ` (${plural(summary.conflicts, 'conflict')})` : ''}.` +
      `${summary.platform ? ` Platform: ${summary.platform}.` : ' Platform not named in the documents.'}`,
    `Review: ${summary.review.pending} pending, ${summary.review.accepted} accepted, ${summary.review.edited} edited, ${summary.review.dismissed} dismissed.`
  ];
  if (summary.unmapped > 0) {
    lines.push(`${plural(summary.unmapped, 'requirement')} fit no work package (unmapped).`);
  }
  lines.push('', '## By workstream', '');
  for (const item of summary.byWorkstream) {
    lines.push(`- ${item.id} ${item.name}: ${plural(item.requirements, 'requirement')}${item.volume ? ', volume found' : ''}`);
  }
  if (summary.noRequirement.length > 0) {
    lines.push('', `## ${plural(summary.noRequirement.length, 'workstream')} with no requirement`, '');
    for (const item of summary.noRequirement) {
      lines.push(`- ${item.id} ${item.name}${item.volume ? ' (volume found)' : ''}`);
    }
  }
  if (summary.estimate) {
    const { estimate } = summary;
    lines.push(
      '',
      '## Estimate',
      '',
      `Traditional ${estimate.traditionalHours} h, AI-assisted ${estimate.aiAssistedHours} h (${estimate.savingHours} h, ${estimate.savingPercent}% less) on ${estimate.platform}. ` +
        `${plural(estimate.fromDocuments, 'workstream')} sized from the documents, ${estimate.assumed} on assumed volumes or hours.`,
      // The likely figure leads and the range follows it as one phrase. Low and high are what
      // the evidence allows, not two more numbers to pick between.
      `${estimate.hours.likely} h likely, ${estimate.hours.low} to ${estimate.hours.high} h on the evidence behind it.`
    );
    if (estimate.phases.length > 0) {
      lines.push('', '### By phase', '');
      for (const item of estimate.phases) {
        lines.push(`- ${item.phase}: ${item.hours.likely} h likely (${item.hours.low} to ${item.hours.high}), ${plural(item.workstreams, 'workstream')}`);
      }
    }
    for (const message of estimate.stale) {
      lines.push(`- Out of date: ${message}`);
    }
    if (estimate.shares.length > 0) {
      lines.push('', '### Sized as a share', '');
      for (const item of estimate.shares) {
        lines.push(`- ${item.id} ${item.name}: ${Math.round(item.share * 1000) / 10}% of ${item.over} ${item.over === 1 ? 'activity' : 'activities'} = ${item.hours} h${item.basis === 'fallback' ? ' (a published ratio, not our own delivery data)' : ''}`);
      }
    }
    if (estimate.bands.length > 0) {
      lines.push('', '### Complexity bands', '');
      for (const item of estimate.bands) {
        lines.push(`- ${item.id} ${item.name}: ${item.band} (${item.confidence} confidence). ${item.reason}`);
        if (item.challenge) {
          lines.push(`  - Challenge: ${item.challenge}`);
        }
        if (item.question) {
          lines.push(`  - Ask: ${item.question}`);
        }
      }
    }
    if (estimate.capped.length > 0) {
      lines.push('', '### Scope caps', '');
      for (const item of estimate.capped) {
        lines.push(`- ${item.id} ${item.name}: capped at ${item.cap} ${item.unit}${item.cap === 1 ? '' : 's'}. ${item.note}`);
      }
    }
    if (estimate.handedOver.length > 0) {
      lines.push('', '### Who does the work', '');
      for (const item of estimate.handedOver) {
        lines.push(item.owner === 'client'
          ? `- ${item.id} ${item.name}: the client. ${item.wholeHours} h out of this estimate.`
          : `- ${item.id} ${item.name}: shared, and sized at the full ${item.wholeHours} h until we know the split.`);
        if (item.note) {
          lines.push(`  - Why: ${item.note}`);
        }
        lines.push(`  - Ask: ${item.question}`);
      }
    }
    if (estimate.assumedWorkstreams.length > 0) {
      lines.push('', '### Assumed volumes (replace by asking the client)', '');
      for (const item of estimate.assumedWorkstreams) {
        lines.push(`- ${item.id} ${item.name}: ${item.volume} ${item.unit}${item.volume === 1 ? '' : 's'}, ${item.label}. ${item.clientQuestion}`);
      }
    }
  }
  if (summary.ai) {
    const { ai } = summary;
    lines.push(
      '',
      '## AI plan',
      '',
      `Every available tool is assumed in use on ${ai.platform}: ${ai.inventory.on} of ${ai.inventory.used} tools that a workstream uses are ON, ${ai.methodsOn} delivery methods ON, ` +
        `${plural(ai.optOuts, 'opt-out')}. ${ai.inventory.unused} tools the catalogs offer are mapped to no workstream. ${plural(ai.readiness, 'item')} on the readiness list.`
    );
    for (const message of ai.stale) {
      lines.push(`- Out of date: ${message} Run ai-plan again.`);
    }
  }
  return `${lines.join('\n')}\n`;
}

// ---------------------------------------------------------------------------------------------------------
// Estimate

/**
 * Write the estimate sections of a plan (in place): the workstreams, the skills roll-up and what they were
 * built on. The three sections are derived, so they are replaced; no requirement, question or volume changes.
 * @param {object} plan a valid plan
 * @param {{ factors: object[], skills: Map<string, object>, defaults: Map<string, object> }} inputs
 * @param {{ platform?: string, workPackages: Map<string, object>, now?: string, catalogs?: object }} options
 *   With `catalogs` (stage 4) an AI plan already in the file is rebuilt for the platform first, keeping its opt-outs;
 *   without them it must be for the same platform. The AI plan decides which columns of the factors a workstream may use.
 * @returns {{ warnings: string[], platform: string }}
 */
export function estimatePlan(plan, inputs, { platform, workPackages, now = new Date().toISOString(), catalogs }) {
  const named = plan.platform ? plan.platform.id : undefined;
  // A platform the estimator chose (the documents named none, or another one) is kept when the estimate runs again.
  const basis = isObject(plan.estimateBasis) ? plan.estimateBasis : undefined;
  const chosen = platform || (basis && basis.platformSource === 'estimator' ? basis.platform : undefined) || named || (basis ? basis.platform : undefined);
  if (!chosen) {
    throw new EstimateError('The documents do not name the platform. Ask the estimator, then run again with --platform aem or --platform aem-eds.');
  }
  const aiWarnings = [];
  if (isObject(plan.aiPlan)) {
    if (catalogs) {
      const rebuilt = buildAiPlan(plan, catalogs, { platform: chosen, now, optOuts: plan.aiPlan.optOuts });
      plan.aiPlan = rebuilt.aiPlan;
      aiWarnings.push(...rebuilt.warnings);
    } else if (plan.aiPlan.platform !== chosen) {
      throw new EstimateError(`The AI plan was built for ${plan.aiPlan.platform}, not ${chosen}. Run ai-plan again for the platform of the estimate.`);
    }
  }
  const activities = Array.from(workPackages, ([id, entry]) => ({ id, kind: kindOf(entry) }));
  const eligibility = isObject(plan.aiPlan) ? eligibilityOf(plan.aiPlan, activities) : undefined;
  const { workstreams, skills, warnings } = buildEstimate(plan, inputs, { platform: chosen, workPackages, eligibility });
  warnings.push(...aiWarnings);
  if (platform && named && platform !== named) {
    warnings.push(`The documents name ${named}; the estimate was built for ${platform} because it was asked for.`);
  }
  plan.workstreams = workstreams;
  plan.skills = skills;
  plan.estimateBasis = { platform: chosen, platformSource: chosen === named ? 'documents' : 'estimator', builtAt: now };
  plan.updatedAt = now;
  return { warnings, platform: chosen };
}

// ---------------------------------------------------------------------------------------------------------
// Command line

function fail(code, message) {
  console.error(message);
  process.exit(code);
}

function readJson(file, label) {
  const abs = path.resolve(file);
  let raw;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch (error) {
    return fail(1, `Cannot read ${abs}: ${error.message}`);
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    return fail(1, `${label}: invalid JSON in ${abs} (${error.message})`);
  }
}

function readOptionalJson(file, label) {
  return fs.existsSync(file) ? readJson(file, label) : undefined;
}

function parseArgs(args, valued, flags) {
  const out = { _: [] };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (!arg.startsWith('--')) {
      out._.push(arg);
      continue;
    }
    const name = arg.slice(2);
    if (flags.indexOf(name) !== -1) {
      out[name] = true;
    } else if (valued.indexOf(name) !== -1 && args[index + 1] !== undefined && !args[index + 1].startsWith('--')) {
      out[name] = args[index + 1];
      index += 1;
    } else {
      return undefined;
    }
  }
  return out;
}

function loadCatalog(file) {
  const abs = path.resolve(file || DEFAULT_CATALOG);
  let catalogMd;
  try {
    catalogMd = fs.readFileSync(abs, 'utf8');
  } catch (error) {
    return fail(1, `Cannot read ${abs}: ${error.message}`);
  }
  const workPackages = parseActivities(catalogMd);
  if (workPackages.size === 0) {
    fail(1, `${abs} has no Activities table`);
  }
  return { catalogMd, workPackages };
}

function projectNameOf(folder, args) {
  if (args.project) {
    return args.project;
  }
  const bootstrap = readOptionalJson(path.join(folder, '.blueprint', 'sources.json'), 'sources.json');
  return isObject(bootstrap) && text(bootstrap.projectName) ? bootstrap.projectName.trim() : path.basename(folder);
}

function runAssemble(args) {
  const folder = path.resolve(args._[0]);
  const blueprintDir = path.join(folder, '.blueprint');
  const extract = readJson(path.join(blueprintDir, 'extract.json'), 'extract');
  const blocks = readJson(path.join(blueprintDir, 'parsed', 'blocks.json'), 'blocks');
  if (!Array.isArray(blocks)) {
    fail(1, '(blocks): expected an array of blocks');
  }
  const { catalogMd, workPackages } = loadCatalog(args.estimating);
  const sketch = readOptionalJson(path.join(blueprintDir, 'design-sketch.json'), 'design sketch');
  const parsedSources = readOptionalJson(path.join(blueprintDir, 'parsed', 'sources.json'), 'parsed sources');
  const projectName = projectNameOf(folder, args);
  const out = path.join(folder, planFileName(projectName));

  let existing;
  if (fs.existsSync(out)) {
    existing = readJson(out, 'existing plan');
    const problems = validatePlan(existing, { workPackages });
    if (problems.length > 0) {
      problems.slice(0, 10).forEach((message) => console.error(message));
      fail(1, `${out} is not a valid plan file. It was left as it is; fix or move it, then run again.`);
    }
  }
  if (sketch !== undefined) {
    const problems = checkSketch(sketch, blocks, workPackages);
    if (problems.length > 0) {
      problems.forEach((message) => console.error(`(design sketch) ${message}`));
      fail(1, 'The design sketch is not valid, so the plan was not written. Run assemble-drivers again.');
    }
  }

  const { plan, stats, warnings } = assemblePlan({ extract, blocks, catalogMd, projectName, sketch, parsedSources, existing });
  warnings.forEach((message) => console.error(`warning: ${message}`));
  if (!existing && plan.requirements.length === 0) {
    const why = stats.requirementsIn === 0
      ? 'the extract file lists no requirements'
      : `none of the ${stats.requirementsIn} requirements is usable (${stats.droppedEmptyStatement} with an empty statement, ${stats.droppedNoSource} with no usable block)`;
    fail(4, `Nothing was written: ${why}.`);
  }
  const problems = validatePlan(plan, { blocks, workPackages });
  if (problems.length > 0) {
    problems.slice(0, 10).forEach((message) => console.error(message));
    fail(1, 'Nothing was written: the plan this run produced is not valid.');
  }
  if (fs.existsSync(out) !== Boolean(existing)) {
    fail(3, `${out} changed while this tool ran, so it was not overwritten. Run the tool again.`);
  }
  writeFileAtomic(out, `${JSON.stringify(plan, null, 2)}\n`);
  console.log(`wrote ${out}`);
  console.log(`${existing ? 'added' : 'new'}: ${stats.addedRequirements} requirements, ${stats.addedQuestions} questions, ${stats.addedVolumes} volumes` +
    `${existing ? `; ${stats.unchangedRequirements} requirements were already in the plan` : ''}`);
  console.log(`stats ${JSON.stringify(stats)}`);
}

function runValidate(args) {
  const plan = readJson(args._[0], 'plan');
  const { workPackages } = loadCatalog(args.estimating);
  let blocks;
  if (args.blocks) {
    blocks = readJson(args.blocks, 'blocks');
    if (!Array.isArray(blocks)) {
      fail(1, '(blocks): expected an array of blocks');
    }
  }
  const errors = validatePlan(plan, { blocks, workPackages });
  errors.forEach((message) => console.error(message));
  if (errors.length > 0) {
    fail(1, `${args._[0]}: ${errors.length} problem(s).`);
  }
  staleWorkstreams(plan).forEach((message) => console.error(`warning: out of date: ${message} Run estimate again.`));
  staleAiPlan(plan).forEach((message) => console.error(`warning: out of date: ${message} Run ai-plan again.`));
  console.log(`ok: ${plan.requirements.length} requirements, ${plan.questions.length} questions, ${plan.volumes.length} volumes${blocks ? ', volumes checked against the blocks' : ''}` +
    `${Array.isArray(plan.workstreams) && plan.workstreams.length ? `, ${plan.workstreams.length} workstreams` : ''}`);
}

function runAccept(args) {
  const file = path.resolve(args._[0]);
  const choices = [args.all, args.workstream, args.ids].filter((value) => value !== undefined && value !== false);
  if (choices.length > 1 || (choices.length === 0 && !args.dismiss)) {
    fail(2, `Choose one of --all, --workstream or --ids (or only --dismiss).\n${USAGE}`);
  }
  if (args.via && REVIEW_VIA.slice(0, 2).indexOf(args.via) === -1) {
    fail(2, '--via is bulk or walk');
  }
  const plan = readJson(file, 'plan');
  const errors = validatePlan(plan);
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${file} is not a valid plan file, so nothing was changed.`);
  }
  const split = (value) => (typeof value === 'string' ? value.split(',').map((id) => id.trim()).filter(Boolean) : []);
  const result = acceptRequirements(plan, {
    all: args.all === true,
    workstream: args.workstream,
    ids: split(args.ids),
    dismiss: split(args.dismiss),
    via: args.via || (args.all ? 'bulk' : 'walk')
  });
  if (result.unknownIds.length > 0) {
    fail(1, `Not requirements in this plan: ${result.unknownIds.join(', ')}. Nothing was changed.`);
  }
  writeFileAtomic(file, `${JSON.stringify(plan, null, 2)}\n`);
  console.log(`accepted ${result.accepted} requirements and ${result.volumesAccepted} volumes, dismissed ${result.dismissed}`);
}

function runSummary(args) {
  const plan = readJson(args._[0], 'plan');
  const errors = validatePlan(plan);
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${args._[0]} is not a valid plan file.`);
  }
  const { workPackages } = loadCatalog(args.estimating);
  const summary = summarizePlan(plan, workPackages);
  console.log(args.markdown ? formatSummary(summary).trimEnd() : JSON.stringify(summary, null, 2));
}

function runEstimate(args) {
  const file = path.resolve(args._[0]);
  const plan = readJson(file, 'plan');
  const { workPackages } = loadCatalog(args.estimating);
  const errors = validatePlan(plan, { workPackages });
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${file} is not a valid plan file, so nothing was changed.`);
  }
  let warnings;
  try {
    const catalogs = isObject(plan.aiPlan) ? readCatalogs({ estimating: args.estimating, cmk: args.cmk, toolkit: args.toolkit }) : undefined;
    ({ warnings } = estimatePlan(plan, loadModelInputs(), { platform: args.platform, workPackages, catalogs }));
  } catch (error) {
    if (error instanceof EstimateError || error instanceof AiPlanError) {
      return fail(1, `Nothing was written: ${error.message}`);
    }
    throw error;
  }
  const problems = validatePlan(plan, { workPackages });
  if (problems.length > 0) {
    problems.slice(0, 10).forEach((message) => console.error(message));
    fail(1, 'Nothing was written: the estimate this run produced is not valid.');
  }
  warnings.forEach((message) => console.error(`warning: ${message}`));
  writeFileAtomic(file, `${JSON.stringify(plan, null, 2)}\n`);
  const totals = estimateTotals(plan);
  console.log(`wrote ${file}`);
  console.log(`${plan.workstreams.length} workstreams (${totals.fromDocuments} from the documents, ${totals.assumed} assumed), ${plan.skills.length} skills`);
  console.log(`traditional ${totals.traditionalHours} h, AI-assisted ${totals.aiAssistedHours} h (${totals.savingHours} h, ${totals.savingPercent}% less)`);
  console.log(`${totals.hours.likely} h likely, ${totals.hours.low} to ${totals.hours.high} h on the evidence behind it`);
}

/**
 * assume: cap the volume an activity is sized on. A volume the documents state produces no
 * assumption of its own, so the estimate silently carries whatever the client later says the
 * figure really was. A cap turns that into something the client agreed to: the estimate is for
 * this many, and more than this many is a change. The note is the estimator's reason, and it is
 * what the row on `Assumptions and risks` is written from. Story B-19.
 */
function runAssume(args) {
  const file = path.resolve(args._[0]);
  const plan = readJson(file, 'plan');
  const cap = Number(args.cap);
  if (!text(args.activity) || !Number.isFinite(cap) || cap <= 0 || !text(args.note)) {
    fail(2, USAGE);
  }
  const { workPackages } = loadCatalog(args.estimating);
  const errors = validatePlan(plan, { workPackages });
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${file} is not a valid plan file, so nothing was changed.`);
  }
  const now = new Date().toISOString();
  const assumptions = Array.isArray(plan.assumptions) ? plan.assumptions : [];
  const existing = assumptions.findIndex((row) => isObject(row) && row.activity === args.activity);
  const record = {
    id: existing === -1 ? `AS-${String(assumptions.length + 1).padStart(3, '0')}` : assumptions[existing].id,
    activity: args.activity,
    // The Context sidecar's vocabulary, and the reason it deliberately has no `commercial` value:
    // a cap is a statement about scope, and what it costs to breach is the client's conversation.
    category: 'scope',
    cap,
    note: args.note,
    review: { status: existing === -1 ? 'accepted' : 'edited', via: 'cap', at: now }
  };
  if (existing === -1) {
    assumptions.push(record);
  } else {
    assumptions[existing] = record;
  }
  plan.assumptions = assumptions;
  plan.updatedAt = now;
  const problems = validatePlan(plan, { workPackages });
  if (problems.length > 0) {
    problems.slice(0, 10).forEach((message) => console.error(message));
    fail(1, 'Nothing was written: that cap does not leave a valid plan file.');
  }
  writeFileAtomic(file, `${JSON.stringify(plan, null, 2)}\n`);
  console.log(`${args.activity}: capped at ${cap} (${record.review.status})`);
  console.log('run estimate again for the hours to follow the cap');
}

/**
 * owner: record who is doing an activity. `client` is only ever a decision made here, never a
 * catalog default, because nothing is handed to the client unless a person said so and said
 * why. The note is what the exclusion in the estimate is written from.
 */
function runOwner(args) {
  const file = path.resolve(args._[0]);
  const plan = readJson(file, 'plan');
  if (!text(args.activity) || OWNERS.indexOf(args.set) === -1 || !text(args.note)) {
    fail(2, USAGE);
  }
  const { workPackages } = loadCatalog(args.estimating);
  if (!workPackages.has(args.activity)) {
    fail(1, `${args.activity} is not an activity in the estimating catalog.`);
  }
  const errors = validatePlan(plan, { workPackages });
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${file} is not a valid plan file, so nothing was changed.`);
  }
  const now = new Date().toISOString();
  const owners = Array.isArray(plan.owners) ? plan.owners : [];
  const existing = owners.findIndex((row) => isObject(row) && row.activity === args.activity);
  const record = {
    activity: args.activity,
    owner: args.set,
    note: args.note,
    review: { status: existing === -1 ? 'accepted' : 'edited', via: 'owner', at: now }
  };
  if (existing === -1) {
    owners.push(record);
  } else {
    owners[existing] = record;
  }
  plan.owners = owners;
  plan.updatedAt = now;
  writeFileAtomic(file, `${JSON.stringify(plan, null, 2)}\n`);
  console.log(`${args.activity}: ${args.set} (${record.review.status})`);
  console.log('Run plan.mjs estimate to size the plan against it.');
}

/**
 * rate: record the estimator's decision on a rate no case covers. The tool never writes one of
 * these by itself — an activity with no evidence keeps the catalog's starting figure and says
 * so — so this is the only way a derived rate becomes a number anyone has stood behind.
 */
function runRate(args) {
  const file = path.resolve(args._[0]);
  const plan = readJson(file, 'plan');
  const hours = Number(args.hours);
  if (!text(args.activity) || !Number.isFinite(hours) || hours <= 0 || !text(args.note)) {
    fail(2, USAGE);
  }
  const { workPackages } = loadCatalog(args.estimating);
  if (!workPackages.has(args.activity)) {
    fail(1, `${args.activity} is not an activity in the estimating catalog.`);
  }
  const errors = validatePlan(plan, { workPackages });
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${file} is not a valid plan file, so nothing was changed.`);
  }
  const now = new Date().toISOString();
  const rates = Array.isArray(plan.rates) ? plan.rates : [];
  const existing = rates.findIndex((row) => isObject(row) && row.activity === args.activity);
  const record = {
    activity: args.activity,
    hoursPerUnit: hours,
    note: args.note,
    review: { status: existing === -1 ? 'accepted' : 'edited', via: 'rate', at: now }
  };
  if (existing === -1) {
    rates.push(record);
  } else {
    rates[existing] = record;
  }
  plan.rates = rates;
  plan.updatedAt = now;
  writeFileAtomic(file, `${JSON.stringify(plan, null, 2)}\n`);
  console.log(`${args.activity}: rate ${record.review.status} at ${hours} h per unit`);
  console.log('Run plan.mjs estimate to size the plan against it.');
}

/**
 * ai-plan, ai-opt-out and ai-restore: build the AI plan (every tool ON), or change one opt-out, then size the
 * estimate again so the hours follow the tools that are ON. Nothing is written when anything fails.
 * @param {object} args
 * @param {(optOuts: object[], aiPlan: object) => object[]} change returns the new opt-out list
 */
function runAiChange(args, change) {
  const file = path.resolve(args._[0]);
  const plan = readJson(file, 'plan');
  const { workPackages } = loadCatalog(args.estimating);
  const errors = validatePlan(plan, { workPackages });
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${file} is not a valid plan file, so nothing was changed.`);
  }
  if (!Array.isArray(plan.workstreams) || plan.workstreams.length === 0 || !isObject(plan.estimateBasis)) {
    fail(1, 'The plan has no estimate yet, so there is nothing for the AI plan to size. Run estimate first.');
  }
  const before = estimateTotals(plan);
  let warnings;
  try {
    const catalogs = readCatalogs({ estimating: args.estimating, cmk: args.cmk, toolkit: args.toolkit });
    const platform = plan.estimateBasis.platform;
    const optOuts = isObject(plan.aiPlan) ? plan.aiPlan.optOuts : [];
    const first = buildAiPlan(plan, catalogs, { platform, optOuts });
    const changed = change(optOuts, first.aiPlan);
    plan.aiPlan = buildAiPlan(plan, catalogs, { platform, optOuts: changed }).aiPlan;
    ({ warnings } = estimatePlan(plan, loadModelInputs(), { workPackages }));
    warnings.push(...first.warnings);
  } catch (error) {
    if (error instanceof AiPlanError || error instanceof EstimateError) {
      return fail(1, `Nothing was written: ${error.message}`);
    }
    throw error;
  }
  const problems = validatePlan(plan, { workPackages });
  if (problems.length > 0) {
    problems.slice(0, 10).forEach((message) => console.error(message));
    fail(1, 'Nothing was written: the AI plan this run produced is not valid.');
  }
  warnings.forEach((message) => console.error(`warning: ${message}`));
  writeFileAtomic(file, `${JSON.stringify(plan, null, 2)}\n`);
  const totals = aiTotalsOf(plan);
  const after = estimateTotals(plan);
  console.log(`wrote ${file}`);
  console.log(`AI plan for ${totals.platform}: ${totals.inventory.on} of ${totals.inventory.used} tools used by a workstream are ON, ${totals.inventory.unused} tools no workstream uses, ${totals.optOuts} opt-outs`);
  console.log(`${totals.requirementsWithoutTool} requirements have no tool (each carries its reason), ${totals.readiness} readiness items`);
  console.log(`AI-assisted ${after.aiAssistedHours} h (was ${before.aiAssistedHours} h), traditional ${after.traditionalHours} h`);
}

function runAiPlan(args) {
  runAiChange(args, (optOuts) => optOuts);
}

function runAiOptOut(args) {
  if (!args.id) {
    fail(2, USAGE);
  }
  runAiChange(args, (optOuts, aiPlan) => {
    if (!optOutTargets(aiPlan).has(args.id)) {
      throw new AiPlanError(`${args.id} is not a tool a workstream uses on ${aiPlan.platform}, and not a delivery method.`);
    }
    return withOptOut(optOuts, { id: args.id, reason: args.reason, note: args.note });
  });
}

function runAiRestore(args) {
  if (!args.id) {
    fail(2, USAGE);
  }
  runAiChange(args, (optOuts) => withoutOptOut(optOuts, args.id));
}

function runAiReport(args) {
  const plan = readJson(args._[0], 'plan');
  const errors = validatePlan(plan);
  if (errors.length > 0) {
    errors.slice(0, 10).forEach((message) => console.error(message));
    fail(1, `${args._[0]} is not a valid plan file.`);
  }
  if (!isObject(plan.aiPlan)) {
    fail(1, 'The plan has no AI plan yet. Run ai-plan first.');
  }
  console.log(args.markdown ? formatAiReport(plan).trimEnd() : JSON.stringify(plan.aiPlan, null, 2));
}

function main(argv) {
  const [command, ...rest] = argv.slice(2);
  const specs = {
    assemble: [['project', 'estimating'], [], 1, runAssemble],
    validate: [['blocks', 'estimating'], [], 1, runValidate],
    accept: [['workstream', 'ids', 'dismiss', 'via'], ['all'], 1, runAccept],
    summary: [['estimating'], ['markdown'], 1, runSummary],
    estimate: [['platform', 'estimating', 'cmk', 'toolkit'], [], 1, runEstimate],
    rate: [['activity', 'hours', 'note', 'estimating'], [], 1, runRate],
    owner: [['activity', 'set', 'note', 'estimating'], [], 1, runOwner],
    assume: [['activity', 'cap', 'note', 'estimating'], [], 1, runAssume],
    'ai-plan': [['estimating', 'cmk', 'toolkit'], [], 1, runAiPlan],
    'ai-opt-out': [['id', 'reason', 'note', 'estimating', 'cmk', 'toolkit'], [], 1, runAiOptOut],
    'ai-restore': [['id', 'estimating', 'cmk', 'toolkit'], [], 1, runAiRestore],
    'ai-report': [[], ['markdown'], 1, runAiReport]
  };
  const spec = specs[command];
  const args = spec ? parseArgs(rest, spec[0], spec[1]) : undefined;
  if (!spec || !args || args._.length !== spec[2]) {
    fail(2, USAGE);
  }
  spec[3](args);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
