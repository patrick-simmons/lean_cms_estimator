#!/usr/bin/env node
/**
 * Builds the estimate workbook from the plan file (stage 5).
 *
 *   node tools/blueprint/build-workbook.mjs "<Project>_Plan.json" [--template <xlsx>] [--out <xlsx>] [--estimating <catalog>]
 *
 * It takes a copy of the template (samples/workbook/Estimate_Template.xlsx), fills the data sheets and the named
 * cells of Coverage from the plan, and saves `<Project>_Estimate.xlsx` next to the plan file. The plan must be
 * valid, estimated (`plan.mjs estimate`) and have an AI plan (`plan.mjs ai-plan`); anything else stops here with
 * nothing written. A plan that moved after the estimate still builds, and says so in the workbook (a row on
 * Assumptions and risks) and on the console.
 *
 * Exit codes: 0 done; 1 the plan or the template cannot be used (nothing written); 2 usage.
 * Contract: docs/spfx/workbook-template.md.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadSeed } from '../factors/seed.mjs';
import { staleAiPlan } from './ai-plan.mjs';
import { estimateTotals, staleWorkstreams } from './estimate-model.mjs';
import { validatePlan } from './plan.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';
import { buildSheetRows, lanesOf, SHEET_COLUMNS } from './workbook-rows.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';
import { fillWorkbook, XlsxFillError } from './xlsx-fill.mjs';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const DEFAULT_TEMPLATE = path.join(root, 'samples', 'workbook', 'Estimate_Template.xlsx');

const USAGE = 'Usage: node tools/blueprint/build-workbook.mjs "<Project>_Plan.json" [--template <xlsx>] [--out <xlsx>] [--estimating <catalog>]';

export class WorkbookError extends Error {}

/** The workbook's path for a plan file: `<Project>_Plan.json` becomes `<Project>_Estimate.xlsx` in the same folder. */
export function workbookPathFor(planPath) {
  const folder = path.dirname(planPath);
  const base = path.basename(planPath).replace(/\.json$/i, '').replace(/_Plan$/i, '');
  return path.join(folder, `${base}_Estimate.xlsx`);
}

/**
 * Check the plan and build the workbook bytes. Pure apart from reading the seed and the template.
 * @returns {{ bytes: Uint8Array, rows: Record<string, number>, totals: object, warnings: string[] }}
 */
export function buildWorkbookBytes(plan, { template, workPackages, lanes, now = new Date().toISOString() }) {
  const errors = validatePlan(plan, { workPackages });
  if (errors.length > 0) {
    throw new WorkbookError(`the plan file is not valid:\n${errors.slice(0, 10).join('\n')}${errors.length > 10 ? `\n... and ${errors.length - 10} more` : ''}`);
  }
  if (!Array.isArray(plan.workstreams) || plan.workstreams.length === 0) {
    throw new WorkbookError('the plan has no estimate yet. Run plan.mjs estimate first.');
  }
  if (typeof plan.aiPlan !== 'object' || plan.aiPlan === null) {
    throw new WorkbookError('the plan has no AI plan yet. Run plan.mjs ai-plan first.');
  }
  const warnings = [...staleWorkstreams(plan).map((message) => `out of date: ${message}`), ...staleAiPlan(plan).map((message) => `out of date: ${message}`)];
  const content = buildSheetRows(plan, { workPackages, lanes, now });
  for (const [name, columns] of Object.entries(SHEET_COLUMNS)) {
    const bad = content.sheets[name].find((row) => row.length !== columns.length);
    if (bad) {
      throw new WorkbookError(`internal error: a ${name} row has ${bad.length} cells, the sheet has ${columns.length} columns`);
    }
  }
  let bytes;
  try {
    bytes = fillWorkbook(template, content);
  } catch (error) {
    if (error instanceof XlsxFillError) {
      throw new WorkbookError(error.message);
    }
    throw error;
  }
  return {
    bytes,
    rows: Object.fromEntries(Object.entries(content.sheets).map(([name, rows]) => [name, rows.length])),
    totals: estimateTotals(plan),
    warnings
  };
}

/**
 * Read the plan, the template and the seed, build the workbook and save it.
 * @param {{ planPath: string, templatePath?: string, out?: string, estimating?: string, now?: string }} options
 */
export function buildWorkbook({ planPath, templatePath = DEFAULT_TEMPLATE, out, estimating = DEFAULT_CATALOG, now }) {
  const readText = (file, label) => {
    try {
      return fs.readFileSync(file);
    } catch (error) {
      throw new WorkbookError(`Cannot read ${label} ${file}: ${error.message}`);
    }
  };
  let plan;
  try {
    plan = JSON.parse(readText(planPath, 'the plan').toString('utf8'));
  } catch (error) {
    throw error instanceof WorkbookError ? error : new WorkbookError(`${planPath}: invalid JSON (${error.message})`);
  }
  const workPackages = parseActivities(readText(estimating, 'the estimating catalog').toString('utf8'));
  const laneSheet = loadSeed().find((sheet) => sheet.name === 'Lanes');
  const template = new Uint8Array(readText(templatePath, 'the template'));
  const result = buildWorkbookBytes(plan, { template, workPackages, lanes: lanesOf(laneSheet), now });
  const target = out || workbookPathFor(planPath);
  writeFileAtomic(target, result.bytes);
  return { ...result, out: target };
}

function parseArgs(args) {
  const valued = ['template', 'out', 'estimating'];
  const out = { _: [] };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (!arg.startsWith('--')) {
      out._.push(arg);
    } else if (valued.includes(arg.slice(2)) && args[index + 1] !== undefined && !args[index + 1].startsWith('--')) {
      out[arg.slice(2)] = args[index + 1];
      index += 1;
    } else {
      return undefined;
    }
  }
  return out._.length === 1 ? out : undefined;
}

function main(argv) {
  const args = parseArgs(argv.slice(2));
  if (!args) {
    console.error(USAGE);
    process.exit(2);
  }
  try {
    const result = buildWorkbook({
      planPath: path.resolve(args._[0]),
      templatePath: args.template ? path.resolve(args.template) : undefined,
      out: args.out ? path.resolve(args.out) : undefined,
      estimating: args.estimating ? path.resolve(args.estimating) : undefined
    });
    result.warnings.forEach((message) => console.error(`warning: ${message}`));
    console.log(`wrote ${result.out}`);
    console.log(`rows: ${Object.entries(result.rows).map(([name, count]) => `${name} ${count}`).join(', ')}`);
    console.log(`hours: ${result.totals.traditionalHours} traditional, ${result.totals.aiAssistedHours} AI-assisted; ${result.totals.assumed} of ${result.totals.fromDocuments + result.totals.assumed} workstreams on assumed volumes or hours`);
  } catch (error) {
    if (error instanceof WorkbookError) {
      console.error(`build-workbook: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
