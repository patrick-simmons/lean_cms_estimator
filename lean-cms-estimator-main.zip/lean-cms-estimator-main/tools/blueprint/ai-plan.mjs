/**
 * The AI plan (stage 4): aggressive AI usage, written into the plan file's `aiPlan`.
 *
 * The rule is "every available tool is used". The tool inventory is generated from the catalogs for the
 * platform of the estimate: every CMK skill and agent (all platforms), every usable CMK vendor capability of
 * the platform (supported or local-only), and every active ai-dev-toolkit skill and agent. Each is ON. The estimating catalog says which
 * workstreams each one speeds up (its Capabilities rows and Delivery methods); a tool no workstream uses is
 * listed as unused, which is a gap in the catalog's mappings, not a decision.
 *
 *  - Opting out (a tool, or a whole delivery method with its tools) needs a reason from a fixed list and a typed
 *    note. The hours of the workstreams that relied on it go back to traditional: the "with opt-in" column needs
 *    one opt-in tool ON in the workstream, the "with methods" column one applicable delivery method ON.
 *  - Every live requirement has a tool or method that applies to it, or a typed reason why none does. The
 *    tool writes the catalog's own fact as the reason when the catalog lists nothing; it never invents one.
 *  - The readiness list says what must be installed or accessed to reach the AI-assisted number.
 *
 * No hours are written here. The estimate model reads the eligibility of each workstream from this file
 * (`eligibilityOf`) and takes the AI-assisted hours from the owner's factors.
 */
import fs from 'node:fs';
import path from 'node:path';
import { catalogPins } from './derive-capabilities.mjs';
import { DEFAULT_CATALOG } from './rank-questions.mjs';

const CATALOG_DIR = path.dirname(DEFAULT_CATALOG);
export const DEFAULT_CMK_CATALOG = path.join(CATALOG_DIR, 'cmk-capability-catalog.md');
export const DEFAULT_TOOLKIT_CATALOG = path.join(CATALOG_DIR, 'toolkit-capability-catalog.md');

export const OPT_OUT_REASONS = ['not-licensed', 'not-installed', 'client-restriction', 'not-suitable'];
export const TOOL_STATUSES = ['on', 'off'];

export class AiPlanError extends Error {}

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function text(value) {
  return typeof value === 'string' && value.trim() !== '';
}

// ---------------------------------------------------------------------------------------------------------
// Reading the catalogs

function splitRow(line) {
  const inner = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  const cells = [];
  let current = '';
  for (let index = 0; index < inner.length; index += 1) {
    const char = inner[index];
    if (char === '\\' && inner[index + 1] === '|') {
      current += '|';
      index += 1;
    } else if (char === '|') {
      cells.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  cells.push(current.trim());
  return cells;
}

/** Every markdown table with the headings above it (level 1 first). */
function parseTables(markdown) {
  const lines = markdown.replace(/\r\n/g, '\n').split('\n');
  const tables = [];
  const headings = [];
  for (let index = 0; index < lines.length; index += 1) {
    const heading = /^(#{1,6})\s+(.*)$/.exec(lines[index]);
    if (heading) {
      headings[heading[1].length] = heading[2].trim();
      headings.length = heading[1].length + 1;
      continue;
    }
    if (lines[index].trim().startsWith('|') && (lines[index + 1] || '').trim().startsWith('| ---')) {
      const header = splitRow(lines[index]);
      const rows = [];
      index += 2;
      while (index < lines.length && lines[index].trim().startsWith('|')) {
        rows.push(splitRow(lines[index]));
        index += 1;
      }
      tables.push({ headings: headings.filter((item) => item !== undefined), header, rows });
      index -= 1;
    }
  }
  return tables;
}

const unwrap = (value) => /^`([^`]+)`$/.exec(String(value).trim())?.[1] ?? String(value).trim();

function idsIn(cell) {
  return Array.from(String(cell).matchAll(/`([^`]+)`(\s*\(opt-in\))?/g), (match) => ({ id: match[1], optIn: Boolean(match[2]) }));
}

/** The Capabilities rows and the Delivery methods of the estimating catalog. */
export function parseEstimating(markdown) {
  const rows = [];
  const methods = new Map();
  for (const table of parseTables(markdown)) {
    const header = table.header.join('|');
    if (header === 'Activity|Platform|Capabilities|Opt-in coverage|Method coverage') {
      for (const cells of table.rows) {
        rows.push({ workPackage: unwrap(cells[0]), platform: cells[1], capabilities: idsIn(cells[2]) });
      }
    } else if (header === 'Method|Capabilities|Applies to|Prerequisites|Default') {
      for (const cells of table.rows) {
        methods.set(unwrap(cells[0]), {
          id: unwrap(cells[0]),
          capabilities: idsIn(cells[1]).map((item) => item.id),
          workstreams: idsIn(cells[2]).map((item) => item.id),
          prerequisites: cells[3],
          isDefault: cells[4].toLowerCase() === 'yes'
        });
      }
    }
  }
  if (rows.length === 0 || methods.size === 0) {
    throw new AiPlanError('The estimating catalog has no Capabilities table or no Delivery methods table.');
  }
  return { rows, methods, pins: catalogPins(markdown) };
}

/** The CMK catalog: skills and agents for all platforms, and the vendor capabilities and assets by platform. */
export function parseCmk(markdown) {
  const common = new Map();
  const vendor = new Map();
  const assets = new Map();
  for (const table of parseTables(markdown)) {
    const [, section, name, kind] = table.headings;
    if (section === 'All platforms' && (name === 'Skills' || name === 'Agents') && table.rows.length > 0) {
      for (const cells of table.rows) {
        common.set(unwrap(cells[0]), { kind: name === 'Skills' ? 'skill' : 'agent', description: cells[1] });
      }
    } else if (section === 'Platforms' && kind === 'Vendor assets') {
      for (const cells of table.rows) {
        assets.set(unwrap(cells[0]), { name: cells[1], mode: cells[2], status: cells[3] });
      }
    } else if (section === 'Platforms' && kind === 'Vendor capabilities') {
      const byId = vendor.get(name) || new Map();
      for (const cells of table.rows) {
        byId.set(unwrap(cells[0]), { assetId: unwrap(cells[1]), mode: cells[2], status: cells[3] });
      }
      vendor.set(name, byId);
    }
  }
  if (common.size === 0) {
    throw new AiPlanError('The CMK capability catalog has no skills table for all platforms.');
  }
  return { common, vendor, assets };
}

/** The toolkit catalog: every skill and agent by plugin. */
export function parseToolkit(markdown) {
  const entries = new Map();
  for (const table of parseTables(markdown)) {
    const [, section, plugin, kind] = table.headings;
    if (section === 'Plugins' && (kind === 'Skills' || kind === 'Agents')) {
      for (const cells of table.rows) {
        entries.set(unwrap(cells[0]), { kind: kind === 'Skills' ? 'skill' : 'agent', plugin, status: cells[1], description: cells[2] });
      }
    }
  }
  if (entries.size === 0) {
    throw new AiPlanError('The toolkit capability catalog has no skills or agents.');
  }
  return entries;
}

/**
 * Every tool the catalogs offer for the platform: CMK for all platforms, the CMK vendor capabilities that are
 * usable on the platform, and the active toolkit skills and agents.
 * @returns {Map<string, { id: string, kind: string, source: string, plugin?: string, assetId?: string, optIn: boolean, localOnly?: boolean }>}
 */
export function buildInventory({ cmk, toolkit, platform }) {
  const inventory = new Map();
  for (const [id, entry] of cmk.common) {
    inventory.set(id, { id, kind: entry.kind, source: 'cmk', optIn: false });
  }
  const vendor = cmk.vendor.get(platform);
  for (const [id, entry] of vendor ? vendor : []) {
    if ((entry.status === 'supported' || entry.status === 'local-only') && !inventory.has(id)) {
      inventory.set(id, {
        id,
        kind: 'skill',
        source: 'vendor',
        assetId: entry.assetId,
        optIn: entry.mode === 'opt_in',
        ...(entry.status === 'local-only' ? { localOnly: true } : {})
      });
    }
  }
  for (const [id, entry] of toolkit) {
    if (entry.status === 'active' && !inventory.has(id)) {
      inventory.set(id, { id, kind: entry.kind, source: 'toolkit', plugin: entry.plugin, optIn: false });
    }
  }
  return inventory;
}

export function readCatalogs({ estimating = DEFAULT_CATALOG, cmk = DEFAULT_CMK_CATALOG, toolkit = DEFAULT_TOOLKIT_CATALOG } = {}) {
  const read = (file) => {
    try {
      return fs.readFileSync(path.resolve(file), 'utf8');
    } catch (error) {
      throw new AiPlanError(`Cannot read ${path.resolve(file)}: ${error.message}`);
    }
  };
  return { estimatingMd: read(estimating), cmkMd: read(cmk), toolkitMd: read(toolkit) };
}

// ---------------------------------------------------------------------------------------------------------
// Build

function reviewOf(item) {
  return isObject(item) && isObject(item.review) && typeof item.review.status === 'string' ? item.review.status : 'pending';
}

/**
 * Build the AI plan for a plan that has been estimated. Opt-outs already in the plan are kept (and checked).
 * @param {object} plan
 * @param {{ estimatingMd: string, cmkMd: string, toolkitMd: string }} catalogs
 * @param {{ platform: string, now?: string, optOuts?: object[] }} options
 * @returns {{ aiPlan: object, warnings: string[] }}
 */
export function buildAiPlan(plan, catalogs, { platform, now = new Date().toISOString(), optOuts = [] }) {
  const estimating = parseEstimating(catalogs.estimatingMd);
  const cmk = parseCmk(catalogs.cmkMd);
  const toolkit = parseToolkit(catalogs.toolkitMd);
  const inventory = buildInventory({ cmk, toolkit, platform });
  const warnings = [];

  // Which workstreams each tool speeds up, and which delivery methods carry it.
  const rowsForPlatform = estimating.rows.filter((row) => row.platform === 'all' || row.platform === platform);
  const used = new Map();
  const touch = (id) => {
    if (!used.has(id)) {
      used.set(id, { workstreams: new Set(), methods: new Set(), optInMark: false });
    }
    return used.get(id);
  };
  const directByWorkstream = new Map();
  for (const row of rowsForPlatform) {
    for (const item of row.capabilities) {
      const entry = touch(item.id);
      entry.workstreams.add(row.workPackage);
      entry.optInMark = entry.optInMark || item.optIn;
      directByWorkstream.set(row.workPackage, [...(directByWorkstream.get(row.workPackage) || []), item.id]);
    }
  }
  for (const method of estimating.methods.values()) {
    for (const id of method.capabilities) {
      const entry = touch(id);
      entry.methods.add(method.id);
      method.workstreams.forEach((workPackage) => entry.workstreams.add(workPackage));
    }
  }
  for (const id of used.keys()) {
    if (!inventory.has(id)) {
      throw new AiPlanError(`The estimating catalog lists ${id} for ${platform}, but the CMK and toolkit catalogs do not offer it there. Run npm run catalog:check.`);
    }
  }

  // Opt-outs: kept when they still name something the plan uses.
  const validOptOuts = [];
  for (const optOut of optOuts) {
    const isMethod = estimating.methods.has(optOut.id);
    const isTool = used.has(optOut.id);
    if (isMethod || isTool) {
      validOptOuts.push({ id: optOut.id, kind: isMethod ? 'method' : 'tool', reason: optOut.reason, note: optOut.note, at: optOut.at });
    } else {
      warnings.push(`The opt-out of ${optOut.id} was dropped: no workstream uses it on ${platform} any more.`);
    }
  }
  const optedOut = new Set(validOptOuts.map((item) => item.id));
  const methodOn = (id) => !optedOut.has(id);

  const methods = Array.from(estimating.methods.values()).map((method) => ({
    id: method.id,
    default: method.isDefault,
    workstreams: method.workstreams,
    tools: method.capabilities,
    status: methodOn(method.id) ? 'on' : 'off',
    prerequisites: method.prerequisites
  }));

  const tools = Array.from(used.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([id, usage]) => {
    const base = inventory.get(id);
    const carriers = Array.from(usage.methods).sort();
    const on = !optedOut.has(id) && (carriers.length === 0 || carriers.some(methodOn));
    return {
      id,
      kind: base.kind,
      source: base.source,
      ...(base.plugin ? { plugin: base.plugin } : {}),
      ...(base.assetId ? { assetId: base.assetId } : {}),
      ...(base.localOnly ? { localOnly: true } : {}),
      optIn: base.optIn || usage.optInMark,
      workstreams: Array.from(usage.workstreams).sort(),
      methods: carriers,
      status: on ? 'on' : 'off'
    };
  });
  const toolById = new Map(tools.map((tool) => [tool.id, tool]));

  // A tool or a reason for every live requirement.
  const existing = new Map((isObject(plan.aiPlan) && Array.isArray(plan.aiPlan.requirements) ? plan.aiPlan.requirements : []).map((entry) => [entry.requirementId, entry]));
  const requirements = (Array.isArray(plan.requirements) ? plan.requirements : [])
    .filter((row) => reviewOf(row) !== 'dismissed')
    .map((row) => {
      const candidates = Array.from(new Set(directByWorkstream.get(row.workPackage) || []));
      const toolIds = candidates.filter((id) => toolById.get(id).status === 'on');
      const methodIds = methods.filter((method) => method.status === 'on' && method.workstreams.indexOf(row.workPackage) !== -1).map((method) => method.id);
      const entry = { requirementId: row.id, workstream: row.workPackage, tools: toolIds, methods: methodIds };
      const typed = existing.get(row.id);
      if (typed && typed.reasonSource === 'estimator' && text(typed.reason)) {
        return { ...entry, reason: typed.reason, reasonSource: 'estimator' };
      }
      if (toolIds.length === 0 && methodIds.length === 0) {
        const anyOffered = candidates.length > 0 || Array.from(estimating.methods.values()).some((method) => method.workstreams.indexOf(row.workPackage) !== -1);
        return {
          ...entry,
          reason: row.workPackage === 'unmapped'
            ? 'No work package fits this requirement, so the catalog assigns it no tool.'
            : anyOffered
              ? `Every tool and delivery method the catalog lists for ${row.workPackage} on ${platform} is opted out.`
              : `The estimating catalog lists no tool or delivery method for ${row.workPackage} on ${platform}.`,
          reasonSource: 'catalog'
        };
      }
      return entry;
    });

  const unusedTools = Array.from(inventory.keys()).filter((id) => !used.has(id)).sort();
  const aiPlan = {
    platform,
    builtAt: now,
    catalog: {
      estimatingVersion: estimating.pins.estimatingVersion,
      cmkCommit: estimating.pins.cmkCommit,
      toolkitCommit: estimating.pins.toolkitCommit
    },
    inventory: {
      total: inventory.size,
      used: tools.length,
      on: tools.filter((tool) => tool.status === 'on').length,
      off: tools.filter((tool) => tool.status === 'off').length,
      unused: unusedTools.length
    },
    methods,
    tools,
    optOuts: validOptOuts,
    requirements,
    unusedTools,
    readiness: readinessOf({ tools, methods, cmk })
  };
  return { aiPlan, warnings };
}

/** What must be installed or reached to get the AI-assisted number: from the tools and methods that are ON. */
export function readinessOf({ tools, methods, cmk }) {
  const items = [];
  const on = tools.filter((tool) => tool.status === 'on');
  const workstreamsOf = (list) => Array.from(new Set(list.flatMap((tool) => tool.workstreams))).sort();

  const cmkTools = on.filter((tool) => tool.source === 'cmk');
  if (cmkTools.length > 0) {
    items.push({ kind: 'install', item: 'CMK plugin', needs: 'Installed in the delivery repository, then cmk-init once per project (it detects the platform and writes the project config).', tools: cmkTools.length, workstreams: workstreamsOf(cmkTools) });
  }
  const assetIds = Array.from(new Set(on.filter((tool) => tool.source === 'vendor').map((tool) => tool.assetId))).sort();
  for (const assetId of assetIds) {
    const forAsset = on.filter((tool) => tool.assetId === assetId);
    const asset = cmk.assets.get(assetId);
    const optIn = forAsset.some((tool) => tool.optIn);
    const localOnly = forAsset.some((tool) => tool.localOnly);
    items.push({
      kind: 'vendor-asset',
      item: asset ? `${asset.name} (${assetId})` : assetId,
      needs: localOnly
        ? `Local-only vendor asset: it must be synced locally and must not be redistributed.${optIn ? ' Opt-in vendor asset: enable it explicitly for the project.' : ''}`
        : optIn ? 'Opt-in vendor asset: enable it explicitly for the project.' : 'Default vendor asset, installed with CMK.',
      tools: forAsset.length,
      workstreams: workstreamsOf(forAsset)
    });
  }
  const plugins = Array.from(new Set(on.filter((tool) => tool.source === 'toolkit').map((tool) => tool.plugin))).sort();
  for (const plugin of plugins) {
    const forPlugin = on.filter((tool) => tool.plugin === plugin);
    items.push({ kind: 'install', item: `ai-dev-toolkit plugin ${plugin}`, needs: 'Installed for every person who runs it.', tools: forPlugin.length, workstreams: workstreamsOf(forPlugin) });
  }
  for (const method of methods.filter((entry) => entry.status === 'on')) {
    items.push({ kind: 'method', item: `Delivery method ${method.id}`, needs: method.prerequisites, tools: method.tools.length, workstreams: method.workstreams });
  }
  return items;
}

// ---------------------------------------------------------------------------------------------------------
// Opt-outs

/**
 * Add or replace the opt-out of a tool or method. A reason from the list and a typed note are required.
 * @returns {object[]} the new list
 */
export function withOptOut(optOuts, { id, reason, note, now = new Date().toISOString() }) {
  if (!text(id)) {
    throw new AiPlanError('Name the tool or delivery method to opt out of (--id).');
  }
  if (OPT_OUT_REASONS.indexOf(reason) === -1) {
    throw new AiPlanError(`An opt-out needs a reason: one of ${OPT_OUT_REASONS.join(', ')}.`);
  }
  if (!text(note)) {
    throw new AiPlanError('An opt-out needs a typed note that says why (--note "...").');
  }
  return [...optOuts.filter((item) => item.id !== id), { id, reason, note: note.trim(), at: now }];
}

export function withoutOptOut(optOuts, id) {
  if (!optOuts.some((item) => item.id === id)) {
    throw new AiPlanError(`${id} is not opted out.`);
  }
  return optOuts.filter((item) => item.id !== id);
}

/** Whether an id can be opted out of: a tool a workstream uses, or a delivery method. */
export function optOutTargets(aiPlan) {
  return new Set([...aiPlan.tools.map((tool) => tool.id), ...aiPlan.methods.map((method) => method.id)]);
}

// ---------------------------------------------------------------------------------------------------------
// What the estimate reads

/**
 * Which columns of the factors each workstream may use: "with methods" needs an applicable delivery method ON,
 * "with opt-in" needs an opt-in tool ON in the workstream, and the saving percentage ("tools") needs any tool or method
 * ON in the workstream. An overhead workstream is served by the whole tool set, so it needs any tool ON.
 * A workstream the AI plan does not mention gets nothing.
 * @param {object} aiPlan
 * @param {Array<string | { id: string, kind?: string }>} workstreams ids, or the rows when overheads are among them
 * @returns {Map<string, { methods: boolean, optIn: boolean, tools: boolean }>}
 */
export function eligibilityOf(aiPlan, workstreams) {
  const map = new Map();
  const anyToolOn = aiPlan.tools.some((tool) => tool.status === 'on');
  for (const workstream of workstreams) {
    const id = typeof workstream === 'string' ? workstream : workstream.id;
    // Running the project is helped by any tool the project uses, so overhead asks whether the
    // AI plan has anything ON at all rather than anything mapped to it.
    const isOverhead = typeof workstream !== 'string' && workstream.kind === 'overhead';
    const covered = aiPlan.methods.some((method) => method.status === 'on' && method.workstreams.indexOf(id) !== -1)
      || aiPlan.tools.some((tool) => tool.status === 'on' && tool.workstreams.indexOf(id) !== -1);
    map.set(id, { tools: isOverhead ? anyToolOn : covered });
  }
  return map;
}

// ---------------------------------------------------------------------------------------------------------
// Validate

/**
 * Field-path errors for the `aiPlan` section. `null` or absent (not built yet) is valid.
 * @returns {string[]}
 */
export function validateAiPlan(plan) {
  const aiPlan = plan.aiPlan;
  if (aiPlan === undefined || aiPlan === null) {
    return [];
  }
  const errors = [];
  if (!isObject(aiPlan)) {
    return ['aiPlan: expected an object or null'];
  }
  if (!text(aiPlan.platform) || !text(aiPlan.builtAt) || Number.isNaN(Date.parse(aiPlan.builtAt))) {
    errors.push('aiPlan: expected platform and builtAt');
  }
  for (const key of ['methods', 'tools', 'optOuts', 'requirements', 'unusedTools', 'readiness']) {
    if (!Array.isArray(aiPlan[key])) {
      errors.push(`aiPlan.${key}: expected an array`);
    }
  }
  if (errors.length > 0) {
    return errors;
  }
  if (isObject(plan.estimateBasis) && plan.estimateBasis.platform !== aiPlan.platform) {
    errors.push(`aiPlan.platform: "${aiPlan.platform}" is not the platform of the estimate ("${plan.estimateBasis.platform}"); run ai-plan again`);
  }

  const methodIds = new Set();
  aiPlan.methods.forEach((method, index) => {
    const where = `aiPlan.methods[${index}]`;
    if (!isObject(method) || !text(method.id) || TOOL_STATUSES.indexOf(method.status) === -1 || !Array.isArray(method.workstreams) || !Array.isArray(method.tools)) {
      errors.push(`${where}: expected id, status (on or off), workstreams and tools`);
      return;
    }
    if (methodIds.has(method.id)) {
      errors.push(`${where}.id: ${method.id} is used twice`);
    }
    methodIds.add(method.id);
  });
  const optedOut = new Map();
  aiPlan.optOuts.forEach((item, index) => {
    const where = `aiPlan.optOuts[${index}]`;
    if (!isObject(item) || !text(item.id)) {
      errors.push(`${where}: expected an id`);
      return;
    }
    if (optedOut.has(item.id)) {
      errors.push(`${where}.id: ${item.id} is opted out twice`);
    }
    optedOut.set(item.id, item);
    if (OPT_OUT_REASONS.indexOf(item.reason) === -1) {
      errors.push(`${where}.reason: expected one of ${OPT_OUT_REASONS.join(', ')}`);
    }
    if (!text(item.note)) {
      errors.push(`${where}.note: an opt-out carries the typed reason`);
    }
    if (!text(item.at) || Number.isNaN(Date.parse(item.at))) {
      errors.push(`${where}.at: expected an ISO time`);
    }
    if (item.kind !== (methodIds.has(item.id) ? 'method' : 'tool')) {
      errors.push(`${where}.kind: ${item.id} is a ${methodIds.has(item.id) ? 'method' : 'tool'}`);
    }
  });
  const methodStatus = new Map(aiPlan.methods.filter(isObject).map((method) => [method.id, method.status]));
  for (const method of aiPlan.methods.filter(isObject)) {
    if (method.status !== (optedOut.has(method.id) ? 'off' : 'on')) {
      errors.push(`aiPlan.methods: ${method.id} is ${method.status} but ${optedOut.has(method.id) ? 'is opted out' : 'is not opted out'}`);
    }
  }
  const toolIds = new Set();
  aiPlan.tools.forEach((tool, index) => {
    const where = `aiPlan.tools[${index}]`;
    if (!isObject(tool) || !text(tool.id) || TOOL_STATUSES.indexOf(tool.status) === -1 || !Array.isArray(tool.workstreams) || !Array.isArray(tool.methods) || typeof tool.optIn !== 'boolean') {
      errors.push(`${where}: expected id, status (on or off), optIn, workstreams and methods`);
      return;
    }
    if (toolIds.has(tool.id)) {
      errors.push(`${where}.id: ${tool.id} is used twice`);
    }
    toolIds.add(tool.id);
    const expected = !optedOut.has(tool.id) && (tool.methods.length === 0 || tool.methods.some((id) => methodStatus.get(id) === 'on')) ? 'on' : 'off';
    if (tool.status !== expected) {
      errors.push(`${where}.status: ${tool.id} is ${tool.status} but should be ${expected} (opt-outs and its delivery methods decide)`);
    }
  });
  for (const id of optedOut.keys()) {
    if (!methodIds.has(id) && !toolIds.has(id)) {
      errors.push(`aiPlan.optOuts: ${id} is not a tool or method of this AI plan`);
    }
  }

  const liveIds = new Set((Array.isArray(plan.requirements) ? plan.requirements : []).map((row) => row.id));
  const toolStatus = new Map(aiPlan.tools.filter(isObject).map((tool) => [tool.id, tool.status]));
  const seen = new Set();
  aiPlan.requirements.forEach((entry, index) => {
    const where = `aiPlan.requirements[${index}]`;
    if (!isObject(entry) || !liveIds.has(entry.requirementId)) {
      errors.push(`${where}.requirementId: expected a requirement of this file`);
      return;
    }
    if (seen.has(entry.requirementId)) {
      errors.push(`${where}.requirementId: ${entry.requirementId} is listed twice`);
    }
    seen.add(entry.requirementId);
    const tools = Array.isArray(entry.tools) ? entry.tools : undefined;
    const methods = Array.isArray(entry.methods) ? entry.methods : undefined;
    if (!tools || !methods) {
      errors.push(`${where}: expected tools and methods arrays`);
      return;
    }
    if (tools.some((id) => toolStatus.get(id) !== 'on') || methods.some((id) => methodStatus.get(id) !== 'on')) {
      errors.push(`${where}: lists a tool or method that is not ON in this AI plan`);
    }
    if (tools.length === 0 && methods.length === 0 && !text(entry.reason)) {
      errors.push(`${where}: ${entry.requirementId} has neither a tool nor a reason`);
    }
  });

  // Hours must not claim a saving from a tool that is off.
  const eligibility = eligibilityOf(aiPlan, Array.isArray(plan.workstreams) ? plan.workstreams : []);
  (Array.isArray(plan.workstreams) ? plan.workstreams : []).forEach((row, index) => {
    // The rate itself says whether a saving was claimed, so this checks the number rather than
    // a label about the number: AI-assisted below traditional means a tool was counted on.
    const rates = isObject(row) ? row.hoursPerUnit : undefined;
    const claimed = isObject(rates) && rates.aiAssisted < rates.traditional;
    if (claimed && !eligibility.get(row.id).tools) {
      errors.push(`workstreams[${index}].hoursPerUnit: ${row.id} claims an AI saving, but no tool for it is ON in this AI plan; run estimate again`);
    }
  });
  return errors;
}

/** Where the AI plan no longer matches the plan: warnings, never errors. */
export function staleAiPlan(plan) {
  if (!isObject(plan.aiPlan) || !Array.isArray(plan.aiPlan.requirements)) {
    return [];
  }
  const covered = new Set(plan.aiPlan.requirements.map((entry) => entry.requirementId));
  const missing = (Array.isArray(plan.requirements) ? plan.requirements : [])
    .filter((row) => reviewOf(row) !== 'dismissed' && !covered.has(row.id))
    .map((row) => row.id);
  return missing.length === 0 ? [] : [`${missing.join(', ')} ${missing.length === 1 ? 'has' : 'have'} no tool or reason in the AI plan yet.`];
}

// ---------------------------------------------------------------------------------------------------------
// Report

export function totalsOf(plan) {
  const aiPlan = plan.aiPlan;
  return {
    platform: aiPlan.platform,
    inventory: aiPlan.inventory,
    methodsOn: aiPlan.methods.filter((method) => method.status === 'on').length,
    methodsOff: aiPlan.methods.filter((method) => method.status === 'off').length,
    optOuts: aiPlan.optOuts.length,
    requirementsWithoutTool: aiPlan.requirements.filter((entry) => entry.tools.length === 0 && entry.methods.length === 0).length,
    readiness: aiPlan.readiness.length
  };
}

/** The AI plan as the estimator reads it: what is on, what is opted out, what must be ready, what is unused. */
export function formatAiReport(plan) {
  const aiPlan = plan.aiPlan;
  const totals = totalsOf(plan);
  const lines = [
    '# AI plan',
    '',
    `Platform ${aiPlan.platform}. Every tool the catalogs offer is assumed in use: ${totals.inventory.on} of the ${totals.inventory.used} tools that a workstream uses are ON, ` +
      `${totals.methodsOn} of ${totals.methodsOn + totals.methodsOff} delivery methods are ON, ${totals.optOuts} opt-out${totals.optOuts === 1 ? '' : 's'}.`
  ];
  const workstreams = Array.isArray(plan.workstreams) ? plan.workstreams.filter((row) => row.kind === 'delivery') : [];
  const traditional = workstreams.reduce((sum, row) => sum + row.traditionalHours, 0);
  const ai = workstreams.reduce((sum, row) => sum + row.aiAssistedHours, 0);
  lines.push(`Delivery workstreams: ${Math.round(traditional * 100) / 100} h traditional, ${Math.round(ai * 100) / 100} h AI-assisted.`);

  lines.push('', '## Opt-outs', '');
  if (aiPlan.optOuts.length === 0) {
    lines.push('None. Opting out needs a reason and a typed note, and the hours it supported go back to traditional.');
  }
  for (const item of aiPlan.optOuts) {
    lines.push(`- ${item.id} (${item.kind}): ${item.reason}. ${item.note}`);
  }

  lines.push('', '## What must be ready', '');
  for (const item of aiPlan.readiness) {
    lines.push(`- ${item.item}: ${item.needs} (${item.tools} tool${item.tools === 1 ? '' : 's'}; ${item.workstreams.join(', ')})`);
  }

  const withoutTool = aiPlan.requirements.filter((entry) => entry.tools.length === 0 && entry.methods.length === 0);
  lines.push('', '## Requirements with no tool', '');
  if (withoutTool.length === 0) {
    lines.push('Every requirement has a tool or method.');
  }
  for (const entry of withoutTool) {
    lines.push(`- ${entry.requirementId} (${entry.workstream}): ${entry.reason}`);
  }

  lines.push('', `## Tools no workstream uses (${aiPlan.unusedTools.length})`, '', 'The catalogs offer these on the platform, but the estimating catalog maps them to no workstream. That is a gap in its mappings, not a decision.', '');
  const prefix = (id) => (id.includes(':') ? id.split(':')[0] : id.startsWith('cmk-') ? 'cmk' : id.split('-').slice(0, 2).join('-'));
  const groups = new Map();
  for (const id of aiPlan.unusedTools) {
    groups.set(prefix(id), [...(groups.get(prefix(id)) || []), id]);
  }
  for (const [group, ids] of Array.from(groups.entries()).sort(([a], [b]) => a.localeCompare(b))) {
    lines.push(`- ${group} (${ids.length}): ${ids.join(', ')}`);
  }
  return `${lines.join('\n')}\n`;
}
