#!/usr/bin/env node
/**
 * Writes `.blueprint/design-sketch.json`: the sizing drivers the design sketch step proposes, each one
 * checked against the parsed source blocks. Nothing is written that the documents do not support.
 *
 * A driver is one count for one work package (pages to migrate, locales to launch, sites, content types,
 * integrations). It must show where the number comes from, in one of three ways:
 *   stated   a `quote` copied from a cited block that contains the number (digits or a word up to twenty)
 *   counted  `items`, a list of named things, each found in a cited block; the quantity is how many
 *   summed   `parts`, each a stated figure with its own quote; the quantity is their sum
 * A quantity that none of these backs is rejected, with the reason, so the model fixes it or leaves it out.
 * No hours, weeks or dates are written, and a quantity is never rounded, averaged or guessed.
 *
 * The file is a proposal beside the Blueprint. The app does not read it yet (structured sizing drivers,
 * SPMVP-048); the estimator reads it, and `tools/eval/backtest.mjs --sketch` scores it against a past
 * estimate. With `--blueprint` the summary shows, per package, the quantity Build would take from the
 * requirement text next to the sketch's.
 *
 * Usage:
 *   node tools/blueprint/assemble-drivers.mjs --input <model.json> --blocks <blocks.json> --out <design-sketch.json>
 *        [--blueprint <Project>_Blueprint.json] [--estimating <estimating-catalog.md>]
 *   node tools/blueprint/assemble-drivers.mjs --check <design-sketch.json> --blocks <blocks.json> [--estimating <file>]
 * Exit 0 on success (rejected drivers are listed, they do not fail the run). Exit 1 when a file cannot be read or
 * has the wrong shape, or `--check` finds an error. Exit 2 on bad usage. Exit 3 when --out already holds
 * a sketch with review decisions (nothing is written). Exit 4 when no driver is valid (nothing is written).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractedQuantities } from './driver-quantity.mjs';
import { containsSequence } from './match-library.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';

export const SKETCH_SCHEMA_VERSION = '1';
export const DESIGN_SKILLS = [
  'cmk-model-content',
  'cmk-multisite-design',
  'cmk-localization-design',
  'cmk-migration-assess',
  'cmk-search-design',
  'cmk-headless-design'
];
export const CONFIDENCE = ['low', 'medium', 'high'];
export const BASES = ['stated', 'counted', 'summed'];

const NOTE_MAX = 400;
const NUMBER_WORDS = new Map(
  ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty'].map(
    (word, index) => [word, index + 1]
  )
);
const USAGE =
  'Usage: node tools/blueprint/assemble-drivers.mjs --input <model.json> --blocks <blocks.json> --out <design-sketch.json> [--blueprint <Blueprint.json>] [--estimating <file>]\n' +
  '       node tools/blueprint/assemble-drivers.mjs --check <design-sketch.json> --blocks <blocks.json> [--estimating <file>]';

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function normalize(text) {
  return String(text ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
}

/**
 * Every number in the text: digit runs and the number words one to twenty. A comma is a thousands separator
 * only in the usual grouping ("6,400"); "1,2,3" is three numbers. A number glued to a letter ("Q4", "H2") is
 * a label, not a count, and "one" in "one-time" is not a count either.
 */
export function numbersIn(text) {
  const found = new Set();
  for (const match of String(text ?? '').matchAll(/(?<![A-Za-z])(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?/g)) {
    const parsed = Number(match[0].replace(/,/g, ''));
    if (Number.isFinite(parsed)) {
      found.add(parsed);
    }
  }
  for (const match of normalize(text).matchAll(/(?<![a-z]-)\b([a-z]+)\b(?!-[a-z])/g)) {
    if (NUMBER_WORDS.has(match[1])) {
      found.add(NUMBER_WORDS.get(match[1]));
    }
  }
  return found;
}

/** The words of a text: lower case letters and digits, no punctuation. */
export function phraseWords(text) {
  return String(text ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().split(' ').filter((word) => word !== '');
}

/** True when `phrase` is in `blockText` as whole words, in order. "en" is not in "english"; "12" is not in "2012". */
export function containsPhrase(blockText, phrase) {
  return containsSequence(phraseWords(blockText), phraseWords(phrase));
}

export const QUOTE_MAX = 300;

/**
 * Why a quote is too weak to back a figure, or undefined when it is fine. A quote is the words around the
 * figure: it has at least `minWords` words, not only numbers, and is not the whole block.
 */
export function weakQuote(quote, minWords) {
  const words = phraseWords(quote);
  if (words.length < minWords || words.every((word) => /^\d+$/.test(word))) {
    return `expected the words copied from the block (at least ${minWords} words, not the number alone)`;
  }
  if (String(quote).trim().length > QUOTE_MAX) {
    return `expected only the part of the block that makes the point (up to ${QUOTE_MAX} characters)`;
  }
  return undefined;
}

function isCount(value) {
  return Number.isInteger(value) && value > 0;
}

/** Errors for one driver. `context` holds the blocks by id (normalized text) and the catalog packages. */
export function checkDriver(driver, context) {
  const errors = [];
  if (!isObject(driver)) {
    return ['expected an object'];
  }
  const pack = typeof driver.workPackageId === 'string' ? context.workPackages.get(driver.workPackageId) : undefined;
  if (!pack) {
    errors.push(`workPackageId: "${driver.workPackageId}" is not an activity in the estimating catalog`);
  } else if (driver.unit !== undefined && driver.unit !== pack.unit) {
    errors.push(`unit: ${driver.workPackageId} is sized in ${pack.unit}s, not "${driver.unit}"`);
  }
  if (!isCount(driver.quantity)) {
    errors.push('quantity: expected a whole number above zero');
  }
  if (CONFIDENCE.indexOf(driver.confidence) === -1) {
    errors.push(`confidence: expected one of ${CONFIDENCE.join(', ')}`);
  }
  if (driver.designSkill !== undefined && DESIGN_SKILLS.indexOf(driver.designSkill) === -1) {
    errors.push(`designSkill: expected one of ${DESIGN_SKILLS.join(', ')}`);
  }
  if (driver.note !== undefined && (typeof driver.note !== 'string' || driver.note.trim() === '' || driver.note.length > NOTE_MAX)) {
    errors.push(`note: expected text of up to ${NOTE_MAX} characters`);
  }

  const blockIds = Array.isArray(driver.blockIds) ? driver.blockIds : [];
  if (blockIds.length === 0 || blockIds.some((id) => typeof id !== 'string')) {
    errors.push('blockIds: expected at least one block id');
  }
  const texts = [];
  for (const id of blockIds) {
    if (typeof id === 'string' && !context.blocks.has(id)) {
      errors.push(`blockIds: "${id}" is not in the blocks file`);
    } else if (typeof id === 'string') {
      texts.push(context.blocks.get(id));
    }
  }
  const inCitedBlocks = (text) => phraseWords(text).length > 0 && texts.some((block) => containsPhrase(block, text));

  // A stated figure: the quote is in a cited block as whole words, is more than the bare number, and holds the number.
  const checkStated = (where, quote, quantity) => {
    if (typeof quote !== 'string' || quote.trim() === '') {
      errors.push(`${where}: expected the words copied from the cited block`);
    } else if (weakQuote(quote, 2)) {
      errors.push(`${where}: ${weakQuote(quote, 2)}`);
    } else if (!inCitedBlocks(quote)) {
      errors.push(`${where}: this text is not in the cited blocks`);
    } else if (!numbersIn(quote).has(quantity)) {
      errors.push(`${where}: the quote does not contain ${quantity}`);
    }
  };

  if (BASES.indexOf(driver.basis) === -1) {
    errors.push(`basis: expected one of ${BASES.join(', ')}`);
  } else if (driver.basis === 'stated') {
    checkStated('quote', driver.quote, driver.quantity);
  } else if (driver.basis === 'counted') {
    const items = Array.isArray(driver.items) ? driver.items : [];
    if (items.length === 0 || items.some((item) => typeof item !== 'string' || item.trim() === '')) {
      errors.push('items: expected the names of the things counted');
    } else {
      const names = items.map(normalize);
      if (new Set(names).size !== names.length) {
        errors.push('items: a name is listed twice');
      }
      items.forEach((item, index) => {
        if (!inCitedBlocks(item)) {
          errors.push(`items[${index}]: "${item}" is not in the cited blocks`);
        }
      });
      if (isCount(driver.quantity) && new Set(names).size === names.length && names.length !== driver.quantity) {
        errors.push(`quantity: ${driver.quantity} does not match the ${names.length} items listed`);
      }
    }
  } else {
    const parts = Array.isArray(driver.parts) ? driver.parts : [];
    if (parts.length < 2) {
      errors.push('parts: a summed driver needs at least two parts');
    } else {
      let sum = 0;
      parts.forEach((part, index) => {
        if (!isObject(part) || typeof part.label !== 'string' || part.label.trim() === '' || !isCount(part.quantity)) {
          errors.push(`parts[${index}]: expected a label and a whole number above zero`);
          return;
        }
        sum += part.quantity;
        checkStated(`parts[${index}].quote`, part.quote, part.quantity);
      });
      if (isCount(driver.quantity) && sum !== driver.quantity) {
        errors.push(`quantity: ${driver.quantity} is not the sum of the parts (${sum})`);
      }
    }
  }
  return errors;
}

function blockIndex(blocks) {
  return new Map(blocks.filter((block) => isObject(block) && typeof block.id === 'string').map((block) => [block.id, normalize(block.text)]));
}

/**
 * Checks the model's drivers and builds the file. A package may have one driver: a second is rejected, and the
 * disagreement belongs in the first one's note.
 */
export function assembleDrivers(model, blocks, workPackages) {
  const context = { blocks: blockIndex(blocks), workPackages };
  const byId = new Map(blocks.filter((block) => isObject(block) && typeof block.id === 'string').map((block) => [block.id, block]));
  const drivers = [];
  const rejected = [];
  const taken = new Set();
  const input = Array.isArray(model.drivers) ? model.drivers : [];
  input.forEach((driver, index) => {
    const errors = checkDriver(driver, context);
    if (errors.length === 0 && taken.has(driver.workPackageId)) {
      errors.push(`workPackageId: ${driver.workPackageId} already has a driver; record the disagreement in its note`);
    }
    if (errors.length > 0) {
      rejected.push({ index, workPackageId: isObject(driver) ? driver.workPackageId : undefined, errors });
      return;
    }
    taken.add(driver.workPackageId);
    const written = {
      id: `D-${String(drivers.length + 1).padStart(3, '0')}`,
      workPackageId: driver.workPackageId,
      unit: workPackages.get(driver.workPackageId).unit,
      quantity: driver.quantity,
      basis: driver.basis,
      ...(driver.basis === 'stated' ? { quote: driver.quote.trim() } : {}),
      ...(driver.basis === 'counted' ? { items: driver.items.map((item) => item.trim()) } : {}),
      ...(driver.basis === 'summed' ? { parts: driver.parts.map((part) => ({ label: part.label.trim(), quantity: part.quantity, quote: part.quote.trim() })) } : {}),
      blockIds: driver.blockIds.slice(),
      sources: driver.blockIds.map((id) => {
        const block = byId.get(id);
        return { blockId: id, ...(block && block.label ? { label: block.label } : {}), ...(block && block.fileName ? { fileName: block.fileName } : {}) };
      }),
      confidence: driver.confidence,
      ...(driver.designSkill ? { designSkill: driver.designSkill } : {}),
      ...(driver.note ? { note: driver.note.trim() } : {}),
      review: { status: 'pending' }
    };
    drivers.push(written);
  });
  return { sketch: { schemaVersion: SKETCH_SCHEMA_VERSION, producedBy: 'skill', drivers }, rejected };
}

/** Errors for a sketch file already on disk: the same rules, plus ids and review state. */
export function checkSketch(sketch, blocks, workPackages) {
  const errors = [];
  if (!isObject(sketch)) {
    return ['(root): expected an object'];
  }
  if (sketch.schemaVersion !== SKETCH_SCHEMA_VERSION) {
    errors.push(`schemaVersion: expected "${SKETCH_SCHEMA_VERSION}"`);
  }
  if (!Array.isArray(sketch.drivers)) {
    return [...errors, 'drivers: expected an array'];
  }
  const context = { blocks: blockIndex(blocks), workPackages };
  const ids = new Set();
  const packages = new Set();
  sketch.drivers.forEach((driver, index) => {
    const where = `drivers[${index}]`;
    checkDriver(driver, context).forEach((message) => errors.push(`${where}.${message}`));
    if (!isObject(driver)) {
      return;
    }
    if (driver.unit === undefined) {
      errors.push(`${where}.unit: expected the unit of the work package (a written sketch always has it)`);
    }
    if (typeof driver.id !== 'string' || !/^D-\d{3}$/.test(driver.id)) {
      errors.push(`${where}.id: expected an id such as D-001`);
    } else if (ids.has(driver.id)) {
      errors.push(`${where}.id: ${driver.id} is used twice`);
    } else {
      ids.add(driver.id);
    }
    if (packages.has(driver.workPackageId)) {
      errors.push(`${where}.workPackageId: ${driver.workPackageId} has two drivers`);
    }
    packages.add(driver.workPackageId);
    if (!isObject(driver.review) || ['pending', 'accepted', 'edited', 'dismissed'].indexOf(driver.review.status) === -1) {
      errors.push(`${where}.review.status: expected pending, accepted, edited or dismissed`);
    }
  });
  return errors;
}

/** Per driver, the sketch quantity beside what Build would take from the requirement text. */
export function compareWithRequirements(sketch, blueprint) {
  const fromText = extractedQuantities(blueprint.requirements);
  return sketch.drivers.map((driver) => ({
    workPackageId: driver.workPackageId,
    unit: driver.unit,
    sketch: driver.quantity,
    fromRequirements: fromText[driver.workPackageId] === undefined ? null : fromText[driver.workPackageId]
  }));
}

function hasReviewDecisions(existing) {
  return isObject(existing) && Array.isArray(existing.drivers) && existing.drivers.some((driver) => isObject(driver) && isObject(driver.review) && driver.review.status !== 'pending');
}

function readJson(file, label) {
  const abs = path.resolve(file);
  let raw;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`Cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.error(`(${label}): invalid JSON (${error.message})`);
    process.exit(1);
  }
}

function parseArgs(args) {
  const names = ['input', 'blocks', 'out', 'blueprint', 'estimating', 'check'];
  const parsed = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    const name = arg.slice(2);
    const next = args[index + 1];
    if (!arg.startsWith('--') || names.indexOf(name) === -1 || next === undefined || next === '' || next.startsWith('--') || parsed[name] !== undefined) {
      return undefined;
    }
    parsed[name] = next;
    index += 1;
  }
  if (!parsed.blocks) {
    return undefined;
  }
  if (parsed.check !== undefined) {
    return parsed.input || parsed.out || parsed.blueprint ? undefined : parsed;
  }
  return parsed.input && parsed.out ? parsed : undefined;
}

function loadWorkPackages(file) {
  const abs = path.resolve(file || DEFAULT_CATALOG);
  let text;
  try {
    text = fs.readFileSync(abs, 'utf8');
  } catch (error) {
    console.error(`Cannot read ${abs}: ${error.message}`);
    process.exit(1);
  }
  const workPackages = parseActivities(text);
  if (workPackages.size === 0) {
    console.error('The estimating catalog has no Activities table');
    process.exit(1);
  }
  return workPackages;
}

function main(argv) {
  const parsed = parseArgs(argv.slice(2));
  if (!parsed) {
    console.error(USAGE);
    process.exit(2);
  }
  const blocks = readJson(parsed.blocks, 'blocks');
  if (!Array.isArray(blocks)) {
    console.error('(blocks): expected an array of blocks');
    process.exit(1);
  }
  const workPackages = loadWorkPackages(parsed.estimating);

  if (parsed.check !== undefined) {
    const errors = checkSketch(readJson(parsed.check, 'design sketch'), blocks, workPackages);
    errors.forEach((message) => console.error(`(design sketch) ${message}`));
    process.exit(errors.length ? 1 : 0);
  }

  const model = readJson(parsed.input, 'input');
  if (!isObject(model) || !Array.isArray(model.drivers)) {
    console.error('(input): expected an object with a drivers array');
    process.exit(1);
  }
  let blueprint;
  if (parsed.blueprint !== undefined) {
    blueprint = readJson(parsed.blueprint, 'blueprint');
    if (!isObject(blueprint) || !Array.isArray(blueprint.requirements)) {
      console.error('(blueprint): expected an object with a requirements array');
      process.exit(1);
    }
  }
  const out = path.resolve(parsed.out);
  if (fs.existsSync(out)) {
    let existing;
    try {
      existing = JSON.parse(fs.readFileSync(out, 'utf8'));
    } catch (error) {
      console.error(`${out} exists and cannot be read as JSON (${error.message}); nothing was written`);
      process.exit(3);
    }
    if (hasReviewDecisions(existing)) {
      console.error(`${out} holds review decisions; nothing was written`);
      process.exit(3);
    }
  }
  const { sketch, rejected } = assembleDrivers(model, blocks, workPackages);
  if (sketch.drivers.length === 0) {
    console.error(`No valid driver: ${rejected.length} rejected. Nothing was written.`);
    process.stderr.write(`${JSON.stringify({ rejected }, null, 2)}\n`);
    process.exit(4);
  }
  writeFileAtomic(out, `${JSON.stringify(sketch, null, 2)}\n`);
  const summary = {
    out,
    drivers: sketch.drivers.length,
    rejected,
    ...(blueprint ? { comparison: compareWithRequirements(sketch, blueprint) } : {})
  };
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main(process.argv);
}
