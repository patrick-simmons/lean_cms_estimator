/**
 * The suppression file written by review-stats.mjs and read by the proposing tools (match-library,
 * gap-sweep, lever-advice) through `--suppress <file>`.
 *
 * It lists what the team keeps dismissing across projects, so the agent stops proposing it. It holds keys
 * only (a library id, or the `source` marker a tool puts on its items), never client text. A tool treats a
 * suppressed key like an item already in the Context sidecar: it is not proposed, so the estimator is not
 * asked again. The estimator can still add the item by hand, and deleting the file brings everything back.
 */
import fs from 'node:fs';
import path from 'node:path';

export const SUPPRESS_SCHEMA_VERSION = '1';
/** Families a proposing tool can honour. `library` keys are library ids; the others are `source` markers. */
export const SUPPRESS_FAMILIES = ['library', 'gap-sweep', 'lever-advice'];

/**
 * What a key of each family looks like. A key under the wrong family would never match anything, and a
 * typo there would silently stop nothing; the shape check says so instead. Library ids have no fixed shape.
 */
const KEY_SHAPE = {
  'gap-sweep': /^Gap sweep checklist [a-z][a-z0-9-]*$/,
  'lever-advice': /^Lever advice \S+$/
};
const KEY_EXAMPLE = { 'gap-sweep': 'Gap sweep checklist integrations', 'lever-advice': 'Lever advice <lever id>' };

function isObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** Field-path errors for a suppression file; empty means it can be used. */
export function validateSuppress(data) {
  const errors = [];
  if (!isObject(data)) {
    return ['(root): expected an object'];
  }
  if (data.schemaVersion !== SUPPRESS_SCHEMA_VERSION) {
    errors.push(`schemaVersion: expected "${SUPPRESS_SCHEMA_VERSION}"`);
  }
  if (!Array.isArray(data.items)) {
    errors.push('items: expected an array');
    return errors;
  }
  data.items.forEach((item, index) => {
    const where = `items[${index}]`;
    if (!isObject(item)) {
      errors.push(`${where}: expected an object`);
      return;
    }
    if (typeof item.key !== 'string' || item.key.trim() === '') {
      errors.push(`${where}.key: expected non-empty text`);
    }
    if (SUPPRESS_FAMILIES.indexOf(item.family) === -1) {
      errors.push(`${where}.family: expected one of ${SUPPRESS_FAMILIES.join(', ')}`);
    } else if (typeof item.key === 'string' && item.key.trim() !== '' && KEY_SHAPE[item.family] && !KEY_SHAPE[item.family].test(item.key.trim())) {
      errors.push(`${where}.key: a ${item.family} key looks like "${KEY_EXAMPLE[item.family]}"`);
    }
  });
  return errors;
}

/** Library ids to leave out. */
export function suppressedLibraryIds(data) {
  return data.items.filter((item) => item.family === 'library').map((item) => item.key);
}

/** `source` markers to treat as already proposed, for one family. */
export function suppressedSources(data, family) {
  return data.items.filter((item) => item.family === family).map((item) => item.key);
}

/**
 * Reads and validates a suppression file.
 * @throws {Error} when the file cannot be read, is not JSON, or has the wrong shape; the message holds every reason, one per line
 */
export function readSuppressFile(file) {
  const abs = path.resolve(file);
  let data;
  try {
    data = JSON.parse(fs.readFileSync(abs, 'utf8'));
  } catch (error) {
    throw new Error(`(suppress) cannot read ${abs}: ${error.message}`);
  }
  const errors = validateSuppress(data);
  if (errors.length) {
    throw new Error(errors.map((message) => `(suppress) ${message}`).join('\n'));
  }
  return data;
}
