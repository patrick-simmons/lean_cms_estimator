// Write a file so a crash, kill or sync client never sees half of it.
// The data goes to a temporary file in the same folder, then replaces the target
// with a rename. Zero dependencies, so it ships in the skill pack unbundled.
import { mkdirSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';

const RETRIES = 5;

function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

/** Replace `path` with `data` in one step. Creates the folder when missing. */
export function writeFileAtomic(path, data) {
  const dir = dirname(path);
  mkdirSync(dir, { recursive: true });
  const temp = join(dir, `.${basename(path)}.${process.pid}.tmp`);
  try {
    writeFileSync(temp, data);
    for (let attempt = 1; ; attempt += 1) {
      try {
        renameSync(temp, path);
        return;
      } catch (error) {
        // Windows reports EPERM/EBUSY when a sync client or virus scanner briefly holds the target.
        const transient = error && (error.code === 'EPERM' || error.code === 'EBUSY' || error.code === 'EACCES');
        if (!transient || attempt >= RETRIES) throw error;
        sleepSync(50 * attempt);
      }
    }
  } finally {
    rmSync(temp, { force: true });
  }
}
