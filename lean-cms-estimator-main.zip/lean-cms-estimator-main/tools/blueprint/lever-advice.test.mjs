import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { adviseLevers, formatMarkdown, leverSource, parseLevers, validateEvidence, DEFAULT_DATA } from './lever-advice.mjs';
import { validateContextValue } from './validate-context.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'lever-advice.mjs');
const catalogMd = fs.readFileSync(path.join(root, 'docs', 'catalogs', 'estimating-catalog.md'), 'utf8');
const evidence = JSON.parse(fs.readFileSync(DEFAULT_DATA, 'utf8'));
const levers = parseLevers(catalogMd);

function block(id, text, label) {
  return { id, text, label: label || id };
}

function blueprint(platformId, requirements = []) {
  return { platform: { id: platformId, name: platformId }, requirements };
}

function advise(platformId, blocks, requirements, existingSources) {
  return adviseLevers({ blueprint: blueprint(platformId, requirements), blocks, levers, evidence, existingSources });
}

test('the catalog parse finds opt-in assets per platform and the delivery methods', () => {
  const pageImport = levers.optIn.get('aem-eds-page-import');
  assert.deepEqual(Array.from(pageImport.platforms.keys()), ['aem-eds']);
  assert.deepEqual(Array.from(pageImport.platforms.get('aem-eds')), ['content-migration']);
  assert.ok(levers.optIn.has('aem-cloud-migration'));
  assert.equal(levers.optIn.has('cmk-audit'), false, 'an asset without the opt-in mark is not a lever');
  assert.equal(levers.methods.get('cdk-loop').isDefault, true);
  assert.equal(levers.methods.get('pdk-product').isDefault, false);
  assert.ok(levers.methods.get('pdk-product').workPackageIds.includes('discovery-audit'));
});

test('the evidence file is valid and names only levers the catalog lists, with no numbers or durations', () => {
  assert.deepEqual(validateEvidence(evidence), []);
  for (const entry of evidence.levers) {
    assert.ok(levers.optIn.has(entry.id) || levers.methods.has(entry.id), `${entry.id} is not a lever in the catalog`);
    assert.doesNotMatch(entry.reason, /\d/);
  }
});

test('validateEvidence names the field that is wrong', () => {
  const errors = validateEvidence({
    schemaVersion: '2',
    levers: [
      { id: 'a', signals: [], reason: 'Saves 3 days' },
      { id: 'a', signals: ['x'], reason: 'ok' }
    ]
  });
  assert.ok(errors.some((message) => message.startsWith('schemaVersion')));
  assert.ok(errors.some((message) => message.startsWith('levers[0].signals')));
  assert.ok(errors.some((message) => message.startsWith('levers[0].reason')));
  assert.ok(errors.some((message) => message.startsWith('levers[1].id') && message.includes('twice')));
});

test('a Figma link advises the Figma asset on Edge Delivery Services, with the block and a quote', () => {
  const result = advise('aem-eds', [
    block('b1', 'Overview\nThe design is in Figma: https://www.figma.com/file/abc/site-design\nAll pages follow it.', 'Brief p.2')
  ], [{ id: 'R-001', workPackage: 'component-build', statement: 'Build the hero block.', coverage: 'accelerated' }]);
  const item = result.advised.find((entry) => entry.id === 'aem-eds-figma-to-content');
  assert.ok(item);
  assert.equal(item.kind, 'optIn');
  assert.deepEqual(item.workPackageIds, ['component-build']);
  assert.deepEqual(item.evidence.blockIds, ['b1']);
  assert.match(item.evidence.quote, /figma\.com/);
  assert.equal(item.hasLiveRequirement, true);
  assert.deepEqual(item.requirementIds, ['R-001']);
  assert.equal(item.assumption.source, leverSource('aem-eds-figma-to-content'));
  assert.deepEqual(item.assumption.review, { status: 'pending' });
  assert.match(item.assumption.statement, /Brief p\.2/);
  assert.deepEqual(result.selection.optIn, ['aem-eds-figma-to-content']);
});

test('the quote is a line of the cited block', () => {
  const text = 'Heading\nSee the Figma file for components.\nTail';
  const item = advise('aem-eds', [block('b1', text)]).advised.find((entry) => entry.id === 'aem-eds-figma-to-content');
  assert.ok(text.includes(item.evidence.quote));
});

test('a lever the catalog offers only on another platform is reported, not advised', () => {
  const result = advise('aem', [block('b1', 'All pages meet WCAG 2.2 AA. The design is in Figma.')]);
  assert.equal(result.advised.some((item) => item.id === 'aem-eds-accessibility-fix'), false);
  assert.equal(result.advised.some((item) => item.id === 'aem-eds-figma-to-content'), false);
  const ids = result.notOffered.map((item) => item.id);
  assert.ok(ids.includes('aem-eds-accessibility-fix'));
  assert.ok(ids.includes('aem-eds-figma-to-content'));
});

test('a stated move from an older AEM installation advises the cloud migration asset on AEM', () => {
  const result = advise('aem', [block('b1', 'The client runs AEM 6.5 on premise and moves to AEM as a Cloud Service.')]);
  const item = result.advised.find((entry) => entry.id === 'aem-cloud-migration');
  assert.ok(item);
  assert.deepEqual(item.workPackageIds, ['environments-devops']);
  assert.equal(item.hasLiveRequirement, false);
  assert.match(formatMarkdown(result), /changes nothing until one exists/);
});

test('a method that is on by default is never advised; one that is not is advised with its prerequisites', () => {
  const result = advise('aem', [block('b1', 'The product owner will write user stories. Acceptance test cases are in the plan.')]);
  assert.equal(result.advised.some((item) => item.id === 'cdk-loop'), false);
  const item = result.advised.find((entry) => entry.id === 'pdk-product');
  assert.ok(item);
  assert.equal(item.kind, 'method');
  assert.match(item.assumption.statement, /Prerequisites:/);
  assert.deepEqual(result.selection.methods, ['pdk-product']);
});

test('a signal that is only part of another word does not match', () => {
  const result = advise('aem', [block('b1', 'The hypercare period is short.'), block('b2', 'Border patrol of the warranted data.')]);
  const hypercare = result.advised.find((item) => item.id === 'ld-bug');
  assert.deepEqual(hypercare.evidence.blockIds, ['b1']);
});

test('no evidence means no advice and no empty assumptions', () => {
  const result = advise('aem-eds', [block('b1', 'Nothing relevant here.')]);
  assert.deepEqual(result.advised, []);
  assert.deepEqual(result.selection, { optIn: [], methods: [] });
  assert.match(formatMarkdown(result), /no reason to enable/);
});

test('a lever already in the sidecar is not advised again, in any review status', () => {
  const blocks = [block('b1', 'The design is in Figma.')];
  const result = advise('aem-eds', blocks, [], [leverSource('aem-eds-figma-to-content')]);
  assert.equal(result.advised.some((item) => item.id === 'aem-eds-figma-to-content'), false);
  assert.deepEqual(result.alreadyProposed, ['aem-eds-figma-to-content']);
});

test('advice never writes hours, durations or a quantity of its own', () => {
  const result = advise('aem-eds', [block('b1', 'Figma designs; migrate the existing site; WCAG 2.2 AA; structured data; Core Web Vitals.')]);
  assert.ok(result.advised.length >= 5);
  for (const item of result.advised) {
    for (const text of [item.reason, item.assumption.ifFails]) {
      // Work package ids such as component-build are the only digits allowed.
      assert.doesNotMatch(text.replace(/WP-\d+/g, ''), /\d|\b(hours?|days?|weeks?|months?)\b/i);
    }
  }
});

test('the command prints JSON, the assumptions pass the Context validator, and --existing makes a re-run add nothing', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lever-advice-'));
  try {
    const blueprintFile = path.join(dir, 'P_Blueprint.json');
    const blocksFile = path.join(dir, 'blocks.json');
    fs.writeFileSync(blueprintFile, JSON.stringify(blueprint('aem-eds', [{ id: 'R-001', workPackage: 'content-migration', statement: 'Migrate the pages.', coverage: 'accelerated' }])));
    fs.writeFileSync(blocksFile, JSON.stringify([block('b1', 'We will migrate the existing site and use the Figma designs.')]));
    const run = (extra = []) => spawnSync(process.execPath, [script, '--blueprint', blueprintFile, '--blocks', blocksFile, ...extra], { encoding: 'utf8' });

    const first = run();
    assert.equal(first.status, 0, first.stderr);
    const result = JSON.parse(first.stdout);
    assert.ok(result.advised.some((item) => item.id === 'aem-eds-page-import'));
    const context = {
      schemaVersion: '2',
      assumptions: result.advised.map((item, index) => ({ id: `AS-${String(index + 1).padStart(3, '0')}`, ...item.assumption, refs: item.requirementIds }))
    };
    assert.deepEqual(validateContextValue(context), []);

    const contextFile = path.join(dir, 'P_Context.json');
    fs.writeFileSync(contextFile, JSON.stringify(context));
    const again = JSON.parse(run(['--existing', contextFile]).stdout);
    assert.deepEqual(again.advised, []);
    assert.ok(again.alreadyProposed.length >= result.advised.length);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('the command exits 2 on bad usage and 1 on a missing file', () => {
  assert.equal(spawnSync(process.execPath, [script], { encoding: 'utf8' }).status, 2);
  assert.equal(spawnSync(process.execPath, [script, '--blueprint', 'nope.json', '--blocks', 'nope.json'], { encoding: 'utf8' }).status, 1);
});

test('the platform id is compared trimmed and in lower case', () => {
  const result = advise(' AEM-EDS ', [block('b1', 'The design is in Figma.')]);
  assert.equal(result.platform, 'aem-eds');
  assert.ok(result.advised.some((item) => item.id === 'aem-eds-figma-to-content'));
});

test('a lever with no signal in the documents is not reported as not offered', () => {
  const result = advise('aem', [block('b1', 'Nothing relevant here.')]);
  assert.deepEqual(result.notOffered, []);
  assert.ok(result.noEvidence.includes('aem-eds-figma-to-content'));
});

test('a suppressed lever is listed apart from one already in the sidecar', () => {
  const blocks = [block('b1', 'The design is in Figma.')];
  const result = adviseLevers({
    blueprint: blueprint('aem-eds'), blocks, levers, evidence,
    existingSources: [], suppressedSources: ['  LEVER ADVICE aem-eds-figma-to-content ']
  });
  assert.deepEqual(result.suppressed, ['aem-eds-figma-to-content']);
  assert.deepEqual(result.alreadyProposed, []);
  assert.equal(result.advised.some((item) => item.id === 'aem-eds-figma-to-content'), false);
});

test('a lever listed as a method on by default and as an opt-in asset is still offered through the asset row', () => {
  const both = {
    optIn: new Map([['dual', { platforms: new Map([['all', new Set(['content-model'])]]) }]]),
    methods: new Map([['dual', { workPackageIds: ['discovery-audit'], prerequisites: '', isDefault: true }]])
  };
  const result = adviseLevers({
    blueprint: blueprint('aem'), blocks: [block('b1', 'dualword here')], levers: both,
    evidence: { levers: [{ id: 'dual', signals: ['dualword'], reason: 'Because.' }] }
  });
  assert.equal(result.advised.length, 1);
  assert.equal(result.advised[0].kind, 'optIn');
  assert.deepEqual(result.advised[0].workPackageIds, ['content-model']);
});

test('the command stops with 1 and the reason on a suppression file that cannot be used', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lever-advice-'));
  try {
    fs.writeFileSync(path.join(dir, 'b.json'), JSON.stringify(blueprint('aem')));
    fs.writeFileSync(path.join(dir, 'blocks.json'), '[]');
    fs.writeFileSync(path.join(dir, 's.json'), JSON.stringify({ schemaVersion: '1', items: [{ key: 'content-model', family: 'gap-sweep' }] }));
    const run = spawnSync(process.execPath, [script, '--blueprint', path.join(dir, 'b.json'), '--blocks', path.join(dir, 'blocks.json'), '--suppress', path.join(dir, 's.json')], { encoding: 'utf8' });
    assert.equal(run.status, 1);
    assert.match(run.stderr, /\(suppress\) items\[0\]\.key/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
