#!/usr/bin/env node
/**
 * The run record: `.blueprint/run.json` in a project folder (SAPP-014).
 *
 * Every agent-side tool writes to it so the app can show which pack produced the files, which stage the
 * run reached and which schema versions it wrote. Each call merges a patch into the existing record;
 * nothing else in the folder is touched. The TypeScript mirror is
 * src/webparts/blueprint/projects/runRecord.ts, and docs/spfx/agent-contract.md is the contract.
 *
 * What persists between calls: `runId`, `startedAt`, the per-stage history, `files`, `parseTool`, `catalog`
 * and `notes`. What does not: `pack` and `schemas` always describe the tool that wrote the record last,
 * so a record never claims an older pack or older schema versions than the one that just ran.
 *
 * `stage` is the furthest stage the current pass reached and does not move backwards, except from `done`
 * (a finished record starts a new pass on any earlier stage) or when `allowRegress` / `--allow-regress` says
 * so. The stage's own entry in `stages` is always refreshed.
 */
import { existsSync, readFileSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { packInfo } from './pack-info.mjs';
import { writeFileAtomic } from './write-file-atomic.mjs';

export const RUN_RECORD_SCHEMA_VERSION = '1';
export const BLUEPRINT_DIR = '.blueprint';
export const RUN_RECORD_FILE = 'run.json';
export const STAGES = ['prepared', 'parse', 'extract', 'enrich', 'validate', 'done'];
export const MODES = ['first-run', 'proposals'];

/** @param {string} folder */
export function runRecordPath(folder) {
  return join(resolve(folder), BLUEPRINT_DIR, RUN_RECORD_FILE);
}

/**
 * @param {string} folder
 * @returns {object|undefined} the record, or undefined when there is none
 * @throws {Error} naming the file when it exists but is not a JSON object
 */
export function readRunRecord(folder) {
  const file = runRecordPath(folder);
  if (!existsSync(file)) {
    return undefined;
  }
  let value;
  try {
    value = JSON.parse(readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Error(`${file} is not valid JSON (${error.message}). Fix or delete it, or pass --reset to start a new record.`);
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`${file}: expected a JSON object. Fix or delete it, or pass --reset to start a new record.`);
  }
  return value;
}

function nextStage(existing, patch, allowRegress) {
  const current = existing?.stage && STAGES.includes(existing.stage) ? existing.stage : undefined;
  if (!patch.stage) {
    return current || 'prepared';
  }
  if (!current) {
    return patch.stage;
  }
  const goesBack = STAGES.indexOf(patch.stage) < STAGES.indexOf(current);
  return goesBack && !allowRegress && current !== 'done' ? current : patch.stage;
}

/**
 * @param {string} folder
 * @param {{ stage?: string, mode?: string, note?: string, pack?: object, catalog?: object, parseTool?: object,
 *   files?: Record<string, object>, reset?: boolean, runId?: string, allowRegress?: boolean }} patch
 * @param {Date} [now]
 */
export function updateRunRecord(folder, patch, now = new Date()) {
  if (patch.stage !== undefined && !STAGES.includes(patch.stage)) {
    throw new Error(`stage must be one of ${STAGES.join(', ')}`);
  }
  if (patch.mode !== undefined && !MODES.includes(patch.mode)) {
    throw new Error(`mode must be one of ${MODES.join(', ')}`);
  }
  const at = now.toISOString();
  const info = packInfo();
  const existing = patch.reset ? undefined : readRunRecord(folder);
  const record = {
    schemaVersion: RUN_RECORD_SCHEMA_VERSION,
    runId: patch.runId || existing?.runId || `run-${at.replace(/[-:.]/g, '').slice(0, 15)}`,
    startedAt: existing?.startedAt || at,
    updatedAt: at,
    stage: nextStage(existing, patch, patch.allowRegress === true),
    mode: patch.mode || existing?.mode || 'first-run',
    pack: {
      name: info.name,
      version: info.version,
      ...(info.commit ? { commit: info.commit } : {}),
      ...(info.builtAt ? { builtAt: info.builtAt } : {}),
      layout: info.layout,
      ...(patch.pack || {})
    },
    schemas: { ...info.schemas },
    parseTool: { ...(existing?.parseTool || {}), ...(patch.parseTool || {}) },
    catalog: { ...(existing?.catalog || {}), ...(patch.catalog || {}) },
    stages: { ...(existing?.stages || {}) },
    files: { ...(existing?.files || {}), ...(patch.files || {}) },
    notes: [...(existing?.notes || [])]
  };
  if (patch.stage) {
    record.stages[patch.stage] = { at, ...(patch.note ? { note: patch.note } : {}) };
  }
  if (patch.note) {
    record.notes.push(`${at} ${patch.stage ? `${patch.stage}: ` : ''}${patch.note}`);
  }
  for (const key of ['parseTool', 'catalog']) {
    if (Object.keys(record[key]).length === 0) {
      delete record[key];
    }
  }
  writeFileAtomic(runRecordPath(folder), `${JSON.stringify(record, null, 2)}\n`);
  return record;
}

export const USAGE = 'Usage: node tools/blueprint/run-record.mjs <project-folder> [--stage prepared|parse|extract|enrich|validate|done] ' +
  '[--mode first-run|proposals] [--note "text"] [--reset] [--allow-regress] [--show]';

const OPTIONS = {
  stage: { type: 'string' },
  mode: { type: 'string' },
  note: { type: 'string' },
  reset: { type: 'boolean' },
  'allow-regress': { type: 'boolean' },
  show: { type: 'boolean' }
};

/**
 * The command line. Returns the exit code: 0 on success, 2 on a bad command line or an unusable record.
 * @param {string[]} argv arguments after the script name
 */
export function main(argv) {
  let parsed;
  try {
    parsed = parseArgs({ args: argv, options: OPTIONS, allowPositionals: true, strict: true });
  } catch (error) {
    console.error(`run-record: ${error.message}`);
    console.error(USAGE);
    return 2;
  }
  const { values, positionals } = parsed;
  if (positionals.length !== 1) {
    console.error(USAGE);
    return 2;
  }
  const folder = positionals[0];
  try {
    if (values.show) {
      const record = readRunRecord(folder);
      process.stdout.write(record ? `${JSON.stringify(record, null, 2)}\n` : 'no run record\n');
      return 0;
    }
    const record = updateRunRecord(folder, {
      stage: values.stage,
      mode: values.mode,
      note: values.note,
      reset: values.reset === true,
      allowRegress: values['allow-regress'] === true
    });
    console.log(`wrote ${runRecordPath(folder)} (stage ${record.stage}, pack ${record.pack.version})`);
    return 0;
  } catch (error) {
    console.error(`run-record: ${error.message}`);
    return 2;
  }
}

/**
 * True only when this file is the script node was started with. Inside an esbuild bundle (parse-local,
 * prepare-folder in the skill pack) `import.meta.url` is the bundle's, so the file name is checked too:
 * a bundle must never run this command line on its own arguments.
 */
function isCliEntry() {
  const entry = process.argv[1];
  return Boolean(entry) && basename(entry) === 'run-record.mjs' && fileURLToPath(import.meta.url) === resolve(entry);
}

if (isCliEntry()) {
  process.exitCode = main(process.argv.slice(2));
}
