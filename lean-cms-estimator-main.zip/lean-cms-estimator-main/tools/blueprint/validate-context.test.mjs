import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { collectContextWarnings, validateContextValue } from './validate-context.mjs';

const root = fileURLToPath(new URL('../..', import.meta.url));
const script = join(root, 'tools', 'blueprint', 'validate-context.mjs');
const scratch = mkdtempSync(join(tmpdir(), 'ctx-val-'));

function run(args) {
  return spawnSync(process.execPath, [script, ...args], { cwd: root, encoding: 'utf8' });
}

after(() => rmSync(scratch, { recursive: true, force: true }));

describe('validate-context', () => {
  it('accepts minimal empty object', () => {
    const result = run(['samples/offline/minimal_Context.json']);
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /OK: minimal_Context\.json/);
  });

  it('accepts Northwind sample', () => {
    const result = run(['samples/offline/Northwind_Context.json']);
    assert.equal(result.status, 0, result.stderr);
  });

  it('fails denylist out-of-scope keys with field path', () => {
    const path = join(scratch, 'deny.json');
    writeFileSync(path, JSON.stringify({ commercialRisks: [] }));
    const result = run([path]);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /commercialRisks/);
  });

  it('fails malformed delivery risk', () => {
    const errors = validateContextValue({
      deliveryRisks: [{ id: 'DR-1' }]
    });
    assert.ok(errors.some((e) => e.includes('deliveryRisks[0].statement')));
  });
});

const USAGE = 'Usage: node tools/blueprint/validate-context.mjs <path-to-context.json> [--blueprint <path-to-blueprint.json>]';
const V2_SAMPLE = 'samples/offline/Northwind_v2_Context.json';

function writeJson(name, value) {
  const file = join(scratch, name);
  writeFileSync(file, JSON.stringify(value));
  return file;
}

function stderrLines(result) {
  return result.stderr.split(/\r?\n/).filter((line) => line !== '');
}

const fixture = JSON.parse(
  readFileSync(join(root, 'tools', 'blueprint', 'fixtures', 'context-validator-cases.json'), 'utf8')
);

describe('validate-context v2 samples', () => {
  it('accepts the v2 sample with no warnings', () => {
    const result = run([V2_SAMPLE]);
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stderr, '');
    assert.match(result.stdout, /OK: Northwind_v2_Context\.json/);
  });

  it('keeps the v1 samples free of warnings', () => {
    for (const file of ['minimal_Context.json', 'Northwind_Context.json']) {
      const result = run([`samples/offline/${file}`]);
      assert.equal(result.status, 0, result.stderr);
      assert.equal(result.stderr, '');
    }
  });

  it('accepts the v2 sample against a Blueprint holding its R- and Q ids', () => {
    const blueprint = writeJson('bp-ok.json', {
      requirements: [{ id: 'R-001' }, { id: 'R-002' }],
      questions: [{ id: 'Q7' }]
    });
    const result = run([V2_SAMPLE, '--blueprint', blueprint]);
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stderr, '');
  });
});

describe('validate-context shared parity fixture', () => {
  it('has unique case names', () => {
    const names = fixture.cases.map((c) => c.name);
    assert.deepEqual(names.filter((n, i) => names.indexOf(n) !== i), []);
    assert.ok(names.length > 40);
  });

  fixture.cases.forEach((c, i) => {
    it(c.name, () => {
      assert.deepEqual(validateContextValue(c.value), c.errors);
      const file = writeJson(`case-${i}.json`, c.value);
      const result = run([file]);
      if (c.errors.length === 0) {
        assert.equal(result.status, 0, result.stderr);
        assert.match(result.stdout, /^OK: /);
        assert.deepEqual(
          stderrLines(result),
          collectContextWarnings(c.value).map((w) => `warning: ${w}`)
        );
      } else {
        assert.equal(result.status, 1);
        assert.deepEqual(stderrLines(result), c.errors);
        assert.ok(!result.stderr.includes('warning:'), 'errors suppress warnings');
      }
    });
  });
});

describe('validate-context warnings', () => {
  const risk = (refs) => ({ deliveryRisks: [{ id: 'DR-001', statement: 's', refs }], meta: { schemaVersion: '2' } });

  it('warns on a dangling sidecar ref, exits 0 and names the path', () => {
    const result = run([writeJson('dangling.json', risk(['DR-009']))]);
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(stderrLines(result), [
      'warning: deliveryRisks[0].refs[0]: reference "DR-009" matches no item in this file'
    ]);
    assert.match(result.stdout, /^OK: /);
  });

  it('matches ids exactly: DR-1 does not match DR-001', () => {
    assert.deepEqual(collectContextWarnings(risk(['DR-1'])), [
      'deliveryRisks[0].refs[0]: reference "DR-1" matches no item in this file'
    ]);
    assert.deepEqual(collectContextWarnings(risk(['DR-001'])), []);
  });

  it('resolves a ref to an item in another list', () => {
    const value = {
      deliveryRisks: [{ id: 'DR-001', statement: 's', refs: ['DP-001', 'AS-001', 'DU-001'] }],
      deliveryUnknowns: [{ id: 'DU-001', statement: 's' }],
      assumptions: [{ id: 'AS-001', statement: 's' }],
      dependencies: [{ id: 'DP-001', statement: 's' }],
      meta: { schemaVersion: '2' }
    };
    assert.deepEqual(collectContextWarnings(value), []);
  });

  it('warns on an unrecognised ref', () => {
    assert.deepEqual(collectContextWarnings(risk(['banana'])), [
      'deliveryRisks[0].refs[0]: unrecognised reference "banana" (expected DR-n, DU-n, AS-n, DP-n, R-n or Qn)'
    ]);
  });

  it('is silent about R- and Q refs without --blueprint', () => {
    const result = run([writeJson('rq.json', risk(['R-099', 'Q99']))]);
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stderr, '');
  });

  it('checks R- and Q refs against the Blueprint when given', () => {
    const value = risk(['R-001', 'R-099', 'Q7', 'Q99']);
    const blueprint = writeJson('bp.json', { requirements: [{ id: 'R-001' }], questions: [{ id: 'Q7' }] });
    const result = run([writeJson('rq-bp.json', value), '--blueprint', blueprint]);
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(stderrLines(result), [
      'warning: deliveryRisks[0].refs[1]: reference "R-099" matches no requirement in the Blueprint file',
      'warning: deliveryRisks[0].refs[3]: reference "Q99" matches no question in the Blueprint file'
    ]);
  });

  it('warns about every R- and Q ref when the Blueprint arrays are empty', () => {
    const blueprint = writeJson('bp-empty.json', { requirements: [], questions: [] });
    const result = run([writeJson('rq-empty.json', risk(['R-001', 'Q1'])), '--blueprint', blueprint]);
    assert.equal(result.status, 0, result.stderr);
    assert.equal(stderrLines(result).length, 2);
  });

  it('warns about v2 content under schemaVersion 1 and under no meta', () => {
    const body = {
      deliveryRisks: [{ id: 'DR-001', statement: 's', refs: [], libraryId: 'L', likelihood: 'low', impact: 'i' }],
      deliveryUnknowns: [{ id: 'DU-001', statement: 's', libraryId: 'L', likelihood: 'low' }],
      assumptions: [{ id: 'AS-001', statement: 's', confidence: 'low' }],
      dependencies: []
    };
    const expected = [
      'deliveryRisks[0].refs: v2 field present but meta.schemaVersion is not "2"',
      'deliveryRisks[0].libraryId: v2 field present but meta.schemaVersion is not "2"',
      'deliveryRisks[0].likelihood: v2 field present but meta.schemaVersion is not "2"',
      'deliveryRisks[0].impact: v2 field present but meta.schemaVersion is not "2"',
      'deliveryUnknowns[0].libraryId: v2 field present but meta.schemaVersion is not "2"',
      'assumptions: v2 array present but meta.schemaVersion is not "2"',
      'dependencies: v2 array present but meta.schemaVersion is not "2"'
    ];
    assert.deepEqual(collectContextWarnings({ ...body, meta: { schemaVersion: '1' } }), expected);
    assert.deepEqual(collectContextWarnings(body), expected);
    const result = run([writeJson('v1-with-v2.json', { ...body, meta: { schemaVersion: '1' } })]);
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(stderrLines(result), expected.map((w) => `warning: ${w}`));
  });

  it('resolves a ref to an item whose id has stray whitespace', () => {
    const value = {
      deliveryRisks: [{ id: ' DR-001 ', statement: 's' }],
      deliveryUnknowns: [{ id: 'DU-001', statement: 's', refs: ['DR-001'] }],
      meta: { schemaVersion: '2' }
    };
    assert.deepEqual(collectContextWarnings(value), []);
  });

  it('resolves a ref to a local id before checking its form', () => {
    const value = {
      deliveryRisks: [{ id: 'banana', statement: 's', refs: ['banana'] }],
      meta: { schemaVersion: '2' }
    };
    assert.deepEqual(collectContextWarnings(value), []);
  });

  it('treats near-miss forms as unrecognised even without --blueprint', () => {
    const refs = ['dr-001', 'R-', 'Q', 'Q-7', 'R001'];
    const warnings = collectContextWarnings(risk(refs));
    assert.equal(warnings.length, refs.length);
    warnings.forEach((w, j) => {
      assert.ok(w.startsWith(`deliveryRisks[0].refs[${j}]: unrecognised reference "${refs[j]}"`), w);
    });
  });

  it('names the list in the warning path for assumptions and dependencies', () => {
    const value = {
      assumptions: [{ id: 'AS-001', statement: 's', refs: ['AS-009'] }],
      dependencies: [{ id: 'DP-001', statement: 's', refs: ['banana'] }],
      meta: { schemaVersion: '2' }
    };
    assert.deepEqual(collectContextWarnings(value), [
      'assumptions[0].refs[0]: reference "AS-009" matches no item in this file',
      'dependencies[0].refs[0]: unrecognised reference "banana" (expected DR-n, DU-n, AS-n, DP-n, R-n or Qn)'
    ]);
  });

  it('does not warn about a plain v1 file', () => {
    assert.deepEqual(collectContextWarnings({
      deliveryRisks: [{ id: 'DR-001', statement: 's', review: { status: 'pending' } }],
      meta: { schemaVersion: '1' }
    }), []);
  });

  it('suppresses warnings when there are errors', () => {
    const value = { ...risk(['DR-009']), assumptions: 'x' };
    const result = run([writeJson('err-and-warn.json', value)]);
    assert.equal(result.status, 1);
    assert.deepEqual(stderrLines(result), ['assumptions: expected array']);
  });

  it('tolerates malformed input', () => {
    assert.deepEqual(collectContextWarnings(null), []);
    assert.deepEqual(collectContextWarnings({ deliveryRisks: 'x', assumptions: [1, { id: 5, refs: 'x' }] }), [
      'assumptions: v2 array present but meta.schemaVersion is not "2"'
    ]);
  });
});

describe('validate-context arguments', () => {
  const ok = () => writeJson('args-ok.json', {});

  it('exits 1 with Cannot read for an unreadable Blueprint', () => {
    const missing = join(scratch, 'no-such-blueprint.json');
    const result = run([ok(), '--blueprint', missing]);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /^Cannot read /);
    assert.ok(result.stderr.includes(missing));
  });

  it('exits 1 for a Blueprint that is not JSON', () => {
    const bad = join(scratch, 'bp-bad.json');
    writeFileSync(bad, '{ nope');
    const result = run([ok(), '--blueprint', bad]);
    assert.equal(result.status, 1);
    assert.match(result.stderr, /^\(blueprint\): invalid JSON \(/);
  });

  it('exits 1 naming the missing arrays for a Blueprint of the wrong shape', () => {
    const cases = [
      [{}, ['(blueprint).requirements: expected array', '(blueprint).questions: expected array']],
      [{ requirements: 'x', questions: null }, ['(blueprint).requirements: expected array', '(blueprint).questions: expected array']],
      [{ requirements: [] }, ['(blueprint).questions: expected array']],
      [[], ['(blueprint): expected object']],
      [null, ['(blueprint): expected object']]
    ];
    cases.forEach(([value, expected], i) => {
      const result = run([writeJson('args-ok-shape.json', { deliveryRisks: [{ id: 'DR-001', statement: 's', refs: ['R-1'] }] }), '--blueprint', writeJson(`bp-shape-${i}.json`, value)]);
      assert.equal(result.status, 1, result.stderr);
      assert.deepEqual(stderrLines(result), expected);
      assert.equal(result.stdout, '');
    });
  });

  it('reports only the context errors when the context is invalid and the Blueprint is unreadable', () => {
    const bad = writeJson('args-bad-ctx.json', { assumptions: 'x' });
    const result = run([bad, '--blueprint', join(scratch, 'missing-bp.json')]);
    assert.equal(result.status, 1);
    assert.deepEqual(stderrLines(result), ['assumptions: expected array']);
  });

  it('exits 2 with the usage line when --blueprint has no usable value', () => {
    for (const args of [[ok(), '--blueprint'], [ok(), '--blueprint', '--other'], [ok(), '--blueprint', ''], [ok(), '--blueprint', '-x']]) {
      const result = run(args);
      assert.equal(result.status, 2);
      assert.equal(result.stderr.trim(), USAGE);
    }
  });

  it('exits 2 for an unknown flag, a second path, a repeated --blueprint or no path', () => {
    const bp = writeJson('args-bp.json', { requirements: [], questions: [] });
    for (const args of [
      [ok(), '--verbose'],
      [ok(), '-h'],
      ['-x', ok()],
      [ok(), '--blueprint=path'],
      [''],
      [ok(), ok()],
      [ok(), '--blueprint', bp, '--blueprint', bp],
      [],
      ['--blueprint', bp]
    ]) {
      const result = run(args);
      assert.equal(result.status, 2, `args: ${args.join(' ')}`);
      assert.equal(result.stderr.trim(), USAGE);
    }
  });

  it('accepts the flag before or after the path', () => {
    const bp = writeJson('args-bp2.json', { requirements: [], questions: [] });
    const file = writeJson('args-order.json', { deliveryRisks: [{ id: 'DR-001', statement: 's', refs: ['R-001'] }], meta: { schemaVersion: '2' } });
    const after = run([file, '--blueprint', bp]);
    const before = run(['--blueprint', bp, file]);
    assert.equal(after.status, 0, after.stderr);
    assert.equal(before.status, 0, before.stderr);
    assert.equal(after.stderr, before.stderr);
    assert.equal(stderrLines(after).length, 1);
  });
});
