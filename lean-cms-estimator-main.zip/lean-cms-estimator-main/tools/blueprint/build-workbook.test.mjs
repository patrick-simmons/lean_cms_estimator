import { test } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { strFromU8, unzipSync } from 'fflate';
import { buildAiPlan, readCatalogs } from './ai-plan.mjs';
import { buildWorkbook, buildWorkbookBytes, DEFAULT_TEMPLATE, workbookPathFor, WorkbookError } from './build-workbook.mjs';
import { estimatePlan, validatePlan } from './plan.mjs';
import { loadModelInputs, PHASES } from './estimate-model.mjs';
import { DEFAULT_CATALOG, parseActivities } from './rank-questions.mjs';
import { assumptionsAndRisks, laneOf, lanesOf, phaseOf, phasesOf, SHEET_COLUMNS, NAMED_CELLS, OVERHEAD_PHASE } from './workbook-rows.mjs';
import { escapeText, fillWorkbook, XlsxFillError } from './xlsx-fill.mjs';
import { loadSeed } from '../factors/seed.mjs';
import { buildSyntheticPlan } from '../eval/synthetic-plan.mjs';
import { buildTemplate, SHEET_ORDER } from '../workbook/build-template.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const script = path.join(root, 'tools', 'blueprint', 'build-workbook.mjs');
const NOW = '2026-11-13T12:00:00.000Z';
const catalogs = readCatalogs();
const workPackages = parseActivities(fs.readFileSync(DEFAULT_CATALOG, 'utf8'));
const inputs = loadModelInputs();
const seed = loadSeed();
const phases = phasesOf(seed.find((sheet) => sheet.name === 'Phase packs'));
const lanes = lanesOf(seed.find((sheet) => sheet.name === 'Lanes'));
const template = new Uint8Array(fs.readFileSync(DEFAULT_TEMPLATE));
const OPT_OUT = { id: 'cdk-loop', kind: 'method', reason: 'client-restriction', note: 'No code leaves the client network.', at: NOW };

/** The synthetic plan (aem), estimated, with an AI plan that carries one opt-out. */
function estimatedPlan(optOuts = [OPT_OUT]) {
  const plan = buildSyntheticPlan();
  plan.aiPlan = buildAiPlan(plan, catalogs, { platform: 'aem', now: NOW, optOuts }).aiPlan;
  estimatePlan(plan, inputs, { workPackages, now: NOW });
  return plan;
}

async function readBook(bytes) {
  const book = new ExcelJS.Workbook();
  await book.xlsx.load(Buffer.from(bytes));
  return book;
}

function column(sheet, index) {
  const out = [];
  sheet.eachRow({ includeEmpty: false }, (row, number) => {
    if (number > 1) {
      out.push(row.getCell(index).value);
    }
  });
  return out;
}

const text = (cell) => (cell && typeof cell === 'object' && 'richText' in cell ? cell.richText.map((part) => part.text).join('') : cell);

test('the template carries the sheets, headers and names the writer expects', async () => {
  const book = await readBook(template);
  assert.deepEqual(book.worksheets.map((sheet) => sheet.name), SHEET_ORDER);
  for (const [name, columns] of Object.entries(SHEET_COLUMNS)) {
    const header = book.getWorksheet(name).getRow(1);
    assert.deepEqual(columns.map((_, i) => header.getCell(i + 1).value), columns, `${name} header`);
    assert.equal(header.getCell(columns.length + 1).value, null, `${name} has no extra header cell`);
  }
  const names = book.definedNames.model.map((entry) => entry.name).sort();
  assert.deepEqual(names, [...NAMED_CELLS].sort());
});

test('the committed template is what the generator builds', async () => {
  const generated = await readBook(await buildTemplate());
  const committed = await readBook(template);
  for (const sheet of generated.worksheets) {
    const other = committed.getWorksheet(sheet.name);
    assert.ok(other, `${sheet.name} is in the committed template`);
    assert.equal(other.rowCount, sheet.rowCount, `${sheet.name} row count`);
    sheet.eachRow({ includeEmpty: false }, (row, number) => {
      row.eachCell({ includeEmpty: false }, (cell, index) => {
        assert.deepEqual(other.getRow(number).getCell(index).value, cell.value, `${sheet.name}!${cell.address}`);
      });
    });
  }
  assert.deepEqual(committed.definedNames.model, generated.definedNames.model);
});

test('the timeline phase shape in the template is the factors seed, with the lanes below it', async () => {
  const book = await readBook(template);
  const sheet = book.getWorksheet('Timeline');
  assert.deepEqual(phases.map((phase) => phase.id), PHASES, 'the seed schedules the catalog phases');
  phases.forEach((phase, i) => {
    const row = sheet.getRow(i + 2);
    assert.equal(row.getCell(1).value, phase.id);
    assert.equal(row.getCell(2).value || '', '', 'a phase row names no lane');
    assert.equal(row.getCell(4).value, phase.weeks);
    assert.equal(row.getCell(5).value || '', phase.after);
  });
  lanes.forEach((lane, i) => {
    const row = sheet.getRow(phases.length + 2 + i);
    assert.equal(row.getCell(1).value, lane.phase);
    assert.equal(row.getCell(2).value, lane.id);
    assert.equal(row.getCell(4).value, lane.weeks);
  });
  assert.equal(sheet.getRow(phases.length + lanes.length + 2).getCell(1).value, OVERHEAD_PHASE);
});

test('build renders two lanes, and content starts behind engineering rather than after it', () => {
  const engineering = lanes.find((lane) => lane.id === 'build-engineering');
  const content = lanes.find((lane) => lane.id === 'build-content');
  assert.ok(engineering && content, 'Build has an Engineering lane and a Content lane');
  assert.equal(engineering.phase, 'build');
  assert.equal(content.phase, 'build');
  assert.equal(engineering.offset, 0);
  assert.ok(content.offset > 0, 'content is offset behind engineering');
  assert.ok(content.offset < engineering.weeks, 'and starts while engineering is still running, not after it');
  // Nothing is in both lanes, and nothing outside Build is in either.
  const overlap = engineering.activities.filter((id) => content.activities.includes(id));
  assert.deepEqual(overlap, []);
  for (const id of [...engineering.activities, ...content.activities]) {
    assert.equal(workPackages.get(id).phase, 'build', `${id} is a Build activity`);
  }
});

test('a workstream falls in the phase the catalog puts it in, and in a lane only where its phase has lanes', () => {
  assert.equal(phaseOf({ id: 'discovery-audit', kind: 'delivery', phase: 'discover' }), 'discover');
  assert.equal(phaseOf({ id: 'uat-support', kind: 'delivery', phase: 'assure' }), 'assure');
  assert.equal(phaseOf({ id: 'project-management', kind: 'overhead', phase: 'run' }), OVERHEAD_PHASE);

  assert.equal(laneOf({ id: 'component-build' }, lanes), 'build-engineering');
  assert.equal(laneOf({ id: 'content-migration' }, lanes), 'build-content');
  assert.equal(laneOf({ id: 'discovery-audit' }, lanes), '', 'Discover runs as one track');
});

test('the workbook is the plan: workstreams, skills, AI plan, requirements and names', async () => {
  const plan = estimatedPlan();
  assert.deepEqual(validatePlan(plan, { workPackages }), []);
  const result = buildWorkbookBytes(plan, { template, workPackages, lanes, now: NOW });
  const book = await readBook(result.bytes);

  const workstreams = book.getWorksheet('Workstreams');
  assert.equal(workstreams.rowCount, plan.workstreams.length + 1);
  assert.deepEqual(column(workstreams, 1), plan.workstreams.map((row) => row.id));
  // Looked up by header rather than counted, because the thing worth asserting is that each plan
  // field lands under the heading that names it, whatever order the columns end up in.
  const at = (header) => SHEET_COLUMNS.Workstreams.indexOf(header) + 1;
  assert.deepEqual(column(workstreams, at('Traditional hours')), plan.workstreams.map((row) => row.traditionalHours));
  assert.deepEqual(column(workstreams, at('AI-assisted hours')), plan.workstreams.map((row) => row.aiAssistedHours));
  assert.deepEqual(column(workstreams, at('Low hours')), plan.workstreams.map((row) => row.hours.low));
  assert.deepEqual(column(workstreams, at('High hours')), plan.workstreams.map((row) => row.hours.high));
  assert.deepEqual(column(workstreams, at('Owner')), plan.workstreams.map((row) => row.owner));
  assert.deepEqual(column(workstreams, at('Rate basis')), plan.workstreams.map((row) => row.rateBasis));
  assert.deepEqual(column(workstreams, at('Cases behind the rate')), plan.workstreams.map((row) => row.caseCount));
  // An empty cell reads back as null, and only a tiered activity has a band to show.
  assert.deepEqual(column(workstreams, at('Band')).map((value) => value || ''), plan.workstreams.map((row) => row.band || ''));
  assert.deepEqual(column(workstreams, at('Volume')), plan.workstreams.map((row) => row.volume));
  assert.deepEqual(column(workstreams, at('Volume basis')), plan.workstreams.map((row) => row.volumeBasis));
  assert.ok(column(workstreams, at('Source of the volume')).includes('quoted in the documents') && column(workstreams, at('Source of the volume')).includes('assumed, no volume in the documents'));
  assert.deepEqual(column(workstreams, at('Phase')), plan.workstreams.map((row) => (row.kind === 'overhead' ? 'overhead' : row.phase)));
  assert.deepEqual(column(workstreams, at('Lane')).map((value) => value || ''), plan.workstreams.map((row) => laneOf(row, lanes)));
  assert.ok(column(workstreams, at('Lane')).includes('build-engineering') && column(workstreams, at('Lane')).includes('build-content'));
  assert.equal(SHEET_COLUMNS.Workstreams.indexOf('AI rate used'), -1, 'the AI saving is one number now, so there is no rate to name');

  const skills = book.getWorksheet('Skills');
  assert.equal(skills.rowCount, plan.skills.length + 1);
  const total = (rows, key) => Math.round(rows.reduce((sum, row) => sum + row[key], 0) * 100) / 100;
  assert.equal(Math.round(column(skills, 4).reduce((sum, value) => sum + value, 0)), Math.round(total(plan.workstreams, 'traditionalHours')));

  const requirements = book.getWorksheet('Requirements');
  assert.equal(requirements.rowCount, plan.requirements.length + 1);
  const ids = column(requirements, 1);
  assert.deepEqual(ids, plan.requirements.map((row) => row.id));
  const reasons = column(requirements, 13).filter(Boolean);
  assert.ok(reasons.length > 0, 'a requirement with no tool carries the catalog fact as its reason');
  const withTool = plan.aiPlan.requirements.find((entry) => entry.tools.length > 0);
  assert.equal(text(requirements.getRow(ids.indexOf(withTool.requirementId) + 2).getCell(11).value), withTool.tools.join(', '));

  const sources = book.getWorksheet('Sources');
  assert.deepEqual(column(sources, 2), plan.sources.map((source) => source.name));

  const coverage = book.getWorksheet('Coverage');
  const named = Object.fromEntries(book.definedNames.model.map((entry) => [entry.name, entry.ranges[0].split('!')[1].replace(/\$/g, '')]));
  assert.equal(coverage.getCell(named.ProjectName).value, plan.projectName);
  assert.equal(coverage.getCell(named.CmkCommit).value, plan.catalog.cmkCommit);
  assert.equal(coverage.getCell(named.EstimatingVersion).value, plan.catalog.estimatingVersion);
  assert.equal(coverage.getCell(named.BuiltAt).value, NOW);
  assert.equal(coverage.getCell(named.EstimatedAt).value, plan.estimateBasis.builtAt);
  assert.match(String(coverage.getCell(named.Platform).value), /aem/);
  assert.equal(coverage.getCell(named.PlatformSource).value, 'named in the documents');

  assert.deepEqual(result.rows, {
    Sources: plan.sources.length,
    Requirements: plan.requirements.length,
    Questions: result.rows.Questions,
    Workstreams: plan.workstreams.length,
    'AI plan': result.rows['AI plan'],
    Skills: plan.skills.length,
    'Assumptions and risks': result.rows['Assumptions and risks']
  });
});

test('the template keeps its formulas, header and widths, and the workbook recalculates on open', async () => {
  const result = buildWorkbookBytes(estimatedPlan(), { template, workPackages, lanes, now: NOW });
  const before = await readBook(template);
  const after = await readBook(result.bytes);
  const formulas = (book) => {
    const out = [];
    for (const sheet of book.worksheets) {
      sheet.eachRow({ includeEmpty: false }, (row) => row.eachCell({ includeEmpty: false }, (cell) => {
        if (cell.value && typeof cell.value === 'object' && 'formula' in cell.value) {
          out.push(`${sheet.name}!${cell.address}=${cell.value.formula}`);
        }
      }));
    }
    return out;
  };
  assert.ok(formulas(before).length > 50);
  assert.deepEqual(formulas(after), formulas(before));
  for (const name of Object.keys(SHEET_COLUMNS)) {
    assert.deepEqual(after.getWorksheet(name).getRow(1).values, before.getWorksheet(name).getRow(1).values, `${name} header`);
    assert.equal(after.getWorksheet(name).getColumn(2).width, before.getWorksheet(name).getColumn(2).width);
  }
  const files = unzipSync(result.bytes);
  assert.match(strFromU8(files['xl/workbook.xml']), /<calcPr[^>]*fullCalcOnLoad="1"/);
  assert.equal(files['xl/calcChain.xml'], undefined);
  assert.equal(Object.keys(files).filter((key) => key.endsWith('/')).length, 0);
});

test('written cells take the number format and wrapping of their column', async () => {
  const result = buildWorkbookBytes(estimatedPlan(), { template, workPackages, lanes, now: NOW });
  const book = await readBook(result.bytes);
  const workstreams = book.getWorksheet('Workstreams');
  // What the format is belongs to the template; that a written row picks it up belongs here.
  const hours = SHEET_COLUMNS.Workstreams.indexOf('Traditional hours') + 1;
  assert.equal(workstreams.getRow(2).getCell(hours).numFmt, workstreams.getColumn(hours).numFmt);
  assert.match(workstreams.getRow(2).getCell(hours).numFmt, /^#,##0\.00/);
  const requirements = book.getWorksheet('Requirements');
  assert.equal(requirements.getRow(2).getCell(2).alignment.wrapText, true);
});

test('opt-outs reach the workbook with their reason and typed note, and the hours fall back', async () => {
  const withOptOut = estimatedPlan();
  const all = estimatedPlan([]);
  const result = buildWorkbookBytes(withOptOut, { template, workPackages, lanes, now: NOW });
  const book = await readBook(result.bytes);
  const aiPlan = book.getWorksheet('AI plan');
  const rows = [];
  aiPlan.eachRow({ includeEmpty: false }, (row, number) => number > 1 && rows.push(row.values.slice(1).map(text)));
  const method = rows.find((row) => row[0] === 'Method' && row[1] === 'cdk-loop');
  assert.equal(method[4], 'off');
  assert.equal(method[6], 'client restriction');
  assert.equal(method[7], 'No code leaves the client network.');
  assert.ok(rows.some((row) => row[0] === 'Tool' && row[4] === 'on'));
  assert.ok(rows.some((row) => row[0] === 'Readiness'));
  assert.ok(rows.some((row) => row[0] === 'Unused'));

  const assumptions = [];
  book.getWorksheet('Assumptions and risks').eachRow({ includeEmpty: false }, (row, number) => number > 1 && assumptions.push(row.values.slice(1).map(text)));
  const optOutRow = assumptions.find((row) => /cdk-loop is not used: client restriction\. No code leaves the client network\./.test(row[2]));
  assert.ok(optOutRow, assumptions.map((row) => row[2]).join('\n'));
  assert.equal(optOutRow[1], 'Assumption');

  const sum = (plan) => plan.workstreams.reduce((total, row) => total + row.aiAssistedHours, 0);
  assert.ok(sum(withOptOut) >= sum(all), 'an opt-out never lowers the AI-assisted hours');
});

test('assumptions and risks are facts of the plan: assumed volumes, bulk accept, unread sources, stale estimate', () => {
  const plan = estimatedPlan([]);
  const rows = assumptionsAndRisks(plan);
  assert.deepEqual(rows.map((row) => row[0]), rows.map((_, i) => `AR-${String(i + 1).padStart(3, '0')}`));
  const placeholders = plan.workstreams.filter((row) => row.volumeBasis === 'placeholder');
  for (const ws of placeholders) {
    assert.ok(rows.some((row) => row[1] === 'Assumption' && row[3] === ws.id), `${ws.id} is sized on a placeholder and owes an assumption`);
  }
  assert.ok(rows.some((row) => /accepted together/.test(row[2]) && row[4] === 'Accepted (bulk)'));
  assert.ok(rows.some((row) => row[1] === 'Risk' && /rest on placeholder volumes/.test(row[2])));
  assert.ok(!rows.some((row) => /out of date/.test(row[2])));

  const unread = JSON.parse(JSON.stringify(plan));
  unread.sources[0].read = 'partial';
  unread.sources[0].notRead = [{ reason: 'Scanned pages have no text', pages: '10-40' }];
  const late = JSON.parse(JSON.stringify(unread));
  late.volumes.find((volume) => volume.workPackageId === 'content-migration').review = { status: 'dismissed', via: 'edit', at: NOW };
  const risks = assumptionsAndRisks(late).filter((row) => row[1] === 'Risk').map((row) => row[2]);
  assert.ok(risks.some((statement) => new RegExp(`${plan.sources[0].name} was only partly read: Scanned pages have no text \\(pages 10-40\\)`).test(statement)), risks.join('\n'));
  assert.ok(risks.some((statement) => /The estimate is out of date: content-migration: volume D-001 is no longer accepted/.test(statement)), risks.join('\n'));
});

test('work the client does, whole or shared, is on Assumptions and risks with the question it owes', () => {
  const plan = buildSyntheticPlan();
  plan.owners = [{
    activity: 'uat-support',
    owner: 'client',
    note: 'Their own business testers run it.',
    review: { status: 'accepted', via: 'owner', at: NOW }
  }];
  estimatePlan(plan, inputs, { workPackages, now: NOW });
  const rows = assumptionsAndRisks(plan);

  const handed = rows.find((row) => row[3] === 'uat-support' && /not in this estimate/.test(row[2]));
  assert.ok(handed, 'the client runs UAT, so the estimate says what it left out');
  assert.match(handed[2], /not in this estimate: the client is doing it\. Their own business testers run it\./);
  assert.match(handed[5], /Ask: .*Is that still their plan/);

  const shared = plan.workstreams.filter((row) => row.owner === 'shared');
  assert.ok(shared.length > 0, 'the catalog shares some activities with the client');
  for (const row of shared) {
    const entry = rows.find((item) => item[3] === row.id && /shared with the client/.test(item[2]));
    assert.ok(entry, `${row.id} is shared and owes an assumption`);
    assert.match(entry[5], /Ask: .*How much of it are they doing\?/);
  }
  assert.equal(rows.filter((row) => /shared with the client|not in this estimate/.test(row[2])).length, shared.length + 1);
});

test('the questions sheet ranks the plan questions with the assumed-volume questions, client ones marked', async () => {
  const plan = estimatedPlan();
  const result = buildWorkbookBytes(plan, { template, workPackages, lanes, now: NOW });
  const book = await readBook(result.bytes);
  const sheet = book.getWorksheet('Questions');
  const rows = [];
  sheet.eachRow({ includeEmpty: false }, (row, number) => number > 1 && rows.push(row.values.slice(1).map(text)));
  assert.deepEqual(rows.map((row) => row[0]), rows.map((_, i) => i + 1), 'ranks run 1..n');
  assert.ok(rows.every((row) => ['high', 'medium', 'low'].includes(row[2]) && ['client', 'team'].includes(row[3])));
  for (const question of plan.questions) {
    assert.ok(rows.some((row) => row[1] === question.id), question.id);
  }
  const placeholder = plan.workstreams.find((row) => row.kind === 'delivery' && row.volumeBasis === 'placeholder');
  assert.ok(rows.some((row) => row[1] === placeholder.id && row[4] === placeholder.clientQuestion && row[3] === 'client'));
  const scores = rows.map((row) => ['high', 'medium', 'low'].indexOf(row[2]));
  assert.deepEqual(scores, [...scores].sort((a, b) => a - b), 'tiers never go back up');
});

test('text stays text: a statement that starts with = is a string, markup and control characters are neutralised', async () => {
  const plan = estimatedPlan();
  plan.requirements[0].statement = '=HYPERLINK("http://example.invalid","x") <b>&</b>\u0001 end';
  const result = buildWorkbookBytes(plan, { template, workPackages, lanes, now: NOW });
  const cell = (await readBook(result.bytes)).getWorksheet('Requirements').getRow(2).getCell(2);
  assert.equal(typeof cell.value, 'string');
  assert.equal(cell.value, '=HYPERLINK("http://example.invalid","x") <b>&</b> end');
  assert.equal(escapeText('a\u0000b\uFFFE'), 'ab');
  assert.equal(escapeText('x'.repeat(40000)).length, 32767);
});

test('a plan that is not valid, not estimated or without an AI plan stops with a message', () => {
  const base = { template, workPackages, lanes, now: NOW };
  const plan = estimatedPlan();
  assert.throws(() => buildWorkbookBytes({ ...plan, requirements: 'nope' }, base), (error) => error instanceof WorkbookError && /not valid/.test(error.message));
  const noEstimate = JSON.parse(JSON.stringify(plan));
  noEstimate.workstreams = [];
  noEstimate.skills = [];
  delete noEstimate.estimateBasis;
  noEstimate.aiPlan = null;
  assert.throws(() => buildWorkbookBytes(noEstimate, base), /no estimate yet/);
  const noAi = buildSyntheticPlan();
  assert.throws(() => buildWorkbookBytes(noAi, base), /no AI plan yet|no estimate yet/);
  const estimatedOnly = buildSyntheticPlan();
  estimatePlan(estimatedOnly, inputs, { workPackages, now: NOW });
  assert.equal(estimatedOnly.aiPlan, null);
  assert.throws(() => buildWorkbookBytes(estimatedOnly, base), /Run plan\.mjs ai-plan first/);
});

test('a template that lacks a sheet or a name the writer needs fails naming it', () => {
  const content = { sheets: { Nowhere: [['x']] }, names: {} };
  assert.throws(() => fillWorkbook(template, content), (error) => error instanceof XlsxFillError && /lacks Nowhere/.test(error.message));
  assert.throws(() => fillWorkbook(template, { sheets: {}, names: { NoSuchName: 'x' } }), /the name NoSuchName/);
  assert.throws(() => fillWorkbook(new Uint8Array([1, 2, 3]), { sheets: {}, names: {} }), /not a workbook/);
});

test('a stale estimate still builds and says so in the workbook and in the warnings', () => {
  const plan = estimatedPlan();
  plan.volumes.find((volume) => volume.workPackageId === 'content-migration').review = { status: 'dismissed', via: 'edit', at: NOW };
  const result = buildWorkbookBytes(plan, { template, workPackages, lanes, now: NOW });
  assert.ok(result.warnings.some((message) => /out of date: content-migration/.test(message)));
});

test('the workbook path follows the plan file name', () => {
  assert.equal(workbookPathFor(path.join('a', 'Fabrikam_Plan.json')), path.join('a', 'Fabrikam_Estimate.xlsx'));
  assert.equal(workbookPathFor(path.join('a', 'plan.json')), path.join('a', 'plan_Estimate.xlsx'));
});

test('the command writes <Project>_Estimate.xlsx beside the plan, and nothing when the plan cannot be used', async () => {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'build-workbook-'));
  try {
    const planFile = path.join(folder, 'Fabrikam_Plan.json');
    fs.writeFileSync(planFile, JSON.stringify(estimatedPlan(), null, 2));
    const run = (...args) => spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });

    const ok = run(planFile);
    assert.equal(ok.status, 0, ok.stderr);
    const output = path.join(folder, 'Fabrikam_Estimate.xlsx');
    assert.ok(fs.existsSync(output));
    assert.match(ok.stdout, /wrote .*Fabrikam_Estimate\.xlsx/);
    assert.match(ok.stdout, /hours: [\d.]+ traditional, [\d.]+ AI-assisted/);
    const book = await readBook(fs.readFileSync(output));
    assert.equal(book.getWorksheet('Workstreams').rowCount, estimatedPlan().workstreams.length + 1);
    assert.deepEqual(fs.readdirSync(folder).sort(), ['Fabrikam_Estimate.xlsx', 'Fabrikam_Plan.json'], 'no temporary file is left behind');

    const bare = path.join(folder, 'Bare_Plan.json');
    fs.writeFileSync(bare, JSON.stringify(buildSyntheticPlan(), null, 2));
    const refused = run(bare);
    assert.equal(refused.status, 1);
    assert.match(refused.stderr, /build-workbook: .*(no estimate yet|no AI plan yet)/);
    assert.ok(!fs.existsSync(path.join(folder, 'Bare_Estimate.xlsx')));

    assert.equal(run().status, 2);
    assert.equal(run(planFile, '--nope').status, 2);
    assert.equal(run(planFile, '--template', path.join(folder, 'missing.xlsx')).status, 1);
  } finally {
    fs.rmSync(folder, { recursive: true, force: true });
  }
});

test('buildWorkbook reads the files and returns the path it wrote', () => {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'build-workbook-'));
  try {
    const planFile = path.join(folder, 'Contoso_Plan.json');
    fs.writeFileSync(planFile, JSON.stringify(estimatedPlan(), null, 2));
    const result = buildWorkbook({ planPath: planFile, now: NOW });
    assert.equal(result.out, path.join(folder, 'Contoso_Estimate.xlsx'));
    assert.ok(result.rows.Workstreams > 0 && result.totals.traditionalHours > 0);
    assert.throws(() => buildWorkbook({ planPath: path.join(folder, 'nope.json') }), /Cannot read the plan/);
    fs.writeFileSync(planFile, '{ nope');
    assert.throws(() => buildWorkbook({ planPath: planFile }), /invalid JSON/);
  } finally {
    fs.rmSync(folder, { recursive: true, force: true });
  }
});
