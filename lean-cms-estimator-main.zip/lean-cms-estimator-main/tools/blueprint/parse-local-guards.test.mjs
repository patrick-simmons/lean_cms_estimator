// Guards of the local parse tool: what it refuses, what it reports, and how it fails.
// main() is called in-process (it returns its exit code) so the many cases stay fast; the CLI wrapper and
// the offline guarantee are covered by parse-local.test.mjs, which spawns the script.
import assert from 'node:assert/strict';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, describe, it } from 'node:test';
import { docxFixture, HEADING_STYLES, wPara } from './fixtures/ooxml-fixture.mjs';
import { classifyPdfError, ENCRYPTED_PDF, listSources, parseLocalFile, SCANNED_PDF, scanFolder, SelectionError } from './parse-local-core.mjs';
import { EXIT, main } from './parse-local.mjs';
import { formatPageRanges, MIN_PAGE_CHARS } from './pdf-text.mjs';
import { isIgnoredName, isSourceCandidate, skipReason } from './source-candidates.mjs';
import { DAMAGED, FILE_TIMEOUT, LEGACY_OFFICE, TEXT_CAP } from '../../function/dist/src/blocks.js';

const root = fileURLToPath(new URL('../..', import.meta.url));
const sources = join(root, 'samples', 'sources', 'synthetic-aem');
const scratch = mkdtempSync(join(tmpdir(), 'parse-guards-'));
let counter = 0;

after(() => rmSync(scratch, { recursive: true, force: true }));

// pdf-lib is a dependency of the extraction function, not of the repository root.
const { PDFDocument, StandardFonts } = createRequire(join(root, 'function', 'package.json'))('pdf-lib');

const docx = (text) => docxFixture({ styles: HEADING_STYLES, body: wPara('1 Scope', 'Heading1') + wPara(text) });

/** A fresh project folder holding the given files: { name: string | Uint8Array }. */
function project(files = {}) {
  counter += 1;
  const folder = join(scratch, `p${counter}`);
  mkdirSync(folder, { recursive: true });
  for (const [name, content] of Object.entries(files)) {
    mkdirSync(dirname(join(folder, name)), { recursive: true });
    writeFileSync(join(folder, name), content);
  }
  return folder;
}

async function run(argv) {
  const errors = [];
  const original = { error: console.error, log: console.log };
  console.error = (...parts) => errors.push(parts.join(' '));
  console.log = () => undefined;
  try {
    const code = await main(argv);
    return { code, stderr: errors.join('\n') };
  } finally {
    console.error = original.error;
    console.log = original.log;
  }
}

const listing = (folder) => readdirSync(folder, { recursive: true }).map(String).sort();
const readJson = (path) => JSON.parse(readFileSync(path, 'utf8'));

async function pdfWithPages(texts) {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  for (const text of texts) {
    const page = doc.addPage([612, 792]);
    if (text) {
      page.drawText(text, { x: 54, y: 700, size: 11, font });
    }
  }
  return new Uint8Array(await doc.save({ useObjectStreams: false }));
}

const BODY = 'The vendor shall migrate approximately 6,400 pages and implement 301 redirects.';

describe('--out is never allowed to damage the project', () => {
  it('refuses the project folder itself and leaves everything in place', async () => {
    const folder = project({ 'Brief.docx': docx('Migrate 100 pages.'), 'notes.txt': 'keep me' });
    const before = listing(folder);
    const result = await run([folder, '--out', folder, '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.match(result.stderr, /project folder or contains it/);
    assert.deepEqual(listing(folder), before);
  });

  it('refuses a folder that contains the project', async () => {
    const folder = project({ 'Brief.docx': docx('Migrate 100 pages.') });
    const parent = dirname(folder);
    const before = listing(parent);
    const result = await run([folder, '--out', parent, '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.deepEqual(listing(parent), before);
  });

  it('refuses an output folder that holds source files', async () => {
    const folder = project({ 'sub/Brief.docx': docx('Migrate 100 pages.') });
    const result = await run([folder, '--select', 'sub/Brief.docx', '--out', join(folder, 'sub'), '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.match(result.stderr, /contains source files/);
    assert.ok(existsSync(join(folder, 'sub', 'Brief.docx')));
  });

  it('refuses a non-empty folder that parse-local did not write, and a file', async () => {
    const folder = project({ 'Brief.docx': docx('Migrate 100 pages.') });
    const foreign = join(scratch, 'foreign');
    mkdirSync(foreign);
    writeFileSync(join(foreign, 'important.txt'), 'not ours');
    const result = await run([folder, '--out', foreign, '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.match(result.stderr, /not written by parse-local/);
    assert.equal(readFileSync(join(foreign, 'important.txt'), 'utf8'), 'not ours');
    const file = join(scratch, 'a-file.txt');
    writeFileSync(file, 'x');
    assert.equal((await run([folder, '--out', file, '--quiet'])).code, EXIT.USAGE);
  });

  it('reuses its own output folder, drops only per-source files it wrote earlier, and keeps foreign files', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.'), 'B.docx': docx('Beta migrates 200 pages.') });
    const out = join(scratch, 'own-out');
    assert.equal((await run([folder, '--out', out, '--select', 'A.docx', 'B.docx', '--quiet'])).code, EXIT.OK);
    writeFileSync(join(out, 'estimator-notes.txt'), 'mine');
    assert.ok(existsSync(join(out, 'src-a.json')) && existsSync(join(out, 'src-b.json')));
    assert.equal((await run([folder, '--out', out, '--select', 'A.docx', '--quiet'])).code, EXIT.OK);
    assert.ok(existsSync(join(out, 'src-a.json')));
    assert.ok(!existsSync(join(out, 'src-b.json')), 'the stale per-source file is gone');
    assert.equal(readFileSync(join(out, 'estimator-notes.txt'), 'utf8'), 'mine');
    assert.deepEqual(readJson(join(out, 'manifest.json')).files.map((f) => f.name), ['A.docx']);
  });

  it('never leaves a temporary file behind', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.') });
    assert.equal((await run([folder, '--quiet'])).code, EXIT.OK);
    assert.ok(!readdirSync(join(folder, '.blueprint', 'parsed')).some((name) => name.endsWith('.tmp')));
  });
});

describe('the selection is exactly what was asked for', () => {
  it('treats an empty .blueprint/sources.json as no sources: exit 3, nothing parsed or written', async () => {
    const folder = project({ 'Brief.docx': docx('Migrate 100 pages.'), '.blueprint/sources.json': JSON.stringify({ sources: [] }) });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.NO_SELECTION);
    assert.match(result.stderr, /no sources were selected/);
    assert.ok(!existsSync(join(folder, '.blueprint', 'parsed')));
  });

  it('reads a bare array in sources.json and lists names given as strings', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.'), 'B.docx': docx('Beta migrates 200 pages.'), '.blueprint/sources.json': JSON.stringify(['B.docx']) });
    assert.equal((await run([folder, '--quiet'])).code, EXIT.OK);
    assert.deepEqual(readJson(join(folder, '.blueprint', 'parsed', 'manifest.json')).files.map((f) => f.name), ['B.docx']);
  });

  it('reports an unreadable sources.json by path instead of crashing', async () => {
    const folder = project({ 'Brief.docx': docx('Migrate 100 pages.'), '.blueprint/sources.json': '{ not json' });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.ok(result.stderr.includes('sources.json'), result.stderr);
    assert.match(result.stderr, /not valid JSON/);
    assert.doesNotMatch(result.stderr, /\n\s+at /, 'no stack trace');
  });

  it('refuses a sources.json with entries that have no file name instead of dropping them', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.'), '.blueprint/sources.json': JSON.stringify({ sources: [{ name: 'A.docx' }, { id: 3 }, 7] }) });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.match(result.stderr, /#2, #3/);
    assert.ok(!existsSync(join(folder, '.blueprint', 'parsed')));
  });

  it('refuses a sources.json of the wrong shape', async () => {
    const folder = project({ 'A.docx': docx('x'), '.blueprint/sources.json': JSON.stringify({ files: [] }) });
    assert.equal((await run([folder, '--quiet'])).code, EXIT.USAGE);
  });

  it('treats --select with no names as a usage error', async () => {
    const folder = project({ 'A.docx': docx('x') });
    const result = await run([folder, '--select', '--quiet']);
    assert.equal(result.code, EXIT.USAGE);
    assert.match(result.stderr, /Usage/);
  });

  it('rejects names that leave the folder and files that do not exist', async () => {
    const folder = project({ 'A.docx': docx('x') });
    writeFileSync(join(dirname(folder), 'outside.docx'), docx('secret'));
    for (const name of ['../outside.docx', '..', '.', 'D:/secret/x.pdf', 'sub/../../outside.docx']) {
      const result = await run([folder, '--select', name, '--quiet']);
      assert.equal(result.code, EXIT.USAGE, `${name} must be refused`);
      assert.match(result.stderr, /outside|not found|not a file/);
    }
    const missing = await run([folder, '--select', 'Missing.pdf', '--quiet']);
    assert.equal(missing.code, EXIT.USAGE);
    assert.match(missing.stderr, /Selected file not found: Missing\.pdf/);
    assert.ok(!existsSync(join(folder, '.blueprint', 'parsed')), 'nothing is written for a refused selection');
  });

  it('accepts a legitimate file whose name starts with two dots', async () => {
    const folder = project({ '..notes.docx': docx('Migrate 100 pages.') });
    const result = await run([folder, '--select', '..notes.docx', '--quiet']);
    assert.equal(result.code, EXIT.OK, result.stderr);
    assert.deepEqual(readJson(join(folder, '.blueprint', 'parsed', 'manifest.json')).files.map((f) => f.name), ['..notes.docx']);
  });

  it('lists a file selected twice once, and gives every source its own id', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.') });
    assert.equal((await run([folder, '--select', 'A.docx', './A.docx', 'A.docx', '--quiet'])).code, EXIT.OK);
    const manifest = readJson(join(folder, '.blueprint', 'parsed', 'manifest.json'));
    assert.equal(manifest.files.length, 1);
    assert.equal(manifest.selection, 'selected');
  });

  it('refuses a link that points outside the folder (when the platform allows creating one)', (t) => {
    const folder = project({ 'A.docx': docx('x') });
    const outside = join(scratch, 'outside-target.docx');
    writeFileSync(outside, docx('secret'));
    try {
      symlinkSync(outside, join(folder, 'link.docx'), 'file');
    } catch {
      t.skip('cannot create a symbolic link here');
      return;
    }
    assert.throws(() => listSources(folder, ['link.docx']), (error) => error instanceof SelectionError && /outside the project folder/.test(error.message));
  });

  it('lists an explicit empty selection as no files, and no selection as the folder', () => {
    const folder = project({ 'A.docx': docx('x'), 'B.pdf': new Uint8Array([1]) });
    assert.deepEqual(listSources(folder, []), []);
    assert.deepEqual(listSources(folder).map((f) => f.name), ['A.docx', 'B.pdf']);
  });
});

describe('what is skipped and what is empty is never silent', () => {
  it('lists unsupported files and subfolders, but not bootstrap, hidden or output files', async () => {
    const folder = project({
      'Brief.docx': docx('Migrate 100 pages.'),
      'notes.txt': 'plain',
      'mail.eml': 'From: x',
      'data.csv': 'a,b',
      'noextension': 'x',
      'Sources/Hidden.docx': docx('in a subfolder'),
      'AGENTS.md': '# bootstrap',
      '.hidden.pdf': 'x',
      'Fabrikam_Blueprint.json': '{}'
    });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.OK, result.stderr);
    const manifest = readJson(join(folder, '.blueprint', 'parsed', 'manifest.json'));
    assert.deepEqual(manifest.files.map((f) => f.name), ['Brief.docx']);
    assert.deepEqual(manifest.skipped.map((s) => s.name), ['data.csv', 'mail.eml', 'noextension', 'notes.txt', 'Sources/']);
    assert.match(manifest.skipped.find((s) => s.name === 'notes.txt').reason, /unsupported file type \.txt/);
    assert.match(manifest.skipped.find((s) => s.name === 'Sources/').reason, /subfolder/);
    assert.deepEqual(scanFolder(folder).skipped, manifest.skipped);
  });

  it('exits 4 when a folder yields no blocks, still writes the manifest, and does not advance the run record', async () => {
    const folder = project({ 'notes.txt': 'plain', 'Sources/Brief.docx': docx('Migrate 100 pages.'), '.blueprint/placeholder.txt': 'x' });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.NOTHING_READ);
    assert.match(result.stderr, /nothing could be read: no supported source files/);
    const manifest = readJson(join(folder, '.blueprint', 'parsed', 'manifest.json'));
    assert.deepEqual(manifest.files, []);
    assert.deepEqual(manifest.skipped.map((s) => s.name), ['notes.txt', 'Sources/']);
    assert.ok(!existsSync(join(folder, '.blueprint', 'run.json')), 'the parse stage was not recorded');
  });

  it('exits 4 when every source is unreadable and 0 with --allow-empty', async () => {
    const ole = new Uint8Array([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0, 0]);
    const folder = project({ 'Old.doc': ole });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.NOTHING_READ);
    assert.match(result.stderr, /every source was unreadable/);
    assert.equal(readJson(join(folder, '.blueprint', 'parsed', 'manifest.json')).files[0].notRead[0].reason, LEGACY_OFFICE);
    assert.equal((await run([folder, '--allow-empty', '--quiet'])).code, EXIT.OK);
  });

  it('survives a damaged run record: the outputs are written and the run succeeds', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.'), '.blueprint/run.json': '{ damaged' });
    const result = await run([folder, '--quiet']);
    assert.equal(result.code, EXIT.OK, result.stderr);
    assert.ok(existsSync(join(folder, '.blueprint', 'parsed', 'blocks.json')));
  });

  it('records the parsed folder relative to the project', async () => {
    const folder = project({ 'A.docx': docx('Alpha migrates 100 pages.'), '.blueprint/placeholder.txt': 'x' });
    assert.equal((await run([folder, '--quiet'])).code, EXIT.OK);
    const record = readJson(join(folder, '.blueprint', 'run.json'));
    assert.equal(record.stage, 'parse');
    assert.equal(record.files.parsed.path, '.blueprint/parsed');
  });

  it('applies the same rule as prepare-folder to what is a source', () => {
    assert.equal(isSourceCandidate('Brief.PDF'), true);
    assert.equal(isSourceCandidate('notes.txt'), false);
    assert.equal(isIgnoredName('Fabrikam_Blueprint.json'), true);
    assert.equal(isIgnoredName('notes.txt'), false);
    assert.equal(skipReason('Brief.pdf'), undefined);
    assert.match(skipReason('x.eml'), /unsupported file type \.eml/);
  });
});

describe('PDFs that look read but are not', () => {
  it('reports pages with only a stamp or footer as unread, by page range, and keeps the real pages', async () => {
    assert.ok('CONFIDENTIAL 0001'.length < MIN_PAGE_CHARS);
    const bytes = await pdfWithPages([BODY, 'CONFIDENTIAL 0002', 'CONFIDENTIAL 0003', BODY, '', BODY]);
    const result = await parseLocalFile(bytes, 'Mixed.pdf', 'src-mixed');
    assert.equal(result.totalPages, 6);
    assert.deepEqual([...new Set(result.blocks.map((b) => b.location.page))], [1, 4, 6]);
    assert.equal(result.pagesRead, '1-6');
    assert.equal(result.notRead.length, 1);
    assert.equal(result.notRead[0].pages, '2-3,5');
    assert.match(result.notRead[0].reason, /Pages 2-3, 5 have no text layer and were not read \(3 of 6 pages\)/);
    assert.ok(!result.blocks.some((b) => /CONFIDENTIAL/.test(b.text)), 'stamp text is not turned into requirements input');
  });

  it('treats a scan whose only text is a stamp as having no text layer', async () => {
    const bytes = await pdfWithPages(['CONFIDENTIAL 0001', 'CONFIDENTIAL 0002']);
    const result = await parseLocalFile(bytes, 'Stamped.pdf', 'src-stamped');
    assert.deepEqual(result.blocks, []);
    assert.equal(result.pagesRead, undefined);
    assert.deepEqual(result.notRead, [{ reason: SCANNED_PDF, pages: '1-2' }]);
  });

  it('does not mistake a short but real single page for a scan', async () => {
    const bytes = await pdfWithPages(['Section 4.2 The platform runs in the EU and holds no payment data.']);
    const result = await parseLocalFile(bytes, 'Short.pdf', 'src-short');
    assert.equal(result.blocks.length, 1);
    assert.deepEqual(result.notRead, []);
  });

  it('formats page ranges', () => {
    assert.equal(formatPageRanges([5, 2, 3, 3, 9, 8]), '2-3,5,8-9');
    assert.equal(formatPageRanges([]), '');
    assert.equal(formatPageRanges([7]), '7');
  });

  it('reports a damaged PDF as damaged', async () => {
    const failures = [];
    const bytes = new TextEncoder().encode('%PDF-1.7 not really a pdf');
    const result = await parseLocalFile(bytes, 'Broken.pdf', 'src-broken', { logFailure: (detail) => failures.push(detail) });
    assert.deepEqual(result.blocks, []);
    assert.deepEqual(result.notRead, [{ reason: DAMAGED }]);
    assert.ok(failures.length > 0, 'the cause is logged for the manifest detail');
  });

  it('names a password-protected PDF instead of calling it damaged', async () => {
    assert.equal(classifyPdfError({ name: 'PasswordException' }), 'encrypted');
    assert.equal(classifyPdfError(new Error('boom')), 'damaged');
    assert.equal(classifyPdfError(undefined), 'damaged');
    const bytes = await pdfWithPages([BODY]);
    const readPdfText = async () => {
      throw Object.assign(new Error('No password given'), { name: 'PasswordException' });
    };
    const result = await parseLocalFile(bytes, 'Locked.pdf', 'src-locked', { readPdfText });
    assert.deepEqual(result.notRead, [{ reason: ENCRYPTED_PDF }]);
    assert.equal(result.totalPages, 1);
  });

  it('uses the pdf.js page count when pdf-lib cannot count the pages', async () => {
    const failures = [];
    const bytes = new TextEncoder().encode('%PDF-1.7 pdf-lib will refuse this');
    const block = { id: 'src-x#p1.1', location: { kind: 'page', page: 1 }, text: BODY };
    const readPdfText = async () => ({ blocks: [block], capped: false, totalPages: 3, textPages: 3, noTextPages: [] });
    const result = await parseLocalFile(bytes, 'Odd.pdf', 'src-x', { readPdfText, logFailure: (d) => failures.push(d) });
    assert.equal(result.totalPages, 3);
    assert.equal(result.pagesRead, '1-3');
    assert.deepEqual(result.notRead, []);
    assert.deepEqual(failures, ['pdf page count failed; used the pdf.js count']);
  });

  it('does not claim pages beyond a capped read', async () => {
    const bytes = await pdfWithPages([BODY]);
    const blocks = [{ id: 'a#p1.1', location: { kind: 'page', page: 1 }, text: BODY }, { id: 'a#p2.1', location: { kind: 'page', page: 2 }, text: BODY }];
    const readPdfText = async () => ({ blocks, capped: true, totalPages: 5, textPages: 5, noTextPages: [4] });
    const result = await parseLocalFile(bytes, 'Big.pdf', 'a', { readPdfText });
    assert.equal(result.pagesRead, '1-2');
    assert.deepEqual(result.notRead, [{ reason: TEXT_CAP, pages: '3-5' }], 'a page past the cap is not also listed as missing a text layer');
  });

  it('keeps reporting a timeout as a timeout', async () => {
    const clock = (() => {
      let t = 0;
      return () => (t += 1000);
    })();
    const bytes = await pdfWithPages([BODY, BODY]);
    const result = await parseLocalFile(bytes, 'Slow.pdf', 'src-slow', { now: clock, budgetMs: 500 });
    assert.deepEqual(result.notRead, [{ reason: FILE_TIMEOUT }]);
  });
});

describe('the committed synthetic sources still read as before', () => {
  it('reads the RFP and the scan the same way after the thin-page rule', async () => {
    const folder = join(scratch, 'synthetic');
    cpSync(sources, folder, { recursive: true });
    const rfp = await parseLocalFile(new Uint8Array(readFileSync(join(folder, 'Fabrikam_RFP_2027.pdf'))), 'Fabrikam_RFP_2027.pdf', 'src-rfp');
    assert.deepEqual(rfp.notRead, []);
    assert.equal(rfp.blocks.length, 4);
    const scan = await parseLocalFile(new Uint8Array(readFileSync(join(folder, 'Signed_NDA_scan.pdf'))), 'Signed_NDA_scan.pdf', 'src-scan');
    assert.deepEqual(scan.notRead, [{ reason: SCANNED_PDF, pages: '1-2' }]);
  });
});
