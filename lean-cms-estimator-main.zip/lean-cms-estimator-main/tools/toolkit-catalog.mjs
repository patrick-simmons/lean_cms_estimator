import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { runCli, writeCatalog } from './catalog/cli.mjs';
import { generateToolkitCatalog, loadToolkitPin } from './catalog/generate.mjs';
import { openPinnedTree, TOOLKIT_TREE_OPTIONS } from './catalog/git-tree.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));

runCli(() => {
  const { values } = parseArgs({
    options: { toolkit: { type: 'string' }, out: { type: 'string' } },
    strict: true,
    allowPositionals: false
  });
  const pin = loadToolkitPin(root);
  const toolkitPath = values.toolkit ? resolve(values.toolkit) : resolve(root, pin.localPath);
  const output = values.out ? resolve(values.out) : join(root, 'docs', 'catalogs', 'toolkit-capability-catalog.md');
  const { text } = generateToolkitCatalog(openPinnedTree(toolkitPath, pin.commit, undefined, TOOLKIT_TREE_OPTIONS), pin);
  writeCatalog(output, text);
});
