# Delivery defaults session notes

**Date:** 2026-10-22 (skills / phases rethink); hub libraries added 2026-11-04  
**Prior:** 2026-10-20 role-mix starter  
**Estimating catalog:** version 2  
**Files:** the CSVs in `samples/factors/seed/` (story B-15 deleted the generated workbook)

## Participants

Catalog owner approved starter hours, skill mixes, and phase FTEs **on behalf of** two delivery leads for the pilot. Where leads would disagree, the more conservative hours were recorded. Named lead attribution can be filled in before hub publish if required for governance.

## Hypotheses

- All factor hours, optional opt-in/methods hours, and phase FTEs are **starter hypotheses**, not calibrated actuals from delivered projects. There is no hub Skill mix.
- Every Factors row has confidence `low` so the challenger in SPMVP-012 will surface them.
- **High-level price uses blended rates only** (hours × chosen mix). Blueprint does not hold Pricer rate ids or bill rates.
- **Role mix / Role map are deprecated.** Staffing is human delivery **skills** + **phase packs** + a skill demand schedule (SPMVP-012 rethink).
- **Hybrid effort:** phase packs size discovery / governance / hypercare (covering discovery-audit, uat-support). Build/migrate packages (content-model–12, frontend-delivery) use driver × factor; hours attribute to the **project skill set** (even split) when saved. **WP-14 Project management was removed** — PM / delivery-lead capacity is phase FTE only (technical delivery focus).
- **Blended rate** rows (rate + country + monthly hours) were seeded from a real Pricer Details export:

  | Delivery mix | Hourly rate | Country | Monthly hours | Default |
  | --- | --- | --- | --- | --- |
  | Onshore-led | 218 | USA | 153 | |
  | Balanced | 150 | USA | 153 | yes |
  | Offshore-led | 82 | India | 172 | |

- Weekly hours for phase math = monthly hours ÷ 4.
- **Skills** stay coarse: delivery seats (`pm`, `ba`, `architect`, …); platform (`aem-core` includes content craft, plus `dam`, `frontend-react`, `devops`); martech (`adobe-analytics`, `adobe-target`, `adobe-cja`, `adobe-ajo`). See `docs/spfx/delivery-skills.md`.
- Example ramp: on `build`, `architect` goes to 0.25 FTE after milestone `design-signoff`.
- Pilot platforms covered by Factors rows: `aem` and `aem-eds` only.

## Hub libraries (2026-11-04)

- `Assumption library`, `Dependency library` and `Risk library` (SPMVP-038) are starter hypotheses written for the pilot, from delivery experience. They are drafted as starter hypotheses and are not yet approved by the catalog owner; review them before hub publish.
- They carry `all`, `aem` and `aem-eds` entries and a small `aep` set. `aep` is the first non-pilot platform; it has no Factors rows.
- No client text, no cost, rate or contingency, and no `commercial` category.

## Regenerating

Edit the CSVs under `samples/factors/seed/`. There is no build step; `loadSeed` reads them and checks them.
