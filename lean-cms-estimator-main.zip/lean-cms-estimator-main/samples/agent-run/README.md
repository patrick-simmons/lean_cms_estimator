# Agent run sample

This folder is generated. Edit the inputs under `tools/samples/agent-run/` and run `node tools/samples/agent-run-sample.mjs`.

A full run of the skill pack tools on `samples/sources/synthetic-aem/` for the project **Fabrikam Outdoor**, then a review, then a
re-run after `samples/sources/synthetic-aem-addendum/Fabrikam_Addendum.docx` arrived. The extract JSON and the Context sidecar are
the model's part, written by hand against the parsed blocks (`tools/samples/agent-run/`); the tools did the rest.

| File | What it shows |
| --- | --- |
| `Fabrikam Outdoor_Blueprint.json` | The first run after review: 16 requirements, of which 6 accepted, 1 edited, 1 dismissed; one planted conflict (R-005) with two citations and no winner. Untouched by the re-run. |
| `Fabrikam Outdoor_Context.json` | The v2 sidecar the enrich stage wrote: 3 delivery unknowns, 3 assumptions, 2 dependencies, 3 delivery risks. |
| `Fabrikam Outdoor_Proposals.json` | What the re-run proposed instead of rewriting the Blueprint: 3 proposals (1 update (R-003), 1 conflict (R-009), 1 add). A restated requirement that changed nothing produced nothing. |
| `AGENTS.md`, `CLAUDE.md` | The bootstrap `prepare-folder` wrote (SAPP-016). |
| `.blueprint/run.json` | The run record (SAPP-014). |
| `.blueprint/sources.json`, `.blueprint/expect.json` | The selection and the versions the app expects. |
| `.blueprint/parsed/` | The parse tool's manifest, blocks and sources for the second parse (with the addendum). |

The source documents themselves stay under `samples/sources/`; copy them beside these files to reproduce the folder the agent saw.
