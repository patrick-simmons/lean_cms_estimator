# Offline skill pack samples

Synthetic fixtures for SPMVP-023 / SPMVP-024 / SPMVP-036. They are **not** a customer pack.

| File | Role |
| --- | --- |
| `minimal_Context.json` | Legal empty Context sidecar (`{}`) |
| `Northwind_Context.json` | Context with constraints, framing, one risk, one unknown |
| `Northwind_v2_Context.json` | Context schema version 2: risks, unknowns, assumptions and dependencies using every v2 field |
| `Synthetic_AEM_Blueprint.json` | Invented `aem` project: eight requirements (one dismissed), four questions. Input for the library matcher |
| `Synthetic_AEM_Plan_Blueprint.json` | The same invented project with a project skill set and a `phasePlan` using plan tasks: a phase `scope`, a `fixed` task, a milestone with a deliverable, a `driver` task bound to `component-build`, a `capacity` task with allocations, and a ramp that names the milestone. Used to check the task schema; `estimate` is null |
| `Synthetic_AEM_Context.json` | What the v2 enrich skill writes for that project: three unknowns each with a linked assumption, library proposals copied from the matcher, one risk with document evidence. Every item is pending |

## Naming

In a real opportunity folder, write `{Project}_Context.json` beside `{Project}_Blueprint.json` (same project title sanitization as the working file).

## Planted conflict

Acceptance for a **customer pack** (private; not in this repo) expects a planted contradiction to become one Blueprint requirement with `coverage: "conflict"` and at least two citations. That lives on `{Project}_Blueprint.json`, not on the Context sidecar.

## Validate

```bash
node tools/blueprint/validate-context.mjs samples/offline/minimal_Context.json
node tools/blueprint/validate-context.mjs samples/offline/Northwind_Context.json
node tools/blueprint/validate-context.mjs samples/offline/Northwind_v2_Context.json
```

Add `--blueprint <path-to-blueprint.json>` to also check `R-n` and `Qn` references against that Blueprint file:

```bash
node tools/blueprint/validate-context.mjs samples/offline/Northwind_v2_Context.json --blueprint <path-to-blueprint.json>
```

The Blueprint file must have `requirements` and `questions` arrays, or the command exits 1.

The synthetic AEM pair validates cleanly, with no warnings, and the matcher lists its library candidates:

```bash
node tools/blueprint/validate-working-file.mjs samples/offline/Synthetic_AEM_Blueprint.json
node tools/blueprint/validate-working-file.mjs samples/offline/Synthetic_AEM_Plan_Blueprint.json
node tools/blueprint/validate-context.mjs samples/offline/Synthetic_AEM_Context.json --blueprint samples/offline/Synthetic_AEM_Blueprint.json
node tools/blueprint/match-library.mjs samples/offline/Synthetic_AEM_Blueprint.json
```

In the Blueprint, requirement R-006 is dismissed and mentions hypercare, and only the source passage of R-008 mentions UAT. The matcher ignores both, so the support-rota and test-tenant library entries are not proposed.

Warnings go to stderr as `warning: ...` and the exit code stays 0. They cover a reference that matches nothing, a reference in no recognised form, and v2 content under another schema version. `R-n` and `Qn` references are checked only with `--blueprint`. Warnings appear only when there are no errors. Errors exit 1; a usage error exits 2.
