# **AI-Assisted CMS Estimating Engine — Transformation & Implementation Plan**

## **1\. Executive Summary & Market Positioning**

This plan outlines the architectural and methodological transformation of the Content Management System (CMS) presales estimating tool into a **multi-platform, research-driven, IDE-native estimation engine** running on **Cursor** and **Enterprise Claude**, while keeping **SharePoint** as the collaborative system of record.

### **Why Custom Tooling Is Necessary (Market Reality Check)**

Commercial presales and project-scoping platforms fall into two categories, neither of which solves technical CMS estimation:

* **AI RFP & Proposal Platforms (Responsive, Loopio, AutogenAI, SiftHub):** Excel at shredding RFPs into compliance matrices and drafting cited narrative responses, but stop at answering questions—they do not translate architectural requirements into a Work Breakdown Structure (WBS), platform-specific engineering effort, or internal delivery accelerators.  
* **PSA & Generic AI Project Estimators (Kantata, Productive, Taskade):** Convert high-level briefs into generic task boards and margin models, but lack deep CMS domain awareness (e.g., Sitecore XP-to-XM Cloud serialization overhead vs. greenfield Contentstack \+ Next.js builds) and cannot map scope against a consulting practice's proprietary IP.

By combining deterministic Node.js (`.mjs`) file processing and Excel hydration with multi-agent reasoning in Cursor and Claude, this solution bridges the exact gap between raw pursuit documents and a defensible, bottom-up consulting estimate.

## **2\. Current State & Enterprise Constraints**

### **Evolution to Date**

1. **Initial Architecture (React / SPFx \+ Local Fallback):** Built a full-stack React solution targeting SharePoint (SPFx) so estimators could work directly inside presales libraries, plus a standalone React entry point reading local folders to bypass SharePoint App Catalog deployment hurdles.  
2. **The UI Bottleneck:** Maintaining React components, state management, and UI plumbing consumed disproportionate engineering time and slowed iteration on the core estimation logic.  
3. **Current Headless Fork:** Forked the codebase to remove the UI completely—retaining `.mjs` scripts for folder preparation, document parsing, and Excel template writing alongside conversational skills executed directly inside **Cursor** and **Claude**.

### **Enterprise Boundaries & Non-Negotiables**

* **SharePoint Is Mandatory for Collaboration:** Pursuit files (RFPs, client emails, decks, spreadsheets) already live in SharePoint, and presales teams collaborate there. Estimates and assumptions must sync back to SharePoint rather than staying stranded on individual hard drives.  
* **Copilot Studio Is Blocked:** Tenant approval for Copilot Studio is unavailable and unlikely in the near term, ruling out M365-hosted agent orchestration.  
* **Cursor & Enterprise Claude Are Approved:** Both tools are licensed and approved for enterprise use (with Cursor as the standard engineering IDE), providing zero-friction adoption with no IT deployment gates.

### **Core Limitations to Resolve**

| Limitation | Current Symptom | Impact on Estimates |
| ----- | ----- | ----- |
| **Single-Platform Lock-In** | Capability mappings and architectural logic only cover **Adobe Experience Manager (AEM)**. | Cannot reliably estimate Sitecore (XP / XM Cloud), Drupal, Contentful, Contentstack, Sanity, or custom headless pursuits. |
| **Mechanical Estimation Logic** | Skills rely on hardcoded baselines (e.g., fixed discovery durations, flat hours per component or activity). | Produces rigid, formulaic outputs that fail to reflect real architectural complexity, legacy debt, or integration risk. |
| **Missing Autonomous Intelligence** | Skills do not research platform-specific traps, prioritize missing client info, or separate IP savings from GenAI coding velocity. | Estimators still have to manually adjust hours for hidden platform constraints and realistic AI productivity gains. |

## **3\. Goals, Objectives & Success Criteria**

| Objective | Target Outcome | Measurable Success Criteria |
| ----- | ----- | ----- |
| **Zero-Friction Enterprise Workflow** | Combine SharePoint team collaboration with local Cursor/Claude execution—requiring zero IT or App Catalog approvals. | Estimators run the pipeline inside OneDrive-synced SharePoint pursuit folders; `.xlsx` and `.md` deliverables sync automatically to the team library. |
| **Multi-CMS Extensibility** | Support AEM, Sitecore, Drupal, and major headless platforms without bloating core skill instructions. | Adding a new CMS platform or internal accelerator requires adding a declarative Markdown card—zero changes to `.mjs` scripts or core agent prompts. |
| **Citation-Backed, Non-Mechanical Sizing** | Replace static hour lookups with quantitative scope drivers, live technical research, and adversarial review. | Every WBS line item traces to an immutable document citation (`[DOC-ID, p.X]`) or explicit assumption, vetted across Lean vs. Conservative passes. |
| **Dual-Track Acceleration Modeling** | Separate and quantify savings from proprietary practice tools versus GenAI engineering/migration tooling. | Excel outputs clearly display **Raw Effort**, **Proprietary IP Savings**, **GenAI Velocity Savings**, and **Net Estimated Hours** per task. |
| **Deterministic Excel Hydration** | Keep file parsing, JSON validation, and workbook population 100% deterministic via `.mjs` scripts. | Populated `.xlsx` workbooks preserve all corporate formulas, macros, styling, and role rate-card lookups without LLM formatting errors. |

## **4\. Proposed Solution: The Hybrid Pursuit Workspace**

To keep SharePoint as the collaborative single source of truth while giving estimators instant execution in Cursor and Claude, decouple **the Engine (central Git repo)** from **the Pursuit Data (OneDrive-synced SharePoint folder)**.

Using the open `.agents/skills/` standard (`SKILL.md` \+ `references/` \+ `scripts/`) alongside a root `AGENTS.md` file ensures every skill and rule loads natively in both **Cursor** and **Claude Code** without maintaining duplicate prompt trees.

### **Repository & Workspace Blueprint**

├── cms-estimator-kit/                      \# Central Git Repo (Cloned once per estimator; updated via git pull)  
│   ├── AGENTS.md                           \# Ambient workspace rules, citation standards, and pipeline invariants  
│   ├── .agents/  
│   │   └── skills/                         \# Cross-compatible skills (loaded natively by Cursor & Claude)  
│   │       ├── shred/SKILL.md              \# Stage 1: Document chunking & scope-driver extraction  
│   │       ├── clarify/SKILL.md            \# Stage 1: Missing driver detection & variance-ranked Q\&A  
│   │       ├── research-stack/SKILL.md     \# Stage 2: Platform profile loading & live complexity research  
│   │       ├── scout-accelerators/SKILL.md \# Stage 2: Proprietary IP matching & GenAI velocity modeling  
│   │       ├── debate-estimate/SKILL.md    \# Stage 3: Lean vs. Conservative debate & Best-Practices audit  
│   │       └── export-estimate/SKILL.md    \# Stage 4: Three-point reconciliation & Excel hydration  
│   ├── knowledge/                          \# Declarative domain intelligence (loaded dynamically on demand)  
│   │   ├── platforms/                      \# aem.md, sitecore-xm-cloud.md, drupal.md, contentful.md, contentstack.md, generic-headless.md  
│   │   ├── accelerators/                   \# Modular cards for starter kits, connectors, migration utilities  
│   │   └── benchmarks/                     \# genai-velocity-bands.md, phase-ratio-guardrails.md  
│   ├── scripts/                            \# Deterministic Node.js (.mjs) pipeline  
│   │   ├── init-pursuit.mjs                \# Scaffolds .estimator/ folder and validates inputs  
│   │   ├── chunk-docs.mjs                  \# Parses PDF, DOCX, PPTX, XLSX, EML/MSG into cited chunks  
│   │   ├── validate-state.mjs              \# Enforces JSON schema compliance across stages 01–07  
│   │   └── export-excel.mjs                \# Hydrates master .xlsx template from 07-final-estimate.json  
│   └── templates/                          \# Corporate .xlsx estimate workbook & JSON schemas  
│  
└── SharePoint \- Client Pursuit Folder/     \# Synced locally via OneDrive ("Add shortcut to OneDrive" / Sync)  
    ├── 01-Client-Docs/                     \# Raw RFPs, RFIs, decks, emails, spreadsheets (read-only inputs)  
    ├── .estimator/                         \# Hidden working directory for pipeline JSON state  
    │   ├── 01-chunks-index.json            \# Normalized text chunks with immutable citation IDs  
    │   ├── 02-scope-drivers.json           \# Quantitative volumes, integrations, locales, constraints  
    │   ├── 03-client-questions.json        \# Clarification questions ranked by hour-variance impact  
    │   ├── 04-complexity-profile.json      \# Platform traps, risk multipliers, architectural notes  
    │   ├── 05-accelerators.json            \# Applied proprietary IP \+ discipline-specific GenAI savings  
    │   ├── 06a-estimate-lean.json          \# Optimistic / competitive floor estimate  
    │   ├── 06b-estimate-conservative.json  \# Risk-adjusted critique & friction estimate  
    │   ├── 06c-audit-findings.json         \# Best-Practices Auditor ratio & dependency checks  
    │   └── 07-final-estimate.json          \# Reconciled Three-Point (Low / Most Likely / High) WBS  
    ├── CMS-Estimate-Draft.xlsx             \# Clean deliverable synced automatically to SharePoint team  
    └── Estimation-Assumptions.md           \# Executive companion doc (drivers, risks, IP, client Q\&A)

### **How the Team Workflow Operates**

1. **Sync Pursuit Folder:** Estimator clicks **Add shortcut to OneDrive** (or **Sync**) on the SharePoint pursuit library.  
2. **Run Pipeline in Cursor / Claude:** Estimator opens the synced pursuit folder in Cursor (or points Claude Code to its path) and runs the staged skills (`/shred` through `/export-estimate`).  
3. **Automatic SharePoint Sync:** Intermediate JSON state stays neatly tucked inside `.estimator/`, while `CMS-Estimate-Draft.xlsx` and `Estimation-Assumptions.md` sync straight back to SharePoint for immediate review by the pursuit lead and delivery architects.  
4. **Optional Phase 2+ Upgrade:** Add a lightweight local **Microsoft Graph MCP Server** using delegated user authentication so estimators can browse and pull SharePoint libraries directly by URL without manual OneDrive syncing.

## **5\. Core Estimation Engine: The Three-Layer Estimation Model**

To eliminate mechanical, lookup-table behavior, the estimation engine separates structural constants from dynamic architectural reasoning across three layers:

### **Layer 1: Structural Anchors (Deterministic JSON & Excel Schema)**

Only the skeleton of the estimate is fixed in code and templates:

* **Standard WBS Phases:** Discovery & Alignment, Solution Architecture, Core Platform & DevOps Setup, Content Modeling & Component Engineering, Third-Party Integrations, Content & Asset Migration, QA & Accessibility (WCAG), and Cutover & Hypercare.  
* **Role & Rate-Card Mapping:** Standardized delivery roles (Solution Architect, Lead CMS Engineer, Frontend Engineer, Backend/Integration Engineer, QA/Accessibility Specialist, Content Strategist, Project Manager) mapped to exact cells in the corporate `.xlsx` template.

### **Layer 2: Scope-Driver Decomposition & Live Intelligence**

Skills are prohibited from assigning flat hour totals to phases. Instead, they must decompose the RFP into **concrete quantitative drivers** and conduct targeted research before sizing any task:

* **Content & Authoring Drivers:** Number of content types/templates, multi-site/multi-brand inheritance rules, locale count and translation workflows (e.g., XLIFF/TMS connectors vs. manual), granular RBAC/approval workflows, and DAM asset volumes.  
* **Frontend & Experience Drivers:** Distinct component count, interactive complexity (static marketing vs. authenticated portals, calculators, or personalization), design system maturity (Figma tokens ready vs. net-new), and WCAG level (A, AA, AAA).  
* **Integration & Migration Drivers:** Count and maturity of external systems (CRM, ERP, Search/Algolia/Coveo, Auth/SSO, Commerce, Analytics), API protocols (modern REST/GraphQL vs. legacy SOAP/batch), and source content cleanliness (structured API/XML export vs. unstructured HTML scraping).  
* **Autonomous Live Research:** Skills use web search inside Cursor/Claude to check current CMS version lifecycles, deprecation traps, API rate limits, and connector maturity for the exact stack mentioned in the pursuit.

### **Layer 3: Sequential Adversarial Calibration**

Rather than trusting a single-pass LLM estimate, specialized skills challenge and audit the numbers sequentially before they reach Excel:

1. **Lean Estimator** sets the competitive floor.  
2. **Conservative Estimator** critiques the Lean estimate line-by-line against risk signals and missing requirements.  
3. **Best-Practices Auditor** validates phase ratios and architectural dependencies.  
4. **Estimate Reconciler** synthesizes a **Three-Point Estimate (Low / Most Likely / High)** with full citation trails.

## **6\. Comprehensive 6-Stage Agent & Skill Roster**

Each skill lives in `.agents/skills/<skill-name>/SKILL.md`, reads the previous stage's JSON artifact from `.estimator/`, and writes a validated JSON output for the next stage.

### **Stage Overview Table**

| Stage | Skill Name | Primary Role | Input Artifact(s) | Output Artifact |
| ----- | ----- | ----- | ----- | ----- |
| **1A** | **`shred`** | Citation & Scope-Driver Extractor | `01-Client-Docs/*` | `01-chunks-index.json` `02-scope-drivers.json` |
| **1B** | **`clarify`** | Gap & Risk Question Researcher | `01-chunks-index.json` `02-scope-drivers.json` | `03-client-questions.json` |
| **2A** | **`research-stack`** | Platform & Complexity Researcher | `02-scope-drivers.json` `knowledge/platforms/*.md` | `04-complexity-profile.json` |
| **2B** | **`scout-accelerators`** | Proprietary IP & GenAI Velocity Scout | `02-scope-drivers.json` `04-complexity-profile.json` `knowledge/accelerators/*.md` | `05-accelerators.json` |
| **3** | **`debate-estimate`** | Lean Estimator, Conservative Estimator & Best-Practices Auditor | `02` through `05` JSON files | `06a-estimate-lean.json` `06b-estimate-conservative.json` `06c-audit-findings.json` |
| **4** | **`export-estimate`** | Three-Point Reconciler & Excel Hydrator | `06a`, `06b`, `06c` JSON files `templates/*.xlsx` | `07-final-estimate.json` `CMS-Estimate-Draft.xlsx` `Estimation-Assumptions.md` |

### **Detailed Skill Specifications**

#### **1A. `shred` — Citation & Scope-Driver Extractor**

* **Deterministic Step:** Invokes `scripts/chunk-docs.mjs` to parse all PDFs, Word docs, PowerPoints, Excel sheets, and email files into normalized text segments with immutable citation IDs (e.g., `[RFP-01, p.14]`, `[Email-03, msg-2]`, `[TechReq-XLSX, Tab:API, R18]`).  
* **Reasoning Step:** Extracts functional requirements, non-functional constraints (SLAs, security/SOC2/HIPAA, hosting), quantitative volumes (pages, components, locales, integrations, assets), and explicit or implied CMS/frontend tech stacks.  
* **Rule:** Every extracted driver must carry at least one citation ID. If a standard CMS driver (e.g., locale count or search provider) is absent from all documents, it is explicitly recorded as `"status": "unstated"`.

#### **1B. `clarify` — Gap & Risk Question Researcher**

* **Mandate:** Inspects `"unstated"` and ambiguous entries in `02-scope-drivers.json` to uncover hidden scope bombs before pricing is locked.  
* **Prioritization Logic:** Ranks every client clarification question by **Potential Hour-Variance Impact** (`High`, `Medium`, `Low`)—for example, whether an undisclosed translation requirement needs automated TMS integration vs. manual copy-paste can swing effort by 150+ hours.  
* **Output:** Generates `03-client-questions.json` containing the targeted question, why it matters technically, the default assumption the estimator will make if unanswered, and the estimated hour swing.

#### **2A. `research-stack` — Platform & Complexity Researcher**

* **Knowledge Loading:** Detects the target CMS (or evaluates candidate platforms if the RFP is CMS-agnostic) and dynamically loads the matching `knowledge/platforms/<cms>.md` profile.  
* **Live Web Research:** Performs targeted searches on the exact CMS version, hosting topology (e.g., AEM as a Cloud Service vs. AMS, Sitecore XM Cloud vs. XP, Drupal 10/11, Contentful/Contentstack tier limits), and named third-party integrations to identify deprecated APIs, licensing ceilings, or known migration bottlenecks.  
* **Output:** Produces `04-complexity-profile.json` assigning workstream-specific complexity multipliers (`1.0x` standard to `2.5x` high friction) backed by cited RFP signals and technical findings.

#### **2B. `scout-accelerators` — Proprietary IP & GenAI Velocity Scout**

To prevent unrealistic blanket AI discounts (such as claiming AI cuts an entire CMS build by 50%), this skill models acceleration across **two independent dimensions** per WBS activity:

| Acceleration Dimension | How It Is Evaluated | Typical Effort Reduction Band |
| ----- | ----- | ----- |
| **1\. Proprietary Practice Accelerators** | Matches requirements against `knowledge/accelerators/*.md` (starter kits, pre-built auth/search connectors, content migration pipelines, design-system bridges) and verifies all applicability prerequisites. | **15% – 60%** on matched workstreams (0% if prerequisites fail, e.g., unstructured HTML scraping). |
| **2\. GenAI Engineering & Migration Velocity** | Applies discipline-specific AI coding, test-generation, and data-transformation benchmarks (`knowledge/benchmarks/genai-velocity-bands.md`) validated via live research. | • **Frontend scaffolding & unit/E2E tests:** 30% – 50% • **Content schema & migration scripts:** 25% – 45% • **Complex ERP/legacy integrations:** 10% – 20% • **Discovery workshops, Infosec & client UAT:** 0% – 10% |

* **Output:** Writes `05-accelerators.json` detailing **Raw Baseline Hours**, **Proprietary IP Hours Saved**, **GenAI Velocity Hours Saved**, and **Net Accelerated Hours** for every task.

#### **3\. `debate-estimate` — Sequential Adversarial Calibration (3 Sub-Roles)**

Runs three distinct passes in sequence so every number is stress-tested:

1. **Pass 1 — Lean / Aggressive Estimator (`06a-estimate-lean.json`):** Models the optimal delivery path—assumes clean source content, maximum out-of-the-box CMS capabilities, full reuse of matched proprietary accelerators, high GenAI coding velocity, and rapid client sign-offs. Establishes the **Competitive Floor**.  
2. **Pass 2 — Conservative / Risk Estimator (`06b-estimate-conservative.json`):** Reads `06a-estimate-lean.json` alongside `01-chunks-index.json` and `04-complexity-profile.json` and **must challenge specific line items**. Every upward adjustment requires an explicit argument citing RFP friction (e.g., *"Lean allocates 24 hrs for SSO using our OIDC starter kit, but `[Email-04]` specifies legacy SAML with custom AD group-to-role mapping—adjusting to 64 hrs"*). Establishes the **Risk Ceiling**.  
3. **Pass 3 — Best-Practices Auditor (`06c-audit-findings.json`):** Acts as a Principal Delivery Architect reviewing both estimates against `knowledge/benchmarks/phase-ratio-guardrails.md`. Flags structural anomalies such as:  
   * QA/Accessibility hours falling below 18–22% of engineering build hours.  
   * Discovery/Architecture falling below 12–15% on multi-integration or migration-heavy builds.  
   * Missing allocations for CI/CD environment setup, content author training, runbooks, or post-launch hypercare.

#### **4\. `export-estimate` — Three-Point Reconciler & Excel Hydrator**

* **Synthesis:** Reconciles `06a`, `06b`, and `06c` into `07-final-estimate.json`, calculating **Low**, **Most Likely** (weighted toward Lean or Conservative based on the Complexity Profile score), and **High** hours per line item.  
* **Traceability:** Formats concise, high-signal audit notes for each WBS row containing the citation IDs, applied accelerators, GenAI velocity % applied, and key Conservative risk flags.  
* **Deterministic Output:** Runs `scripts/validate-state.mjs` and `scripts/export-excel.mjs` to hydrate `CMS-Estimate-Draft.xlsx`, and writes `Estimation-Assumptions.md` to the root of the synced SharePoint folder.

## **7\. Declarative Knowledge Base Architecture**

Keeping domain rules in modular Markdown files inside `knowledge/` allows the practice to expand across platforms without touching code or bloating agent context windows.

### **Platform Profile Template (`knowledge/platforms/<cms>.md`)**

\---  
platform: Sitecore XM Cloud  
category: Composable / Headless PaaS  
supported\_frontends: \[Next.js, Astro, .NET Core\]  
\---

\# Platform Profile: Sitecore XM Cloud

\#\# 1\. Architectural Strengths (Where OOTB Saves Effort)  
\- Built-in Pages visual editor, SXA headless components, and Vercel/Netlify hosting integration.  
\- Sitecore Content Serialization (SCS) streamlines developer item promotion across environments.

\#\# 2\. Complexity Traps & Hidden Effort Drivers  
\- \*\*XP-to-XM Cloud Migrations:\*\* Custom C\# pipelines, MVC renderings, and xDB/xConnect customizations do NOT lift-and-shift; require full re-architecture to webhooks/Next.js API routes (add 1.4x–1.8x multiplier on legacy migration tasks).  
\- \*\*GraphQL Edge Rate Limits & Layout Service:\*\* Deeply nested component datasources can trigger payload bloat; requires careful GraphQL query optimization.  
\- \*\*Multi-Site / Shared Content:\*\* Cross-site datasource sharing requires strict site-collection governance upfront.

\#\# 3\. Mandatory Discovery & Clarification Triggers  
\- Confirm whether legacy Sitecore XP personalization rules or xDB historical analytics must be migrated.  
\- Verify target frontend hosting (Vercel Enterprise vs. Azure Static Web Apps) and preview environment count.

### **Proprietary Accelerator Template (`knowledge/accelerators/<tool-name>.md`)**

\---  
accelerator\_id: ACC-MIG-01  
name: Universal Structured Content Migration Pipeline  
applicable\_platforms: \[AEM, Sitecore XM Cloud, Drupal, Contentful, Contentstack\]  
\---

\# Accelerator: Universal Structured Content Migration Pipeline

\#\# Capabilities  
\- Node.js/TypeScript ETL framework with automated HTML-to-Rich-Text/JSON AST conversion, DAM asset ingestion, link rewriting, and validation reporting.

\#\# Applicability Prerequisites (All Must Be Met)  
1\. Source content is accessible via structured API, database dump, XML/JSON export, or clean sitemap crawl.  
2\. Target content models are frozen prior to migration script execution.

\#\# Effort Reduction Impact  
\- \*\*When Prerequisites Met:\*\* Reduces Content Migration engineering effort by \*\*35% – 50%\*\*.  
\- \*\*When Prerequisites Fail:\*\* \*\*0% reduction\*\* (e.g., unauthenticated legacy portals requiring custom headless-browser scraping or heavy manual editorial cleanup).

## **8\. Data Pipeline & State Contracts (`.estimator/`)**

To prevent context drift across long pursuits and keep `.mjs` scripts deterministic, all intermediate artifacts in `.estimator/` must conform to strict JSON contracts:

| File | Key Schema Fields | Validation Rule (`validate-state.mjs`) |
| ----- | ----- | ----- |
| `01-chunks-index.json` | `chunk_id`, `source_file`, `location` (page/slide/sheet/row), `text`, `token_count` | Every chunk ID must be unique and immutable across re-runs. |
| `02-scope-drivers.json` | `driver_id`, `category`, `description`, `quantity`, `unit`, `citations[]`, `status` (`confirmed` / `inferred` / `unstated`) | `confirmed` items require `citations.length >= 1`. |
| `03-client-questions.json` | `question_id`, `question`, `impact_level`, `estimated_hour_swing`, `default_assumption`, `related_driver_ids[]` | Sorted descending by `estimated_hour_swing`. |
| `04-complexity-profile.json` | `detected_stack`, `workstream_multipliers[]` (`phase`, `multiplier`, `rationale`, `citations[]`), `research_notes[]` | Multipliers bounded between `1.0` and `2.5`. |
| `05-accelerators.json` | `task_id`, `raw_hours`, `matched_accelerators[]`, `ip_hours_saved`, `genai_velocity_pct`, `genai_hours_saved`, `net_hours` | `net_hours == raw_hours - ip_hours_saved - genai_hours_saved` (floored at 0). |
| `06a` & `06b` Estimates | `wbs_items[]` (`task_id`, `phase`, `role`, `hours`, `assumptions`, `citations[]`, `challenge_notes`) | Every item in `06b` must reference its counterpart `task_id` in `06a`. |
| `07-final-estimate.json` | `wbs_items[]` (`task_id`, `phase`, `task_name`, `role`, `low_hours`, `likely_hours`, `high_hours`, `ip_savings`, `genai_savings`, `audit_trail`) | `low_hours <= likely_hours <= high_hours`; maps 1:1 to Excel template columns. |

## **9\. Phased Implementation Roadmap (15-Day Transformation)**

### **Phase 1: Repository Hygiene & Schema Lock (Days 1–2)**

* **Audit Existing `.mjs` Scripts:** Separate deterministic document parsing and Excel population from any hardcoded AEM hour baselines embedded in scripts.  
* **Establish Cross-Tool Repo Layout:** Set up `AGENTS.md`, `.agents/skills/`, `knowledge/`, `scripts/`, and `templates/` so Cursor and Claude Code load all skills natively.  
* **Build `validate-state.mjs`:** Enforce the JSON contracts for `.estimator/01` through `07`.  
* **Verify OneDrive/SharePoint Sync:** Test `init-pursuit.mjs` and `export-excel.mjs` inside a OneDrive-synced SharePoint test folder to confirm clean deliverable syncing.

### **Phase 2: Declarative Knowledge Extraction & Multi-CMS Cards (Days 3–5)**

* **Extract Existing AEM Logic:** Migrate AEM capability mappings and accelerator rules out of old prompts into `knowledge/platforms/aem.md` and `knowledge/accelerators/aem-*.md`.  
* **Author Multi-CMS Platform Profiles:** Create standardized Markdown profiles for:  
  * `sitecore-xm-cloud.md` (including XP-to-XM Cloud migration patterns)  
  * `drupal.md` (Drupal 10/11, contributed module upgrade debt, decoupled vs. Layout Builder)  
  * `contentful.md` & `contentstack.md` (content type/environment limits, Next.js/Vercel rendering topologies)  
  * `generic-headless.md` (Sanity, Strapi, Kontent.ai baseline rules)  
* **Codify Practice Accelerators & Benchmarks:** Document internal starter kits, connectors, and migration utilities in `knowledge/accelerators/`, plus `genai-velocity-bands.md` and `phase-ratio-guardrails.md` in `knowledge/benchmarks/`.

### **Phase 3: Rewriting Skills from Mechanical to Adversarial (Days 6–9)**

* **Remove Hardcoded Baselines:** Strip static phase durations out of skill prompts; enforce citation-backed bottom-up sizing from `02-scope-drivers.json`.  
* **Implement Live Research Directives:** Configure `research-stack` and `scout-accelerators` to run targeted web verification on CMS lifecycles, API constraints, and current GenAI velocity benchmarks before computing hours.  
* **Implement Sequential Adversarial Debate:** Build `debate-estimate` so the Conservative Estimator explicitly challenges `06a-estimate-lean.json` line-by-line, followed by automated phase-ratio checks from the Best-Practices Auditor.

### **Phase 4: Three-Point Excel Hydration & Traceability (Days 10–12)**

* **Upgrade `export-excel.mjs`:** Map `07-final-estimate.json` into the corporate `.xlsx` template with dedicated columns for **Raw Hours**, **IP Accelerator Savings**, **GenAI Velocity Savings**, **Low**, **Most Likely**, and **High** hours.  
* **Embed Inline Audit Trails:** Populate the Excel notes/rationale column with citation IDs (`[RFP-02, p.8]`), applied accelerator names, and Conservative risk callouts so deal reviewers can verify every number immediately.  
* **Automate `Estimation-Assumptions.md`:** Generate a clean executive summary covering top scope drivers, prioritized client clarification questions, complexity multipliers, and recommended practice IP.

### **Phase 5: Shadow Pilot & Practice Calibration (Days 13–15)**

* **Historical Pursuit Replay:** Run the end-to-end pipeline against 2–3 recently completed pursuits (spanning at least two distinct CMS platforms) and compare **Most Likely** and **High** estimates against actual scoped/delivered hours.  
* **Tune Multipliers & Cards:** Refine platform complexity multipliers, accelerator reduction bands, and ratio guardrails based on variance analysis.  
* **Practice Rollout:** Publish a 1-page Quickstart guide in the repo README covering OneDrive folder sync, `git pull` updates, and running `/shred` through `/export-estimate` in Cursor or Claude.

## **10\. Immediate Next Step: Phase 1 Codebase Audit Checklist**

To kick off **Phase 1**, inspect and share the following artifacts from the current headless fork:

1. **Directory Tree:** Current folder layout of the forked repository.  
2. **`.mjs` Scripts:** Current folder-prep, document-chunking, and Excel-writing scripts (to isolate any embedded AEM estimation rules).  
3. **Existing Skill / Prompt Files:** Current AEM capability mappings and agent instructions.  
4. **Target Excel Workbook Structure:** Sheet names, column headers, and formula cells in the practice's standard `.xlsx` estimating template.

