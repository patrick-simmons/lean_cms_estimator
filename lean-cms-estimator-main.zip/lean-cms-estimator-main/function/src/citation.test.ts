import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { baseName, blockId, citationLabel, splitHeading } from './citation';

describe('baseName', () => {
  it('drops only the last extension', () => {
    assert.equal(baseName('Northwind_RFP_2026.pdf'), 'Northwind_RFP_2026');
    assert.equal(baseName('a.b.docx'), 'a.b');
    assert.equal(baseName('.env'), '.env');
    assert.equal(baseName('notes'), 'notes');
  });
});

describe('splitHeading', () => {
  it('splits a printed section number from the heading', () => {
    assert.deepEqual(splitHeading('3.6.1 Hosting'), { section: '3.6.1', heading: 'Hosting' });
    assert.deepEqual(splitHeading('4. Search'), { section: '4', heading: 'Search' });
    assert.deepEqual(splitHeading('Scope'), { heading: 'Scope' });
  });
});

describe('citationLabel', () => {
  it('labels a PDF page with its section', () => {
    assert.equal(
      citationLabel('Northwind_RFP_2026.pdf', { kind: 'page', page: 38, heading: 'Hosting', section: '3.6.1' }),
      'Northwind_RFP_2026 p.38 \u00A73.6.1'
    );
    assert.equal(citationLabel('Workshop.pdf', { kind: 'page', page: 6 }), 'Workshop p.6');
    assert.equal(citationLabel('RFP.pdf', { kind: 'page', page: 12, pageEnd: 13 }), 'RFP p.12\u201313');
  });

  it('labels a Word section with an approximate page', () => {
    assert.equal(
      citationLabel('Spec.docx', { kind: 'section', section: '3.6.1', heading: 'Hosting' }),
      'Spec \u00A73.6.1 Hosting'
    );
    assert.equal(
      citationLabel('Spec.docx', { kind: 'section', page: 12, pageApprox: true, section: '3.6.1', heading: 'Hosting' }),
      'Spec p.~12 \u00A73.6.1 Hosting'
    );
    assert.equal(citationLabel('Spec.docx', { kind: 'section' }), 'Spec opening text');
    const long = citationLabel('Spec.docx', { kind: 'section', heading: 'x'.repeat(80) });
    assert.equal(long, `Spec ${'x'.repeat(60)}\u2026`);
  });

  it('labels slides, notes and sheet rows', () => {
    assert.equal(citationLabel('Kickoff_deck.pptx', { kind: 'slide', slide: 14 }), 'Kickoff_deck slide 14');
    assert.equal(citationLabel('Kickoff_deck.pptx', { kind: 'slide', slide: 1, notes: true }), 'Kickoff_deck slide 1 notes');
    assert.equal(
      citationLabel('Inventory.xlsx', { kind: 'sheet', sheet: 'Inventory', rowStart: 2, rowEnd: 21 }),
      'Inventory Inventory rows 2\u201321'
    );
    assert.equal(
      citationLabel('Inventory.xlsx', { kind: 'sheet', sheet: 'Inventory', rowStart: 14, rowEnd: 14 }),
      'Inventory Inventory row 14'
    );
  });
});

describe('blockId', () => {
  it('joins the item id and the anchor', () => {
    assert.equal(blockId('item-1', 'p38.2'), 'item-1#p38.2');
  });
});
