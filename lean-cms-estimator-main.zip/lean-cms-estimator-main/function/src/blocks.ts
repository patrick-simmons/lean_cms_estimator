export type LocationKind = 'page' | 'section' | 'slide' | 'sheet';

export interface IPagedFields {
  page?: number;
  pageEnd?: number;
  pageApprox?: boolean;
  heading?: string;
  section?: string;
}

export interface IPageLocation extends IPagedFields {
  kind: 'page';
}

export interface ISectionLocation extends IPagedFields {
  kind: 'section';
}

export interface ISlideLocation {
  kind: 'slide';
  slide: number;
  slideTitle?: string;
  notes?: boolean;
}

export interface ISheetLocation {
  kind: 'sheet';
  sheet: string;
  rowStart: number;
  rowEnd: number;
}

export type ISourceLocation = IPageLocation | ISectionLocation | ISlideLocation | ISheetLocation;

export interface IBlock {
  id: string;
  fileName: string;
  itemId: string;
  label: string;
  location: ISourceLocation;
  text: string;
}

export interface INotRead {
  reason: string;
  pages?: string;
}

export interface IParseBody {
  runId: string;
  status: 'accepted';
  blocks: IBlock[];
  notRead: INotRead[];
  pagesRead?: string;
  totalPages?: number;
  nextPage?: number;
  carryHeading?: string;
}

export interface IErrorBody {
  error: string;
}

export const PARSE_BUDGET_MS = 180000;
export const MAX_PASSAGE_CHARS = 1500;
export const MAX_TEXT_CHARS = 5000000;

export const UNSUPPORTED = 'This file type is not supported.';
export const LEGACY_OFFICE = 'This is a legacy binary or encrypted Office file. Save it as .docx, .pptx or .xlsx without a password.';
export const XLSB = 'Excel binary workbooks (.xlsb) cannot be read. Save it as .xlsx.';
export const UNSAFE = 'The file could not be read safely.';
export const DAMAGED = 'The file could not be read. It may be damaged.';
export const LAYOUT_FAILED = 'Document Intelligence could not read these pages.';
export const LAYOUT_TIMEOUT = 'Reading these pages took too long.';
export const TEXT_CAP = 'This part of the file has more text than one read can keep. The rest was not read.';
export const FILE_TIMEOUT = 'Reading this file took too long.';
export const NO_TEXT = 'No readable text was found.';
export const MISSING_PARTS = 'Some slides or sheets in this file could not be found.';
export const LAYOUT_UNAVAILABLE = 'Document Intelligence could not be reached or refused access.';
