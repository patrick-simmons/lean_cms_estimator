import { IPagedFields, ISourceLocation } from './blocks';

const EN_DASH = '\u2013';
const ELLIPSIS = '\u2026';
const MAX_HEADING_IN_LABEL = 60;
const HEADING_NUMBER = /^(\d+(?:\.\d+)*)\.?\s+(.+)$/;

export function baseName(fileName: string): string {
  const name = fileName.trim();
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(0, dot) : name;
}

export function splitHeading(text: string): { section?: string; heading: string } {
  const trimmed = text.trim();
  const match = HEADING_NUMBER.exec(trimmed);
  if (match) {
    return { section: match[1], heading: match[2].trim() };
  }
  return { heading: trimmed };
}

function pagePart(location: IPagedFields): string | undefined {
  if (location.page === undefined) {
    return undefined;
  }
  const approx = location.pageApprox ? '~' : '';
  if (location.pageEnd !== undefined && location.pageEnd > location.page) {
    return `p.${approx}${location.page}${EN_DASH}${location.pageEnd}`;
  }
  return `p.${approx}${location.page}`;
}

function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max).trimEnd()}${ELLIPSIS}` : text;
}

export function citationLabel(fileName: string, location: ISourceLocation): string {
  const parts: string[] = [baseName(fileName)];
  if (location.kind === 'slide') {
    parts.push(`slide ${location.slide}`);
    if (location.notes) {
      parts.push('notes');
    }
    return parts.join(' ');
  }
  if (location.kind === 'sheet') {
    const start = location.rowStart;
    const end = location.rowEnd;
    parts.push(location.sheet);
    parts.push(end > start ? `rows ${start}${EN_DASH}${end}` : `row ${start}`);
    return parts.filter((part) => part.length > 0).join(' ');
  }

  const page = pagePart(location);
  if (page) {
    parts.push(page);
  }
  if (location.section) {
    parts.push(`\u00A7${location.section}`);
  }
  if (location.kind === 'section') {
    if (location.heading) {
      parts.push(truncate(location.heading, MAX_HEADING_IN_LABEL));
    } else if (!page && !location.section) {
      parts.push('opening text');
    }
  }
  return parts.join(' ');
}

export function blockId(itemId: string, anchor: string): string {
  return `${itemId}#${anchor}`;
}
