import { PDFDocument } from 'pdf-lib';

export async function pdfWithPages(count: number): Promise<Uint8Array> {
  const document = await PDFDocument.create();
  for (let index = 0; index < count; index++) {
    document.addPage([72, 72]);
  }
  return document.save();
}
