import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { pdfWithPages } from './pdf.fixture';
import { clampRange, countPdfPages } from './pdfPages';

describe('countPdfPages', () => {
  it('counts the pages of a generated PDF', async () => {
    assert.deepEqual(await countPdfPages(await pdfWithPages(1)), { kind: 'ok', total: 1 });
    assert.deepEqual(await countPdfPages(await pdfWithPages(150)), { kind: 'ok', total: 150 });
  });

  it('reports garbage as damaged', async () => {
    assert.deepEqual(await countPdfPages(new TextEncoder().encode('%PDF-1.7 not really')), { kind: 'damaged' });
  });
});

describe('clampRange', () => {
  it('defaults, clamps and caps the range', () => {
    assert.deepEqual(clampRange('', 150), { kind: 'range', start: 1, end: 25 });
    assert.deepEqual(clampRange('140-200', 150), { kind: 'range', start: 140, end: 150 });
    assert.deepEqual(clampRange('1-200', 150), { kind: 'range', start: 1, end: 25 });
    assert.deepEqual(clampRange('7', 150), { kind: 'range', start: 7, end: 7 });
    assert.deepEqual(clampRange('1-25', 3), { kind: 'range', start: 1, end: 3 });
  });

  it('reports a range past the end', () => {
    assert.deepEqual(clampRange('151-175', 150), { kind: 'pastEnd' });
  });
});
