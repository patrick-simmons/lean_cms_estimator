import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { DAMAGED, FILE_TIMEOUT, UNSAFE, UNSUPPORTED, XLSB } from '../blocks';
import { contentTypes, docxFixture, patchDeclaredSize, pptxFixture, relationships, storedZipOf, xlsxFixture, zipOf } from './ooxml.fixture';
import { UnsafeContentError } from './xml';
import { openOoxml, resolveTarget } from './ooxml';

const noBudget = (): void => undefined;

describe('openOoxml', () => {
  it('detects Word, PowerPoint and Excel packages', () => {
    const docx = openOoxml(docxFixture({ body: '<w:p/>' }), noBudget);
    assert.equal(docx.kind, 'docx');
    assert.equal(docx.kind === 'docx' && docx.main, 'word/document.xml');
    assert.equal(openOoxml(pptxFixture({ slides: [{ file: 1, shapes: '' }], order: [1] }), noBudget).kind, 'pptx');
    assert.equal(openOoxml(xlsxFixture({ sheets: [{ name: 'S', rows: '' }] }), noBudget).kind, 'xlsx');
  });

  it('reports xlsb and non-Office zips as not read', () => {
    const xlsb = zipOf({
      '[Content_Types].xml': contentTypes([{ part: 'xl/workbook.bin', type: 'application/vnd.ms-excel.sheet.binary.macroEnabled.main' }]),
      'xl/workbook.bin': 'binary'
    });
    assert.deepEqual(openOoxml(xlsb, noBudget), { kind: 'notRead', reason: XLSB, detail: 'xlsb' });
    assert.equal(openOoxml(zipOf({ 'a.txt': 'hello' }), noBudget).kind === 'notRead' &&
      (openOoxml(zipOf({ 'a.txt': 'hello' }), noBudget) as { reason: string }).reason, UNSUPPORTED);
  });

  it('rejects a DOCTYPE in a part', () => {
    const docx = docxFixture({ body: '<w:p/>' });
    const opened = openOoxml(docx, noBudget);
    assert.equal(opened.kind, 'docx');
    const unsafe = zipOf({
      '[Content_Types].xml': contentTypes([{ part: 'word/document.xml', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml' }]),
      'word/document.xml': '<?xml version="1.0"?><!DOCTYPE x [<!ENTITY a "aaaa">]><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'
    });
    const result = openOoxml(unsafe, noBudget);
    assert.equal(result.kind, 'docx');
    if (result.kind === 'docx') {
      assert.throws(() => result.package.xml(result.main));
    }
    const typesUnsafe = zipOf({ '[Content_Types].xml': '<!DOCTYPE x><Types/>' });
    assert.equal((openOoxml(typesUnsafe, noBudget) as { reason: string }).reason, UNSAFE);
  });

  it('rejects too many entries', () => {
    const entries: Record<string, string> = { '[Content_Types].xml': contentTypes([]) };
    for (let index = 0; index < 10001; index++) {
      entries[`f${index}.txt`] = '';
    }
    assert.deepEqual(openOoxml(zipOf(entries), noBudget), { kind: 'notRead', reason: UNSAFE, detail: 'zip unsafe' });
  });

  it('rejects a highly compressed large part', () => {
    const bomb = docxFixture({ body: '<w:p/>', extra: { 'word/styles.xml': ' '.repeat(2 * 1024 * 1024) } });
    assert.deepEqual(openOoxml(bomb, noBudget), { kind: 'notRead', reason: UNSAFE, detail: 'zip unsafe' });
  });

  it('reports a truncated zip as damaged', () => {
    const docx = docxFixture({ body: '<w:p><w:r><w:t>Hello</w:t></w:r></w:p>' });
    const result = openOoxml(docx.slice(0, docx.length - 30), noBudget);
    assert.equal(result.kind, 'notRead');
    assert.equal((result as { reason: string }).reason, DAMAGED);
  });

  it('ignores external and escaping relationships', () => {
    const docx = docxFixture({
      body: '<w:p/>',
      extra: {
        'word/_rels/document.xml.rels': relationships([
          { id: 'rId1', type: 'image', target: 'http://example.test/x.png', external: true },
          { id: 'rId2', type: 'styles', target: '../../../etc/passwd' },
          { id: 'rId3', type: 'styles', target: 'styles.xml' }
        ])
      }
    });
    const result = openOoxml(docx, noBudget);
    assert.equal(result.kind, 'docx');
    if (result.kind === 'docx') {
      assert.deepEqual(result.package.rels(result.main).map((rel) => rel.id), ['rId3']);
      assert.equal(result.package.rels(result.main)[0].target, 'word/styles.xml');
    }
  });
});

describe('resolveTarget', () => {
  it('resolves relative and absolute targets', () => {
    assert.equal(resolveTarget('ppt/slides/slide1.xml', '../notesSlides/notesSlide1.xml'), 'ppt/notesSlides/notesSlide1.xml');
    assert.equal(resolveTarget('xl/workbook.xml', '/xl/worksheets/sheet1.xml'), 'xl/worksheets/sheet1.xml');
    assert.equal(resolveTarget('word/document.xml', '../../x'), undefined);
  });

});

describe('openOoxml limits', () => {
  it('rejects a part whose real length differs from the declared length', () => {
    const types = contentTypes([{ part: 'word/document.xml', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml' }]);
    const documentXml = '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body/></w:document>';
    const stored = storedZipOf({ '[Content_Types].xml': types, 'word/document.xml': documentXml });
    assert.equal(openOoxml(stored, noBudget).kind, 'docx');
    const patched = patchDeclaredSize(stored, 'word/document.xml', documentXml.length + 5);
    assert.deepEqual(openOoxml(patched, noBudget), { kind: 'notRead', reason: UNSAFE, detail: 'zip unsafe' });
  });

  it('rejects a part declared over 200 MB and a package declared over 500 MB', () => {
    const types = contentTypes([{ part: 'word/document.xml', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml' }]);
    const big = storedZipOf({ '[Content_Types].xml': types, 'word/document.xml': '<w:document/>' });
    assert.equal((openOoxml(patchDeclaredSize(big, 'word/document.xml', 201 * 1024 * 1024), noBudget) as { reason: string }).reason, UNSAFE);

    const noise = (seed: number): Uint8Array => {
      const out = new Uint8Array(2 * 1024 * 1024);
      let value = seed;
      for (let index = 0; index < out.length; index++) {
        value = (value * 1103515245 + 12345) % 2147483648;
        out[index] = value % 256;
      }
      return out;
    };
    let total = storedZipOf({
      '[Content_Types].xml': types,
      'word/document.xml': noise(1),
      'word/styles.xml': noise(2),
      'word/numbering.xml': noise(3)
    });
    for (const name of ['word/document.xml', 'word/styles.xml', 'word/numbering.xml']) {
      total = patchDeclaredSize(total, name, 190 * 1024 * 1024);
    }
    assert.deepEqual(openOoxml(total, noBudget), { kind: 'notRead', reason: UNSAFE, detail: 'zip unsafe' });
  });

  it('reports a blown budget as taking too long', () => {
    const result = openOoxml(docxFixture({ body: '<w:p/>' }), () => {
      throw new UnsafeContentError('budget');
    });
    assert.deepEqual(result, { kind: 'notRead', reason: FILE_TIMEOUT, detail: 'budget' });
  });
});
