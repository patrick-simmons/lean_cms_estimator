import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { docxFixture } from './ooxml.fixture';
import { openOoxml } from './ooxml';
import { formatNumber, readDocx } from './docx';

function p(text: string, options: { style?: string; numId?: string; ilvl?: number; outline?: number; runs?: string; before?: string } = {}): string {
  const style = options.style ? `<w:pStyle w:val="${options.style}"/>` : '';
  const num = options.numId !== undefined ? `<w:numPr><w:ilvl w:val="${options.ilvl ?? 0}"/><w:numId w:val="${options.numId}"/></w:numPr>` : '';
  const outline = options.outline !== undefined ? `<w:outlineLvl w:val="${options.outline}"/>` : '';
  const runs = options.runs ?? `<w:r><w:t>${text}</w:t></w:r>`;
  return `<w:p><w:pPr>${style}${num}${outline}</w:pPr>${options.before ?? ''}${runs}</w:p>`;
}

const styles = [
  '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/></w:style>',
  '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/></w:style>',
  '<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:pPr><w:numPr><w:ilvl w:val="2"/><w:numId w:val="1"/></w:numPr></w:pPr></w:style>',
  '<w:style w:type="paragraph" w:styleId="MyHeading"><w:name w:val="My heading"/><w:basedOn w:val="Heading1"/></w:style>',
  '<w:style w:type="paragraph" w:styleId="Roman"><w:name w:val="heading 1"/><w:pPr><w:numPr><w:numId w:val="2"/></w:numPr></w:pPr></w:style>'
].join('');

const numbering = [
  '<w:abstractNum w:abstractNumId="0">',
  '<w:lvl w:ilvl="0"><w:start w:val="3"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/></w:lvl>',
  '<w:lvl w:ilvl="1"><w:start w:val="6"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1.%2."/></w:lvl>',
  '<w:lvl w:ilvl="2"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1.%2.%3"/></w:lvl>',
  '</w:abstractNum>',
  '<w:abstractNum w:abstractNumId="1"><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="upperRoman"/><w:lvlText w:val="%1."/></w:lvl></w:abstractNum>',
  '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>',
  '<w:num w:numId="2"><w:abstractNumId w:val="1"/></w:num>'
].join('');

function read(body: string): ReturnType<typeof readDocx> {
  const opened = openOoxml(docxFixture({ body, styles, numbering }), () => undefined);
  assert.equal(opened.kind, 'docx');
  if (opened.kind !== 'docx') {
    throw new Error('not docx');
  }
  return readDocx(opened.package, opened.main, 'Spec.docx', 'item-1', () => undefined);
}

describe('readDocx', () => {
  it('rebuilds heading numbers from numbering.xml', () => {
    const { blocks } = read(p('Hosting', { style: 'Heading3' }) + p('The site runs on Azure.'));
    assert.equal(blocks.length, 1);
    assert.equal(blocks[0].label, 'Spec \u00A73.6.1 Hosting');
    assert.deepEqual(blocks[0].location, { kind: 'section', section: '3.6.1', heading: 'Hosting' });
    assert.equal(blocks[0].text, '3.6.1 Hosting\nThe site runs on Azure.');
    assert.equal(blocks[0].id, 'item-1#w1');
  });

  it('follows basedOn chains and outline levels, and reads printed numbers', () => {
    const viaChain = read(p('2.1 Scope', { style: 'MyHeading' }) + p('Body.'));
    assert.deepEqual(viaChain.blocks[0].location, { kind: 'section', section: '2.1', heading: 'Scope' });
    const viaOutline = read(p('Overview', { outline: 0 }) + p('Body.'));
    assert.deepEqual(viaOutline.blocks[0].location, { kind: 'section', heading: 'Overview' });
  });

  it('formats upper roman numbering', () => {
    const { blocks } = read(p('Background', { style: 'Roman' }) + p('Body.'));
    assert.equal(blocks[0].location.section, 'I');
    assert.equal(formatNumber(28, 'lowerLetter'), 'ab');
    assert.equal(formatNumber(14, 'lowerRoman'), 'xiv');
    assert.equal(formatNumber(5, 'ordinal'), '5');
  });

  it('uses rendered page breaks as an approximate page', () => {
    const body = p('Intro.') + p('Later text.', { before: '<w:r><w:lastRenderedPageBreak/></w:r>' });
    const { blocks } = read(body);
    assert.equal(blocks[blocks.length - 1].location.page, 2);
    assert.equal(blocks[blocks.length - 1].location.pageApprox, true);
    assert.equal(blocks[blocks.length - 1].label, 'Spec p.~2');
  });

  it('uses explicit page breaks when no rendered breaks exist, without double counting', () => {
    const explicit = read(p('Intro.') + '<w:p><w:r><w:br w:type="page"/></w:r></w:p>' + p('Next.'));
    assert.equal(explicit.blocks[explicit.blocks.length - 1].location.page, 2);
    const both = read(
      p('Intro.') +
      '<w:p><w:r><w:br w:type="page"/></w:r></w:p>' +
      p('Next.', { before: '<w:r><w:lastRenderedPageBreak/></w:r>' })
    );
    assert.equal(both.blocks[both.blocks.length - 1].location.page, 2);
  });

  it('emits no page when the file has no page markers', () => {
    const { blocks } = read(p('Hosting', { style: 'Heading3' }) + p('Body.'));
    assert.equal(blocks.every((block) => block.location.page === undefined), true);
  });

  it('reads insertions, hyperlinks and content controls but not deletions', () => {
    const runs = [
      '<w:r><w:t xml:space="preserve">Keep </w:t></w:r>',
      '<w:ins><w:r><w:t>added </w:t></w:r></w:ins>',
      '<w:del><w:r><w:delText>removed </w:delText></w:r></w:del>',
      '<w:hyperlink><w:r><w:t>link </w:t></w:r></w:hyperlink>',
      '<w:sdt><w:sdtContent><w:r><w:t>control</w:t></w:r></w:sdtContent></w:sdt>',
      '<w:r><w:fldChar/><w:instrText>HYPERLINK x</w:instrText></w:r>'
    ].join('');
    const { blocks } = read(p('', { runs }));
    assert.equal(blocks[0].text, 'Keep added link control');
  });

  it('joins table cells with a separator', () => {
    const table = '<w:tbl><w:tr><w:tc>' + p('Name') + '</w:tc><w:tc>' + p('Value') + '</w:tc></w:tr></w:tbl>';
    const { blocks } = read(table);
    assert.equal(blocks[0].text, 'Name | Value');
  });

  it('labels text before any heading as opening text', () => {
    const { blocks } = read(p('Cover note.'));
    assert.equal(blocks[0].label, 'Spec opening text');
  });

  it('splits a paragraph over the passage limit', () => {
    const { blocks } = read(p('word '.repeat(400).trim()));
    assert.ok(blocks.length > 1);
    assert.ok(blocks.every((block) => block.text.length <= 1500));
  });

  it('keeps the section number for a deeper unnumbered heading and clears it at the same level', () => {
    const { blocks } = read(
      p('2 Services', { style: 'Heading1' }) + p('Intro.') +
      p('Reporting', { style: 'Heading2' }) + p('Monthly reports.') +
      p('Appendix', { style: 'Heading1' }) + p('Extra.')
    );
    assert.deepEqual(blocks.map((block) => block.location.section), ['2', '2', undefined]);
    assert.equal(blocks[1].label, 'Spec \u00A72 Reporting');
    assert.equal(blocks[1].text, 'Reporting\nMonthly reports.');
    assert.equal(blocks[2].label, 'Spec Appendix');
  });

  it('counts headings in sequence and resets deeper levels', () => {
    const levels = [
      '<w:abstractNum w:abstractNumId="5">',
      '<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1"/></w:lvl>',
      '<w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1.%2"/></w:lvl>',
      '</w:abstractNum>',
      '<w:num w:numId="9"><w:abstractNumId w:val="5"/></w:num>'
    ].join('');
    const opened = openOoxml(docxFixture({
      body: [
        p('A', { style: 'Heading1', numId: '9', ilvl: 0 }), p('a.'),
        p('B', { style: 'Heading2', numId: '9', ilvl: 1 }), p('b.'),
        p('C', { style: 'Heading2', numId: '9', ilvl: 1 }), p('c.'),
        p('D', { style: 'Heading1', numId: '9', ilvl: 0 }), p('d.'),
        p('E', { style: 'Heading2', numId: '9', ilvl: 1 }), p('e.')
      ].join(''),
      styles,
      numbering: levels
    }), () => undefined);
    if (opened.kind !== 'docx') {
      throw new Error('not docx');
    }
    const { blocks } = readDocx(opened.package, opened.main, 'Spec.docx', 'item-1', () => undefined);
    assert.deepEqual(blocks.map((block) => block.location.kind === 'section' ? block.location.section : ''), ['1', '1.1', '1.2', '2', '2.1']);
  });

  it('restarts numbering for a list with a start override', () => {
    const levels = [
      '<w:abstractNum w:abstractNumId="5"><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1"/></w:lvl></w:abstractNum>',
      '<w:num w:numId="1"><w:abstractNumId w:val="5"/></w:num>',
      '<w:num w:numId="3"><w:abstractNumId w:val="5"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>'
    ].join('');
    const opened = openOoxml(docxFixture({
      body: [
        p('A', { style: 'Heading1', numId: '1' }), p('a.'),
        p('B', { style: 'Heading1', numId: '1' }), p('b.'),
        p('Restart', { style: 'Heading1', numId: '3' }), p('r.'),
        p('Next', { style: 'Heading1', numId: '3' }), p('n.')
      ].join(''),
      styles,
      numbering: levels
    }), () => undefined);
    if (opened.kind !== 'docx') {
      throw new Error('not docx');
    }
    const { blocks } = readDocx(opened.package, opened.main, 'Spec.docx', 'item-1', () => undefined);
    assert.deepEqual(blocks.map((block) => block.location.kind === 'section' ? block.location.section : ''), ['1', '2', '1', '2']);
  });

  it('gives no section for numId 0 or a bullet level', () => {
    const zero = read(p('Zero', { style: 'Heading3', numId: '0' }) + p('Body.'));
    assert.equal(zero.blocks[0].location.kind === 'section' && zero.blocks[0].location.section, undefined);
    const bullets = [
      '<w:abstractNum w:abstractNumId="7"><w:lvl w:ilvl="0"><w:numFmt w:val="bullet"/><w:lvlText w:val="*"/></w:lvl></w:abstractNum>',
      '<w:num w:numId="7"><w:abstractNumId w:val="7"/></w:num>'
    ].join('');
    const opened = openOoxml(docxFixture({ body: p('2.1 Scope', { style: 'Heading1', numId: '7' }) + p('Body.'), styles, numbering: bullets }), () => undefined);
    if (opened.kind !== 'docx') {
      throw new Error('not docx');
    }
    const { blocks } = readDocx(opened.package, opened.main, 'Spec.docx', 'item-1', () => undefined);
    assert.deepEqual(blocks[0].location, { kind: 'section', section: '2.1', heading: 'Scope' });
  });

  it('ignores list levels outside 0 to 8', () => {
    const { blocks } = read(p('Hosting', { style: 'Heading1', numId: '1', ilvl: 4000000000 }) + p('Body.'));
    assert.equal(blocks.length, 1);
    assert.equal(blocks[0].location.kind === 'section' && blocks[0].location.heading, 'Hosting');
  });

  it('uses the current paragraph style, not a tracked earlier one, and skips moved-from text', () => {
    const changed = '<w:p><w:pPr><w:pStyle w:val="Heading1"/><w:pPrChange><w:pPr><w:pStyle w:val="Normal"/></w:pPr></w:pPrChange></w:pPr><w:r><w:t>Scope</w:t></w:r></w:p>';
    const moved = '<w:p><w:moveFrom><w:r><w:t>old place </w:t></w:r></w:moveFrom><w:moveTo><w:r><w:t>new place</w:t></w:r></w:moveTo></w:p>';
    const { blocks } = read(changed + moved);
    assert.deepEqual(blocks[0].location, { kind: 'section', heading: 'Scope' });
    assert.equal(blocks[0].text, 'Scope\nnew place');
  });
});
