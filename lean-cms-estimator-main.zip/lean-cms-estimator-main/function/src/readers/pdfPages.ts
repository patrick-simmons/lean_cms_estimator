import { PDFDocument } from 'pdf-lib';

export const PAGE_BATCH = 25;

export type PageCountResult = { kind: 'ok'; total: number } | { kind: 'damaged' };

export type RangeResult = { kind: 'range'; start: number; end: number } | { kind: 'pastEnd' };

export async function countPdfPages(bytes: Uint8Array): Promise<PageCountResult> {
  try {
    const document = await PDFDocument.load(bytes, {
      ignoreEncryption: true,
      updateMetadata: false,
      throwOnInvalidObject: false
    });
    const total = document.getPageCount();
    return total > 0 ? { kind: 'ok', total } : { kind: 'damaged' };
  } catch {
    return { kind: 'damaged' };
  }
}

export function clampRange(pages: string, total: number): RangeResult {
  const match = /^(\d+)(?:-(\d+))?$/.exec(pages.trim());
  const first = match ? Number(match[1]) : 1;
  const last = match ? (match[2] === undefined ? first : Number(match[2])) : PAGE_BATCH;
  const start = Math.max(1, first);
  if (start > total) {
    return { kind: 'pastEnd' };
  }
  const end = Math.min(total, last, start + PAGE_BATCH - 1);
  return { kind: 'range', start, end: Math.max(start, end) };
}
