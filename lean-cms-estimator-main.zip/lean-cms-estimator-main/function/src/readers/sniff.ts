export type SniffResult =
  | { kind: 'zip' }
  | { kind: 'pdf' }
  | { kind: 'image'; contentType: string }
  | { kind: 'ole2' }
  | { kind: 'unknown' };

const PDF_SEARCH_BYTES = 1024;
const HEIF_BRANDS = ['heic', 'heix', 'hevc', 'heim', 'heis', 'mif1', 'msf1'];

function startsWith(bytes: Uint8Array, signature: number[], offset: number = 0): boolean {
  if (bytes.length < offset + signature.length) {
    return false;
  }
  for (let index = 0; index < signature.length; index++) {
    if (bytes[offset + index] !== signature[index]) {
      return false;
    }
  }
  return true;
}

function ascii(bytes: Uint8Array, start: number, length: number): string {
  let value = '';
  for (let index = start; index < start + length && index < bytes.length; index++) {
    value += String.fromCharCode(bytes[index]);
  }
  return value;
}

function hasPdfHeader(bytes: Uint8Array): boolean {
  const limit = Math.min(bytes.length, PDF_SEARCH_BYTES);
  return ascii(bytes, 0, limit).indexOf('%PDF-') !== -1;
}

export function sniff(bytes: Uint8Array): SniffResult {
  if (startsWith(bytes, [0x50, 0x4b, 0x03, 0x04])) {
    return { kind: 'zip' };
  }
  if (startsWith(bytes, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1])) {
    return { kind: 'ole2' };
  }
  if (startsWith(bytes, [0xff, 0xd8, 0xff])) {
    return { kind: 'image', contentType: 'image/jpeg' };
  }
  if (startsWith(bytes, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) {
    return { kind: 'image', contentType: 'image/png' };
  }
  if (startsWith(bytes, [0x49, 0x49, 0x2a, 0x00]) || startsWith(bytes, [0x4d, 0x4d, 0x00, 0x2a])) {
    return { kind: 'image', contentType: 'image/tiff' };
  }
  if (ascii(bytes, 4, 4) === 'ftyp' && HEIF_BRANDS.indexOf(ascii(bytes, 8, 4)) !== -1) {
    return { kind: 'image', contentType: 'image/heif' };
  }
  if (hasPdfHeader(bytes)) {
    return { kind: 'pdf' };
  }
  if (startsWith(bytes, [0x42, 0x4d]) && bytes.length >= 26) {
    return { kind: 'image', contentType: 'image/bmp' };
  }
  return { kind: 'unknown' };
}
