import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { MAX_PASSAGE_CHARS, MAX_TEXT_CHARS } from '../blocks';
import { createPassages, splitLong } from './passages';

const page38 = { kind: 'page' as const, page: 38, section: '3.6.1', heading: 'Hosting' };

describe('createPassages', () => {
  it('groups text with the same location and labels it', () => {
    const passages = createPassages('RFP.pdf', 'item-1');
    passages.add(page38, 'p38.', 'First line.');
    passages.add(page38, 'p38.', 'Second line.');
    passages.add({ kind: 'page', page: 39 }, 'p39.', 'Next page.');
    const blocks = passages.blocks();
    assert.equal(blocks.length, 2);
    assert.deepEqual(blocks[0], {
      id: 'item-1#p38.1',
      fileName: 'RFP.pdf',
      itemId: 'item-1',
      label: 'RFP p.38 \u00A73.6.1',
      location: page38,
      text: 'First line.\nSecond line.'
    });
    assert.equal(blocks[1].id, 'item-1#p39.1');
  });

  it('starts a new block when the cap would be passed', () => {
    const passages = createPassages('RFP.pdf', 'item-1');
    passages.add(page38, 'p38.', 'a'.repeat(1000));
    passages.add(page38, 'p38.', 'b'.repeat(1000));
    const blocks = passages.blocks();
    assert.deepEqual(blocks.map((block) => block.id), ['item-1#p38.1', 'item-1#p38.2']);
  });

  it('splits a long paragraph at whitespace', () => {
    const word = 'word ';
    const text = word.repeat(400);
    const pieces = splitLong(text.trim());
    assert.ok(pieces.length > 1);
    assert.ok(pieces.every((piece) => piece.length <= MAX_PASSAGE_CHARS));
    assert.equal(pieces.join(' '), text.trim());
    assert.deepEqual(splitLong('x'.repeat(3001)).map((piece) => piece.length), [1500, 1500, 1]);
  });

  it('prefixes the header on every group after the first', () => {
    const passages = createPassages('Inventory.xlsx', 'item-2');
    const rows = Array.from({ length: 4 }, (_value, index) => `${index}: ${'v'.repeat(600)}`);
    passages.addRows({ kind: 'page', page: 2 }, 'p2.t', 'Header: A | B', rows);
    const blocks = passages.blocks();
    assert.equal(blocks.length, 2);
    assert.equal(blocks[0].text.startsWith('Header'), false);
    assert.equal(blocks[1].text.startsWith('Header: A | B\n'), true);
  });

  it('ignores blank text', () => {
    const passages = createPassages('a.pdf', 'item-1');
    passages.add(page38, 'p38.', '   ');
    assert.deepEqual(passages.blocks(), []);
  });

  it('stops at the text cap and ignores later text', () => {
    const passages = createPassages('RFP.pdf', 'item-1');
    const chunk = 'x'.repeat(MAX_PASSAGE_CHARS);
    const needed = Math.ceil(MAX_TEXT_CHARS / MAX_PASSAGE_CHARS) + 2;
    for (let index = 0; index < needed; index++) {
      passages.add({ kind: 'page', page: index + 1 }, `p${index + 1}.`, chunk);
    }
    const blocks = passages.blocks();
    assert.equal(passages.capped, true);
    assert.ok(blocks.reduce((sum, block) => sum + block.text.length, 0) <= MAX_TEXT_CHARS);
    const count = blocks.length;
    passages.add({ kind: 'page', page: 9999 }, 'p9999.', 'more');
    assert.equal(passages.blocks().length, count);
  });
});
