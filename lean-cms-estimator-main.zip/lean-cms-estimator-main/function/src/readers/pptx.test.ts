import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { A_NS, ISlideFixture, P_NS, pptxFixture, shape } from './ooxml.fixture';
import { openOoxml } from './ooxml';
import { readPptx } from './pptx';

function read(slides: ISlideFixture[], order: number[]): ReturnType<typeof readPptx> {
  const opened = openOoxml(pptxFixture({ slides, order }), () => undefined);
  if (opened.kind !== 'pptx') {
    throw new Error('not pptx');
  }
  return readPptx(opened.package, opened.main, 'Kickoff_deck.pptx', 'item-3', () => undefined);
}

const table = '<p:graphicFrame><a:graphic><a:graphicData><a:tbl>' +
  '<a:tr><a:tc><a:txBody><a:p><a:r><a:t>Site</a:t></a:r></a:p></a:txBody></a:tc><a:tc><a:txBody><a:p><a:r><a:t>Pages</a:t></a:r></a:p></a:txBody></a:tc></a:tr>' +
  '<a:tr><a:tc><a:txBody><a:p><a:r><a:t>Corporate</a:t></a:r></a:p></a:txBody></a:tc><a:tc><a:txBody><a:p><a:r><a:t>120</a:t></a:r></a:p></a:txBody></a:tc></a:tr>' +
  '</a:tbl></a:graphicData></a:graphic></p:graphicFrame>';

describe('readPptx', () => {
  it('numbers slides by presentation order, not file name', () => {
    const { blocks } = read([
      { file: 1, shapes: shape('Second in order', 'title') },
      { file: 3, shapes: shape('First in order', 'title') }
    ], [3, 1]);
    assert.equal(blocks[0].label, 'Kickoff_deck slide 1');
    assert.equal(blocks[0].location.slideTitle, 'First in order');
    assert.equal(blocks[1].location.slide, 2);
    assert.equal(blocks.every((block) => block.location.page === undefined), true);
  });

  it('reads grouped shapes and tables, and skips number, date and footer placeholders', () => {
    const shapes = shape('Scope', 'title') +
      `<p:grpSp>${shape('Grouped text')}</p:grpSp>` +
      table +
      shape('12', 'sldNum') + shape('Oct 2026', 'dt') + shape('Confidential', 'ftr');
    const { blocks } = read([{ file: 1, shapes }], [1]);
    assert.equal(blocks.length, 1);
    assert.equal(blocks[0].text, 'Scope\nGrouped text\nSite | Pages\nCorporate | 120');
    assert.equal(blocks[0].id, 'item-3#s1.1');
  });

  it('reads speaker notes as a separate block', () => {
    const { blocks } = read([{ file: 1, shapes: shape('Agenda', 'title'), notes: 'Mention the deadline.' }], [1]);
    assert.equal(blocks.length, 2);
    assert.equal(blocks[1].label, 'Kickoff_deck slide 1 notes');
    assert.equal(blocks[1].text, 'Mention the deadline.');
    assert.equal(blocks[1].location.notes, true);
  });

  it('skips slides without text', () => {
    const { blocks } = read([{ file: 1, shapes: '' }, { file: 2, shapes: shape('Body only') }], [1, 2]);
    assert.equal(blocks.length, 1);
    assert.equal(blocks[0].location.slide, 2);
  });

  it('keeps presentation numbers when a slide relationship points nowhere, and counts it', () => {
    const bytes = pptxFixture({ slides: [{ file: 1, shapes: shape('One') }], order: [9, 1] });
    const opened = openOoxml(bytes, () => undefined);
    if (opened.kind !== 'pptx') {
      throw new Error('not pptx');
    }
    const result = readPptx(opened.package, opened.main, 'Deck.pptx', 'item-3', () => undefined);
    assert.deepEqual(result.blocks.map((block) => block.location.kind === 'slide' ? block.location.slide : 0), [2]);
    assert.equal(result.missing, 1);
  });

  it('reads hidden slides', () => {
    const hiddenXml = `<?xml version="1.0" encoding="UTF-8"?><p:sld xmlns:p="${P_NS}" xmlns:a="${A_NS}" show="0"><p:cSld><p:spTree>${shape('Hidden text')}</p:spTree></p:cSld></p:sld>`;
    const bytes = pptxFixture({ slides: [{ file: 1, shapes: '' }], order: [1], extra: { 'ppt/slides/slide1.xml': hiddenXml } });
    const opened = openOoxml(bytes, () => undefined);
    if (opened.kind !== 'pptx') {
      throw new Error('not pptx');
    }
    const result = readPptx(opened.package, opened.main, 'Deck.pptx', 'item-3', () => undefined);
    assert.equal(result.blocks[0].text, 'Hidden text');
  });
});
