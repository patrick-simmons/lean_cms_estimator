import { ISourceLocation } from '../blocks';
import { IReaderOutput } from './docx';
import { IOoxmlPackage } from './ooxml';
import { createPassages } from './passages';
import { attr, attrPlain, is, NS, parseXml } from './xml';

const SKIPPED_PLACEHOLDERS = ['sldNum', 'dt', 'ftr'];
const TITLE_PLACEHOLDERS = ['title', 'ctrTitle'];

interface IShape {
  placeholder?: string;
  paragraphs: string[];
}

interface ISlideText {
  title?: string;
  body: string[];
}

function readShapes(text: string, keep: (placeholder: string | undefined) => boolean, checkBudget: () => void): ISlideText {
  const result: ISlideText = { body: [] };
  const shapes: IShape[] = [];
  let paragraph: string | undefined;
  let inT = false;
  let rows: string[] | undefined;
  let cells: string[] | undefined;
  let cell: string[] | undefined;

  parseXml(text, {
    open(tag) {
      if (is(tag, NS.P, 'sp')) {
        shapes.push({ paragraphs: [] });
      } else if (is(tag, NS.P, 'ph') && shapes.length > 0) {
        shapes[shapes.length - 1].placeholder = attrPlain(tag, 'type') ?? 'body';
      } else if (is(tag, NS.A, 'tbl')) {
        rows = [];
      } else if (is(tag, NS.A, 'tr') && rows) {
        cells = [];
      } else if (is(tag, NS.A, 'tc') && cells) {
        cell = [];
      } else if (is(tag, NS.A, 'p')) {
        paragraph = '';
      } else if (is(tag, NS.A, 't')) {
        inT = true;
      } else if (is(tag, NS.A, 'br') && paragraph !== undefined) {
        paragraph += '\n';
      }
    },
    close(tag) {
      if (is(tag, NS.A, 't')) {
        inT = false;
      } else if (is(tag, NS.A, 'p')) {
        const value = (paragraph ?? '').trim();
        paragraph = undefined;
        if (value.length === 0) {
          return;
        }
        if (cell) {
          cell.push(value);
        } else if (shapes.length > 0) {
          shapes[shapes.length - 1].paragraphs.push(value);
        }
      } else if (is(tag, NS.A, 'tc') && cell && cells) {
        cells.push(cell.join(' '));
        cell = undefined;
      } else if (is(tag, NS.A, 'tr') && cells && rows) {
        if (cells.some((value) => value.length > 0)) {
          rows.push(cells.join(' | '));
        }
        cells = undefined;
      } else if (is(tag, NS.A, 'tbl') && rows) {
        result.body.push(...rows);
        rows = undefined;
      } else if (is(tag, NS.P, 'sp')) {
        const shape = shapes.pop();
        if (!shape || shape.paragraphs.length === 0 || !keep(shape.placeholder)) {
          return;
        }
        const value = shape.paragraphs.join('\n');
        if (shape.placeholder !== undefined && TITLE_PLACEHOLDERS.indexOf(shape.placeholder) !== -1 && result.title === undefined) {
          result.title = value;
        } else {
          result.body.push(value);
        }
      }
    },
    text(value) {
      if (inT && paragraph !== undefined) {
        paragraph += value;
      }
    }
  }, checkBudget);
  return result;
}

function slideOrder(pkg: IOoxmlPackage, main: string, checkBudget: () => void): (string | undefined)[] {
  const targets = new Map<string, string>();
  for (const rel of pkg.rels(main)) {
    if (rel.type.endsWith('/slide')) {
      targets.set(rel.id, rel.target);
    }
  }
  const order: (string | undefined)[] = [];
  parseXml(pkg.xml(main) ?? '', {
    open(tag) {
      if (is(tag, NS.P, 'sldId')) {
        order.push(targets.get(attr(tag, NS.R, 'id') ?? ''));
      }
    }
  }, checkBudget);
  return order;
}

export function readPptx(
  pkg: IOoxmlPackage,
  main: string,
  fileName: string,
  itemId: string,
  checkBudget: () => void
): IReaderOutput {
  const passages = createPassages(fileName, itemId);
  const order = slideOrder(pkg, main, checkBudget);
  let missing = 0;
  order.forEach((part, index) => {
    const slide = index + 1;
    const xml = part ? pkg.xml(part) : undefined;
    if (!part || xml === undefined) {
      missing++;
      return;
    }
    checkBudget();
    const content = readShapes(xml, (placeholder) =>
      placeholder === undefined || SKIPPED_PLACEHOLDERS.indexOf(placeholder) === -1, checkBudget);
    const location: ISourceLocation = { kind: 'slide', slide };
    if (content.title !== undefined) {
      location.slideTitle = content.title;
    }
    const lines = (content.title !== undefined ? [content.title] : []).concat(content.body);
    lines.forEach((line) => passages.add(location, `s${slide}.`, line));
    passages.flush();

    const notesRel = pkg.rels(part).filter((rel) => rel.type.endsWith('/notesSlide'))[0];
    const notesXml = notesRel ? pkg.xml(notesRel.target) : undefined;
    if (notesXml !== undefined) {
      const notes = readShapes(notesXml, (placeholder) => placeholder === 'body', checkBudget);
      const notesLocation: ISourceLocation = { ...location, notes: true };
      notes.body.forEach((line) => passages.add(notesLocation, `s${slide}.n`, line));
      passages.flush();
    }
  });
  const blocks = passages.blocks();
  return { blocks, capped: passages.capped, missing };
}
