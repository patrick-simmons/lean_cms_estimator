import { unzipSync, Unzipped } from 'fflate';
import { DAMAGED, FILE_TIMEOUT, UNSAFE, UNSUPPORTED, XLSB } from '../blocks';
import { attrPlain, is, NS, parseXml, UnsafeContentError, assertNoDoctype } from './xml';

export const MAX_ENTRIES = 10000;
export const MAX_PART_BYTES = 200 * 1024 * 1024;
export const MAX_TOTAL_BYTES = 500 * 1024 * 1024;
export const MAX_RATIO = 100;
const RATIO_MIN_BYTES = 1024 * 1024;
const CONTENT_TYPES = '[Content_Types].xml';

export type OoxmlKind = 'docx' | 'pptx' | 'xlsx';

export interface IRelationship {
  id: string;
  type: string;
  target: string;
}

export interface IOoxmlPackage {
  xml(partName: string): string | undefined;
  rels(partName: string): IRelationship[];
  has(partName: string): boolean;
}

export type OoxmlResult =
  | { kind: OoxmlKind; main: string; package: IOoxmlPackage }
  | { kind: 'notRead'; reason: string; detail: string };

const MAIN_TYPES: { kind: OoxmlKind; types: string[] }[] = [
  {
    kind: 'docx',
    types: [
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',
      'application/vnd.ms-word.document.macroEnabled.main+xml',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml'
    ]
  },
  {
    kind: 'pptx',
    types: [
      'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml',
      'application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml',
      'application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml'
    ]
  },
  {
    kind: 'xlsx',
    types: [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
      'application/vnd.ms-excel.sheet.macroEnabled.main+xml'
    ]
  }
];
const XLSB_TYPE = 'application/vnd.ms-excel.sheet.binary.macroEnabled.main';

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function directoryOf(partName: string): string {
  const slash = partName.lastIndexOf('/');
  return slash === -1 ? '' : partName.slice(0, slash);
}

function fileOf(partName: string): string {
  const slash = partName.lastIndexOf('/');
  return slash === -1 ? partName : partName.slice(slash + 1);
}

export function relsPartFor(partName: string): string {
  const dir = directoryOf(partName);
  const rels = `_rels/${fileOf(partName)}.rels`;
  return dir.length > 0 ? `${dir}/${rels}` : rels;
}

export function resolveTarget(sourcePart: string, target: string): string | undefined {
  const base = target.startsWith('/') ? [] : directoryOf(sourcePart).split('/').filter((part) => part.length > 0);
  const segments = base.slice();
  for (const segment of target.split('/')) {
    if (segment === '' || segment === '.') {
      continue;
    }
    if (segment === '..') {
      if (segments.length === 0) {
        return undefined;
      }
      segments.pop();
      continue;
    }
    segments.push(segment);
  }
  return segments.length > 0 ? segments.join('/') : undefined;
}

function allowlist(kind: OoxmlKind, main: string): RegExp[] {
  const dir = directoryOf(main);
  const d = dir.length > 0 ? `${escapeRegExp(dir)}/` : '';
  const exact = (name: string): RegExp => new RegExp(`^${escapeRegExp(name)}$`);
  const common = [exact(main), exact(relsPartFor(main))];
  if (kind === 'docx') {
    return common.concat([new RegExp(`^${d}styles\\.xml$`), new RegExp(`^${d}numbering\\.xml$`)]);
  }
  if (kind === 'pptx') {
    return common.concat([
      new RegExp(`^${d}slides/[^/]+\\.xml$`),
      new RegExp(`^${d}slides/_rels/[^/]+\\.xml\\.rels$`),
      new RegExp(`^${d}notesSlides/[^/]+\\.xml$`)
    ]);
  }
  return common.concat([
    new RegExp(`^${d}[^/]+\\.xml$`),
    new RegExp(`^${d}worksheets/[^/]+\\.xml$`)
  ]);
}

function decode(bytes: Uint8Array): string {
  if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
    return new TextDecoder('utf-16le').decode(bytes);
  }
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
    return new TextDecoder('utf-16be').decode(bytes);
  }
  return new TextDecoder('utf-8').decode(bytes);
}

function findMain(text: string): { kind: OoxmlKind | 'xlsb'; main: string } | undefined {
  let found: { kind: OoxmlKind | 'xlsb'; main: string } | undefined;
  parseXml(text, {
    open(tag) {
      if (found || !is(tag, NS.CT, 'Override')) {
        return;
      }
      const partName = (attrPlain(tag, 'PartName') ?? '').replace(/^\//, '');
      const contentType = (attrPlain(tag, 'ContentType') ?? '').trim();
      if (partName.length === 0) {
        return;
      }
      if (contentType === XLSB_TYPE) {
        found = { kind: 'xlsb', main: partName };
        return;
      }
      for (const entry of MAIN_TYPES) {
        if (entry.types.indexOf(contentType) !== -1) {
          found = { kind: entry.kind, main: partName };
          return;
        }
      }
    }
  });
  return found;
}

function inflate(bytes: Uint8Array, accept: (name: string) => boolean, checkBudget: () => void): Unzipped {
  let entries = 0;
  let declaredTotal = 0;
  const declared = new Map<string, number>();
  const output = unzipSync(bytes, {
    filter(file) {
      entries++;
      if (entries > MAX_ENTRIES) {
        throw new UnsafeContentError('zip unsafe');
      }
      if (!accept(file.name)) {
        return false;
      }
      if (file.name.indexOf('..') !== -1 || file.name.startsWith('/')) {
        return false;
      }
      if (file.originalSize > MAX_PART_BYTES) {
        throw new UnsafeContentError('zip unsafe');
      }
      if (file.originalSize > RATIO_MIN_BYTES && file.size > 0 && file.originalSize / file.size > MAX_RATIO) {
        throw new UnsafeContentError('zip unsafe');
      }
      declaredTotal += file.originalSize;
      if (declaredTotal > MAX_TOTAL_BYTES) {
        throw new UnsafeContentError('zip unsafe');
      }
      declared.set(file.name, file.originalSize);
      return true;
    }
  });
  checkBudget();
  let actualTotal = 0;
  for (const name of Object.keys(output)) {
    const length = output[name].length;
    actualTotal += length;
    if (declared.get(name) !== length || actualTotal > MAX_TOTAL_BYTES) {
      throw new UnsafeContentError('zip unsafe');
    }
  }
  return output;
}

function createPackage(files: Unzipped, checkBudget: () => void): IOoxmlPackage {
  const parts = new Map<string, Uint8Array>();
  for (const name of Object.keys(files)) {
    parts.set(name, files[name]);
  }
  const xml = (partName: string): string | undefined => {
    const bytes = parts.get(partName);
    if (!bytes) {
      return undefined;
    }
    const text = decode(bytes);
    assertNoDoctype(text);
    return text;
  };
  return {
    xml,
    has: (partName) => parts.has(partName),
    rels(partName) {
      const text = xml(relsPartFor(partName));
      if (text === undefined) {
        return [];
      }
      const found: IRelationship[] = [];
      parseXml(text, {
        open(tag) {
          if (!is(tag, NS.PKG_REL, 'Relationship')) {
            return;
          }
          if ((attrPlain(tag, 'TargetMode') ?? '').toLowerCase() === 'external') {
            return;
          }
          const target = resolveTarget(partName, attrPlain(tag, 'Target') ?? '');
          if (target === undefined) {
            return;
          }
          found.push({ id: attrPlain(tag, 'Id') ?? '', type: attrPlain(tag, 'Type') ?? '', target });
        }
      }, checkBudget);
      return found;
    }
  };
}

export function errorName(error: unknown): string {
  return error instanceof Error ? error.name.replace(/[^A-Za-z0-9]/g, '') : typeof error;
}

export function openOoxml(bytes: Uint8Array, checkBudget: () => void): OoxmlResult {
  try {
    const first = inflate(bytes, (name) => name === CONTENT_TYPES, checkBudget);
    const contentTypes = first[CONTENT_TYPES];
    if (!contentTypes) {
      return { kind: 'notRead', reason: UNSUPPORTED, detail: 'zip not office' };
    }
    const text = decode(contentTypes);
    const main = findMain(text);
    if (!main) {
      return { kind: 'notRead', reason: UNSUPPORTED, detail: 'zip not office' };
    }
    if (main.kind === 'xlsb') {
      return { kind: 'notRead', reason: XLSB, detail: 'xlsb' };
    }
    const patterns = allowlist(main.kind, main.main);
    const files = inflate(bytes, (name) => patterns.some((pattern) => pattern.test(name)), checkBudget);
    if (!files[main.main]) {
      return { kind: 'notRead', reason: DAMAGED, detail: 'zip main missing' };
    }
    return { kind: main.kind, main: main.main, package: createPackage(files, checkBudget) };
  } catch (error) {
    if (error instanceof UnsafeContentError) {
      return { kind: 'notRead', reason: error.code === 'budget' ? FILE_TIMEOUT : UNSAFE, detail: error.code };
    }
    return { kind: 'notRead', reason: DAMAGED, detail: `zip damaged ${errorName(error)}` };
  }
}
