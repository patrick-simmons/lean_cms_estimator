import { MAX_PASSAGE_CHARS } from '../blocks';
import { IReaderOutput } from './docx';
import { IOoxmlPackage, resolveTarget } from './ooxml';
import { createPassages } from './passages';
import { attr, attrPlain, is, NS, parseXml } from './xml';

export const MAX_ROWS_PER_BLOCK = 20;
const MAX_COLUMN = 16384;
const MAX_ROW = 1048576;

interface ISheetRef {
  name: string;
  part: string;
}

interface IRow {
  number: number;
  values: string[];
}

function columnIndex(reference: string | undefined): number | undefined {
  const match = /^([A-Z]{1,3})\d*$/i.exec(reference ?? '');
  if (!match) {
    return undefined;
  }
  let index = 0;
  for (const char of match[1].toUpperCase()) {
    index = index * 26 + (char.charCodeAt(0) - 64);
  }
  return index <= MAX_COLUMN ? index : undefined;
}

function readSharedStrings(text: string | undefined, checkBudget: () => void): string[] {
  const strings: string[] = [];
  if (text === undefined) {
    return strings;
  }
  let current: string | undefined;
  let inT = false;
  let phonetic = 0;
  parseXml(text, {
    open(tag) {
      if (is(tag, NS.S, 'si')) {
        current = '';
      } else if (is(tag, NS.S, 'rPh')) {
        phonetic++;
      } else if (is(tag, NS.S, 't')) {
        inT = true;
      }
    },
    close(tag) {
      if (is(tag, NS.S, 'si')) {
        strings.push(current ?? '');
        current = undefined;
      } else if (is(tag, NS.S, 'rPh')) {
        phonetic--;
      } else if (is(tag, NS.S, 't')) {
        inT = false;
      }
    },
    text(value) {
      if (inT && phonetic === 0 && current !== undefined) {
        current += value;
      }
    }
  }, checkBudget);
  return strings;
}

function readSheets(pkg: IOoxmlPackage, main: string, checkBudget: () => void): { sheets: ISheetRef[]; shared?: string } {
  const worksheets = new Map<string, string>();
  let shared: string | undefined;
  for (const rel of pkg.rels(main)) {
    if (rel.type.endsWith('/worksheet')) {
      worksheets.set(rel.id, rel.target);
    } else if (rel.type.endsWith('/sharedStrings')) {
      shared = rel.target;
    }
  }
  const sheets: ISheetRef[] = [];
  parseXml(pkg.xml(main) ?? '', {
    open(tag) {
      if (is(tag, NS.S, 'sheet')) {
        const part = worksheets.get(attr(tag, NS.R, 'id') ?? '');
        if (part) {
          sheets.push({ name: attrPlain(tag, 'name') ?? '', part });
        }
      }
    }
  }, checkBudget);
  return { sheets, shared: shared ?? resolveTarget(main, 'sharedStrings.xml') };
}

function readRows(text: string, shared: string[], checkBudget: () => void): IRow[] {
  const rows: IRow[] = [];
  let row: IRow | undefined;
  let lastRow = 0;
  let column = 0;
  let cellType: string | undefined;
  let value: string | undefined;
  let inV = false;
  let inInline = false;
  let inT = false;
  let phonetic = 0;

  parseXml(text, {
    open(tag) {
      if (tag.uri !== NS.S) {
        return;
      }
      if (tag.local === 'row') {
        const declared = Number(attrPlain(tag, 'r'));
        lastRow = Number.isInteger(declared) && declared > 0 ? declared : lastRow + 1;
        row = lastRow <= MAX_ROW ? { number: lastRow, values: [] } : undefined;
        column = 0;
      } else if (tag.local === 'c' && row) {
        const declaredColumn = attrPlain(tag, 'r');
        const parsedColumn = declaredColumn === undefined ? column + 1 : columnIndex(declaredColumn);
        column = parsedColumn === undefined || parsedColumn > MAX_COLUMN ? MAX_COLUMN + 1 : parsedColumn;
        cellType = attrPlain(tag, 't');
        value = undefined;
      } else if (tag.local === 'v') {
        inV = true;
        value = value ?? '';
      } else if (tag.local === 'is') {
        inInline = true;
        value = value ?? '';
      } else if (tag.local === 'rPh') {
        phonetic++;
      } else if (tag.local === 't' && inInline) {
        inT = true;
      }
    },
    close(tag) {
      if (tag.uri !== NS.S) {
        return;
      }
      if (tag.local === 'v') {
        inV = false;
      } else if (tag.local === 'is') {
        inInline = false;
      } else if (tag.local === 'rPh') {
        phonetic--;
      } else if (tag.local === 't') {
        inT = false;
      } else if (tag.local === 'c' && row && column <= MAX_COLUMN) {
        let display = (value ?? '').trim();
        if (cellType === 's') {
          display = shared[Number(display)] ?? '';
        } else if (cellType === 'b') {
          display = display === '1' ? 'TRUE' : display === '0' ? 'FALSE' : display;
        }
        row.values[column - 1] = display.replace(/\s+/g, ' ').trim();
      } else if (tag.local === 'row' && row) {
        if (row.values.some((cell) => cell !== undefined && cell.length > 0)) {
          rows.push(row);
        }
        row = undefined;
        checkBudget();
      }
    },
    text(chunk) {
      if (inV || (inInline && inT && phonetic === 0)) {
        value = (value ?? '') + chunk;
      }
    }
  }, checkBudget);
  return rows;
}

function rowCells(values: string[]): string[] {
  let first = 0;
  while (first < values.length && !values[first]) {
    first++;
  }
  let last = values.length - 1;
  while (last >= first && !values[last]) {
    last--;
  }
  const cells: string[] = [];
  for (let index = first; index <= last; index++) {
    cells.push(values[index] ?? '');
  }
  return cells;
}

export function readXlsx(
  pkg: IOoxmlPackage,
  main: string,
  fileName: string,
  itemId: string,
  checkBudget: () => void
): IReaderOutput {
  const passages = createPassages(fileName, itemId);
  const workbook = readSheets(pkg, main, checkBudget);
  const shared = readSharedStrings(workbook.shared ? pkg.xml(workbook.shared) : undefined, checkBudget);
  let missing = 0;
  workbook.sheets.forEach((sheet, sheetIndex) => {
    const xml = pkg.xml(sheet.part);
    if (xml === undefined) {
      missing++;
      return;
    }
    const rows = readRows(xml, shared, checkBudget);
    if (rows.length === 0) {
      return;
    }
    const header = `Header: ${rowCells(rows[0].values).join(' | ')}`;
    let group: IRow[] = [];
    let size = 0;
    let groups = 0;
    const close = (): void => {
      if (group.length === 0) {
        return;
      }
      const lines = group.map((item) => `${item.number}: ${rowCells(item.values).join(' | ')}`);
      passages.addRows(
        { kind: 'sheet', sheet: sheet.name, rowStart: group[0].number, rowEnd: group[group.length - 1].number },
        `x${sheetIndex + 1}.r${group[0].number}.`,
        header,
        lines,
        groups > 0
      );
      groups++;
      group = [];
      size = 0;
    };
    rows.forEach((item) => {
      const length = `${item.number}: ${rowCells(item.values).join(' | ')}`.length + 1;
      const budget = MAX_PASSAGE_CHARS - (groups > 0 ? header.length + 1 : 0);
      if (group.length >= MAX_ROWS_PER_BLOCK || (group.length > 0 && size + length > budget)) {
        close();
      }
      group.push(item);
      size += length;
    });
    close();
  });
  const blocks = passages.blocks();
  return { blocks, capped: passages.capped, missing };
}
