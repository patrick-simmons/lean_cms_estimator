import { DAMAGED, FILE_TIMEOUT, IBlock, INotRead, MISSING_PARTS, NO_TEXT, TEXT_CAP, UNSAFE } from '../blocks';
import { IReaderOutput, readDocx } from './docx';
import { errorName, OoxmlKind, openOoxml } from './ooxml';
import { readPptx } from './pptx';
import { UnsafeContentError } from './xml';
import { readXlsx } from './xlsx';

// The Office (OOXML) read path shared by the Azure function and the local parse tool.
// It needs no network, no token and no Document Intelligence: only the zip and XML readers.

export type OfficeFormat = OoxmlKind | 'xlsb' | 'zip';

export interface IOfficeRead {
  format: OfficeFormat;
  blocks: IBlock[];
  notRead: INotRead[];
}

const READERS = { docx: readDocx, pptx: readPptx, xlsx: readXlsx };

function entry(reason: string): INotRead {
  return { reason };
}

function notRead(format: OfficeFormat, reason: string): IOfficeRead {
  return { format, blocks: [], notRead: [entry(reason)] };
}

export function readOffice(
  bytes: Uint8Array,
  fileName: string,
  itemId: string,
  checkBudget: () => void,
  logFailure: (detail: string) => void
): IOfficeRead {
  const opened = openOoxml(bytes, checkBudget);
  if (opened.kind === 'notRead') {
    logFailure(opened.detail);
    return notRead(opened.detail === 'xlsb' ? 'xlsb' : 'zip', opened.reason);
  }
  let output: IReaderOutput;
  try {
    output = READERS[opened.kind](opened.package, opened.main, fileName, itemId, checkBudget);
  } catch (error) {
    if (error instanceof UnsafeContentError) {
      logFailure(error.code);
      return notRead(opened.kind, error.code === 'budget' ? FILE_TIMEOUT : UNSAFE);
    }
    logFailure(`${opened.kind} damaged ${errorName(error)}`);
    return notRead(opened.kind, DAMAGED);
  }
  const notReadEntries: INotRead[] = [];
  if (output.missing > 0) {
    logFailure(`${opened.kind} missing ${output.missing}`);
    notReadEntries.push(entry(MISSING_PARTS));
  }
  if (output.capped) {
    notReadEntries.push(entry(TEXT_CAP));
  }
  if (output.blocks.length === 0 && notReadEntries.length === 0) {
    notReadEntries.push(entry(NO_TEXT));
  }
  return { format: opened.kind, blocks: output.blocks, notRead: notReadEntries };
}
