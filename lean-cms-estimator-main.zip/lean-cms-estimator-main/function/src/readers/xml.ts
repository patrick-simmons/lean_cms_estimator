import { SaxesParser, SaxesTagNS } from 'saxes';

export const NS = {
  W: 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
  A: 'http://schemas.openxmlformats.org/drawingml/2006/main',
  P: 'http://schemas.openxmlformats.org/presentationml/2006/main',
  S: 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
  R: 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
  PKG_REL: 'http://schemas.openxmlformats.org/package/2006/relationships',
  CT: 'http://schemas.openxmlformats.org/package/2006/content-types',
  MC: 'http://schemas.openxmlformats.org/markup-compatibility/2006'
};

const BUDGET_CHECK_EVERY = 1000;

export class UnsafeContentError extends Error {
  public constructor(public readonly code: string) {
    super(code);
  }
}

export type XmlTag = SaxesTagNS;

export interface IXmlHandlers {
  open?(tag: XmlTag): void;
  close?(tag: XmlTag): void;
  text?(value: string): void;
}

export function assertNoDoctype(text: string): void {
  if (text.indexOf('<!DOCTYPE') !== -1 || text.indexOf('<!ENTITY') !== -1) {
    throw new UnsafeContentError('xml unsafe');
  }
}

export function parseXml(text: string, handlers: IXmlHandlers, checkBudget: () => void = () => undefined): void {
  assertNoDoctype(text);
  const parser = new SaxesParser({ xmlns: true });
  let opened = 0;
  parser.on('doctype', () => {
    throw new UnsafeContentError('xml unsafe');
  });
  parser.on('error', (error) => {
    throw error;
  });
  parser.on('opentag', (tag) => {
    opened++;
    if (opened % BUDGET_CHECK_EVERY === 0) {
      checkBudget();
    }
    handlers.open?.(tag);
  });
  parser.on('closetag', (tag) => {
    handlers.close?.(tag);
  });
  parser.on('text', (value) => {
    handlers.text?.(value);
  });
  parser.on('cdata', (value) => {
    handlers.text?.(value);
  });
  parser.write(text).close();
}

export function is(tag: XmlTag, uri: string, local: string): boolean {
  return tag.uri === uri && tag.local === local;
}

export function attr(tag: XmlTag, uri: string, local: string): string | undefined {
  const attributes = tag.attributes;
  for (const key of Object.keys(attributes)) {
    const value = attributes[key];
    if (value.uri === uri && value.local === local) {
      return value.value;
    }
  }
  return undefined;
}

export function attrPlain(tag: XmlTag, local: string): string | undefined {
  return attr(tag, '', local);
}
