import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { sniff } from './sniff';

function bytes(values: number[], padTo: number = 0): Uint8Array {
  const out = new Uint8Array(Math.max(values.length, padTo));
  out.set(values);
  return out;
}

const text = (value: string): Uint8Array => new TextEncoder().encode(value);

describe('sniff', () => {
  it('recognises zip, OLE2 and PDF', () => {
    assert.deepEqual(sniff(bytes([0x50, 0x4b, 0x03, 0x04, 0x14])), { kind: 'zip' });
    assert.deepEqual(sniff(bytes([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0])), { kind: 'ole2' });
    assert.deepEqual(sniff(text('%PDF-1.7\n')), { kind: 'pdf' });
    assert.deepEqual(sniff(text(`${' '.repeat(100)}%PDF-1.4`)), { kind: 'pdf' });
  });

  it('recognises each image type', () => {
    assert.deepEqual(sniff(bytes([0xff, 0xd8, 0xff, 0xe0])), { kind: 'image', contentType: 'image/jpeg' });
    assert.deepEqual(sniff(bytes([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), { kind: 'image', contentType: 'image/png' });
    assert.deepEqual(sniff(bytes([0x49, 0x49, 0x2a, 0x00])), { kind: 'image', contentType: 'image/tiff' });
    assert.deepEqual(sniff(bytes([0x4d, 0x4d, 0x00, 0x2a])), { kind: 'image', contentType: 'image/tiff' });
    assert.deepEqual(sniff(bytes([0x42, 0x4d], 26)), { kind: 'image', contentType: 'image/bmp' });
    const heif = new Uint8Array(12);
    heif.set(text('ftypheic'), 4);
    assert.deepEqual(sniff(heif), { kind: 'image', contentType: 'image/heif' });
  });

  it('returns unknown for empty, short, empty-zip and text input', () => {
    assert.deepEqual(sniff(new Uint8Array(0)), { kind: 'unknown' });
    assert.deepEqual(sniff(bytes([0x50, 0x4b])), { kind: 'unknown' });
    assert.deepEqual(sniff(bytes([0x50, 0x4b, 0x05, 0x06])), { kind: 'unknown' });
    assert.deepEqual(sniff(text('Plain notes, nothing else.')), { kind: 'unknown' });
    assert.deepEqual(sniff(text('BM')), { kind: 'unknown' });
  });
});
