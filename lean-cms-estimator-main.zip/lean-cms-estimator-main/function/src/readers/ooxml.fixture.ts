import { strToU8, zipSync, Zippable } from 'fflate';

const CT_NS = 'http://schemas.openxmlformats.org/package/2006/content-types';
const REL_NS = 'http://schemas.openxmlformats.org/package/2006/relationships';
const R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
export const W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
export const P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main';
export const A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main';
export const S_NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const REL_TYPE = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

export function zipOf(entries: Record<string, string | Uint8Array>): Uint8Array {
  const files: Zippable = {};
  for (const name of Object.keys(entries)) {
    const value = entries[name];
    files[name] = typeof value === 'string' ? strToU8(value) : value;
  }
  return zipSync(files);
}

function contentTypes(overrides: { part: string; type: string }[]): string {
  const items = overrides.map((item) => `<Override PartName="/${item.part}" ContentType="${item.type}"/>`).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="${CT_NS}"><Default Extension="xml" ContentType="application/xml"/>${items}</Types>`;
}

function relationships(items: { id: string; type: string; target: string; external?: boolean }[]): string {
  const rels = items.map((item) =>
    `<Relationship Id="${item.id}" Type="${REL_TYPE}/${item.type}" Target="${item.target}"${item.external ? ' TargetMode="External"' : ''}/>`
  ).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="${REL_NS}">${rels}</Relationships>`;
}

export function docxFixture(options: { body: string; styles?: string; numbering?: string; extra?: Record<string, string> }): Uint8Array {
  const entries: Record<string, string> = {
    '[Content_Types].xml': contentTypes([
      { part: 'word/document.xml', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml' }
    ]),
    'word/document.xml': `<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="${W_NS}" xmlns:r="${R_NS}"><w:body>${options.body}</w:body></w:document>`
  };
  if (options.styles) {
    entries['word/styles.xml'] = `<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="${W_NS}">${options.styles}</w:styles>`;
  }
  if (options.numbering) {
    entries['word/numbering.xml'] = `<?xml version="1.0" encoding="UTF-8"?><w:numbering xmlns:w="${W_NS}">${options.numbering}</w:numbering>`;
  }
  return zipOf({ ...entries, ...(options.extra ?? {}) });
}

export interface ISlideFixture {
  file: number;
  shapes: string;
  notes?: string;
}

export function pptxFixture(options: { slides: ISlideFixture[]; order: number[]; extra?: Record<string, string> }): Uint8Array {
  const entries: Record<string, string> = {
    '[Content_Types].xml': contentTypes([
      { part: 'ppt/presentation.xml', type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml' }
    ])
  };
  const ids = options.order.map((file, index) => `<p:sldId id="${256 + index}" r:id="rId${file}"/>`).join('');
  entries['ppt/presentation.xml'] = `<?xml version="1.0" encoding="UTF-8"?><p:presentation xmlns:p="${P_NS}" xmlns:r="${R_NS}"><p:sldIdLst>${ids}</p:sldIdLst></p:presentation>`;
  entries['ppt/_rels/presentation.xml.rels'] = relationships(
    options.slides.map((slide) => ({ id: `rId${slide.file}`, type: 'slide', target: `slides/slide${slide.file}.xml` }))
  );
  for (const slide of options.slides) {
    entries[`ppt/slides/slide${slide.file}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><p:sld xmlns:p="${P_NS}" xmlns:a="${A_NS}" xmlns:r="${R_NS}"><p:cSld><p:spTree>${slide.shapes}</p:spTree></p:cSld></p:sld>`;
    if (slide.notes !== undefined) {
      entries[`ppt/slides/_rels/slide${slide.file}.xml.rels`] = relationships([
        { id: 'rId1', type: 'notesSlide', target: `../notesSlides/notesSlide${slide.file}.xml` }
      ]);
      entries[`ppt/notesSlides/notesSlide${slide.file}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><p:notes xmlns:p="${P_NS}" xmlns:a="${A_NS}"><p:cSld><p:spTree>${shape(slide.notes, 'body')}${shape('3', 'sldNum')}</p:spTree></p:cSld></p:notes>`;
    }
  }
  return zipOf({ ...entries, ...(options.extra ?? {}) });
}

export function shape(text: string, placeholder?: string): string {
  const ph = placeholder ? `<p:ph type="${placeholder}"/>` : '';
  const paragraphs = text.split('\n').map((line) => `<a:p><a:r><a:t>${line}</a:t></a:r></a:p>`).join('');
  return `<p:sp><p:nvSpPr><p:cNvPr id="1" name="s"/><p:cNvSpPr/><p:nvPr>${ph}</p:nvPr></p:nvSpPr><p:txBody>${paragraphs}</p:txBody></p:sp>`;
}

export interface ISheetFixture {
  name: string;
  rows: string;
  chart?: boolean;
}

export function xlsxFixture(options: { sheets: ISheetFixture[]; sharedStrings?: string[]; sharedXml?: string }): Uint8Array {
  const entries: Record<string, string> = {
    '[Content_Types].xml': contentTypes([
      { part: 'xl/workbook.xml', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml' }
    ])
  };
  const sheets = options.sheets.map((sheet, index) =>
    `<sheet name="${sheet.name}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`
  ).join('');
  entries['xl/workbook.xml'] = `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="${S_NS}" xmlns:r="${R_NS}"><sheets>${sheets}</sheets></workbook>`;
  const rels = options.sheets.map((sheet, index) => ({
    id: `rId${index + 1}`,
    type: sheet.chart ? 'chartsheet' : 'worksheet',
    target: sheet.chart ? `chartsheets/sheet${index + 1}.xml` : `worksheets/sheet${index + 1}.xml`
  }));
  if (options.sharedStrings || options.sharedXml) {
    rels.push({ id: 'rIdS', type: 'sharedStrings', target: 'sharedStrings.xml' });
    const items = options.sharedXml ?? (options.sharedStrings ?? []).map((value) => `<si><t>${value}</t></si>`).join('');
    entries['xl/sharedStrings.xml'] = `<?xml version="1.0" encoding="UTF-8"?><sst xmlns="${S_NS}">${items}</sst>`;
  }
  entries['xl/_rels/workbook.xml.rels'] = relationships(rels);
  options.sheets.forEach((sheet, index) => {
    if (!sheet.chart) {
      entries[`xl/worksheets/sheet${index + 1}.xml`] = `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="${S_NS}"><sheetData>${sheet.rows}</sheetData></worksheet>`;
    }
  });
  return zipOf(entries);
}

export { REL_NS, CT_NS, R_NS, contentTypes, relationships };

export function patchDeclaredSize(zip: Uint8Array, name: string, size: number): Uint8Array {
  const out = zip.slice();
  const view = new DataView(out.buffer, out.byteOffset, out.byteLength);
  const target = new TextEncoder().encode(name);
  for (let offset = 0; offset + 46 <= out.length; offset++) {
    if (view.getUint32(offset, true) !== 0x02014b50) {
      continue;
    }
    const nameLength = view.getUint16(offset + 28, true);
    const found = out.subarray(offset + 46, offset + 46 + nameLength);
    if (found.length === target.length && found.every((byte, index) => byte === target[index])) {
      view.setUint32(offset + 24, size, true);
      return out;
    }
  }
  throw new Error(`entry ${name} not found`);
}

export function storedZipOf(entries: Record<string, Uint8Array | string>): Uint8Array {
  const files: Zippable = {};
  for (const name of Object.keys(entries)) {
    const value = entries[name];
    files[name] = [typeof value === 'string' ? strToU8(value) : value, { level: 0 }];
  }
  return zipSync(files);
}
