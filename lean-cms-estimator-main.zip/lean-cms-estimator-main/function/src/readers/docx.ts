import { IBlock, ISourceLocation } from '../blocks';
import { splitHeading } from '../citation';
import { IOoxmlPackage } from './ooxml';
import { createPassages } from './passages';
import { attr, is, NS, parseXml, XmlTag } from './xml';

export interface IReaderOutput {
  blocks: IBlock[];
  capped: boolean;
  missing: number;
}

interface IStyle {
  name: string;
  basedOn?: string;
  outlineLvl?: number;
  numId?: string;
  ilvl?: number;
}

interface ILevel {
  start: number;
  numFmt: string;
  lvlText: string;
}

interface INumbering {
  abstractOf: Map<string, string>;
  startOverrides: Map<string, Map<number, number>>;
  levels: Map<string, Map<number, ILevel>>;
}

interface IItem {
  text: string;
  page: number;
  heading?: string;
  section?: string;
}

const MAX_STYLE_DEPTH = 10;
const SKIPPED = [
  'del',
  'delText',
  'instrText',
  'txbxContent',
  'moveFrom',
  'pPrChange',
  'rPrChange',
  'sectPrChange',
  'numberingChange'
];
const MAX_LEVEL = 8;
const MAX_START = 32767;

function readLevel(value: string | undefined): number | undefined {
  const level = Number(value);
  return Number.isInteger(level) && level >= 0 && level <= MAX_LEVEL ? level : undefined;
}

function readStart(value: string | undefined): number {
  const start = Number(value);
  return Number.isInteger(start) && start >= 0 && start <= MAX_START ? start : 1;
}

function wAttr(tag: XmlTag, local: string): string | undefined {
  return attr(tag, NS.W, local);
}

function readStyles(text: string | undefined, checkBudget: () => void): Map<string, IStyle> {
  const styles = new Map<string, IStyle>();
  if (text === undefined) {
    return styles;
  }
  let current: { id: string; style: IStyle } | undefined;
  let inPPr = false;
  parseXml(text, {
    open(tag) {
      if (tag.uri !== NS.W) {
        return;
      }
      if (tag.local === 'style') {
        current = { id: wAttr(tag, 'styleId') ?? '', style: { name: '' } };
        return;
      }
      if (!current) {
        return;
      }
      if (tag.local === 'name') {
        current.style.name = wAttr(tag, 'val') ?? '';
      } else if (tag.local === 'basedOn') {
        current.style.basedOn = wAttr(tag, 'val');
      } else if (tag.local === 'pPr') {
        inPPr = true;
      } else if (inPPr && tag.local === 'outlineLvl') {
        current.style.outlineLvl = readLevel(wAttr(tag, 'val'));
      } else if (inPPr && tag.local === 'numId') {
        current.style.numId = wAttr(tag, 'val');
      } else if (inPPr && tag.local === 'ilvl') {
        current.style.ilvl = readLevel(wAttr(tag, 'val'));
      }
    },
    close(tag) {
      if (is(tag, NS.W, 'pPr')) {
        inPPr = false;
      } else if (is(tag, NS.W, 'style') && current) {
        if (current.id.length > 0) {
          styles.set(current.id, current.style);
        }
        current = undefined;
      }
    }
  }, checkBudget);
  return styles;
}

function readNumbering(text: string | undefined, checkBudget: () => void): INumbering {
  const numbering: INumbering = { abstractOf: new Map(), startOverrides: new Map(), levels: new Map() };
  if (text === undefined) {
    return numbering;
  }
  let abstractId: string | undefined;
  let numId: string | undefined;
  let level: { ilvl: number; value: ILevel } | undefined;
  let overrideLevel: number | undefined;
  parseXml(text, {
    open(tag) {
      if (tag.uri !== NS.W) {
        return;
      }
      if (tag.local === 'abstractNum') {
        abstractId = wAttr(tag, 'abstractNumId');
        if (abstractId !== undefined) {
          numbering.levels.set(abstractId, new Map());
        }
      } else if (tag.local === 'num') {
        numId = wAttr(tag, 'numId');
      } else if (tag.local === 'lvl' && abstractId !== undefined && numId === undefined) {
        const ilvl = readLevel(wAttr(tag, 'ilvl') ?? '0');
        level = ilvl === undefined ? undefined : { ilvl, value: { start: 1, numFmt: 'decimal', lvlText: '' } };
      } else if (level && tag.local === 'start') {
        level.value.start = readStart(wAttr(tag, 'val'));
      } else if (level && tag.local === 'numFmt') {
        level.value.numFmt = wAttr(tag, 'val') ?? 'decimal';
      } else if (level && tag.local === 'lvlText') {
        level.value.lvlText = wAttr(tag, 'val') ?? '';
      } else if (numId !== undefined && tag.local === 'abstractNumId') {
        numbering.abstractOf.set(numId, wAttr(tag, 'val') ?? '');
      } else if (numId !== undefined && tag.local === 'lvlOverride') {
        overrideLevel = readLevel(wAttr(tag, 'ilvl') ?? '0');
      } else if (numId !== undefined && overrideLevel !== undefined && tag.local === 'startOverride') {
        const overrides = numbering.startOverrides.get(numId) ?? new Map<number, number>();
        overrides.set(overrideLevel, readStart(wAttr(tag, 'val')));
        numbering.startOverrides.set(numId, overrides);
      }
    },
    close(tag) {
      if (tag.uri !== NS.W) {
        return;
      }
      if (tag.local === 'lvl' && level && abstractId !== undefined) {
        numbering.levels.get(abstractId)?.set(level.ilvl, level.value);
        level = undefined;
      } else if (tag.local === 'abstractNum') {
        abstractId = undefined;
      } else if (tag.local === 'num') {
        numId = undefined;
      } else if (tag.local === 'lvlOverride') {
        overrideLevel = undefined;
      }
    }
  }, checkBudget);
  return numbering;
}

function roman(value: number): string {
  const table: [number, string][] = [
    [1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'],
    [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']
  ];
  let rest = value;
  let out = '';
  for (const [amount, symbol] of table) {
    while (rest >= amount) {
      out += symbol;
      rest -= amount;
    }
  }
  return out;
}

function letters(value: number): string {
  let rest = value;
  let out = '';
  while (rest > 0) {
    const index = (rest - 1) % 26;
    out = String.fromCharCode(65 + index) + out;
    rest = Math.floor((rest - 1) / 26);
  }
  return out;
}

export function formatNumber(value: number, numFmt: string): string {
  if (numFmt === 'upperRoman') {
    return roman(value);
  }
  if (numFmt === 'lowerRoman') {
    return roman(value).toLowerCase();
  }
  if (numFmt === 'upperLetter') {
    return letters(value);
  }
  if (numFmt === 'lowerLetter') {
    return letters(value).toLowerCase();
  }
  return String(value);
}

function createCounter(numbering: INumbering): (numId: string, ilvl: number) => string | undefined {
  const counters = new Map<string, (number | undefined)[]>();
  const seen = new Set<string>();
  return (numId, ilvl) => {
    const abstractId = numbering.abstractOf.get(numId);
    if (abstractId === undefined) {
      return undefined;
    }
    const levels = numbering.levels.get(abstractId);
    if (!levels) {
      return undefined;
    }
    const startOf = (level: number): number =>
      numbering.startOverrides.get(numId)?.get(level) ?? levels.get(level)?.start ?? 1;
    const values = counters.get(abstractId) ?? [];
    const overrides = numbering.startOverrides.get(numId);
    if (!seen.has(numId)) {
      seen.add(numId);
      if (overrides && overrides.size > 0) {
        const first = Math.min(...Array.from(overrides.keys()));
        for (let restart = first; restart < values.length; restart++) {
          values[restart] = undefined;
        }
      }
    }
    const currentValue = values[ilvl];
    values[ilvl] = currentValue === undefined ? startOf(ilvl) : currentValue + 1;
    for (let deeper = ilvl + 1; deeper < values.length; deeper++) {
      values[deeper] = undefined;
    }
    counters.set(abstractId, values);
    const own = levels.get(ilvl);
    if (!own || own.numFmt === 'bullet' || own.numFmt === 'none') {
      return undefined;
    }
    const rendered = own.lvlText.replace(/%([1-9])/g, (_match, digit: string) => {
      const level = Number(digit) - 1;
      const value = values[level] ?? startOf(level);
      return formatNumber(value, levels.get(level)?.numFmt ?? 'decimal');
    });
    const section = rendered.trim().replace(/[.)]+$/, '');
    return section.length > 0 ? section : undefined;
  };
}

function headingLevel(styles: Map<string, IStyle>, styleId: string | undefined): number | undefined {
  const visited = new Set<string>();
  let id = styleId;
  for (let depth = 0; id !== undefined && depth < MAX_STYLE_DEPTH && !visited.has(id); depth++) {
    visited.add(id);
    const style = styles.get(id);
    if (!style) {
      return undefined;
    }
    if (style.outlineLvl !== undefined && style.outlineLvl >= 0 && style.outlineLvl <= 8) {
      return style.outlineLvl + 1;
    }
    const match = /^heading\s+([1-9])$/i.exec(style.name.trim());
    if (match) {
      return Number(match[1]);
    }
    if (style.name.trim().toLowerCase() === 'title') {
      return 0;
    }
    id = style.basedOn;
  }
  return undefined;
}

function styleNumbering(styles: Map<string, IStyle>, styleId: string | undefined): { numId: string; ilvl: number } | undefined {
  const visited = new Set<string>();
  let id = styleId;
  for (let depth = 0; id !== undefined && depth < MAX_STYLE_DEPTH && !visited.has(id); depth++) {
    visited.add(id);
    const style = styles.get(id);
    if (!style) {
      return undefined;
    }
    if (style.numId !== undefined) {
      return { numId: style.numId, ilvl: style.ilvl ?? 0 };
    }
    id = style.basedOn;
  }
  return undefined;
}

interface IParagraph {
  text: string;
  styleId?: string;
  outlineLvl?: number;
  numId?: string;
  ilvl?: number;
  page?: number;
}

export function readDocx(
  pkg: IOoxmlPackage,
  main: string,
  fileName: string,
  itemId: string,
  checkBudget: () => void
): IReaderOutput {
  const dir = main.indexOf('/') === -1 ? '' : `${main.slice(0, main.lastIndexOf('/'))}/`;
  const styles = readStyles(pkg.xml(`${dir}styles.xml`), checkBudget);
  const numbering = readNumbering(pkg.xml(`${dir}numbering.xml`), checkBudget);
  const count = createCounter(numbering);
  const document = pkg.xml(main) ?? '';
  const renderedMode = document.indexOf('lastRenderedPageBreak') !== -1;

  const items: IItem[] = [];
  let heading: string | undefined;
  let section: string | undefined;
  let sectionLevel: number | undefined;
  let page = 1;
  let markers = false;
  let skipDepth = 0;
  let inPPr = false;
  let inT = false;
  let paragraph: IParagraph | undefined;
  const cellStack: string[] = [];
  const rowStack: string[][] = [];

  const pageBreak = (): void => {
    page++;
    markers = true;
  };

  const finishParagraph = (current: IParagraph): void => {
    const text = current.text.replace(/[ \t]+/g, ' ').trim();
    if (cellStack.length > 0) {
      if (text.length > 0) {
        const top = cellStack.length - 1;
        cellStack[top] = cellStack[top].length > 0 ? `${cellStack[top]} ${text}` : text;
      }
      return;
    }
    const own = current.numId !== undefined
      ? { numId: current.numId, ilvl: current.ilvl ?? 0 }
      : styleNumbering(styles, current.styleId);
    const numbered = own && own.numId !== '0' ? count(own.numId, own.ilvl) : undefined;
    const level = current.outlineLvl !== undefined && current.outlineLvl >= 0 && current.outlineLvl <= 8
      ? current.outlineLvl + 1
      : headingLevel(styles, current.styleId);
    if (level !== undefined && text.length > 0) {
      const split = numbered !== undefined ? { section: numbered, heading: text } : splitHeading(text);
      heading = split.heading;
      if (split.section !== undefined) {
        section = split.section;
        sectionLevel = level;
      } else if (sectionLevel === undefined || level <= sectionLevel) {
        section = undefined;
        sectionLevel = undefined;
      }
      const line = split.section !== undefined ? `${split.section} ${split.heading}` : split.heading;
      items.push({ text: line, page: current.page ?? page, heading, section });
      return;
    }
    if (text.length > 0) {
      items.push({ text, page: current.page ?? page, heading, section });
    }
  };

  parseXml(document, {
    open(tag) {
      if (skipDepth > 0) {
        skipDepth++;
        return;
      }
      if ((tag.uri === NS.W && SKIPPED.indexOf(tag.local) !== -1) || is(tag, NS.MC, 'Fallback')) {
        skipDepth = 1;
        return;
      }
      if (tag.uri !== NS.W) {
        return;
      }
      switch (tag.local) {
        case 'p':
          paragraph = { text: '' };
          return;
        case 'pPr':
          inPPr = true;
          return;
        case 'pStyle':
          if (inPPr && paragraph) {
            paragraph.styleId = wAttr(tag, 'val');
          }
          return;
        case 'outlineLvl':
          if (inPPr && paragraph) {
            paragraph.outlineLvl = readLevel(wAttr(tag, 'val'));
          }
          return;
        case 'numId':
          if (inPPr && paragraph) {
            paragraph.numId = wAttr(tag, 'val');
          }
          return;
        case 'ilvl':
          if (inPPr && paragraph) {
            paragraph.ilvl = readLevel(wAttr(tag, 'val'));
          }
          return;
        case 'pageBreakBefore':
          if (inPPr && paragraph && !renderedMode && wAttr(tag, 'val') !== '0' && wAttr(tag, 'val') !== 'false') {
            pageBreak();
          }
          return;
        case 't':
          inT = true;
          return;
        case 'tab':
          if (paragraph && !inPPr) {
            paragraph.text += ' ';
          }
          return;
        case 'br':
          if (wAttr(tag, 'type') === 'page') {
            if (!renderedMode) {
              pageBreak();
            }
          } else if (paragraph) {
            paragraph.text += '\n';
          }
          return;
        case 'cr':
          if (paragraph) {
            paragraph.text += '\n';
          }
          return;
        case 'lastRenderedPageBreak':
          if (renderedMode) {
            pageBreak();
          }
          return;
        case 'tr':
          rowStack.push([]);
          return;
        case 'tc':
          cellStack.push('');
          return;
        default:
          return;
      }
    },
    close(tag) {
      if (skipDepth > 0) {
        skipDepth--;
        return;
      }
      if (tag.uri !== NS.W) {
        return;
      }
      switch (tag.local) {
        case 'pPr':
          inPPr = false;
          return;
        case 't':
          inT = false;
          return;
        case 'p':
          if (paragraph) {
            finishParagraph(paragraph);
          }
          paragraph = undefined;
          return;
        case 'tc': {
          const cell = cellStack.pop() ?? '';
          if (cellStack.length > 0) {
            const top = cellStack.length - 1;
            cellStack[top] = cell.length > 0 ? (cellStack[top].length > 0 ? `${cellStack[top]} ${cell}` : cell) : cellStack[top];
          } else if (rowStack.length > 0) {
            rowStack[rowStack.length - 1].push(cell);
          }
          return;
        }
        case 'tr': {
          const cells = rowStack.pop() ?? [];
          if (cellStack.length === 0 && cells.some((cell) => cell.length > 0)) {
            items.push({ text: cells.join(' | '), page, heading, section });
          }
          return;
        }
        default:
          return;
      }
    },
    text(value) {
      if (skipDepth === 0 && inT && paragraph) {
        if (paragraph.page === undefined && value.trim().length > 0) {
          paragraph.page = page;
        }
        paragraph.text += value;
      }
    }
  }, checkBudget);

  const passages = createPassages(fileName, itemId);
  for (const item of items) {
    const location: ISourceLocation = { kind: 'section' };
    if (markers) {
      location.page = item.page;
      location.pageApprox = true;
    }
    if (item.section !== undefined) {
      location.section = item.section;
    }
    if (item.heading !== undefined) {
      location.heading = item.heading;
    }
    passages.add(location, 'w', item.text);
  }
  const blocks = passages.blocks();
  return { blocks, capped: passages.capped, missing: 0 };
}
