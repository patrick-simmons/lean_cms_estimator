import { IBlock, ISourceLocation, MAX_PASSAGE_CHARS, MAX_TEXT_CHARS } from '../blocks';
import { blockId, citationLabel } from '../citation';

export interface IPassages {
  add(location: ISourceLocation, family: string, text: string): void;
  addRows(location: ISourceLocation, family: string, header: string | undefined, rows: string[], headerFirst?: boolean): void;
  flush(): void;
  readonly capped: boolean;
  blocks(): IBlock[];
}

interface IOpenGroup {
  location: ISourceLocation;
  family: string;
  text: string;
}

const LOCATION_KEYS = ['kind', 'page', 'pageApprox', 'section', 'heading', 'slide', 'notes', 'sheet'];

function sameLocation(a: ISourceLocation, b: ISourceLocation): boolean {
  const left = a as unknown as Record<string, unknown>;
  const right = b as unknown as Record<string, unknown>;
  return LOCATION_KEYS.every((key) => left[key] === right[key]);
}

export function splitLong(text: string, max: number = MAX_PASSAGE_CHARS): string[] {
  const pieces: string[] = [];
  let rest = text;
  while (rest.length > max) {
    const window = rest.slice(0, max + 1);
    let cut = Math.max(window.lastIndexOf(' '), window.lastIndexOf('\n'));
    if (cut <= 0) {
      cut = max;
    }
    pieces.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  if (rest.length > 0) {
    pieces.push(rest);
  }
  return pieces.filter((piece) => piece.length > 0);
}

export function createPassages(fileName: string, itemId: string): IPassages {
  const output: IBlock[] = [];
  const counters = new Map<string, number>();
  let open: IOpenGroup | undefined;
  let total = 0;
  let capped = false;

  const emit = (location: ISourceLocation, family: string, text: string): void => {
    if (capped) {
      return;
    }
    if (total + text.length > MAX_TEXT_CHARS) {
      capped = true;
      return;
    }
    const next = (counters.get(family) ?? 0) + 1;
    counters.set(family, next);
    total += text.length;
    output.push({
      id: blockId(itemId, `${family}${next}`),
      fileName,
      itemId,
      label: citationLabel(fileName, location),
      location: { ...location },
      text
    });
  };

  const flush = (): void => {
    if (open) {
      emit(open.location, open.family, open.text);
      open = undefined;
    }
  };

  return {
    add(location, family, text): void {
      const value = text.trim();
      if (value.length === 0 || capped) {
        return;
      }
      if (
        open &&
        open.family === family &&
        sameLocation(open.location, location) &&
        open.text.length + 1 + value.length <= MAX_PASSAGE_CHARS
      ) {
        open.text = `${open.text}\n${value}`;
        return;
      }
      flush();
      const pieces = splitLong(value);
      for (let index = 0; index < pieces.length - 1; index++) {
        emit(location, family, pieces[index]);
      }
      if (pieces.length > 0) {
        open = { location, family, text: pieces[pieces.length - 1] };
      }
    },
    addRows(location, family, header, rows, headerFirst = false): void {
      flush();
      const lines = rows.map((row) => row.trim()).filter((row) => row.length > 0);
      if (lines.length === 0) {
        return;
      }
      let group: string[] = [];
      let size = 0;
      let groups = 0;
      const prefix = header && header.trim().length > 0 ? header.trim() : undefined;
      const close = (): void => {
        if (group.length > 0) {
          const withHeader = prefix !== undefined && (headerFirst || groups > 0);
          const text = (withHeader && prefix !== undefined ? [prefix] : []).concat(group).join('\n');
          splitLong(text).forEach((piece) => emit(location, family, piece));
          groups++;
        }
        group = [];
        size = 0;
      };
      lines.forEach((line) => {
        if (group.length > 0 && size + 1 + line.length > MAX_PASSAGE_CHARS) {
          close();
        }
        group.push(line);
        size += line.length + 1;
      });
      close();
    },
    flush,
    get capped(): boolean {
      return capped;
    },
    blocks(): IBlock[] {
      flush();
      return output;
    }
  };
}
