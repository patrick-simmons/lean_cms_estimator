import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { contentTypes, ISheetFixture, R_NS, relationships, S_NS, xlsxFixture, zipOf } from './ooxml.fixture';
import { openOoxml } from './ooxml';
import { readXlsx } from './xlsx';

function read(sheets: ISheetFixture[], options: { sharedStrings?: string[]; sharedXml?: string } = {}): ReturnType<typeof readXlsx> {
  const opened = openOoxml(xlsxFixture({ sheets, ...options }), () => undefined);
  if (opened.kind !== 'xlsx') {
    throw new Error('not xlsx');
  }
  return readXlsx(opened.package, opened.main, 'Inventory.xlsx', 'item-4', () => undefined);
}

function row(number: number, cells: string[]): string {
  const letters = 'ABCDEFGH';
  return `<row r="${number}">${cells.map((cell, index) => `<c r="${letters[index]}${number}" t="inlineStr"><is><t>${cell}</t></is></c>`).join('')}</row>`;
}

describe('readXlsx', () => {
  it('reads sheets in workbook order and labels rows', () => {
    const { blocks } = read([
      { name: 'Inventory', rows: row(1, ['Page', 'Count']) + row(2, ['Home', '1']) },
      { name: 'Notes', rows: row(1, ['Free text']) }
    ]);
    assert.equal(blocks.length, 2);
    assert.equal(blocks[0].label, 'Inventory Inventory rows 1\u20132');
    assert.equal(blocks[0].text, '1: Page | Count\n2: Home | 1');
    assert.deepEqual(blocks[0].location, { kind: 'sheet', sheet: 'Inventory', rowStart: 1, rowEnd: 2 });
    assert.equal(blocks[1].label, 'Inventory Notes row 1');
    assert.equal(blocks.every((block) => block.location.page === undefined), true);
  });

  it('renders every cell type', () => {
    const cells = [
      '<c r="A1" t="s"><v>0</v></c>',
      '<c r="B1" t="inlineStr"><is><r><t>rich </t></r><r><t>text</t></r></is></c>',
      '<c r="C1" t="str"><v>formula</v></c>',
      '<c r="D1" t="b"><v>1</v></c>',
      '<c r="E1" t="e"><v>#N/A</v></c>',
      '<c r="F1"><v>45678</v></c>'
    ].join('');
    const { blocks } = read([{ name: 'S', rows: `<row r="1">${cells}</row>` }], { sharedStrings: ['shared'] });
    assert.equal(blocks[0].text, '1: shared | rich text | formula | TRUE | #N/A | 45678');
  });

  it('infers positions when rows and cells have no reference, and skips phonetic runs', () => {
    const rows = '<row><c t="s"><v>0</v></c><c><v>2</v></c></row><row><c><v>3</v></c></row>';
    const sharedXml = '<si><t>Base</t><rPh><t>ruby</t></rPh></si>';
    const { blocks } = read([{ name: 'S', rows }], { sharedXml });
    assert.equal(blocks[0].text, '1: Base | 2\n2: 3');
  });

  it('groups 20 rows per block and repeats the header', () => {
    let rows = row(1, ['Page', 'Template']);
    for (let index = 2; index <= 31; index++) {
      rows += row(index, [`Page ${index}`, 'Detail']);
    }
    const { blocks } = read([{ name: 'Inventory', rows }]);
    assert.equal(blocks.length, 2);
    assert.equal(blocks[0].location.rowStart, 1);
    assert.equal(blocks[0].location.rowEnd, 20);
    assert.equal(blocks[1].location.rowStart, 21);
    assert.equal(blocks[1].location.rowEnd, 31);
    assert.equal(blocks[1].text.startsWith('Header: Page | Template\n21: Page 21 | Detail'), true);
    assert.equal(blocks[1].id, 'item-4#x1.r21.1');
  });

  it('skips chart sheets', () => {
    const { blocks } = read([
      { name: 'Chart', rows: '', chart: true },
      { name: 'Data', rows: row(1, ['Value']) }
    ]);
    assert.equal(blocks.length, 1);
    assert.equal(blocks[0].location.sheet, 'Data');
  });

  it('ignores column references past XFD and rows past the sheet limit', () => {
    const rows = '<row r="1"><c r="A1"><v>1</v></c><c r="FXSHRXW1"><v>2</v></c><c r="XFE1"><v>3</v></c></row>' +
      '<row r="2000000"><c r="A2000000"><v>4</v></c></row>';
    const { blocks } = read([{ name: 'S', rows }]);
    assert.equal(blocks.length, 1);
    assert.equal(blocks[0].text, '1: 1');
  });

  it('finds shared strings through the workbook relationship', () => {
    const opened = openOoxml(zipOf({
      '[Content_Types].xml': contentTypes([{ part: 'xl/workbook.xml', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml' }]),
      'xl/workbook.xml': `<workbook xmlns="${S_NS}" xmlns:r="${R_NS}"><sheets><sheet name="S" sheetId="1" r:id="rId1"/></sheets></workbook>`,
      'xl/_rels/workbook.xml.rels': relationships([
        { id: 'rId1', type: 'worksheet', target: 'worksheets/data.xml' },
        { id: 'rId2', type: 'sharedStrings', target: '/xl/strings.xml' }
      ]),
      'xl/worksheets/data.xml': `<worksheet xmlns="${S_NS}"><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c></row></sheetData></worksheet>`,
      'xl/strings.xml': `<sst xmlns="${S_NS}"><si><t>Renamed part</t></si></sst>`
    }), () => undefined);
    if (opened.kind !== 'xlsx') {
      throw new Error('not xlsx');
    }
    const { blocks, missing } = readXlsx(opened.package, opened.main, 'Inventory.xlsx', 'item-4', () => undefined);
    assert.equal(blocks[0].text, '1: Renamed part');
    assert.equal(missing, 0);
  });

  it('counts a sheet whose part is missing', () => {
    const opened = openOoxml(zipOf({
      '[Content_Types].xml': contentTypes([{ part: 'xl/workbook.xml', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml' }]),
      'xl/workbook.xml': `<workbook xmlns="${S_NS}" xmlns:r="${R_NS}"><sheets><sheet name="Gone" sheetId="1" r:id="rId1"/></sheets></workbook>`,
      'xl/_rels/workbook.xml.rels': relationships([{ id: 'rId1', type: 'worksheet', target: 'worksheets/sheet1.xml' }])
    }), () => undefined);
    if (opened.kind !== 'xlsx') {
      throw new Error('not xlsx');
    }
    assert.equal(readXlsx(opened.package, opened.main, 'Inventory.xlsx', 'item-4', () => undefined).missing, 1);
  });
});
