/**
 * Entry point for code that parses documents outside the Azure function, such as
 * tools/blueprint/parse-local.mjs. Everything exported here is pure: no HTTP, no tokens,
 * no Document Intelligence. The function's own parse path (parse.ts) uses the same modules,
 * so the two stay in step by construction rather than by copy.
 */
export * from './blocks';
export { baseName, blockId, citationLabel, splitHeading } from './citation';
export { readOffice } from './readers/office';
export type { IOfficeRead, OfficeFormat } from './readers/office';
export { createPassages, splitLong } from './readers/passages';
export type { IPassages } from './readers/passages';
export { clampRange, countPdfPages, PAGE_BATCH } from './readers/pdfPages';
export { sniff } from './readers/sniff';
export type { SniffResult } from './readers/sniff';
export { UnsafeContentError } from './readers/xml';
